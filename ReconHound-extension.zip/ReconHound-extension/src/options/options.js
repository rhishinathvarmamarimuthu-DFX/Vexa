// ReconHound — Settings controller

const DEFAULTS = {
  nvdApiKey: "",
  enableCves: true,
  enableSecurity: true,
  enableSecrets: true,
  enableBadge: true,
  globalAuth: false,
  enableActiveDeep: true,
  enableBypass40x: true,
  bypassDiagnostic: true,
  enableAutoBypass: true,
  customSecretRules: []
};

async function load() {
  const cfg = await chrome.storage.local.get(DEFAULTS);
  document.getElementById("nvdKey").value = cfg.nvdApiKey || "";
  document.getElementById("enableCves").checked = cfg.enableCves;
  document.getElementById("enableSecurity").checked = cfg.enableSecurity;
  document.getElementById("enableSecrets").checked = cfg.enableSecrets;
  document.getElementById("enableBadge").checked = cfg.enableBadge;
  document.getElementById("globalAuth").checked = !!cfg.globalAuth;
  document.getElementById("enableActiveDeep").checked = cfg.enableActiveDeep !== false;
  document.getElementById("enableBypass40x").checked = cfg.enableBypass40x !== false;
  document.getElementById("bypassDiagnostic").checked = cfg.bypassDiagnostic !== false;
  document.getElementById("enableAutoBypass").checked = cfg.enableAutoBypass !== false;
  document.getElementById("customRules").value = rulesToText(cfg.customSecretRules || []);
}

async function save() {
  await chrome.storage.local.set({
    nvdApiKey: document.getElementById("nvdKey").value.trim(),
    enableCves: document.getElementById("enableCves").checked,
    enableSecurity: document.getElementById("enableSecurity").checked,
    enableSecrets: document.getElementById("enableSecrets").checked,
    enableBadge: document.getElementById("enableBadge").checked,
    globalAuth: document.getElementById("globalAuth").checked,
    enableActiveDeep: document.getElementById("enableActiveDeep").checked,
    enableBypass40x: document.getElementById("enableBypass40x").checked,
    bypassDiagnostic: document.getElementById("bypassDiagnostic").checked,
    enableAutoBypass: document.getElementById("enableAutoBypass").checked,
    customSecretRules: textToRules(document.getElementById("customRules").value)
  });
  flash("✓ Saved");
}

// "Name | SEVERITY | regex" per line  <->  rule objects
function textToRules(text) {
  return (text || "")
    .split("\n")
    .map((line) => line.trim())
    .filter(Boolean)
    .map((line) => {
      const parts = line.split("|").map((p) => p.trim());
      if (parts.length < 3) return null;
      const [title, severity, ...rest] = parts;
      return { title, severity: severity.toUpperCase(), pattern: rest.join("|") };
    })
    .filter((r) => r && r.pattern);
}

function rulesToText(rules) {
  return rules.map((r) => `${r.title} | ${r.severity} | ${r.pattern}`).join("\n");
}

function flash(msg) {
  const status = document.getElementById("status");
  status.textContent = msg;
  setTimeout(() => (status.textContent = ""), 1800);
}

document.getElementById("save").addEventListener("click", save);
document.getElementById("clearHistory").addEventListener("click", () => {
  chrome.runtime.sendMessage({ type: "RH_CLEAR_HISTORY" }, () => flash("✓ History cleared"));
});
load();

