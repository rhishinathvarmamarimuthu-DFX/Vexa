// ReconHound — Exposure checker
// Confirms exposure of VCS metadata and env/config files by validating the
// RESPONSE CONTENT, not just the HTTP status — so results are real, not soft
// 404s dressed as 200s.

const CHECKS = [
  {
    id: "git-config",
    path: "/.git/config",
    name: "Exposed .git/config",
    severity: "HIGH",
    verify: (t) => /\[core\]/i.test(t) || /\[remote/i.test(t),
    note: "Git repository config is publicly readable — repo & remote URLs leak."
  },
  {
    id: "git-head",
    path: "/.git/HEAD",
    name: "Exposed .git/HEAD",
    severity: "HIGH",
    verify: (t) => /^ref:\s+refs\//im.test(t) || /^[0-9a-f]{40}$/im.test(t.trim()),
    note: "Git HEAD readable — full source history may be reconstructable."
  },
  {
    id: "env",
    path: "/.env",
    name: "Exposed .env file",
    severity: "CRITICAL",
    verify: (t) => /^[A-Z0-9_]+\s*=/m.test(t) && !/<html/i.test(t),
    note: "Environment file readable — likely secrets/credentials disclosure."
  },
  {
    id: "svn",
    path: "/.svn/entries",
    name: "Exposed .svn/entries",
    severity: "HIGH",
    verify: (t) => /^\d+\s*$/m.test(t) || /svn/i.test(t),
    note: "Subversion metadata readable — source disclosure."
  },
  {
    id: "ds-store",
    path: "/.DS_Store",
    name: "Exposed .DS_Store",
    severity: "MEDIUM",
    verify: (t) => t.includes("Bud1") || /\x00\x00\x00\x01Bud1/.test(t),
    note: "macOS directory index readable — reveals hidden filenames."
  },
  {
    id: "htaccess",
    path: "/.htaccess",
    name: "Exposed .htaccess",
    severity: "MEDIUM",
    verify: (t) => /RewriteEngine|Order allow|Require /i.test(t),
    note: "Apache access rules readable — server config disclosure."
  },
  {
    id: "ssh-key",
    path: "/.ssh/id_rsa",
    name: "Exposed SSH private key",
    severity: "CRITICAL",
    verify: (t) => /BEGIN (?:RSA |OPENSSH )?PRIVATE KEY/.test(t),
    note: "Private SSH key readable — full host compromise risk."
  },
  {
    id: "wp-config-bak",
    path: "/wp-config.php.bak",
    name: "Exposed wp-config backup",
    severity: "CRITICAL",
    verify: (t) => /DB_PASSWORD|DB_USER/i.test(t),
    note: "WordPress DB credentials readable."
  }
];

async function fetchText(url, timeoutMs = 6000) {
  const controller = new AbortController();
  const t = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const res = await fetch(url, { method: "GET", redirect: "follow", credentials: "omit", signal: controller.signal });
    clearTimeout(t);
    if (res.status >= 400) return null;
    const ctype = res.headers.get("content-type") || "";
    const text = await res.text();
    // Reject obvious HTML soft-404 pages for non-HTML paths.
    const sample = text.slice(0, 8192);
    if (/text\/html/i.test(ctype) && /<html|<!doctype/i.test(sample.slice(0, 512))) return null;
    return sample;
  } catch (_) {
    clearTimeout(t);
    return null;
  }
}

export async function checkExposures(origin) {
  const base = origin.replace(/\/$/, "");
  const results = [];

  await Promise.all(
    CHECKS.map(async (c) => {
      const url = base + c.path;
      const text = await fetchText(url);
      if (text != null && c.verify(text)) {
        results.push({
          id: c.id,
          title: c.name,
          severity: c.severity,
          url,
          detail: c.note,
          verified: true
        });
      }
    })
  );

  const weight = { CRITICAL: 4, HIGH: 3, MEDIUM: 2, LOW: 1 };
  return results.sort((a, b) => (weight[b.severity] || 0) - (weight[a.severity] || 0));
}

