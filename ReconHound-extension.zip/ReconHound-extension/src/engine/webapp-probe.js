// ReconHound — Generic web-app safe verification probes (ACTIVE)
// Focuses on framework/infra exposures that leak secrets or admin surface:
//   Spring Boot Actuator, PHP info, Tomcat/JBoss consoles, Laravel debug,
//   Django/Rails debug, Node.js debug, exposed backups & config files,
//   API docs (Swagger/OpenAPI), Docker/K8s metadata, common admin dashboards.
// All probes are non-destructive GET/HEAD requests.

async function get(url, opts = {}, timeoutMs = 6000) {
  const controller = new AbortController();
  const t = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const res = await fetch(url, { credentials: "omit", redirect: "follow", signal: controller.signal, ...opts });
    clearTimeout(t);
    const text = (await res.text()).slice(0, 65536);
    return { status: res.status, text, ctype: res.headers.get("content-type") || "", url: res.url };
  } catch (_) {
    clearTimeout(t);
    return null;
  }
}

// Each probe: { path, id, title, severity, verify(text, res) → bool, note }
const PROBES = [
  // ── Spring Boot Actuator ────────────────────────────────────────────────
  { path: "/actuator", id: "actuator-index",
    title: "Spring Boot Actuator index exposed", severity: "HIGH",
    verify: (t) => /"_links"/.test(t) && /health|info|env|metrics/.test(t),
    note: "Actuator index lists all reachable management endpoints." },
  { path: "/actuator/env", id: "actuator-env",
    title: "Spring Actuator /env exposed (secrets disclosure)", severity: "CRITICAL",
    verify: (t) => /"activeProfiles"|"propertySources"/.test(t),
    note: "/env can disclose DB passwords, API keys, encryption secrets." },
  { path: "/actuator/heapdump", id: "actuator-heapdump",
    title: "Spring Actuator /heapdump exposed", severity: "CRITICAL",
    verify: (_, res) => res && /application\/octet-stream|hprof/i.test(res.ctype || ""),
    note: "Heap dump download — full process memory including credentials." },
  { path: "/actuator/mappings", id: "actuator-mappings",
    title: "Spring Actuator /mappings exposed", severity: "MEDIUM",
    verify: (t) => /"contexts"|"handler"|"predicate"/.test(t),
    note: "Full internal route table disclosed." },
  { path: "/actuator/threaddump", id: "actuator-threaddump",
    title: "Spring Actuator /threaddump exposed", severity: "HIGH",
    verify: (t) => /"threads"\s*:/.test(t),
    note: "Live thread dump — internal state, sometimes secrets." },
  { path: "/actuator/loggers", id: "actuator-loggers",
    title: "Spring Actuator /loggers exposed", severity: "MEDIUM",
    verify: (t) => /"configuredLevel"|"effectiveLevel"/.test(t),
    note: "Log configuration modifiable if not read-only." },
  { path: "/actuator/gateway/routes", id: "actuator-gateway",
    title: "Spring Cloud Gateway routes exposed", severity: "HIGH",
    verify: (t) => /"route_id"|"predicate"/.test(t),
    note: "Full gateway routing table disclosed — internal-service map." },
  { path: "/env", id: "actuator-env-legacy",
    title: "Spring Boot 1.x /env exposed", severity: "CRITICAL",
    verify: (t) => /"applicationConfig"|"systemProperties"|"configService"/.test(t),
    note: "Legacy Actuator /env — same secrets disclosure risk." },

  // ── PHP info leak ───────────────────────────────────────────────────────
  { path: "/phpinfo.php", id: "phpinfo",
    title: "phpinfo() exposed", severity: "HIGH",
    verify: (t) => /<title>phpinfo\(\)/i.test(t) || /PHP Version/i.test(t),
    note: "Full PHP configuration + env vars disclosed." },
  { path: "/info.php", id: "phpinfo-alt",
    title: "phpinfo() exposed (alternate path)", severity: "HIGH",
    verify: (t) => /<title>phpinfo\(\)/i.test(t) || /PHP Version/i.test(t),
    note: "Full PHP configuration + env vars disclosed." },
  { path: "/test.php", id: "phpinfo-test",
    title: "PHP test page exposed", severity: "MEDIUM",
    verify: (t) => /<title>phpinfo\(\)/i.test(t),
    note: "PHP debug page reachable." },

  // ── Java servlet containers ─────────────────────────────────────────────
  { path: "/manager/html", id: "tomcat-manager",
    title: "Tomcat Manager reachable", severity: "HIGH",
    verify: (t) => /Tomcat Web Application Manager/i.test(t) || /HTTP Status 401|Unauthorized/i.test(t),
    note: "Tomcat admin console reachable — check for weak/default credentials." },
  { path: "/host-manager/html", id: "tomcat-host-manager",
    title: "Tomcat Host Manager reachable", severity: "HIGH",
    verify: (t) => /Tomcat Virtual Host Manager|Host Manager/i.test(t) || /401 Unauthorized/i.test(t),
    note: "Tomcat host manager reachable." },
  { path: "/jmx-console/", id: "jboss-jmx",
    title: "JBoss JMX console reachable", severity: "HIGH",
    verify: (t) => /jmx-console|jboss.system|MBean/i.test(t),
    note: "JBoss JMX console reachable — historic default-credential + deserialization risk." },
  { path: "/console/login/LoginForm.jsp", id: "weblogic-console",
    title: "WebLogic admin console reachable", severity: "HIGH",
    verify: (t) => /WebLogic|Oracle WebLogic|Server Administration/i.test(t),
    note: "WebLogic administration console reachable." },

  // ── Web-server status pages ─────────────────────────────────────────────
  { path: "/server-status", id: "apache-status",
    title: "Apache mod_status exposed", severity: "MEDIUM",
    verify: (t) => /Apache Server Status|Server uptime|Total accesses/i.test(t),
    note: "Live traffic, IPs, and requested URLs disclosed." },
  { path: "/server-info", id: "apache-info",
    title: "Apache mod_info exposed", severity: "MEDIUM",
    verify: (t) => /Apache Server Information|Server Settings/i.test(t),
    note: "Full server config disclosed." },
  { path: "/nginx_status", id: "nginx-status",
    title: "nginx stub_status exposed", severity: "LOW",
    verify: (t) => /Active connections:|server accepts handled requests/i.test(t),
    note: "nginx runtime stats disclosed." },

  // ── Debug pages ─────────────────────────────────────────────────────────
  { path: "/_debug", id: "generic-debug",
    title: "Debug endpoint reachable at /_debug", severity: "MEDIUM",
    verify: (t) => /Debug|Stack Trace|Traceback|Exception/i.test(t),
    note: "Application debug output reachable." },
  { path: "/debug/pprof/", id: "go-pprof",
    title: "Go pprof profiler exposed", severity: "HIGH",
    verify: (t) => /Types of profiles|goroutine|heap.*allocs/i.test(t),
    note: "Live goroutine / heap / cmdline profiles — DoS + info leak risk." },
  { path: "/debug/vars", id: "go-expvar",
    title: "Go expvar exposed", severity: "MEDIUM",
    verify: (t) => /^\{[\s\S]*"cmdline":/m.test(t),
    note: "Process metrics + cmdline disclosed." },
  { path: "/telescope/requests", id: "laravel-telescope",
    title: "Laravel Telescope exposed", severity: "HIGH",
    verify: (t) => /Telescope|laravel_telescope/i.test(t),
    note: "Laravel Telescope debug UI reachable — request/query dumps." },
  { path: "/_profiler/", id: "symfony-profiler",
    title: "Symfony profiler exposed", severity: "HIGH",
    verify: (t) => /Symfony Profiler|Web Profiler/i.test(t),
    note: "Symfony debug profiler reachable in production." },

  // ── DB admin dashboards ─────────────────────────────────────────────────
  { path: "/adminer.php", id: "adminer",
    title: "Adminer DB admin exposed", severity: "HIGH",
    verify: (t) => /Adminer.*Login|Adminer\s*\d/i.test(t),
    note: "Adminer login reachable — test for weak/default credentials in engagement scope." },
  { path: "/phpmyadmin/", id: "phpmyadmin",
    title: "phpMyAdmin exposed", severity: "MEDIUM",
    verify: (t) => /phpMyAdmin|pmaLogin/i.test(t),
    note: "phpMyAdmin reachable." },
  { path: "/pma/", id: "phpmyadmin-pma",
    title: "phpMyAdmin exposed (/pma/)", severity: "MEDIUM",
    verify: (t) => /phpMyAdmin/i.test(t),
    note: "phpMyAdmin reachable." },
  { path: "/wp-admin/install.php", id: "wp-install",
    title: "WordPress installer reachable", severity: "CRITICAL",
    verify: (t) => /WordPress[\s\S]{0,200}Installation|already installed/i.test(t),
    note: "WordPress installer reachable — if not already installed, attacker can complete setup." },

  // ── Cloud metadata reflectors ───────────────────────────────────────────
  { path: "/latest/meta-data/", id: "cloud-metadata-proxy",
    title: "Possible cloud metadata SSRF surface", severity: "MEDIUM",
    verify: (t) => /instance-id|ami-id|iam\/security-credentials/.test(t),
    note: "Response resembles AWS IMDS content — server may proxy metadata (SSRF)." },

  // ── Kubernetes / Docker ─────────────────────────────────────────────────
  { path: "/api/v1/namespaces", id: "kube-api",
    title: "Kubernetes API reachable unauthenticated", severity: "CRITICAL",
    verify: (t) => /"kind"\s*:\s*"NamespaceList"/i.test(t),
    note: "Unauthenticated Kubernetes API — full cluster read." },
  { path: "/version", id: "kube-version",
    title: "Kubernetes /version reachable", severity: "LOW",
    verify: (t) => /"gitVersion":\s*"v\d/i.test(t),
    note: "Kubernetes API server version leak." },
  { path: "/v2/_catalog", id: "docker-registry",
    title: "Docker registry catalog exposed", severity: "HIGH",
    verify: (t) => /"repositories"\s*:\s*\[/.test(t),
    note: "Docker registry catalog readable — image inventory disclosure." },
  { path: "/metrics", id: "prometheus-metrics",
    title: "Prometheus /metrics exposed", severity: "LOW",
    verify: (t) => /^# HELP |^# TYPE /m.test(t),
    note: "Prometheus exporter metrics disclosed." },

  // ── API docs ────────────────────────────────────────────────────────────
  { path: "/swagger-ui.html", id: "swagger-ui",
    title: "Swagger UI exposed", severity: "MEDIUM",
    verify: (t) => /swagger-ui|Swagger UI/i.test(t),
    note: "Full API documentation reachable." },
  { path: "/swagger/index.html", id: "swagger-ui-alt",
    title: "Swagger UI exposed (alt path)", severity: "MEDIUM",
    verify: (t) => /swagger-ui|Swagger UI/i.test(t),
    note: "Full API documentation reachable." },
  { path: "/swagger.json", id: "swagger-json",
    title: "OpenAPI/Swagger spec exposed", severity: "MEDIUM",
    verify: (t) => /"swagger"|"openapi"/.test(t),
    note: "Full API surface disclosed." },
  { path: "/openapi.json", id: "openapi-json",
    title: "OpenAPI spec exposed", severity: "MEDIUM",
    verify: (t) => /"openapi":\s*"[23]\./.test(t),
    note: "OpenAPI 3 spec — full API surface disclosed." },
  { path: "/api-docs", id: "api-docs",
    title: "API docs endpoint exposed", severity: "MEDIUM",
    verify: (t) => /"swagger"|"openapi"|"paths"/.test(t),
    note: "API docs reachable." },

  // ── Config / dependency-manifest exposure ───────────────────────────────
  { path: "/package.json", id: "package-json",
    title: "package.json exposed", severity: "LOW",
    verify: (t) => /"dependencies"\s*:/.test(t),
    note: "Dependency manifest disclosed — informs targeted CVE lookup." },
  { path: "/package-lock.json", id: "package-lock",
    title: "package-lock.json exposed", severity: "LOW",
    verify: (t) => /"lockfileVersion"/.test(t),
    note: "Full dependency tree with pinned versions disclosed." },
  { path: "/composer.json", id: "composer-json",
    title: "composer.json exposed", severity: "LOW",
    verify: (t) => /"require"\s*:/.test(t),
    note: "PHP dependency manifest disclosed." },
  { path: "/composer.lock", id: "composer-lock",
    title: "composer.lock exposed", severity: "LOW",
    verify: (t) => /"packages"\s*:/.test(t),
    note: "PHP dependency tree with pinned versions disclosed." },
  { path: "/yarn.lock", id: "yarn-lock",
    title: "yarn.lock exposed", severity: "LOW",
    verify: (t) => /# THIS IS AN AUTOGENERATED FILE|"resolved"\s+"http/.test(t),
    note: "Yarn dependency tree disclosed." },
  { path: "/Gemfile.lock", id: "gemfile-lock",
    title: "Gemfile.lock exposed", severity: "LOW",
    verify: (t) => /GEM\s*\n\s*remote:/i.test(t),
    note: "Ruby dependency manifest disclosed." },
  { path: "/requirements.txt", id: "requirements-txt",
    title: "requirements.txt exposed", severity: "LOW",
    verify: (t) => /^[A-Za-z0-9_.-]+==[\d.]+/m.test(t),
    note: "Python dependency manifest disclosed." },
  { path: "/Dockerfile", id: "dockerfile",
    title: "Dockerfile exposed", severity: "MEDIUM",
    verify: (t) => /^FROM\s+/mi.test(t),
    note: "Container build recipe disclosed." },
  { path: "/docker-compose.yml", id: "compose",
    title: "docker-compose.yml exposed", severity: "MEDIUM",
    verify: (t) => /^services\s*:/mi.test(t),
    note: "Service topology + env vars often disclosed." },

  // ── Env / secret files ──────────────────────────────────────────────────
  { path: "/.env.local", id: "env-local",
    title: "Exposed .env.local", severity: "CRITICAL",
    verify: (t) => /^[A-Z0-9_]+\s*=/m.test(t) && !/<html/i.test(t),
    note: "Local env overrides — likely secrets disclosure." },
  { path: "/.env.production", id: "env-prod",
    title: "Exposed .env.production", severity: "CRITICAL",
    verify: (t) => /^[A-Z0-9_]+\s*=/m.test(t) && !/<html/i.test(t),
    note: "Production env — credentials disclosure." },
  { path: "/.env.development", id: "env-dev",
    title: "Exposed .env.development", severity: "HIGH",
    verify: (t) => /^[A-Z0-9_]+\s*=/m.test(t) && !/<html/i.test(t),
    note: "Development env — often contains stagng credentials." },
  { path: "/.env.staging", id: "env-staging",
    title: "Exposed .env.staging", severity: "HIGH",
    verify: (t) => /^[A-Z0-9_]+\s*=/m.test(t) && !/<html/i.test(t),
    note: "Staging env — credentials disclosure." },
  { path: "/.aws/credentials", id: "aws-creds",
    title: "Exposed AWS credentials file", severity: "CRITICAL",
    verify: (t) => /\[default\]|aws_access_key_id/i.test(t),
    note: "AWS credentials file — immediate account compromise." },
  { path: "/.npmrc", id: "npmrc",
    title: "Exposed .npmrc", severity: "HIGH",
    verify: (t) => /_authToken|_password/i.test(t),
    note: "npm registry auth token likely disclosed." },
  { path: "/.pypirc", id: "pypirc",
    title: "Exposed .pypirc", severity: "HIGH",
    verify: (t) => /\[pypi\]|password\s*=/i.test(t),
    note: "PyPI upload credentials likely disclosed." },
  { path: "/.netrc", id: "netrc",
    title: "Exposed .netrc", severity: "HIGH",
    verify: (t) => /machine .+ login .+ password/i.test(t),
    note: ".netrc contains cleartext credentials." },

  // ── Backup archives ─────────────────────────────────────────────────────
  { path: "/backup.tar.gz", id: "backup-tar",
    title: "Exposed backup archive", severity: "CRITICAL",
    verify: (_, res) => res && /application\/(x-gzip|gzip|octet-stream)/i.test(res.ctype || ""),
    note: "Full backup archive downloadable." },
  { path: "/db.sql", id: "db-sql",
    title: "Exposed database dump /db.sql", severity: "CRITICAL",
    verify: (t) => /CREATE TABLE|INSERT INTO|-- MySQL dump/i.test(t),
    note: "Database dump readable — full data disclosure." },
  { path: "/dump.sql", id: "dump-sql",
    title: "Exposed database dump /dump.sql", severity: "CRITICAL",
    verify: (t) => /CREATE TABLE|INSERT INTO|-- (MySQL|PostgreSQL) dump/i.test(t),
    note: "Database dump readable — full data disclosure." },
  { path: "/site.zip", id: "site-zip",
    title: "Exposed site archive /site.zip", severity: "HIGH",
    verify: (_, res) => res && /application\/(zip|octet-stream)/i.test(res.ctype || ""),
    note: "Site source archive downloadable." },

  // ── Health / mgmt (informational) ───────────────────────────────────────
  { path: "/health", id: "health",
    title: "Health endpoint reachable", severity: "LOW",
    verify: (t) => /"status"\s*:\s*"(UP|OK)"|\bok\b/i.test(t),
    note: "Health endpoint reachable — may reveal downstream service state." }
];

// Concurrency-limited runner.
export async function probeWebApp(origin, { concurrency = 6 } = {}) {
  const base = origin.replace(/\/$/, "");
  const queue = [...PROBES];
  const found = [];

  async function worker() {
    while (queue.length) {
      const probe = queue.shift();
      const url = base + probe.path;
      const res = await get(url, {}, 6000);
      if (!res || res.status >= 400 || res.status === 0) continue;
      const passed = probe.verify(res.text, res);
      if (!passed) continue;
      found.push({
        id: probe.id,
        title: probe.title,
        severity: probe.severity,
        url,
        detail: probe.note,
        verified: true
      });
    }
  }

  await Promise.all(Array.from({ length: concurrency }, worker));

  const weight = { CRITICAL: 4, HIGH: 3, MEDIUM: 2, LOW: 1 };
  return found.sort((a, b) => (weight[b.severity] || 0) - (weight[a.severity] || 0));
}
