// ReconHound — XSS attack-surface consolidator
// Author: Rhishinathvarma Marimuthu
//
// Builds a UNIFIED XSS attack-surface map from data already collected by other
// engines (reflected parameters + contexts, DOM sinks, postMessage listeners,
// CSP posture) and adds new DETECTION-ONLY signals:
//
//   · Trusted Types policy presence         (headers)
//   · X-Content-Type-Options: nosniff       (headers)
//   · Sanitizer libraries in use            (DOMPurify, sanitize-html, xss)
//   · Framework-context XSS risk profile    (React, Vue, Angular versions)
//   · Content-Type mismatch (JSON endpoint returning text/html echo)
//
// No payloads are fired. No sinks are executed. Output is scored guidance
// for the operator to manually verify with a dedicated XSS tool.

const SANITIZER_LIBS = [
  { re: /\bDOMPurify\b/, name: "DOMPurify", risk: -20 },       // presence LOWERS risk
  { re: /\bsanitize-html\b/i, name: "sanitize-html", risk: -15 },
  { re: /\bxss(?:-filter)?\b/, name: "js-xss / xss-filters", risk: -10 },
  { re: /\bcreateHTML\s*\(/, name: "Trusted Types createHTML policy in JS", risk: -25 }
];

// Detected framework name → intrinsic XSS-defence baseline (0..100).
// React: bulletproof unless dangerouslySetInnerHTML is used.
// Vue: bulletproof unless v-html is used.
// Angular: [innerHTML] uses sanitizer by default but is often bypassed.
// jQuery: no intrinsic defence.
const FRAMEWORK_DEFENCE = {
  "React":     70,
  "Vue.js":    68,
  "Angular":   65,
  "AngularJS": 15,   // legacy, template injection surface
  "jQuery":    10,
  "Backbone.js": 15
};

function detectSanitizers(inlineCode = "", scriptUrls = []) {
  const found = [];
  for (const lib of SANITIZER_LIBS) {
    if (lib.re.test(inlineCode || "")) { found.push(lib); continue; }
    if ((scriptUrls || []).some((u) => lib.re.test(u))) found.push(lib);
  }
  return found;
}

// Analyse HTTP response-header list for XSS-relevant defensive headers.
// Accepts either the raw webRequest headers array [{name,value},…] or
// the analyzed security[] array already stored on the tab.
export function analyzeXssHeaders(responseHeaders = []) {
  const findings = [];
  const headers = new Map();
  for (const h of responseHeaders) headers.set(String(h.name || "").toLowerCase(), String(h.value || ""));

  if (!headers.has("x-content-type-options") || !/nosniff/i.test(headers.get("x-content-type-options") || "")) {
    findings.push({
      id: "xss-no-nosniff",
      title: "Missing X-Content-Type-Options: nosniff",
      severity: "MEDIUM",
      detail: "Without nosniff, a JSON/text endpoint that echoes user input can be sniffed as HTML by older browsers → XSS via content-type confusion. Set X-Content-Type-Options: nosniff site-wide.",
      verified: true
    });
  }

  // Trusted Types: only enforced via CSP directive `require-trusted-types-for 'script'`.
  const csp = headers.get("content-security-policy") || headers.get("content-security-policy-report-only") || "";
  if (!/require-trusted-types-for/i.test(csp)) {
    findings.push({
      id: "xss-no-trusted-types",
      title: "Trusted Types not enforced",
      severity: "LOW",
      detail: "CSP does not include `require-trusted-types-for 'script'`. Enforcing Trusted Types is the strongest modern defence against DOM XSS on evergreen browsers.",
      verified: true,
      needsManual: true
    });
  }

  // Framework-context XSS via mis-typed API response.
  const ct = headers.get("content-type") || "";
  if (/text\/html/i.test(ct) && /application\/json|json/i.test(headers.get("accept") || "")) {
    findings.push({
      id: "xss-content-type-mismatch",
      title: "Content-Type text/html on what looks like a JSON endpoint",
      severity: "MEDIUM",
      detail: "The response is text/html but the request was Accept: application/json. If the endpoint echoes JSON-encoded user input, browsers may still parse it as HTML → XSS.",
      verified: true,
      needsManual: true
    });
  }

  return findings;
}

// Frame the DOM sinks by count + severity — turn them into ATTACK vectors.
function classifySinks(domSinks = []) {
  const vectors = [];
  const buckets = new Map();
  for (const s of domSinks || []) {
    const k = s.name;
    if (!buckets.has(k)) buckets.set(k, { name: k, severity: s.severity, count: 0, samples: [] });
    const b = buckets.get(k);
    b.count++;
    if (b.samples.length < 3) b.samples.push(s.context);
  }
  for (const b of buckets.values()) {
    // Map sink to attack vector name.
    let vector = "DOM-XSS";
    if (/eval|new\s+Function|setTimeout|setInterval/.test(b.name)) vector = "eval-family DOM-XSS";
    else if (/innerHTML|outerHTML|dangerouslySetInnerHTML|v-html|\[innerHTML\]/.test(b.name)) vector = "innerHTML-family DOM-XSS";
    else if (/document\.write/.test(b.name)) vector = "document.write DOM-XSS";
    else if (/document\.domain/.test(b.name)) vector = "document.domain relaxation";
    else if (/location/.test(b.name)) vector = "location-based DOM-XSS";
    else if (/^inline on/.test(b.name)) vector = "inline event-handler XSS surface";
    vectors.push({ ...b, vector });
  }
  return vectors;
}

// postMessage listener risk assessment.
function classifyPostMessage(listeners = []) {
  return (listeners || []).map((l, i) => ({
    idx: i,
    hasOriginCheck: !!l.hasOriginCheck,
    preview: l.preview,
    // Any listener without an origin check is a pmXSS candidate.
    risk: l.hasOriginCheck ? "LOW" : "MEDIUM"
  }));
}

// Reflected-param contexts consolidated per-parameter.
function consolidateReflections(exposures = []) {
  const byParam = new Map();
  for (const e of exposures || []) {
    if (!e || !e.xssSurface || !e.xssSurface.param) continue;
    const p = e.xssSurface.param;
    if (!byParam.has(p)) byParam.set(p, { param: p, contexts: [], reflections: 0, encoded: false, url: e.url, worstSeverity: "LOW" });
    const entry = byParam.get(p);
    entry.contexts.push(e.xssSurface.context);
    entry.reflections += e.xssSurface.reflections || 1;
    if (e.xssSurface.encoded) entry.encoded = true;
    const w = { CRITICAL: 4, HIGH: 3, MEDIUM: 2, LOW: 1 };
    if ((w[e.severity] || 0) > (w[entry.worstSeverity] || 0)) entry.worstSeverity = e.severity;
  }
  return [...byParam.values()];
}

// Score the target's overall XSS-defence posture (0..100). Higher = better.
function scoreDefence(report) {
  let score = 50;
  // CSP grade
  const csp = report.cspAnalysis;
  if (csp && csp.grade === "A") score += 25;
  else if (csp && csp.grade === "B") score += 15;
  else if (csp && csp.grade === "C") score += 5;
  else if (csp && csp.grade === "D") score -= 10;
  else if (csp && csp.grade === "F") score -= 25;
  else score -= 5; // no CSP header

  // Framework
  const worstFrameworkDefence = (report.tech || [])
    .filter((t) => t.tech in FRAMEWORK_DEFENCE)
    .reduce((min, t) => Math.min(min, FRAMEWORK_DEFENCE[t.tech]), 100);
  if (worstFrameworkDefence < 100) {
    score += Math.round((worstFrameworkDefence - 50) * 0.3);
  }

  // Sanitizer libs (positive weight already baked into lib.risk which is NEGATIVE == LOWERS attack risk == RAISES score)
  const sanitizers = detectSanitizers(report._inlineCode || "", (report._scriptUrls || []));
  for (const s of sanitizers) score -= s.risk; // s.risk is negative → subtracting negative raises score

  // Missing nosniff
  if (!(report._headers || []).some((h) => h.name === "x-content-type-options")) score -= 5;
  // Trusted Types
  if ((report._headers || []).some((h) => /trusted-types/i.test(h.value))) score += 10;

  // Reflected-param severity
  const reflections = consolidateReflections(report.exposures || []);
  for (const r of reflections) {
    if (r.worstSeverity === "HIGH") score -= 15;
    else if (r.worstSeverity === "MEDIUM") score -= 7;
    else score -= 3;
  }
  // DOM sinks
  const sinks = classifySinks(report.domSinks || []);
  for (const s of sinks) {
    if (s.severity === "HIGH") score -= 8;
    else if (s.severity === "MEDIUM") score -= 4;
    else score -= 1;
  }
  // postMessage without origin check
  const pm = (report.postMessageListeners || []).filter((l) => !l.hasOriginCheck).length;
  score -= pm * 4;

  score = Math.max(0, Math.min(100, score));
  const grade = score >= 85 ? "A" : score >= 70 ? "B" : score >= 50 ? "C" : score >= 30 ? "D" : "F";
  return { score, grade };
}

// Main entry-point — produce the XSS-surface report block for a target.
export function buildXssSurface(report, inputs = {}) {
  const inlineCode = inputs.inlineCode || "";
  const scriptUrls = inputs.scriptUrls || [];
  const responseHeaders = inputs.responseHeaders || [];

  // Attach ephemeral bits so scoreDefence can reason about them.
  report._inlineCode = inlineCode;
  report._scriptUrls = scriptUrls;
  report._headers = responseHeaders.map((h) => ({
    name: String(h.name || "").toLowerCase(),
    value: String(h.value || "")
  }));

  const sanitizers = detectSanitizers(inlineCode, scriptUrls);
  const headerFindings = analyzeXssHeaders(responseHeaders);
  const reflections = consolidateReflections(report.exposures || []);
  const sinks = classifySinks(report.domSinks || []);
  const pm = classifyPostMessage(report.postMessageListeners || []);
  const defence = scoreDefence(report);

  // Build parameter-level suggested "hand off to XSS tool" targets.
  const handoffTargets = reflections.map((r) => ({
    url: r.url,
    param: r.param,
    contexts: [...new Set(r.contexts)],
    priority: r.worstSeverity
  }));

  // Clean up ephemeral fields.
  delete report._inlineCode;
  delete report._scriptUrls;
  delete report._headers;

  return {
    defence,
    reflections,
    sinks,
    postMessageListeners: pm,
    headerFindings,
    sanitizers: sanitizers.map((s) => ({ name: s.name })),
    handoffTargets
  };
}
