// ReconHound — JWT weakness analyzer
// Decodes JWTs found in page HTML / scripts / storage / cookies and scores
// them for common misconfigurations. Does NOT attempt to forge or replay
// tokens — analysis is read-only, no network requests.

function b64urlDecode(s) {
  let str = String(s || "").replace(/-/g, "+").replace(/_/g, "/");
  while (str.length % 4) str += "=";
  try {
    // atob returns a binary string; convert via TextDecoder to handle unicode.
    const bin = atob(str);
    const bytes = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
    return new TextDecoder().decode(bytes);
  } catch (_) { return null; }
}

function decodeJwt(token) {
  if (typeof token !== "string") return null;
  const parts = token.split(".");
  if (parts.length !== 3) return null;
  const headerRaw = b64urlDecode(parts[0]);
  const payloadRaw = b64urlDecode(parts[1]);
  if (!headerRaw || !payloadRaw) return null;
  try {
    return {
      header: JSON.parse(headerRaw),
      payload: JSON.parse(payloadRaw),
      signature: parts[2],
      raw: token
    };
  } catch (_) { return null; }
}

function sanitizePayload(p) {
  const out = {};
  for (const [k, v] of Object.entries(p || {})) {
    if (typeof v === "string" && v.length > 60) out[k] = v.slice(0, 24) + "…";
    else if (typeof v === "object" && v !== null) out[k] = "[object]";
    else out[k] = v;
  }
  return out;
}

const SENSITIVE_CLAIM_HINTS = [
  "password", "passwd", "secret", "api_key", "apikey", "private_key",
  "privatekey", "credential", "token", "session_id", "ssn", "credit_card"
];

// Analyze a single JWT string. Returns null if not a valid JWT.
export function analyzeJwt(token, source = "unknown") {
  const decoded = decodeJwt(token);
  if (!decoded) return null;
  const { header, payload, signature } = decoded;
  const now = Math.floor(Date.now() / 1000);
  const issues = [];

  // Algorithm class.
  const alg = String(header.alg || "").toUpperCase();
  if (alg === "NONE" || alg === "") {
    issues.push({
      severity: "CRITICAL",
      text: "Header declares alg=none — server may accept unsigned tokens (auth bypass class)."
    });
  } else if (alg.startsWith("HS")) {
    issues.push({
      severity: "MEDIUM",
      text: `Symmetric algorithm ${alg} — if the signing secret is weak or leaked, tokens can be forged. Verify server enforces a rotated, high-entropy secret.`
    });
  }

  // Signature sanity.
  if (!signature || signature.length < 8) {
    issues.push({
      severity: "HIGH",
      text: "Signature segment is empty or trivially short — unsigned tokens likely accepted."
    });
  }

  // `kid` file-path injection.
  if (typeof header.kid === "string" && /(\.\.|\/|\\)/.test(header.kid)) {
    issues.push({
      severity: "HIGH",
      text: `Suspicious "kid" header ("${header.kid}") — verify server does not use it as a filesystem path (LFI/RCE class).`
    });
  }
  // `jku` / `x5u` — attacker-controlled key fetch surface.
  for (const hdr of ["jku", "x5u", "jwk"]) {
    if (header[hdr]) {
      issues.push({
        severity: "HIGH",
        text: `Token declares "${hdr}" header — verify the server pins an allowlist of trusted JWK/URI hosts.`
      });
    }
  }
  // `x5c` embedded cert chain: signer trust needs review.
  if (Array.isArray(header.x5c) && header.x5c.length) {
    issues.push({
      severity: "MEDIUM",
      text: "Token embeds x5c certificate chain — verify server chains to a trusted root, not attacker-supplied."
    });
  }

  // Expiration / age.
  if (payload.exp == null) {
    issues.push({
      severity: "MEDIUM",
      text: "No `exp` claim — token effectively never expires."
    });
  } else if (typeof payload.exp === "number" && payload.exp < now) {
    issues.push({
      severity: "LOW",
      text: `Token already expired at ${new Date(payload.exp * 1000).toISOString()}.`
    });
  }
  if (typeof payload.exp === "number" && typeof payload.iat === "number") {
    const lifetimeSec = payload.exp - payload.iat;
    const days = Math.floor(lifetimeSec / 86400);
    if (days >= 30) {
      issues.push({
        severity: "LOW",
        text: `Long-lived token: ${days} day lifetime. Short-lived + refresh tokens are safer.`
      });
    }
  }
  if (payload.nbf && typeof payload.nbf === "number" && payload.nbf > now + 300) {
    issues.push({
      severity: "LOW",
      text: `nbf (${new Date(payload.nbf * 1000).toISOString()}) is far in the future — validate clock-skew handling.`
    });
  }

  // Sensitive claim names in payload.
  for (const k of Object.keys(payload)) {
    const kl = k.toLowerCase();
    if (SENSITIVE_CLAIM_HINTS.some((h) => kl.includes(h))) {
      issues.push({
        severity: "HIGH",
        text: `Sensitive-looking claim "${k}" in payload — JWT payloads are only base64, not encrypted.`
      });
    }
  }

  // Missing common claims that server-side validation usually needs.
  const missing = ["iss", "aud"].filter((c) => payload[c] == null);
  if (missing.length) {
    issues.push({
      severity: "LOW",
      text: `Missing claim(s): ${missing.join(", ")} — verify server does not blindly trust unbound tokens.`
    });
  }

  // Weight worst issue → verdict severity.
  const weight = { CRITICAL: 4, HIGH: 3, MEDIUM: 2, LOW: 1 };
  const verdict = issues.reduce((worst, i) =>
    (weight[i.severity] || 0) > (weight[worst] || 0) ? i.severity : worst,
    "LOW"
  );

  return {
    algorithm: alg || null,
    typ: header.typ || null,
    kid: header.kid || null,
    issuer: payload.iss || null,
    subject: payload.sub || null,
    audience: payload.aud || null,
    issuedAt: typeof payload.iat === "number" ? new Date(payload.iat * 1000).toISOString() : null,
    expiresAt: typeof payload.exp === "number" ? new Date(payload.exp * 1000).toISOString() : null,
    header,
    payloadSample: sanitizePayload(payload),
    issues,
    verdict,
    source
  };
}

// Batch: extract every JWT-looking substring from a blob and analyze each once.
const JWT_RE = /\beyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\b/g;

export function scanJwts(text, source = "page") {
  if (!text) return [];
  const out = [];
  const seen = new Set();
  let m;
  JWT_RE.lastIndex = 0;
  while ((m = JWT_RE.exec(text)) !== null) {
    const tok = m[0];
    if (seen.has(tok)) continue;
    seen.add(tok);
    const analysis = analyzeJwt(tok, source);
    if (analysis) out.push(analysis);
    if (out.length > 20) break;
  }
  return out;
}
