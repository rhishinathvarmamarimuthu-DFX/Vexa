// ReconHound — Third-party / supply-chain inventory & subdomain-takeover risk
// Analyses which external services the target loads code from. Categorises
// them (analytics, ads, cdn, payments, auth, chat, fonts) and flags loaded
// hosts pointing to platforms that are prone to dangling-CNAME takeover
// (verification always requires a DNS check — flagged `needsManual`).

const KNOWN_SERVICES = [
  // Analytics / RUM / session-replay
  { re: /(?:^|\.)google-analytics\.com$|(?:^|\.)googletagmanager\.com$/, category: "analytics", tech: "Google Analytics / GTM" },
  { re: /(?:^|\.)segment\.(?:com|io)$/, category: "analytics", tech: "Segment" },
  { re: /(?:^|\.)mixpanel\.com$/, category: "analytics", tech: "Mixpanel" },
  { re: /(?:^|\.)amplitude\.com$/, category: "analytics", tech: "Amplitude" },
  { re: /(?:^|\.)hotjar\.com$|(?:^|\.)hotjar\.io$/, category: "analytics", tech: "Hotjar" },
  { re: /(?:^|\.)fullstory\.com$/, category: "analytics", tech: "FullStory" },
  { re: /(?:^|\.)heap\.io$|(?:^|\.)heapanalytics\.com$/, category: "analytics", tech: "Heap" },
  { re: /(?:^|\.)matomo\.cloud$|(?:^|\.)matomo\.org$/, category: "analytics", tech: "Matomo" },
  { re: /(?:^|\.)posthog\.com$/, category: "analytics", tech: "PostHog" },
  { re: /(?:^|\.)plausible\.io$/, category: "analytics", tech: "Plausible" },

  // Advertising / tracking
  { re: /(?:^|\.)doubleclick\.net$|(?:^|\.)googlesyndication\.com$|(?:^|\.)adservice\.google\.com$/, category: "advertising", tech: "Google Ads / DoubleClick" },
  { re: /(?:^|\.)facebook\.(?:com|net)$|(?:^|\.)fbcdn\.net$/, category: "advertising", tech: "Facebook / Meta Pixel" },
  { re: /(?:^|\.)linkedin\.com$|(?:^|\.)licdn\.com$/, category: "advertising", tech: "LinkedIn Insight" },
  { re: /(?:^|\.)twitter\.com$|(?:^|\.)t\.co$|(?:^|\.)twimg\.com$/, category: "advertising", tech: "X / Twitter" },
  { re: /(?:^|\.)tiktok\.com$/, category: "advertising", tech: "TikTok Pixel" },
  { re: /(?:^|\.)bing\.com$|(?:^|\.)clarity\.ms$/, category: "advertising", tech: "Microsoft Ads / Clarity" },

  // Support / chat / CRM
  { re: /(?:^|\.)intercom\.io$|(?:^|\.)intercomcdn\.com$/, category: "support", tech: "Intercom" },
  { re: /(?:^|\.)zendesk\.com$/, category: "support", tech: "Zendesk" },
  { re: /(?:^|\.)drift\.com$/, category: "support", tech: "Drift" },
  { re: /(?:^|\.)hubspot\.com$|(?:^|\.)hs-scripts\.com$|(?:^|\.)hs-analytics\.net$/, category: "support", tech: "HubSpot" },
  { re: /(?:^|\.)crisp\.chat$/, category: "support", tech: "Crisp" },
  { re: /(?:^|\.)freshworks\.com$/, category: "support", tech: "Freshworks" },
  { re: /(?:^|\.)tawk\.to$/, category: "support", tech: "tawk.to" },

  // CDN / static hosting
  { re: /(?:^|\.)cdnjs\.cloudflare\.com$/, category: "cdn", tech: "cdnjs (Cloudflare)" },
  { re: /(?:^|\.)jsdelivr\.net$/, category: "cdn", tech: "jsDelivr" },
  { re: /(?:^|\.)unpkg\.com$/, category: "cdn", tech: "unpkg" },
  { re: /(?:^|\.)ajax\.googleapis\.com$/, category: "cdn", tech: "Google Hosted Libraries" },
  { re: /(?:^|\.)cloudfront\.net$/, category: "cdn", tech: "AWS CloudFront" },
  { re: /(?:^|\.)akamaihd\.net$|(?:^|\.)akamaized\.net$/, category: "cdn", tech: "Akamai" },
  { re: /(?:^|\.)fastly\.net$/, category: "cdn", tech: "Fastly" },
  { re: /(?:^|\.)stackpathdns\.com$/, category: "cdn", tech: "StackPath" },

  // Payments
  { re: /(?:^|\.)stripe\.com$|(?:^|\.)stripe\.network$/, category: "payments", tech: "Stripe" },
  { re: /(?:^|\.)paypal\.com$|(?:^|\.)paypalobjects\.com$/, category: "payments", tech: "PayPal" },
  { re: /(?:^|\.)braintreepayments\.com$|(?:^|\.)braintree-api\.com$/, category: "payments", tech: "Braintree" },
  { re: /(?:^|\.)adyen\.com$/, category: "payments", tech: "Adyen" },
  { re: /(?:^|\.)squareup\.com$/, category: "payments", tech: "Square" },
  { re: /(?:^|\.)klarna\.com$/, category: "payments", tech: "Klarna" },
  { re: /(?:^|\.)razorpay\.com$/, category: "payments", tech: "Razorpay" },

  // Fonts
  { re: /(?:^|\.)fonts\.googleapis\.com$|(?:^|\.)fonts\.gstatic\.com$/, category: "fonts", tech: "Google Fonts" },
  { re: /(?:^|\.)use\.typekit\.net$/, category: "fonts", tech: "Adobe Fonts" },
  { re: /(?:^|\.)use\.fontawesome\.com$/, category: "fonts", tech: "Font Awesome" },

  // Auth / identity
  { re: /(?:^|\.)auth0\.com$/, category: "auth", tech: "Auth0" },
  { re: /(?:^|\.)okta\.com$/, category: "auth", tech: "Okta" },
  { re: /(?:^|\.)accounts\.google\.com$|(?:^|\.)apis\.google\.com$/, category: "auth", tech: "Google OAuth" },
  { re: /(?:^|\.)login\.microsoftonline\.com$/, category: "auth", tech: "Microsoft Entra ID" },
  { re: /(?:^|\.)cognito\-identity\.[a-z0-9-]+\.amazonaws\.com$/, category: "auth", tech: "AWS Cognito" },
  { re: /(?:^|\.)firebaseapp\.com$/, category: "auth", tech: "Firebase Auth" },

  // Error / performance monitoring
  { re: /(?:^|\.)sentry\.io$|(?:^|\.)ingest\.sentry\.io$/, category: "monitoring", tech: "Sentry" },
  { re: /(?:^|\.)datadoghq\.com$|(?:^|\.)datadog\.eu$/, category: "monitoring", tech: "Datadog RUM" },
  { re: /(?:^|\.)newrelic\.com$|(?:^|\.)nr-data\.net$/, category: "monitoring", tech: "New Relic" },
  { re: /(?:^|\.)bugsnag\.com$/, category: "monitoring", tech: "Bugsnag" },
  { re: /(?:^|\.)rollbar\.com$/, category: "monitoring", tech: "Rollbar" }
];

// Hosts prone to subdomain takeover via dangling CNAME.
const TAKEOVER_PATTERNS = [
  { re: /(?:^|\.)github\.io$/, service: "GitHub Pages",
    note: "Dangling CNAME to *.github.io — takeable by creating a repo with the matching name." },
  { re: /(?:^|\.)herokuapp\.com$/, service: "Heroku",
    note: "Dangling CNAME to *.herokuapp.com — takeable via free Heroku app registration." },
  { re: /(?:^|\.)s3(?:[.-][a-z0-9-]+)?\.amazonaws\.com$/, service: "AWS S3",
    note: "Dangling CNAME to S3 bucket — takeable by claiming the unclaimed bucket name." },
  { re: /(?:^|\.)azurewebsites\.net$|(?:^|\.)cloudapp\.net$|(?:^|\.)trafficmanager\.net$/, service: "Azure",
    note: "Dangling Azure App Service / Cloud Service / Traffic Manager — takeable via free resource registration." },
  { re: /(?:^|\.)netlify\.app$|(?:^|\.)netlify\.com$/, service: "Netlify",
    note: "Dangling Netlify site — takeable via free site registration." },
  { re: /(?:^|\.)readthedocs\.io$/, service: "Read the Docs",
    note: "Dangling RTD project — takeable by creating a project with the matching name." },
  { re: /(?:^|\.)wordpress\.com$/, service: "WordPress.com",
    note: "Dangling WordPress.com site — takeable via free site registration." },
  { re: /(?:^|\.)pantheonsite\.io$/, service: "Pantheon",
    note: "Dangling Pantheon site — takeable via free site registration." },
  { re: /(?:^|\.)ghost\.io$/, service: "Ghost",
    note: "Dangling Ghost.io site — takeable via free site registration." },
  { re: /(?:^|\.)webflow\.io$/, service: "Webflow",
    note: "Dangling Webflow site — takeable via free site registration." },
  { re: /(?:^|\.)surge\.sh$/, service: "Surge",
    note: "Dangling Surge site — takeable via free site registration." },
  { re: /(?:^|\.)fastly\.net$/, service: "Fastly",
    note: "Dangling Fastly service reference — verify Fastly host is still provisioned." },
  { re: /(?:^|\.)shopify\.com$/, service: "Shopify",
    note: "Dangling myshopify subdomain — takeable if store is closed." },
  { re: /(?:^|\.)zendesk\.com$/, service: "Zendesk",
    note: "Dangling Zendesk subdomain — takeable if account is cancelled." },
  { re: /(?:^|\.)helpscoutdocs\.com$/, service: "Help Scout",
    note: "Dangling Help Scout site — takeable if project is closed." },
  { re: /(?:^|\.)tumblr\.com$/, service: "Tumblr",
    note: "Dangling Tumblr blog — takeable via free registration." },
  { re: /(?:^|\.)desk\.com$/, service: "Desk.com",
    note: "Dangling Desk.com subdomain — takeable if project is closed." }
];

function hostOf(url) {
  try { return new URL(url, "http://x").host.toLowerCase(); } catch (_) { return null; }
}

// Analyse the resource list from a passive scan.
//   scriptUrls : string[]   — every JS/CSS/asset URL the page loaded
//   pageOrigin : string     — origin of the page being scanned (for scope)
// Returns { inventory, findings }.
export function analyzeSupplyChain(scriptUrls = [], pageOrigin = "") {
  const inventory = {};   // { tech: { category, hosts: Set } }
  const findings = [];
  const seenTakeovers = new Set();
  const pageHost = hostOf(pageOrigin) || "";
  const rootPart = pageHost.split(".").slice(-2).join(".");

  for (const url of scriptUrls) {
    const host = hostOf(url);
    if (!host) continue;
    // First-party — skip (same registrable domain).
    if (rootPart && (host === pageHost || host.endsWith("." + rootPart))) continue;

    // Categorise via known-services table.
    let matched = null;
    for (const svc of KNOWN_SERVICES) {
      if (svc.re.test(host)) { matched = svc; break; }
    }
    const tech = matched ? matched.tech : host;
    const category = matched ? matched.category : "third-party";
    if (!inventory[tech]) inventory[tech] = { category, hosts: new Set() };
    inventory[tech].hosts.add(host);

    // Takeover risk.
    for (const t of TAKEOVER_PATTERNS) {
      if (!t.re.test(host)) continue;
      const key = t.service + "|" + host;
      if (seenTakeovers.has(key)) break;
      seenTakeovers.add(key);
      findings.push({
        id: "takeover-" + t.service.toLowerCase().replace(/[^a-z0-9]+/g, "-"),
        title: `Potential subdomain-takeover surface — ${t.service}`,
        severity: "MEDIUM",
        url,
        detail: `${host} → ${t.note} Verify via DNS: if the ${t.service} target no longer exists, the CNAME is takeable.`,
        verified: false,
        needsManual: true,
        service: t.service,
        host
      });
      break;
    }
  }

  const summary = Object.entries(inventory)
    .map(([tech, info]) => ({ tech, category: info.category, hosts: [...info.hosts].sort() }))
    .sort((a, b) => a.category.localeCompare(b.category) || a.tech.localeCompare(b.tech));

  return { inventory: summary, findings };
}
