// ReconHound — Data-source health ledger
// Wraps external HTTP calls so we can track which upstreams are healthy vs
// degraded, and surface that state in the popup instead of silently returning
// empty results. State lives in chrome.storage.session (per-browsing-session)
// so it survives worker restarts but resets each browser start.

const KEY = "rh_source_status";

const DEFAULT_STATE = {
  nvd:          { ok: null, lastSeen: 0, lastError: null },
  kev:          { ok: null, lastSeen: 0, lastError: null },
  epss:         { ok: null, lastSeen: 0, lastError: null },
  crtsh:        { ok: null, lastSeen: 0, lastError: null },
  certspotter:  { ok: null, lastSeen: 0, lastError: null },
  endoflife:    { ok: null, lastSeen: 0, lastError: null },
  npm:          { ok: null, lastSeen: 0, lastError: null },
  wpcore:       { ok: null, lastSeen: 0, lastError: null }
};

async function readState() {
  try {
    const d = await chrome.storage.session.get(KEY);
    return { ...DEFAULT_STATE, ...(d[KEY] || {}) };
  } catch (_) { return { ...DEFAULT_STATE }; }
}
async function writeState(s) {
  try { await chrome.storage.session.set({ [KEY]: s }); } catch (_) {}
}

export async function markSourceOk(source) {
  const s = await readState();
  s[source] = { ok: true, lastSeen: Date.now(), lastError: null };
  await writeState(s);
}
export async function markSourceDown(source, error) {
  const s = await readState();
  s[source] = { ok: false, lastSeen: Date.now(), lastError: String(error || "error") };
  await writeState(s);
}
export async function getSourceStatus() {
  return await readState();
}
