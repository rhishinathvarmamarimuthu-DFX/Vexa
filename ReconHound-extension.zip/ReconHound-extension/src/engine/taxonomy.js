// ReconHound — Finding taxonomy: OWASP Top 10 (2021) + CWE + MITRE ATT&CK
// Author: Rhishinathvarma Marimuthu
//
// Maps every finding id → { owasp, cwe, mitre } so exports (SARIF, HTML,
// Markdown) can carry industry-standard classifications. Enterprise consumers
// (GitHub Advanced Security, Splunk, security dashboards) key off these.

// Base mapping table. Keys are finding IDs or id-prefixes (matched by
// startsWith). Values reference OWASP-Top-10 (2021), CWE IDs, and MITRE
// ATT&CK Enterprise techniques.
const MAP = {
  // ── Broken access control ───────────────────────────────────────────────
  "bypass-40x-":       { owasp: "A01:2021 – Broken Access Control", cwe: ["CWE-284", "CWE-285"], mitre: ["T1190"] },
  "wp-user-enum":      { owasp: "A01:2021 – Broken Access Control", cwe: ["CWE-200"], mitre: ["T1589.002"] },
  "wp-author-enum":    { owasp: "A01:2021 – Broken Access Control", cwe: ["CWE-200"], mitre: ["T1589.002"] },
  "actuator-":         { owasp: "A05:2021 – Security Misconfiguration", cwe: ["CWE-16", "CWE-798"], mitre: ["T1190"] },
  "wp-install":        { owasp: "A05:2021 – Security Misconfiguration", cwe: ["CWE-732"], mitre: ["T1190"] },
  "tomcat-":           { owasp: "A05:2021 – Security Misconfiguration", cwe: ["CWE-16"], mitre: ["T1190"] },
  "jboss-jmx":         { owasp: "A05:2021 – Security Misconfiguration", cwe: ["CWE-16"], mitre: ["T1190"] },
  "weblogic-console":  { owasp: "A05:2021 – Security Misconfiguration", cwe: ["CWE-16"], mitre: ["T1190"] },

  // ── Cryptographic failures ──────────────────────────────────────────────
  "jwt":               { owasp: "A02:2021 – Cryptographic Failures", cwe: ["CWE-347", "CWE-327"], mitre: ["T1552.004"] },
  "private-key":       { owasp: "A02:2021 – Cryptographic Failures", cwe: ["CWE-798"], mitre: ["T1552.004"] },
  "ssh-key":           { owasp: "A02:2021 – Cryptographic Failures", cwe: ["CWE-798"], mitre: ["T1552.004"] },
  "putty-key":         { owasp: "A02:2021 – Cryptographic Failures", cwe: ["CWE-798"], mitre: ["T1552.004"] },
  "pkcs12":            { owasp: "A02:2021 – Cryptographic Failures", cwe: ["CWE-798"], mitre: ["T1552.004"] },

  // ── Injection surface (we DETECT, we do not exploit) ────────────────────
  "reflected-param":   { owasp: "A03:2021 – Injection", cwe: ["CWE-79"], mitre: ["T1059.007"] },
  "graphql-introspection": { owasp: "A05:2021 – Security Misconfiguration", cwe: ["CWE-200"], mitre: ["T1213"] },

  // ── Insecure design ─────────────────────────────────────────────────────
  "wp-xmlrpc":         { owasp: "A04:2021 – Insecure Design", cwe: ["CWE-693"], mitre: ["T1499.003"] },
  "wp-cron":           { owasp: "A04:2021 – Insecure Design", cwe: ["CWE-693"], mitre: ["T1499.003"] },

  // ── Security misconfiguration (main bucket) ─────────────────────────────
  "git-":              { owasp: "A05:2021 – Security Misconfiguration", cwe: ["CWE-538", "CWE-540"], mitre: ["T1213"] },
  "svn-":              { owasp: "A05:2021 – Security Misconfiguration", cwe: ["CWE-538", "CWE-540"], mitre: ["T1213"] },
  "hg-":               { owasp: "A05:2021 – Security Misconfiguration", cwe: ["CWE-538"], mitre: ["T1213"] },
  "bzr-":              { owasp: "A05:2021 – Security Misconfiguration", cwe: ["CWE-538"], mitre: ["T1213"] },
  "env":               { owasp: "A05:2021 – Security Misconfiguration", cwe: ["CWE-538", "CWE-798"], mitre: ["T1552.001"] },
  "env-":              { owasp: "A05:2021 – Security Misconfiguration", cwe: ["CWE-538", "CWE-798"], mitre: ["T1552.001"] },
  "aws-creds":         { owasp: "A05:2021 – Security Misconfiguration", cwe: ["CWE-798"], mitre: ["T1552.001"] },
  "npmrc":             { owasp: "A05:2021 – Security Misconfiguration", cwe: ["CWE-798"], mitre: ["T1552.001"] },
  "pypirc":            { owasp: "A05:2021 – Security Misconfiguration", cwe: ["CWE-798"], mitre: ["T1552.001"] },
  "netrc":             { owasp: "A05:2021 – Security Misconfiguration", cwe: ["CWE-798"], mitre: ["T1552.001"] },
  "ds-store":          { owasp: "A05:2021 – Security Misconfiguration", cwe: ["CWE-538"], mitre: ["T1083"] },
  "htaccess":          { owasp: "A05:2021 – Security Misconfiguration", cwe: ["CWE-538"], mitre: ["T1213"] },
  "phpinfo":           { owasp: "A05:2021 – Security Misconfiguration", cwe: ["CWE-200"], mitre: ["T1082"] },
  "phpinfo-":          { owasp: "A05:2021 – Security Misconfiguration", cwe: ["CWE-200"], mitre: ["T1082"] },
  "apache-status":     { owasp: "A05:2021 – Security Misconfiguration", cwe: ["CWE-200"], mitre: ["T1082"] },
  "apache-info":       { owasp: "A05:2021 – Security Misconfiguration", cwe: ["CWE-200"], mitre: ["T1082"] },
  "nginx-status":      { owasp: "A05:2021 – Security Misconfiguration", cwe: ["CWE-200"], mitre: ["T1082"] },
  "adminer":           { owasp: "A05:2021 – Security Misconfiguration", cwe: ["CWE-16"], mitre: ["T1190"] },
  "phpmyadmin":        { owasp: "A05:2021 – Security Misconfiguration", cwe: ["CWE-16"], mitre: ["T1190"] },
  "phpmyadmin-pma":    { owasp: "A05:2021 – Security Misconfiguration", cwe: ["CWE-16"], mitre: ["T1190"] },
  "source-map":        { owasp: "A05:2021 – Security Misconfiguration", cwe: ["CWE-540"], mitre: ["T1213"] },
  "dir-listing":       { owasp: "A05:2021 – Security Misconfiguration", cwe: ["CWE-548"], mitre: ["T1083"] },
  "wp-debug-log":      { owasp: "A05:2021 – Security Misconfiguration", cwe: ["CWE-532"], mitre: ["T1005"] },
  "wp-uploads-listing":{ owasp: "A05:2021 – Security Misconfiguration", cwe: ["CWE-548"], mitre: ["T1083"] },
  "swagger-ui":        { owasp: "A05:2021 – Security Misconfiguration", cwe: ["CWE-200"], mitre: ["T1213"] },
  "swagger-json":      { owasp: "A05:2021 – Security Misconfiguration", cwe: ["CWE-200"], mitre: ["T1213"] },
  "swagger-ui-alt":    { owasp: "A05:2021 – Security Misconfiguration", cwe: ["CWE-200"], mitre: ["T1213"] },
  "openapi-json":      { owasp: "A05:2021 – Security Misconfiguration", cwe: ["CWE-200"], mitre: ["T1213"] },
  "api-docs":          { owasp: "A05:2021 – Security Misconfiguration", cwe: ["CWE-200"], mitre: ["T1213"] },
  "package-json":      { owasp: "A05:2021 – Security Misconfiguration", cwe: ["CWE-200"], mitre: ["T1592.002"] },
  "package-lock":      { owasp: "A05:2021 – Security Misconfiguration", cwe: ["CWE-200"], mitre: ["T1592.002"] },
  "composer-json":     { owasp: "A05:2021 – Security Misconfiguration", cwe: ["CWE-200"], mitre: ["T1592.002"] },
  "composer-lock":     { owasp: "A05:2021 – Security Misconfiguration", cwe: ["CWE-200"], mitre: ["T1592.002"] },
  "yarn-lock":         { owasp: "A05:2021 – Security Misconfiguration", cwe: ["CWE-200"], mitre: ["T1592.002"] },
  "gemfile-lock":      { owasp: "A05:2021 – Security Misconfiguration", cwe: ["CWE-200"], mitre: ["T1592.002"] },
  "requirements-txt":  { owasp: "A05:2021 – Security Misconfiguration", cwe: ["CWE-200"], mitre: ["T1592.002"] },
  "dockerfile":        { owasp: "A05:2021 – Security Misconfiguration", cwe: ["CWE-200"], mitre: ["T1596.005"] },
  "compose":           { owasp: "A05:2021 – Security Misconfiguration", cwe: ["CWE-200"], mitre: ["T1596.005"] },
  "prometheus-metrics":{ owasp: "A05:2021 – Security Misconfiguration", cwe: ["CWE-200"], mitre: ["T1082"] },
  "kube-api":          { owasp: "A05:2021 – Security Misconfiguration", cwe: ["CWE-306"], mitre: ["T1190"] },
  "kube-version":      { owasp: "A05:2021 – Security Misconfiguration", cwe: ["CWE-200"], mitre: ["T1082"] },
  "docker-registry":   { owasp: "A05:2021 – Security Misconfiguration", cwe: ["CWE-284"], mitre: ["T1069"] },
  "cloud-metadata-proxy": { owasp: "A10:2021 – SSRF", cwe: ["CWE-918"], mitre: ["T1552.005"] },

  // ── Debug / dev endpoints ───────────────────────────────────────────────
  "generic-debug":     { owasp: "A05:2021 – Security Misconfiguration", cwe: ["CWE-489"], mitre: ["T1082"] },
  "go-pprof":          { owasp: "A05:2021 – Security Misconfiguration", cwe: ["CWE-489", "CWE-200"], mitre: ["T1082"] },
  "go-expvar":         { owasp: "A05:2021 – Security Misconfiguration", cwe: ["CWE-489"], mitre: ["T1082"] },
  "laravel-telescope": { owasp: "A05:2021 – Security Misconfiguration", cwe: ["CWE-489"], mitre: ["T1005"] },
  "symfony-profiler":  { owasp: "A05:2021 – Security Misconfiguration", cwe: ["CWE-489"], mitre: ["T1005"] },
  "health":            { owasp: "A05:2021 – Security Misconfiguration", cwe: ["CWE-200"], mitre: ["T1082"] },

  // ── Vulnerable & outdated components ────────────────────────────────────
  "outdated":          { owasp: "A06:2021 – Vulnerable & Outdated Components", cwe: ["CWE-1104"], mitre: ["T1190"] },
  "eol":               { owasp: "A06:2021 – Vulnerable & Outdated Components", cwe: ["CWE-1104", "CWE-1329"], mitre: ["T1190"] },
  "cve":               { owasp: "A06:2021 – Vulnerable & Outdated Components", cwe: ["CWE-1104"], mitre: ["T1190"] },
  "wp-plugin-risk-":   { owasp: "A06:2021 – Vulnerable & Outdated Components", cwe: ["CWE-1104"], mitre: ["T1190"] },

  // ── Identification / authentication failures ────────────────────────────
  "wp-plugins":        { owasp: "A06:2021 – Vulnerable & Outdated Components", cwe: ["CWE-1104"], mitre: ["T1592.002"] },
  "wp-themes":         { owasp: "A06:2021 – Vulnerable & Outdated Components", cwe: ["CWE-1104"], mitre: ["T1592.002"] },
  "wp-readme":         { owasp: "A05:2021 – Security Misconfiguration", cwe: ["CWE-200"], mitre: ["T1592.002"] },

  // ── Software & data integrity ───────────────────────────────────────────
  "takeover-":         { owasp: "A08:2021 – Software & Data Integrity Failures", cwe: ["CWE-350"], mitre: ["T1584.001"] },

  // ── Security logging & monitoring ───────────────────────────────────────
  // (unused; kept for future rules)

  // ── SSRF ─────────────────────────────────────────────────────────────────

  // ── Secret exposure (main bucket) ───────────────────────────────────────
  "aws-":              { owasp: "A07:2021 – Identification & Authentication Failures", cwe: ["CWE-798"], mitre: ["T1552.001"] },
  "azure-":            { owasp: "A07:2021 – Identification & Authentication Failures", cwe: ["CWE-798"], mitre: ["T1552.001"] },
  "google-":           { owasp: "A07:2021 – Identification & Authentication Failures", cwe: ["CWE-798"], mitre: ["T1552.001"] },
  "gcp-":              { owasp: "A07:2021 – Identification & Authentication Failures", cwe: ["CWE-798"], mitre: ["T1552.001"] },
  "github-":           { owasp: "A07:2021 – Identification & Authentication Failures", cwe: ["CWE-798"], mitre: ["T1552.004"] },
  "gitlab-":           { owasp: "A07:2021 – Identification & Authentication Failures", cwe: ["CWE-798"], mitre: ["T1552.004"] },
  "slack-":            { owasp: "A07:2021 – Identification & Authentication Failures", cwe: ["CWE-798"], mitre: ["T1552.004"] },
  "stripe-":           { owasp: "A07:2021 – Identification & Authentication Failures", cwe: ["CWE-798"], mitre: ["T1552.001"] },
  "sendgrid":          { owasp: "A07:2021 – Identification & Authentication Failures", cwe: ["CWE-798"], mitre: ["T1552.001"] },
  "twilio-":           { owasp: "A07:2021 – Identification & Authentication Failures", cwe: ["CWE-798"], mitre: ["T1552.001"] },
  "openai-":           { owasp: "A07:2021 – Identification & Authentication Failures", cwe: ["CWE-798"], mitre: ["T1552.001"] },
  "anthropic-":        { owasp: "A07:2021 – Identification & Authentication Failures", cwe: ["CWE-798"], mitre: ["T1552.001"] },
  "db-uri":            { owasp: "A07:2021 – Identification & Authentication Failures", cwe: ["CWE-798"], mitre: ["T1552.001"] },
  "basic-auth-url":    { owasp: "A07:2021 – Identification & Authentication Failures", cwe: ["CWE-798"], mitre: ["T1552.001"] },
  "basic-auth-header": { owasp: "A07:2021 – Identification & Authentication Failures", cwe: ["CWE-798"], mitre: ["T1552.001"] },
  "kube-config":       { owasp: "A07:2021 – Identification & Authentication Failures", cwe: ["CWE-798"], mitre: ["T1552.007"] },

  // ── Security header hygiene ─────────────────────────────────────────────
  "csp":               { owasp: "A05:2021 – Security Misconfiguration", cwe: ["CWE-693"], mitre: ["T1059.007"] },
  "hsts":              { owasp: "A02:2021 – Cryptographic Failures", cwe: ["CWE-319"], mitre: ["T1557"] },
  "xfo":               { owasp: "A05:2021 – Security Misconfiguration", cwe: ["CWE-1021"], mitre: ["T1189"] },
  "cors":              { owasp: "A05:2021 – Security Misconfiguration", cwe: ["CWE-942", "CWE-346"], mitre: ["T1190"] }
};

// Longest-prefix match against known keys so specific rules win over general.
export function classifyFinding(finding) {
  if (!finding) return null;
  const id = String(finding.id || "").toLowerCase();
  const title = String(finding.title || "").toLowerCase();

  // Exact match first.
  if (MAP[id]) return MAP[id];

  // Longest matching prefix.
  let best = null, bestLen = 0;
  for (const key of Object.keys(MAP)) {
    if (id.startsWith(key) && key.length > bestLen) { best = MAP[key]; bestLen = key.length; }
  }
  if (best) return best;

  // Fall back to keyword sniffing from title.
  if (/csp|content-security-policy/i.test(title)) return MAP.csp;
  if (/hsts|strict-transport/i.test(title)) return MAP.hsts;
  if (/x-frame-options|clickjack/i.test(title)) return MAP.xfo;
  if (/cors/i.test(title)) return MAP.cors;
  if (/eol|end-of-life/i.test(title)) return MAP.eol;
  if (/outdated/i.test(title)) return MAP.outdated;

  return { owasp: "Unclassified", cwe: [], mitre: [] };
}

// Enrich a full report's findings in place with taxonomy metadata.
// Adds `.taxonomy = { owasp, cwe, mitre }` to each item.
export function enrichWithTaxonomy(report) {
  if (!report) return;
  const buckets = [
    ...(report.security || []),
    ...(report.secrets || []),
    ...(report.exposures || []),
    ...(report.activeScan || [])
  ];
  for (const f of buckets) {
    if (!f.taxonomy) f.taxonomy = classifyFinding(f);
  }
  // CVEs are classified as A06 (vulnerable components) across the board.
  for (const t of (report.tech || [])) {
    for (const c of (t.cves || [])) {
      c.taxonomy = { owasp: "A06:2021 – Vulnerable & Outdated Components", cwe: ["CWE-1104"], mitre: ["T1190"] };
    }
    if (t.outdated) t.outdated.taxonomy = MAP.outdated;
  }
}
