// ReconHound — Safe verification checks (ACTIVE, non-destructive)
// These confirm whether a weakness is likely PRESENT using benign canary values
// and signature checks — NOT weaponized payloads. They never attempt to execute
// code, modify data, or cause harm. Results flag surfaces for MANUAL confirmation.

// Unique, harmless canary token (no HTML/script — just a marker string).
function canary() {
  return "RHCANARY" + Math.random().toString(36).slice(2, 10).toUpperCase();
}

async function getText(url, timeoutMs = 6000) {
  const controller = new AbortController();
  const t = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const res = await fetch(url, { method: "GET", credentials: "omit", redirect: "follow", signal: controller.signal });
    clearTimeout(t);
    const text = (await res.text()).slice(0, 200000);
    return { status: res.status, text, ctype: res.headers.get("content-type") || "" };
  } catch (_) {
    clearTimeout(t);
    return null;
  }
}

// ─── Context classification for a reflection ───────────────────────────
// Given the response body and the offset of the canary, work outwards to
// classify WHERE the canary landed. We do NOT send any payload — this is
// pure string inspection of the benign canary's placement.
//
// Contexts we recognise (ranked by realistic XSS-risk):
//   · js-block           — inside a `<script>...</script>` and not in a string literal
//   · js-string          — inside a `<script>...</script>` between quotes
//   · attr-event         — value of an `on*` HTML attribute
//   · attr-href-src      — inside href / src / action / formaction (URL context)
//   · attr-style         — inside a `style="..."` attribute (CSS context)
//   · attr-quoted        — inside a normal attribute wrapped in quotes
//   · attr-unquoted      — inside an unquoted attribute (very risky)
//   · css-block          — inside a `<style>...</style>` block
//   · html-tag           — landed inside a tag name / raw HTML nodetext
//   · html-comment       — inside `<!-- ... -->`
//   · html-text          — inside plain text between tags (baseline reflected)
//   · unknown            — could not classify
function classifyContext(body, offset) {
  if (offset < 0) return "unknown";
  // Only the preceding 500 chars are needed for context classification —
  // tag/attribute state is determined by the last-unclosed open before us.
  const before = body.slice(Math.max(0, offset - 500), offset);

  // Are we inside a <script> block?
  const lastScriptOpen  = before.toLowerCase().lastIndexOf("<script");
  const lastScriptClose = before.toLowerCase().lastIndexOf("</script");
  const insideScript    = lastScriptOpen > lastScriptClose;

  // Inside a <style> block?
  const lastStyleOpen  = before.toLowerCase().lastIndexOf("<style");
  const lastStyleClose = before.toLowerCase().lastIndexOf("</style");
  const insideStyle    = lastStyleOpen > lastStyleClose;

  // Inside an HTML comment?
  const lastCommentOpen  = before.lastIndexOf("<!--");
  const lastCommentClose = before.lastIndexOf("-->");
  const insideComment    = lastCommentOpen > lastCommentClose;

  if (insideComment) return "html-comment";

  if (insideScript) {
    // Simple heuristic: count unescaped quotes between the last `<script>` and
    // the canary. If we're inside a string literal (odd count), it's js-string;
    // otherwise js-block.
    const inScript = before.slice(lastScriptOpen);
    const singleQuotes = (inScript.match(/(?<!\\)'/g) || []).length;
    const doubleQuotes = (inScript.match(/(?<!\\)"/g) || []).length;
    const backticks   = (inScript.match(/(?<!\\)`/g) || []).length;
    if ((singleQuotes % 2) || (doubleQuotes % 2) || (backticks % 2)) return "js-string";
    return "js-block";
  }

  if (insideStyle) return "css-block";

  // Are we inside an HTML attribute?
  // Look at the last `<tagname ...` before us — if there's an opened `="` or
  // `='` without matching close, we're in a quoted attribute.
  const lastTagOpen = before.lastIndexOf("<");
  const lastTagClose = before.lastIndexOf(">");
  const insideTag = lastTagOpen > lastTagClose;

  if (insideTag) {
    // What's the last attribute name/value pair fragment?
    const tagFragment = before.slice(lastTagOpen);
    // Find the attribute name we're mid-value of.
    const attrRe = /([a-zA-Z_:][\w:.-]*)\s*=\s*(["'])?([^"'>\s]*)$/;
    const m = tagFragment.match(attrRe);
    if (m) {
      const attrName = m[1].toLowerCase();
      const quote = m[2] || null;
      // Event handlers → most dangerous (XSS in one keystroke).
      if (/^on/.test(attrName)) return "attr-event";
      // URL-context attributes → javascript: risk.
      if (["href", "src", "action", "formaction", "data", "poster", "background", "cite"].includes(attrName)) return "attr-href-src";
      // Style attribute → CSS context.
      if (attrName === "style") return "attr-style";
      if (!quote) return "attr-unquoted";
      return "attr-quoted";
    }
    return "html-tag";
  }

  return "html-text";
}

function contextSeverity(ctx) {
  switch (ctx) {
    case "js-block":
    case "attr-event":
    case "attr-unquoted":
      return "HIGH";
    case "js-string":
    case "attr-href-src":
    case "attr-style":
    case "css-block":
      return "MEDIUM";
    case "attr-quoted":
    case "html-text":
    case "html-tag":
      return "MEDIUM";
    case "html-comment":
      return "LOW";
    default:
      return "LOW";
  }
}

function contextDetail(ctx, param) {
  const base = `User-controlled parameter "${param}" is reflected in the response`;
  switch (ctx) {
    case "js-block":     return base + " inside a `<script>` block — arbitrary JavaScript can be injected if not sanitized. Verify with manual XSS testing tooling.";
    case "js-string":    return base + " inside a JS string literal — an unescaped quote character escapes the string and enables JS injection. Verify with manual XSS testing tooling.";
    case "attr-event":   return base + " inside an on* event-handler attribute — direct JS execution surface. Verify with manual XSS testing tooling.";
    case "attr-href-src":return base + " inside a URL-context attribute (href/src/action/…) — javascript:-URI attacks possible if not filtered. Verify with manual XSS testing tooling.";
    case "attr-style":   return base + " inside a style=\"…\" attribute — CSS expression / url(javascript:) surface. Verify with manual XSS testing tooling.";
    case "attr-unquoted":return base + " inside an unquoted attribute — a single space/tab breaks out into a new attribute (e.g. onmouseover=). Verify with manual XSS testing tooling.";
    case "attr-quoted":  return base + " inside a quoted HTML attribute — a quote character escapes the attribute. Verify with manual XSS testing tooling.";
    case "css-block":    return base + " inside a `<style>` block — CSS injection surface. Verify with manual XSS testing tooling.";
    case "html-tag":     return base + " inside HTML markup — tag-injection surface. Verify with manual XSS testing tooling.";
    case "html-text":    return base + " inside HTML body text — baseline reflection; XSS requires the ability to inject '<' and '>'. Verify with manual XSS testing tooling.";
    case "html-comment": return base + " inside an HTML comment — low risk unless the comment is server-rendered without escaping.";
    default:             return base + ". Manually verify.";
  }
}

// Reflected-parameter probe: substitute a benign canary into each query param
// and detect (a) whether it is reflected and (b) the OUTPUT CONTEXT it lands
// in. We do NOT deliver XSS payloads — only the canary letter/digit token.
// Manual verification with a dedicated XSS tool is always required.
export async function reflectionProbe(pageUrl, params = [], maxParams = 16) {
  let base;
  try { base = new URL(pageUrl); } catch (_) { return []; }
  if (!/^https?:$/.test(base.protocol)) return [];

  const candidate = new Set();
  base.searchParams.forEach((_, k) => candidate.add(k));
  params.forEach((p) => candidate.add(p));
  const list = [...candidate].slice(0, maxParams);
  if (!list.length) return [];

  const findings = [];
  const queue = [...list];

  async function worker() {
    while (queue.length) {
      const param = queue.shift();
      const mark = canary();
      const u = new URL(base.toString());
      u.searchParams.set(param, mark);
      const res = await getText(u.toString());
      if (!res || !/html/i.test(res.ctype)) continue;
      const offset = res.text.indexOf(mark);
      if (offset < 0) continue;

      // How many times is the canary reflected? Some sinks echo twice.
      let count = 0, idx = -1;
      while ((idx = res.text.indexOf(mark, idx + 1)) !== -1) count++;

      // Was the canary HTML-encoded? (Would only matter if we injected <, but
      // we don't — encoded reflection would just mean the app does encode.)
      const encoded = res.text.includes(`&#${mark.charCodeAt(0)}`);

      const context = classifyContext(res.text, offset);
      const severity = contextSeverity(context);

      findings.push({
        id: "reflected-param-" + context,
        title: `Reflected parameter "${param}" — ${context} context (×${count})`,
        severity,
        url: u.toString(),
        detail: contextDetail(context, param) + (encoded ? " (server appears to HTML-encode some characters — verify which.)" : ""),
        verified: true,
        needsManual: true,
        xssSurface: {
          param,
          context,
          reflections: count,
          encoded
        }
      });
    }
  }

  await Promise.all(Array.from({ length: 4 }, worker));
  return findings;
}

// Directory-listing probe: confirms an open directory index (safe GET).
export async function directoryListingProbe(origin, paths = ["/uploads/", "/images/", "/files/", "/assets/", "/backup/"]) {
  const base = origin.replace(/\/$/, "");
  const findings = [];
  await Promise.all(
    paths.map(async (p) => {
      const url = base + p;
      const res = await getText(url);
      if (res && res.status < 400 && /<title>\s*Index of\s*\/|Directory listing for/i.test(res.text)) {
        findings.push({
          id: "dir-listing",
          title: `Open directory listing at ${p}`,
          severity: "MEDIUM",
          url,
          detail: "Server returns a browsable directory index — may expose files not meant to be public.",
          verified: true
        });
      }
    })
  );
  return findings;
}

