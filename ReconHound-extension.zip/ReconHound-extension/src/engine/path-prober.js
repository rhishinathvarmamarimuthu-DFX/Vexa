// ReconHound — Sensitive path prober (ACTIVE scan)
// Sends real HTTP requests to common sensitive paths and reports which exist.
// This is ACTIVE reconnaissance and only runs after explicit user consent
// confirming the target is authorized for testing.

const PATHS = [
  { path: "/robots.txt", severity: "LOW", note: "Crawler rules; may reveal hidden paths.", expectNonHtml: true },
  { path: "/sitemap.xml", severity: "LOW", note: "Site structure disclosure.", expectNonHtml: true },
  { path: "/.git/HEAD", severity: "HIGH", note: "Exposed Git repo — source code leak.", expectNonHtml: true },
  { path: "/.git/config", severity: "HIGH", note: "Exposed Git config — repo/remote leak.", expectNonHtml: true },
  { path: "/.env", severity: "CRITICAL", note: "Environment file — secrets/credentials leak.", expectNonHtml: true },
  { path: "/.svn/entries", severity: "HIGH", note: "Exposed SVN metadata.", expectNonHtml: true },
  { path: "/.DS_Store", severity: "MEDIUM", note: "Directory listing leak (macOS).", expectNonHtml: true },
  { path: "/config.php.bak", severity: "HIGH", note: "Backup config — possible secrets.", expectNonHtml: true },
  { path: "/backup.zip", severity: "HIGH", note: "Exposed backup archive.", expectNonHtml: true },
  { path: "/admin", severity: "MEDIUM", note: "Admin interface reachable." },
  { path: "/administrator", severity: "MEDIUM", note: "Admin interface reachable." },
  { path: "/wp-login.php", severity: "LOW", note: "WordPress login present." },
  { path: "/wp-json/wp/v2/users", severity: "MEDIUM", note: "WP REST API user enumeration.", expectNonHtml: true },
  { path: "/phpinfo.php", severity: "HIGH", note: "phpinfo() — full PHP config disclosure." },
  { path: "/server-status", severity: "MEDIUM", note: "Apache server-status exposed." },
  { path: "/actuator", severity: "HIGH", note: "Spring Boot Actuator exposed.", expectNonHtml: true },
  { path: "/actuator/env", severity: "CRITICAL", note: "Spring env — secrets disclosure.", expectNonHtml: true },
  { path: "/swagger-ui.html", severity: "MEDIUM", note: "Swagger UI — API surface disclosure." },
  { path: "/api/swagger.json", severity: "MEDIUM", note: "OpenAPI spec — API surface disclosure.", expectNonHtml: true },
  { path: "/.well-known/security.txt", severity: "LOW", note: "Security contact info.", expectNonHtml: true }
];

// Probe a single path; treat 200/401/403 as "exists" signals.
async function probe(origin, entry, timeoutMs = 6000) {
  const url = origin.replace(/\/$/, "") + entry.path;
  const controller = new AbortController();
  const t = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const res = await fetch(url, {
      method: "GET",
      redirect: "follow",
      credentials: "omit",
      signal: controller.signal
    });
    clearTimeout(t);
    const status = res.status;
    // 404/410/301-302 landing on generic pages ⇒ noise. Only report clear signals:
    //   200 → present
    //   401/403 → present-but-protected
    //   500/503 → route exists (produced a server-side error)
    // We also filter out HTML-looking bodies for path expected to return non-HTML.
    const clearlyExists = status === 200 || status === 401 || status === 403 || status === 500 || status === 503;
    if (!clearlyExists) return null;

    // For paths that should NOT return HTML (e.g. /.git/HEAD, /.env, /*.sql),
    // reject responses that look like the site's HTML fallback template.
    if (entry.expectNonHtml && status === 200) {
      const ctype = res.headers.get("content-type") || "";
      if (/text\/html/i.test(ctype)) {
        const sample = (await res.text()).slice(0, 512);
        if (/<html|<!doctype/i.test(sample)) return null;
      }
    }
    return { ...entry, url, status };
  } catch (_) {
    clearTimeout(t);
    return null;
  }
}

// Run all probes with limited concurrency to avoid hammering the target.
export async function probePaths(origin, concurrency = 4) {
  const queue = [...PATHS];
  const results = [];

  async function worker() {
    while (queue.length) {
      const entry = queue.shift();
      const hit = await probe(origin, entry);
      if (hit) results.push(hit);
    }
  }

  await Promise.all(Array.from({ length: concurrency }, worker));
  const weight = { CRITICAL: 4, HIGH: 3, MEDIUM: 2, LOW: 1 };
  return results.sort((a, b) => (weight[b.severity] || 0) - (weight[a.severity] || 0));
}

