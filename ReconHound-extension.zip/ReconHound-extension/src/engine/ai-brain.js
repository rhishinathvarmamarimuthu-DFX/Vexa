// ReconHound — "AI Brain" exploit-intelligence reasoning engine
// Fuses multiple authoritative signals into an exploitability verdict per CVE
// and an overall target assessment. Sources:
//   - CVSS base score (NVD)            → technical severity
//   - CISA KEV                         → confirmed real-world exploitation
//   - EPSS (FIRST.org)                 → probability of exploitation (next 30d)
//   - Public PoC / Metasploit / Nuclei → exploit tooling availability
// It does NOT run exploits — it decides what is worth exploiting and why.

import { markSourceOk, markSourceDown } from "./source-status.js";

const EPSS_API = "https://api.first.org/data/v1/epss";
const epssCache = new Map(); // cveId -> { epss, percentile }

// Batch-fetch EPSS scores for a set of CVE IDs (chunked).
export async function fetchEpss(cveIds = []) {
  const need = [...new Set(cveIds)].filter((id) => id && !epssCache.has(id));
  for (let i = 0; i < need.length; i += 90) {
    const chunk = need.slice(i, i + 90);
    try {
      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), 7000);
      const res = await fetch(`${EPSS_API}?cve=${encodeURIComponent(chunk.join(","))}`, { signal: controller.signal });
      clearTimeout(timer);
      if (!res.ok) { markSourceDown("epss", `HTTP ${res.status}`); continue; }
      const json = await res.json();
      markSourceOk("epss");
      for (const row of json.data || []) {
        epssCache.set(row.cve, {
          epss: parseFloat(row.epss) || 0,
          percentile: parseFloat(row.percentile) || 0
        });
      }
    } catch (err) {
      markSourceDown("epss", String(err && err.message || err));
      // network failure — continue without EPSS for this chunk
    }
  }
  const out = {};
  for (const id of cveIds) out[id] = epssCache.get(id) || null;
  return out;
}

// Fuse one CVE's signals into an exploitability score (0-100) + verdict + reasoning.
export function assessCve(cve, epss) {
  const cvss = cve.score || 0;
  const p = epss ? epss.epss : 0;

  let score = 0;
  score += cvss * 4;                 // up to 40 (CVSS 10 → 40)
  score += p * 35;                   // up to 35 (EPSS prob)
  if (cve.kev) score += 30;          // confirmed exploited
  if (cve.ransomware) score += 15;   // ransomware usage
  if (cve.exploitAvailable) score += 8;
  score = Math.min(100, Math.round(score));

  let verdict, cls;
  if (cve.kev || score >= 80) { verdict = "WEAPONIZED"; cls = "weaponized"; }
  else if (score >= 55) { verdict = "LIKELY EXPLOITABLE"; cls = "likely"; }
  else if (score >= 30) { verdict = "POSSIBLE"; cls = "possible"; }
  else { verdict = "LOW PRIORITY"; cls = "low"; }

  const reasons = [];
  if (cve.kev) reasons.push("listed in CISA KEV (actively exploited in the wild)");
  if (cve.ransomware) reasons.push("used in known ransomware campaigns");
  if (p >= 0.5) reasons.push(`EPSS ${(p * 100).toFixed(1)}% — high near-term exploitation probability`);
  else if (p > 0) reasons.push(`EPSS ${(p * 100).toFixed(1)}% exploitation probability`);
  if (cvss >= 9) reasons.push(`critical CVSS ${cvss}`);
  else if (cvss >= 7) reasons.push(`high CVSS ${cvss}`);
  if (cve.confidence === "confirmed") reasons.push("version-confirmed affected");
  if (!reasons.length) reasons.push("limited public exploit signal");

  let action;
  if (verdict === "WEAPONIZED") action = "Patch immediately. Validate with the linked Metasploit/Nuclei module in your authorized lab.";
  else if (verdict === "LIKELY EXPLOITABLE") action = "Prioritize remediation. Confirm exploitability with the linked PoC/Nuclei template.";
  else if (verdict === "POSSIBLE") action = "Schedule remediation; manually verify with available PoCs.";
  else action = "Track and patch in normal cycle.";

  return {
    exploitability: score,
    verdict,
    verdictClass: cls,
    epss: p,
    epssPercentile: epss ? epss.percentile : 0,
    reasoning: reasons.join("; ") + ".",
    action
  };
}

// Run the brain over a full report: enrich every CVE and produce an overall
// target assessment with prioritized findings and a narrative headline.
export async function runBrain(report) {
  const allCves = [];
  for (const t of report.tech || []) {
    for (const c of t.cves || []) allCves.push({ tech: t, cve: c });
  }

  const epssMap = await fetchEpss(allCves.map(({ cve }) => cve.id));

  for (const { cve } of allCves) {
    Object.assign(cve, assessCve(cve, epssMap[cve.id]));
  }

  // Sort each tech's CVEs by exploitability.
  for (const t of report.tech || []) {
    (t.cves || []).sort((a, b) => (b.exploitability || 0) - (a.exploitability || 0));
  }

  const ranked = allCves
    .map(({ tech, cve }) => ({
      id: cve.id,
      tech: `${tech.tech} ${tech.version || ""}`.trim(),
      severity: cve.severity,
      score: cve.score,
      exploitability: cve.exploitability,
      verdict: cve.verdict,
      verdictClass: cve.verdictClass,
      epss: cve.epss,
      kev: cve.kev,
      ransomware: cve.ransomware,
      reasoning: cve.reasoning,
      action: cve.action,
      nvd: cve.nvd,
      metasploit: cve.metasploit,
      nuclei: cve.nuclei,
      githubPoc: cve.githubPoc,
      exploitDb: cve.exploitDb
    }))
    .sort((a, b) => (b.exploitability || 0) - (a.exploitability || 0));

  const weaponized = ranked.filter((r) => r.verdict === "WEAPONIZED").length;
  const likely = ranked.filter((r) => r.verdict === "LIKELY EXPLOITABLE").length;
  const secretsN = (report.secrets || []).length;
  const exposuresN = (report.exposures || []).length;

  // Overall exploitability = strongest single CVE blended with breadth.
  const top = ranked[0]?.exploitability || 0;
  const overall = Math.min(100, Math.round(top * 0.8 + Math.min(20, ranked.length * 2)));

  let headline;
  if (weaponized > 0)
    headline = `🔴 ${weaponized} weaponized vulnerability(ies) present — exploitation tooling exists and is in active use. Treat as high-likelihood compromise.`;
  else if (likely > 0)
    headline = `🟠 ${likely} likely-exploitable vulnerability(ies) detected. Public PoCs/high EPSS — prioritize validation.`;
  else if (secretsN || exposuresN)
    headline = `🟡 No weaponized CVEs, but ${secretsN} secret(s) and ${exposuresN} exposure(s) provide a viable attack path.`;
  else if (ranked.length)
    headline = `🟢 Known CVEs present but low current exploit signal. Patch in normal cycle.`;
  else
    headline = `🟢 No known CVEs correlated to the detected stack. Manual testing still recommended.`;

  report.brain = {
    overall,
    headline,
    counts: { weaponized, likely, total: ranked.length },
    top: ranked.slice(0, 12)
  };
  return report;
}

