// ReconHound — Form / DOM-sink / postMessage-listener analyser
// Author: Rhishinathvarma Marimuthu
//
// Consumes the raw catalogs the content-script produced (forms[], domSinks[],
// postMessageListeners[]) and turns them into ReconHound findings. All static
// analysis — no script execution, no state modification.

// ── Forms ────────────────────────────────────────────────────────────────
export function analyzeForms(forms = [], pageUrl = "") {
  const findings = [];
  for (const f of forms) {
    // Login-form heuristics
    if (f.hasPassword) {
      // Cross-origin password submission
      if (f.crossOrigin) {
        findings.push({
          id: "form-password-cross-origin",
          title: `Password form submits cross-origin → ${safeHost(f.action)}`,
          severity: "HIGH",
          url: f.action,
          detail: "Login form's action URL is a different origin from the page. Credentials leave the origin — verify this is intentional (federated SSO) and that the receiver is trusted.",
          verified: true
        });
      }
      // GET method with password
      if (f.method === "GET") {
        findings.push({
          id: "form-password-get",
          title: "Password form uses GET method",
          severity: "HIGH",
          url: f.action,
          detail: "Passwords sent as query-string are logged by proxies, browser history, and referer headers. Change to POST.",
          verified: true
        });
      }
      // Missing CSRF token on POST login form
      if (f.method === "POST" && !f.hasCsrf && !f.crossOrigin) {
        findings.push({
          id: "form-password-no-csrf",
          title: "Login form (POST) has no visible CSRF token",
          severity: "MEDIUM",
          url: f.action,
          detail: "No field matching csrf/authenticity_token/__RequestVerificationToken was found. Framework may handle CSRF via cookie-only patterns — verify.",
          verified: false,
          needsManual: true
        });
      }
      // autocomplete=off on password (deprecated - lowers security since browsers refuse to save)
      const pw = f.inputs.find((x) => x.type === "password");
      if (pw && pw.autocomplete && /off|new-password/i.test(pw.autocomplete)) {
        findings.push({
          id: "form-password-autocomplete-off",
          title: `Password input has autocomplete="${pw.autocomplete}"`,
          severity: "LOW",
          url: f.action,
          detail: "Modern guidance: prefer autocomplete=\"current-password\" or \"new-password\" over \"off\" — off encourages users to pick weaker passwords.",
          verified: true
        });
      }
    }
    // Non-password POST form without CSRF (mutating action)
    if (!f.hasPassword && f.method === "POST" && !f.hasCsrf && !f.crossOrigin) {
      // Only if action looks state-changing (not a search form)
      if (!/search|filter|query/i.test(f.action)) {
        findings.push({
          id: "form-post-no-csrf",
          title: `Mutating POST form without CSRF token → ${safePath(f.action)}`,
          severity: "LOW",
          url: f.action,
          detail: "POST form has no visible CSRF token. Framework may protect via SameSite cookies — verify against a full CSRF probe.",
          verified: false,
          needsManual: true
        });
      }
    }
  }
  return findings;
}

// ── DOM sinks ────────────────────────────────────────────────────────────
export function analyzeDomSinks(sinks = [], pageUrl = "") {
  const findings = [];
  // Aggregate counts per sink type
  const counts = new Map();
  for (const s of sinks) counts.set(s.name, (counts.get(s.name) || 0) + 1);
  for (const [name, n] of counts.entries()) {
    // Pick worst severity across occurrences
    const sev = sinks.find((x) => x.name === name)?.severity || "LOW";
    findings.push({
      id: "dom-sink-" + slugify(name),
      title: `Dangerous DOM sink present: ${name} (×${n})`,
      severity: sev,
      url: pageUrl,
      detail: `Static scan of inline scripts found ${n} occurrence(s) of ${name}. Trace back to user-controlled input to confirm XSS surface.`,
      verified: true,
      needsManual: true,
      samples: sinks.filter((x) => x.name === name).slice(0, 3).map((x) => x.context)
    });
  }
  return findings;
}

// ── postMessage listeners ────────────────────────────────────────────────
export function analyzePostMessageListeners(listeners = [], pageUrl = "") {
  const findings = [];
  const unchecked = listeners.filter((l) => !l.hasOriginCheck);
  const checked = listeners.filter((l) => l.hasOriginCheck);
  if (unchecked.length) {
    findings.push({
      id: "pm-listener-no-origin-check",
      title: `${unchecked.length} postMessage listener(s) without origin validation`,
      severity: "MEDIUM",
      url: pageUrl,
      detail: `Statically detected postMessage handlers that don't reference event.origin — potential postMessage XSS / cross-frame injection surface.`,
      verified: true,
      needsManual: true,
      samples: unchecked.slice(0, 3).map((x) => x.preview)
    });
  }
  if (checked.length) {
    findings.push({
      id: "pm-listener-with-origin-check",
      title: `${checked.length} postMessage listener(s) validate event.origin`,
      severity: "LOW",
      url: pageUrl,
      detail: `Static scan found postMessage handlers that reference event.origin — informational; verify the check is a strict allowlist, not a startsWith match.`,
      verified: true
    });
  }
  return findings;
}

// ── helpers ──────────────────────────────────────────────────────────────
function safeHost(u) { try { return new URL(u).host; } catch { return u; } }
function safePath(u) { try { return new URL(u).pathname; } catch { return u; } }
function slugify(s) { return String(s).toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "").slice(0, 40); }
