// ReconHound — Security analyzer
// Inspects response headers and cookies for missing protections and weak config.
// Useful for offensive recon: highlights attack surface and misconfigurations.

// Security headers that SHOULD be present. Absence = finding.
const EXPECTED_SECURITY_HEADERS = [
  {
    name: "content-security-policy",
    label: "Content-Security-Policy",
    severity: "HIGH",
    why: "No CSP — page is more exposed to XSS / data injection."
  },
  {
    name: "strict-transport-security",
    label: "Strict-Transport-Security (HSTS)",
    severity: "MEDIUM",
    why: "No HSTS — vulnerable to SSL-strip / downgrade attacks."
  },
  {
    name: "x-frame-options",
    label: "X-Frame-Options",
    severity: "MEDIUM",
    why: "No anti-framing — clickjacking possible (unless CSP frame-ancestors set)."
  },
  {
    name: "x-content-type-options",
    label: "X-Content-Type-Options",
    severity: "LOW",
    why: "Missing nosniff — MIME-sniffing attacks possible."
  },
  {
    name: "referrer-policy",
    label: "Referrer-Policy",
    severity: "LOW",
    why: "No referrer policy — may leak URLs to third parties."
  },
  {
    name: "permissions-policy",
    label: "Permissions-Policy",
    severity: "LOW",
    why: "No permissions policy — powerful browser features unrestricted."
  }
];

// Headers that LEAK information. Presence = finding.
const INFO_LEAK_HEADERS = [
  { name: "server", severity: "LOW", why: "Server software/version disclosed." },
  { name: "x-powered-by", severity: "LOW", why: "Backend technology disclosed." },
  { name: "x-aspnet-version", severity: "MEDIUM", why: "ASP.NET version disclosed." },
  { name: "x-aspnetmvc-version", severity: "MEDIUM", why: "ASP.NET MVC version disclosed." },
  { name: "x-generator", severity: "LOW", why: "CMS/generator disclosed." }
];

export function analyzeSecurityHeaders(responseHeaders = []) {
  const present = new Map();
  for (const h of responseHeaders) present.set(h.name.toLowerCase(), h.value || "");

  const findings = [];

  // 1. Missing protective headers
  for (const exp of EXPECTED_SECURITY_HEADERS) {
    if (!present.has(exp.name)) {
      findings.push({
        type: "missing-header",
        title: `Missing: ${exp.label}`,
        severity: exp.severity,
        detail: exp.why
      });
    }
  }

  // 2. Information-leak headers
  for (const leak of INFO_LEAK_HEADERS) {
    if (present.has(leak.name)) {
      findings.push({
        type: "info-leak",
        title: `Info disclosure: ${leak.name}: ${present.get(leak.name)}`,
        severity: leak.severity,
        detail: leak.why
      });
    }
  }

  // 3. Weak CSP heuristics
  const csp = present.get("content-security-policy");
  if (csp && /unsafe-inline|unsafe-eval|\*/.test(csp)) {
    findings.push({
      type: "weak-csp",
      title: "Weak CSP (unsafe-inline / unsafe-eval / wildcard)",
      severity: "MEDIUM",
      detail: "CSP present but uses unsafe directives, weakening XSS protection."
    });
  }

  return findings;
}

export function analyzeCookies(setCookieValues = []) {
  const findings = [];
  for (const raw of setCookieValues) {
    const name = (raw.split("=")[0] || "cookie").trim();
    const lower = raw.toLowerCase();
    const flags = [];
    if (!/;\s*httponly/.test(lower)) flags.push("HttpOnly");
    if (!/;\s*secure/.test(lower)) flags.push("Secure");
    if (!/;\s*samesite/.test(lower)) flags.push("SameSite");

    if (flags.length) {
      findings.push({
        type: "weak-cookie",
        title: `Cookie "${name}" missing: ${flags.join(", ")}`,
        severity: flags.includes("HttpOnly") ? "MEDIUM" : "LOW",
        detail: "Cookie lacks recommended security attributes (session theft / CSRF risk)."
      });
    }
  }
  return findings;
}

// CORS misconfiguration analysis from response headers.
export function analyzeCors(responseHeaders = []) {
  const map = new Map();
  for (const h of responseHeaders) map.set(h.name.toLowerCase(), h.value || "");

  const acao = map.get("access-control-allow-origin");
  const acac = (map.get("access-control-allow-credentials") || "").toLowerCase() === "true";
  const findings = [];

  if (!acao) return findings;

  if (acao === "*" && acac) {
    findings.push({
      type: "cors",
      title: "Insecure CORS: wildcard origin with credentials",
      severity: "HIGH",
      detail: "ACAO:* together with Allow-Credentials:true exposes authenticated data cross-origin."
    });
  } else if (acao === "*") {
    findings.push({
      type: "cors",
      title: "Permissive CORS: Access-Control-Allow-Origin: *",
      severity: "LOW",
      detail: "Any origin may read responses. Acceptable for public data, risky for private APIs."
    });
  } else if (acao === "null") {
    findings.push({
      type: "cors",
      title: "CORS allows 'null' origin",
      severity: "MEDIUM",
      detail: "'null' origin can be forged via sandboxed iframes/data URIs — potential cross-origin read."
    });
  } else if (acac) {
    findings.push({
      type: "cors",
      title: `CORS reflects a specific origin with credentials (${acao})`,
      severity: "MEDIUM",
      detail: "If the origin is reflected from the request, this enables cross-origin credentialed reads."
    });
  }

  return findings;
}

