// ReconHound — Evidence capture
// Author: Rhishinathvarma Marimuthu
//
// Records the request/response pair that proved a finding so it can be shown
// verbatim in the popup and exported into the HTML/Markdown reports. This is
// screenshot-ready courtroom-style evidence — timestamped, self-contained,
// non-repudiable.
//
// We DO NOT capture arbitrary secrets in evidence. Bodies are sanitised for
// obvious secret patterns before storage.

const MAX_BODY = 4096;
// Redaction is applied to captured response bodies BEFORE they are written to
// chrome.storage. Each pattern replaces the sensitive part with a fixed
// [REDACTED] marker while keeping a short leading capture group so context
// (variable name, prefix) is preserved for the operator.
const REDACT_PATTERNS = [
  // ── AWS ─────────────────────────────────────────────────────────────
  /(\b(?:AKIA|ASIA|AGPA|AIDA|AROA|AIPA|ANPA|ANVA|ASCA)[0-9A-Z]{16}\b)/g,
  /(\baws_secret_access_key\s*[=:]\s*['"]?)[A-Za-z0-9/+=]{40}(['"]?)/gi,
  /(\baws_session_token\s*[=:]\s*['"]?)[A-Za-z0-9/+=]{100,}/gi,
  // ── Azure ────────────────────────────────────────────────────────────
  /(DefaultEndpointsProtocol=https;AccountName=[a-z0-9]+;AccountKey=)[A-Za-z0-9+/=]{60,}/g,
  /(Endpoint=sb:\/\/[^;]+;SharedAccessKey(?:Name)?=)[^;\s'"]+/g,
  /(\bsig=)[A-Za-z0-9%]{40,}(&(?:se|sv|sr)=)/g,
  // ── GCP ──────────────────────────────────────────────────────────────
  /("type"\s*:\s*"service_account"[\s\S]{0,300}?"private_key"\s*:\s*")[\s\S]+?"/g,
  /(\bGOCSPX-)[0-9A-Za-z_-]{20,}/g,
  /(\bAIza)[0-9A-Za-z_-]{35}/g,          // Google API keys
  /(\bya29\.)[0-9A-Za-z_-]{20,}/g,       // Google OAuth
  // ── Source hosts ─────────────────────────────────────────────────────
  /(\b(?:ghp|gho|ghu|ghs|ghr)_)[0-9A-Za-z]{20,}/g,
  /(\bgithub_pat_)[0-9A-Za-z_]{20,}/g,
  /(\bglpat-)[0-9A-Za-z\-_]{15,}/g,
  // ── AI providers ─────────────────────────────────────────────────────
  /(\bsk-ant-)[A-Za-z0-9_-]{20,}/g,      // Anthropic
  /(\bsk-(?:proj-)?)[A-Za-z0-9_-]{20,}/g, // OpenAI (broader match)
  /(\bhf_)[A-Za-z0-9]{20,}/g,            // HuggingFace
  // ── Payments ─────────────────────────────────────────────────────────
  /(\b(?:sk|rk)_(?:live|test)_)[0-9a-zA-Z]{24,}/g,   // Stripe
  /(\bwhsec_)[A-Za-z0-9]{20,}/g,                     // Stripe webhook secret
  // ── Messaging ────────────────────────────────────────────────────────
  /(\bxox[baprs]-)[0-9]{10,13}-[0-9]{10,13}-[0-9A-Za-z]{20,}/g,
  /(https:\/\/hooks\.slack\.com\/services\/)[A-Z0-9]+\/[A-Z0-9]+\/[A-Za-z0-9]+/g,
  /(https:\/\/(?:canary\.|ptb\.)?discord(?:app)?\.com\/api\/webhooks\/)\d+\/[A-Za-z0-9_-]{40,}/g,
  // ── PEM / key blocks ─────────────────────────────────────────────────
  /(-----BEGIN (?:RSA |EC |DSA |OPENSSH |PGP |ENCRYPTED )?PRIVATE KEY(?: BLOCK)?-----)[\s\S]+?(-----END)/g,
  /(PuTTY-User-Key-File-[23]:[\s\S]{0,4000}?Private-MAC:\s*)[A-Fa-f0-9]+/g,
  // ── Generic bearer / basic / JWT ─────────────────────────────────────
  /(\bBearer\s+)[A-Za-z0-9\-._~+/]{20,}=*/g,
  /(\bAuthorization:\s*Basic\s+)[A-Za-z0-9+/=]{16,}/gi,
  /(\beyJ)[A-Za-z0-9_-]{10,}\.eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}/g,   // JWT
  // ── Database URIs with embedded credentials ──────────────────────────
  /((?:mongodb(?:\+srv)?|postgres(?:ql)?|mysql|redis|amqp):\/\/[^\s:@/]+:)[^\s:@/]+(@[^\s/'"]+)/gi,
  /(https?:\/\/[^\s:@/]+:)[^\s:@/]+(@[^\s/'"]+)/gi,
  // ── Kubeconfig ───────────────────────────────────────────────────────
  /(client-certificate-data:\s*)[A-Za-z0-9+/=]{80,}/g,
  /(client-key-data:\s*)[A-Za-z0-9+/=]{80,}/g,
  // ── Twilio / SendGrid / Mailgun ──────────────────────────────────────
  /(\bSG\.)[A-Za-z0-9_\-]{22}\.[A-Za-z0-9_\-]{40,}/g,
  /(\bAC)[0-9a-fA-F]{32}/g,              // Twilio SID
  /(\bSK)[0-9a-fA-F]{32}/g               // Twilio API Key
];

function sanitiseBody(body) {
  let s = String(body || "").slice(0, MAX_BODY);
  for (const re of REDACT_PATTERNS) {
    s = s.replace(re, (...args) => {
      // Signature: (match, group1, group2, …, offset, wholeString[, groups?])
      // Drop the trailing non-capture args (offset, wholeString, and any
      // named-groups object) so we only handle real capture groups.
      const trailing = typeof args[args.length - 1] === "object" ? 3 : 2;
      const captures = args.slice(1, args.length - trailing);
      const stringCaps = captures.filter((c) => typeof c === "string");
      // Convention across our patterns:
      //   · 0 string captures → redact the whole match
      //   · 1 string capture  → it's a leading identifier/prefix; keep it, redact the rest
      //   · 2 string captures → leading identifier + trailing context (e.g. "@host");
      //     preserve both so the redacted body still shows the surrounding shape.
      if (!stringCaps.length) return "[REDACTED-BY-RECONHOUND]";
      if (stringCaps.length === 1) return stringCaps[0] + "[REDACTED-BY-RECONHOUND]";
      return stringCaps[0] + "[REDACTED-BY-RECONHOUND]" + stringCaps[stringCaps.length - 1];
    });
  }
  return s;
}

function pickHeaders(headersObj, allowed = null) {
  const out = {};
  if (!headersObj) return out;
  const defaultAllowed = new Set([
    "content-type", "content-length", "server", "location",
    "set-cookie", "cache-control", "x-powered-by",
    "cf-ray", "x-amzn-requestid", "x-served-by", "via",
    "x-frame-options", "x-content-type-options",
    "content-security-policy", "strict-transport-security",
    "referrer-policy", "permissions-policy"
  ]);
  const allow = allowed ? new Set(allowed) : defaultAllowed;

  // headersObj may be either a plain object OR a Headers instance's Map form.
  const entries = headersObj instanceof Map
    ? [...headersObj.entries()]
    : Object.entries(headersObj);

  for (const [k, v] of entries) {
    const kl = String(k).toLowerCase();
    if (allow.has(kl)) out[kl] = String(v).slice(0, 400);
  }
  return out;
}

// Build an evidence object from a request+response pair captured during
// verification. `request` = { method, url, headers } · `response` =
// { status, headers, body, finalUrl, ctype, bodyLen }
export function buildEvidence(request, response, meta = {}) {
  const now = new Date();
  return {
    capturedAt: now.toISOString(),
    capturedAtDisplay: now.toLocaleString(),
    request: {
      method: (request.method || "GET").toUpperCase(),
      url: request.url,
      headers: pickHeaders(request.headers || {}, [
        "user-agent", "accept", "content-type", "content-length",
        "x-original-url", "x-rewrite-url",
        "x-forwarded-for", "x-real-ip", "x-client-ip",
        "x-forwarded-host", "x-forwarded-proto",
        "cf-connecting-ip", "true-client-ip",
        "x-custom-ip-authorization", "x-cluster-client-ip",
        "x-http-method-override"
      ])
    },
    response: {
      status: response.status,
      finalUrl: response.finalUrl || response.url || request.url,
      contentType: response.ctype || response.contentType || "",
      bodyBytes: response.bodyLen != null ? response.bodyLen : (response.body ? response.body.length : 0),
      headers: pickHeaders(response.headers || {}),
      bodyPreview: sanitiseBody(response.body || "")
    },
    ...meta
  };
}

// Convert an evidence object to a copy-pastable HTTP transcript.
// Useful for the popup's "copy raw" button and the HTML/Markdown report.
export function evidenceToTranscript(ev) {
  if (!ev) return "";
  const req = ev.request || {};
  const res = ev.response || {};
  const reqHeaders = Object.entries(req.headers || {})
    .map(([k, v]) => `${headerCase(k)}: ${v}`).join("\n");
  const resHeaders = Object.entries(res.headers || {})
    .map(([k, v]) => `${headerCase(k)}: ${v}`).join("\n");
  let urlPath = req.url || "/";
  try { const u = new URL(req.url); urlPath = u.pathname + u.search; } catch (_) {}
  return [
    `# captured at ${ev.capturedAtDisplay || ev.capturedAt}`,
    `# ─── REQUEST ─────────────────────────────`,
    `${req.method || "GET"} ${urlPath} HTTP/1.1`,
    `Host: ${hostOf(req.url)}`,
    reqHeaders,
    ``,
    ``,
    `# ─── RESPONSE ────────────────────────────`,
    `HTTP/1.1 ${res.status || "?"} `,
    resHeaders,
    ``,
    res.bodyPreview ? `[body ${res.bodyBytes || 0} bytes — preview truncated to ${MAX_BODY}]` : `[no body captured]`,
    res.bodyPreview || ""
  ].join("\n");
}

function headerCase(name) {
  return String(name)
    .split("-")
    .map((p) => p.charAt(0).toUpperCase() + p.slice(1))
    .join("-");
}
function hostOf(url) {
  try { return new URL(url).host; } catch (_) { return ""; }
}
