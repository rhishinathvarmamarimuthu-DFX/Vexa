// ReconHound — Internet Archive Wayback Machine URL enumeration
// Author: Rhishinathvarma Marimuthu
//
// Queries the CDX Server API for every distinct URL ever archived under a
// host. Reveals removed-but-still-alive endpoints, legacy admin pages, old
// API versions, staged content that "went dark" but is still reachable —
// classic bug-bounty gold.
//
// The CDX API is CORS-friendly, requires no key, but can be slow (5–15 s for
// popular hosts). Cached per host in chrome.storage.session for 12 h.

import { markSourceOk, markSourceDown } from "./source-status.js";

const CACHE_KEY = "rh_wayback_cache";
const CACHE_TTL_MS = 12 * 60 * 60 * 1000;
const MAX_URLS = 500;

// Categorise Wayback-recovered URLs so the popup can highlight the ones an
// operator should actually try live.
const HIGH_INTEREST = /(?:\/admin|\/administrator|\/manager|\/actuator|\/api\/|\/graphql|\/console|\/backup|\/dump|\/config|\/secret|\/staging|\/dev\/|\/beta\/|\/test\/|\/internal|\/private|\/legacy|\.env|\.git|\.sql|\.bak|\.backup|\.tar|\.zip|swagger|openapi|\/wp-admin|\/xmlrpc|\.php\?|debug|profiler|telescope|\/pprof|adminer|phpmyadmin)/i;

async function readCache() {
  try { const d = await chrome.storage.session.get(CACHE_KEY); return d[CACHE_KEY] || {}; }
  catch { return {}; }
}
async function writeCache(c) {
  try { await chrome.storage.session.set({ [CACHE_KEY]: c }); } catch (_) {}
}

async function queryCDX(host) {
  const url = `https://web.archive.org/cdx/search/cdx`
    + `?url=${encodeURIComponent(host + "/*")}`
    + `&output=json&fl=timestamp,original,statuscode,mimetype`
    + `&collapse=urlkey&limit=${MAX_URLS * 2}`;
  const controller = new AbortController();
  const t = setTimeout(() => controller.abort(), 18000);
  try {
    const res = await fetch(url, { credentials: "omit", signal: controller.signal });
    clearTimeout(t);
    if (!res.ok) { markSourceDown("wayback", `HTTP ${res.status}`); return null; }
    const json = await res.json();
    markSourceOk("wayback");
    return json;
  } catch (e) {
    clearTimeout(t);
    markSourceDown("wayback", String(e && e.message || e));
    return null;
  }
}

export async function enumerateWayback(host) {
  if (!host) return { urls: [], highInterest: [], findings: [], degraded: true };

  const cache = await readCache();
  const cached = cache[host];
  if (cached && Date.now() - cached.ts < CACHE_TTL_MS) return cached.data;

  const rows = await queryCDX(host);
  if (!Array.isArray(rows) || rows.length < 2) {
    return { urls: [], highInterest: [], findings: [], degraded: true };
  }

  // First row is the header: ["timestamp","original","statuscode","mimetype"]
  const header = rows[0];
  const idxOriginal = header.indexOf("original");
  const idxStatus = header.indexOf("statuscode");
  const idxMime = header.indexOf("mimetype");

  const seen = new Set();
  const urls = [];
  const highInterest = [];
  for (const row of rows.slice(1)) {
    const u = row[idxOriginal];
    if (!u || seen.has(u)) continue;
    seen.add(u);
    const status = row[idxStatus] || "";
    const mime = row[idxMime] || "";
    // Skip obvious static assets.
    if (/\.(?:png|jpe?g|gif|webp|svg|ico|woff2?|ttf|eot|mp[34]|webm|avif|otf)(?:$|\?)/i.test(u)) continue;
    urls.push({ url: u, status, mime });
    if (HIGH_INTEREST.test(u)) highInterest.push({ url: u, status, mime });
    if (urls.length >= MAX_URLS) break;
  }

  const findings = [];
  if (highInterest.length) {
    findings.push({
      id: "wayback-high-interest",
      title: `Wayback Machine: ${highInterest.length} high-interest historical URL(s) on ${host}`,
      severity: "LOW",
      url: `https://web.archive.org/web/*/${host}/*`,
      detail: `Recovered ${urls.length} archived URL(s) from Internet Archive; ${highInterest.length} match admin/API/config/backup patterns worth manually checking against the live host.`,
      verified: true,
      needsManual: true,
      sample: highInterest.slice(0, 15).map((x) => x.url)
    });
  }

  const result = { urls, highInterest, findings, degraded: false };
  cache[host] = { ts: Date.now(), data: result };
  await writeCache(cache);
  return result;
}
