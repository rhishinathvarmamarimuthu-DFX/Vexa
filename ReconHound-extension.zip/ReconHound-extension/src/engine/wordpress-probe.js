// ReconHound — WordPress fingerprint & safe verification probes (ACTIVE)
// Non-destructive checks: version disclosure, user enumeration, XML-RPC status,
// exposed backups/debug logs, plugin/theme inventory via public readme files.
// No credential brute-forcing, no state-modifying requests.

const TOP_PLUGINS = [
  "akismet", "jetpack", "yoast-seo", "wordpress-seo", "elementor",
  "woocommerce", "contact-form-7", "wpforms-lite", "wordfence", "duplicator",
  "updraftplus", "all-in-one-seo-pack", "classic-editor", "google-site-kit",
  "really-simple-ssl", "wp-super-cache", "w3-total-cache", "litespeed-cache",
  "wp-mail-smtp", "mailchimp-for-wp", "advanced-custom-fields",
  "wp-optimize", "smush", "redirection", "loginizer",
  "revslider", "wp-file-manager", "elementor-pro", "learnpress",
  "bbpress", "buddypress", "wp-super-cron", "backwpup"
];

const TOP_THEMES = [
  "twentytwentyfour", "twentytwentythree", "twentytwentytwo",
  "twentytwentyone", "astra", "hello-elementor", "oceanwp",
  "generatepress", "kadence", "storefront"
];

const HIGH_RISK_PLUGINS = {
  "revslider": { severity: "HIGH", note: "Historical RFI/RCE issues (CVE-2014-9734, CVE-2022-21661)." },
  "wp-file-manager": { severity: "CRITICAL", note: "CVE-2020-25213 unauthenticated RCE class." },
  "duplicator": { severity: "HIGH", note: "Historical arbitrary file download (CVE-2020-11738)." },
  "learnpress": { severity: "HIGH", note: "SQLi history (multiple CVEs)." },
  "elementor-pro": { severity: "HIGH", note: "CVE-2020-9377 / CVE-2023-48777 privilege escalation history." },
  "loginizer": { severity: "HIGH", note: "CVE-2020-27615 SQLi." }
};

async function get(url, opts = {}, timeoutMs = 6000) {
  const controller = new AbortController();
  const t = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const res = await fetch(url, { credentials: "omit", redirect: "follow", signal: controller.signal, ...opts });
    clearTimeout(t);
    const text = (await res.text()).slice(0, 65536);
    return { status: res.status, text, headers: res.headers, url: res.url };
  } catch (_) {
    clearTimeout(t);
    return null;
  }
}

async function head(url, timeoutMs = 5000) {
  const controller = new AbortController();
  const t = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const res = await fetch(url, {
      method: "HEAD", credentials: "omit", redirect: "follow", signal: controller.signal
    });
    clearTimeout(t);
    return { status: res.status, headers: res.headers, url: res.url };
  } catch (_) {
    clearTimeout(t);
    return null;
  }
}

// Detect whether a target is actually WordPress before doing WP-specific work.
async function isWordPress(origin) {
  const r = await get(origin + "/", {}, 5000);
  if (!r) return { present: false };
  if (/wp-content|wp-includes|wp-json|generator[^>]*wordpress/i.test(r.text)) {
    const version = (r.text.match(/name="generator"[^>]*content="WordPress\s+([\d.]+)/i) || [])[1] || null;
    return { present: true, version };
  }
  // Fallback: probe /wp-login.php
  const login = await head(origin + "/wp-login.php");
  if (login && login.status < 400) return { present: true, version: null };
  return { present: false };
}

// Passive & lightly-active WordPress checks.
export async function probeWordPress(origin) {
  const base = origin.replace(/\/$/, "");
  const wp = await isWordPress(base);
  if (!wp.present) return { present: false, findings: [] };

  const findings = [];

  // 1. Version disclosure via /readme.html
  const readme = await get(base + "/readme.html", {}, 5000);
  if (readme && readme.status === 200 && /wordpress/i.test(readme.text)) {
    const ver = (readme.text.match(/Version\s+([\d.]+)/i) || [])[1] || wp.version || null;
    findings.push({
      id: "wp-readme",
      title: "WordPress version disclosed via /readme.html",
      severity: "LOW",
      url: base + "/readme.html",
      detail: ver ? `WordPress ${ver} — remove /readme.html to reduce fingerprinting.` : "readme.html is public.",
      verified: true,
      version: ver
    });
  }

  // 2. User enumeration via /wp-json/wp/v2/users
  const users = await get(base + "/wp-json/wp/v2/users?per_page=100", {}, 6000);
  if (users && users.status === 200) {
    try {
      const arr = JSON.parse(users.text);
      if (Array.isArray(arr) && arr.length) {
        const names = arr.slice(0, 20).map((u) => u.slug || u.name).filter(Boolean);
        findings.push({
          id: "wp-user-enum",
          title: `WordPress user enumeration — ${arr.length} account(s) disclosed`,
          severity: "MEDIUM",
          url: base + "/wp-json/wp/v2/users",
          detail: `Public REST API lists usernames: ${names.join(", ")}${arr.length > 20 ? ", …" : ""}. Restrict via plugin or web-server rule.`,
          verified: true,
          users: names
        });
      }
    } catch (_) {}
  }

  // 2b. Author enumeration via ?author=1
  const author = await get(base + "/?author=1", {}, 5000);
  if (author && /author\/([\w-]+)/i.test(author.url + " " + author.text)) {
    const name = ((author.url + " " + author.text).match(/author\/([\w-]+)/i) || [])[1];
    if (name && name !== "1") {
      findings.push({
        id: "wp-author-enum",
        title: `WordPress author URL enumeration → user "${name}"`,
        severity: "LOW",
        url: base + "/?author=1",
        detail: "?author=<id> redirects to /author/<login>/ — disable via plugin.",
        verified: true
      });
    }
  }

  // 3. XML-RPC surface
  const xmlrpcGet = await get(base + "/xmlrpc.php", {}, 5000);
  if (xmlrpcGet && xmlrpcGet.status !== 404 && /XML-RPC server accepts POST/i.test(xmlrpcGet.text)) {
    // Confirm POST works with a harmless system.listMethods introspection.
    const xmlrpcPost = await get(base + "/xmlrpc.php", {
      method: "POST",
      headers: { "Content-Type": "text/xml" },
      body: "<?xml version=\"1.0\"?><methodCall><methodName>system.listMethods</methodName><params/></methodCall>"
    }, 6000);
    const hasMethods = xmlrpcPost && /<methodResponse>[\s\S]*<value>/i.test(xmlrpcPost.text);
    const hasPingback = xmlrpcPost && /pingback\.ping/.test(xmlrpcPost.text);
    findings.push({
      id: "wp-xmlrpc",
      title: hasPingback ? "WordPress XML-RPC pingback enabled" : "WordPress XML-RPC enabled",
      severity: hasPingback ? "MEDIUM" : "LOW",
      url: base + "/xmlrpc.php",
      detail: hasPingback
        ? "pingback.ping is exposed — historically abused for SSRF and DDoS reflection. Disable if unused."
        : "XML-RPC endpoint responds to POST. Consider disabling if unused.",
      verified: !!hasMethods
    });
  }

  // 4. Debug log / error log exposure
  for (const p of ["/wp-content/debug.log", "/error_log", "/wp-content/uploads/error_log"]) {
    const r = await get(base + p, {}, 5000);
    if (r && r.status === 200 && r.text.length > 20 && !/<html/i.test(r.text)) {
      findings.push({
        id: "wp-debug-log",
        title: `Exposed log file at ${p}`,
        severity: "HIGH",
        url: base + p,
        detail: "Server error/debug log is publicly readable — may leak file paths, SQL, secrets.",
        verified: true
      });
      break;
    }
  }

  // 5. Uploads directory listing
  const uploads = await get(base + "/wp-content/uploads/", {}, 5000);
  if (uploads && uploads.status < 400 && /<title>\s*Index of|Directory listing for/i.test(uploads.text)) {
    findings.push({
      id: "wp-uploads-listing",
      title: "Open directory listing at /wp-content/uploads/",
      severity: "MEDIUM",
      url: base + "/wp-content/uploads/",
      detail: "Uploads directory is browsable — reveals files not intended to be public.",
      verified: true
    });
  }

  // 6. Plugin inventory (readme.txt is stable across versions)
  const foundPlugins = [];
  await Promise.all(TOP_PLUGINS.map(async (slug) => {
    const p = await get(`${base}/wp-content/plugins/${slug}/readme.txt`, {}, 4500);
    if (p && p.status === 200 && /Stable tag|Contributors:/i.test(p.text)) {
      const ver = (p.text.match(/Stable tag:\s*([\d.]+)/i) || p.text.match(/Version\s*:\s*([\d.]+)/i) || [])[1] || null;
      foundPlugins.push({ slug, version: ver });
    }
  }));
  if (foundPlugins.length) {
    findings.push({
      id: "wp-plugins",
      title: `WordPress plugins detected: ${foundPlugins.length}`,
      severity: "LOW",
      url: base + "/wp-content/plugins/",
      detail: foundPlugins.map((p) => p.slug + (p.version ? `@${p.version}` : "")).join(", "),
      verified: true,
      plugins: foundPlugins
    });
    for (const p of foundPlugins) {
      const risk = HIGH_RISK_PLUGINS[p.slug];
      if (risk) {
        findings.push({
          id: "wp-plugin-risk-" + p.slug,
          title: `High-risk plugin "${p.slug}"${p.version ? ` @ ${p.version}` : ""}`,
          severity: risk.severity,
          url: `${base}/wp-content/plugins/${p.slug}/readme.txt`,
          detail: risk.note + " Verify version against advisories before assessing exploitability.",
          verified: true
        });
      }
    }
  }

  // 7. Theme inventory
  const foundThemes = [];
  await Promise.all(TOP_THEMES.map(async (slug) => {
    const p = await get(`${base}/wp-content/themes/${slug}/style.css`, {}, 4500);
    if (p && p.status === 200 && /Theme Name/i.test(p.text)) {
      const ver = (p.text.match(/Version:\s*([\d.]+)/i) || [])[1] || null;
      foundThemes.push({ slug, version: ver });
    }
  }));
  if (foundThemes.length) {
    findings.push({
      id: "wp-themes",
      title: `WordPress themes detected: ${foundThemes.length}`,
      severity: "LOW",
      url: base + "/wp-content/themes/",
      detail: foundThemes.map((t) => t.slug + (t.version ? `@${t.version}` : "")).join(", "),
      verified: true,
      themes: foundThemes
    });
  }

  // 8. Backups / archives named by convention
  const backupNames = [
    "/wp-config.php.bak", "/wp-config.php~", "/wp-config.php.save",
    "/wp-config.php.old", "/wp-config.txt", "/wp-config.php.swp",
    "/backup.zip", "/backup.tar.gz", "/site.zip", "/wordpress.zip",
    "/db.sql", "/dump.sql", "/database.sql", "/wp.sql"
  ];
  await Promise.all(backupNames.map(async (p) => {
    const r = await get(base + p, {}, 4500);
    if (!r || r.status !== 200 || r.text.length < 20) return;
    if (/<html|<!doctype/i.test(r.text.slice(0, 500))) return; // page redirect / soft-404
    findings.push({
      id: "wp-backup",
      title: `Exposed backup/config file at ${p}`,
      severity: "CRITICAL",
      url: base + p,
      detail: "Backup or database dump reachable — may contain credentials or full data.",
      verified: true
    });
  }));

  // 9. wp-cron reachable (LOW — informational, DoS reflection risk if abused)
  const cron = await head(base + "/wp-cron.php");
  if (cron && cron.status < 500) {
    findings.push({
      id: "wp-cron",
      title: "wp-cron.php reachable externally",
      severity: "LOW",
      url: base + "/wp-cron.php",
      detail: "Consider disabling remote wp-cron and running via system cron to prevent DoS abuse.",
      verified: true
    });
  }

  return {
    present: true,
    version: wp.version || (findings.find((f) => f.id === "wp-readme") || {}).version || null,
    findings
  };
}
