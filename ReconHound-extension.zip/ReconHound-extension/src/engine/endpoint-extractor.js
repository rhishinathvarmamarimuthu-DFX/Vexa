 // ReconHound — Endpoint / API extractor
// Pulls REAL URLs, API paths, and route strings out of fetched JS bundles and
// inline code. Useful for mapping hidden attack surface during recon.

// Patterns that capture interesting links/paths inside JS source.
const LINK_RE =
  /(?:"|'|`)(\s*(?:https?:\/\/|\/\/|\/)[a-zA-Z0-9_\-./?=&%@:+~#]{2,260}?)(?:"|'|`)/g;

// Filter out obvious noise (images, fonts, css) — keep API-ish endpoints.
const NOISE_RE = /\.(png|jpe?g|gif|svg|webp|ico|woff2?|ttf|eot|css|mp4|webm|map)(\?|#|$)/i;
const API_HINT_RE = /(\/api\/|\/v\d+\/|\/graphql|\/rest\/|\/oauth|\/auth|\/token|\/admin|\/internal|\/user|\/account|\.json($|\?)|\/swagger|\/wp-json)/i;

function classify(path) {
  if (/\/graphql/i.test(path)) return "graphql";
  if (/\/(oauth|auth|token|login|sso)/i.test(path)) return "auth";
  if (/\/admin|\/internal/i.test(path)) return "admin";
  if (/\/api\/|\/v\d+\/|\/rest\//i.test(path)) return "api";
  if (/\.json($|\?)/i.test(path)) return "data";
  return "link";
}

// Extract endpoints from one blob of code. `source` labels its origin.
export function extractEndpoints(code, source = "script") {
  if (!code) return [];
  const found = new Map();

  let m;
  LINK_RE.lastIndex = 0;
  while ((m = LINK_RE.exec(code)) !== null) {
    const raw = (m[1] || "").trim();
    if (!raw || raw.length < 3) continue;
    if (NOISE_RE.test(raw)) continue;
    // Keep absolute URLs or API-looking relative paths only.
    const isAbsolute = /^(https?:)?\/\//i.test(raw);
    if (!isAbsolute && !API_HINT_RE.test(raw)) continue;
    if (raw.includes(" ")) continue;

    if (!found.has(raw)) {
      found.set(raw, { path: raw, type: classify(raw), source });
    }
    if (found.size > 500) break;
  }

  // Sort: sensitive types first.
  const order = { graphql: 0, admin: 1, auth: 2, api: 3, data: 4, link: 5 };
  return [...found.values()].sort((a, b) => (order[a.type] ?? 9) - (order[b.type] ?? 9));
}

// Extract unique subdomains referenced in code, scoped to the page's base domain.
export function extractSubdomains(code, baseHost = "") {
  if (!code) return [];
  const root = baseHost.split(".").slice(-2).join("."); // e.g. example.com
  const re = /\b([a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?(?:\.[a-z0-9-]+)+)\b/gi;
  const hosts = new Set();
  let m;
  while ((m = re.exec(code)) !== null) {
    const host = m[1].toLowerCase();
    if (!host.includes(".")) continue;
    if (/\.(js|css|png|jpg|svg|json|html|min|map)$/i.test(host)) continue; // not a file
    if (root && host.endsWith(root) && host !== root) hosts.add(host);
    if (hosts.size > 200) break;
  }
  return [...hosts].sort();
}

// Extract query-parameter names from URLs in the code (useful for fuzzing).
export function extractParams(code) {
  if (!code) return [];
  const params = new Set();
  const re = /[?&]([a-zA-Z_][a-zA-Z0-9_\-]{1,40})=/g;
  let m;
  while ((m = re.exec(code)) !== null) {
    params.add(m[1]);
    if (params.size > 200) break;
  }
  return [...params].sort();
}

