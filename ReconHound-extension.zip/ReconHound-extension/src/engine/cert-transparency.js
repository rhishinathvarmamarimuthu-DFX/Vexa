// ReconHound — Passive subdomain enumeration via Certificate Transparency
// Queries public CT logs (crt.sh + certspotter) which return every certificate
// ever issued for a domain. Purely passive OSINT — no packets touch the target.
// Results are cached in chrome.storage.session per-host (per-browsing-session)
// so repeat popups don't refetch.

import { markSourceOk, markSourceDown } from "./source-status.js";

const CACHE_KEY = "rh_ct_cache";
const CACHE_TTL_MS = 6 * 60 * 60 * 1000; // 6 h

async function readCache() {
  try {
    const d = await chrome.storage.session.get(CACHE_KEY);
    return d[CACHE_KEY] || {};
  } catch (_) { return {}; }
}
async function writeCache(cache) {
  try { await chrome.storage.session.set({ [CACHE_KEY]: cache }); } catch (_) {}
}

// Very rough registrable-domain extractor. Handles common `.co.uk`-style TLDs.
const MULTI_PART_TLDS = new Set([
  "co.uk", "org.uk", "gov.uk", "ac.uk", "co.jp", "com.au", "org.au",
  "com.br", "co.in", "co.kr", "com.mx", "co.za", "com.sg"
]);
function registrableDomain(host) {
  const parts = String(host || "").toLowerCase().split(".").filter(Boolean);
  if (parts.length < 2) return host || "";
  const last2 = parts.slice(-2).join(".");
  const last3 = parts.slice(-3).join(".");
  if (MULTI_PART_TLDS.has(last2)) return last3;
  return last2;
}

async function timedFetchJson(url, timeoutMs = 12000) {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const res = await fetch(url, { credentials: "omit", signal: controller.signal });
    clearTimeout(timeout);
    if (!res.ok) return null;
    const text = await res.text();
    if (!text || (text[0] !== "[" && text[0] !== "{")) return null;
    return JSON.parse(text);
  } catch (_) {
    clearTimeout(timeout);
    return null;
  }
}

// Source A — crt.sh JSON.
async function queryCrtsh(domain) {
  const url = `https://crt.sh/?q=%25.${encodeURIComponent(domain)}&output=json`;
  const json = await timedFetchJson(url, 15000);
  if (!Array.isArray(json)) { markSourceDown("crtsh", "unreachable-or-non-json"); return null; }
  const set = new Set();
  for (const entry of json) {
    for (const line of String(entry.name_value || "").split(/\r?\n/)) {
      const name = line.trim().toLowerCase().replace(/^\*\./, "");
      if (name) set.add(name);
    }
  }
  markSourceOk("crtsh");
  return set;
}

// Source B — certspotter (SSLMate). Free API, no auth. Returns first 100 issued
// certs by default which is often enough for demo-time coverage.
async function queryCertspotter(domain) {
  const url = `https://api.certspotter.com/v1/issuances?domain=${encodeURIComponent(domain)}&include_subdomains=true&expand=dns_names`;
  const json = await timedFetchJson(url, 12000);
  if (!Array.isArray(json)) { markSourceDown("certspotter", "unreachable-or-non-json"); return null; }
  const set = new Set();
  for (const entry of json) {
    for (const raw of entry.dns_names || []) {
      const name = String(raw || "").trim().toLowerCase().replace(/^\*\./, "");
      if (name) set.add(name);
    }
  }
  markSourceOk("certspotter");
  return set;
}

// Enumerate subdomains for the given host. Returns
//   { subdomains: string[], sources: string[], degraded: bool }
export async function enumerateSubdomains(host) {
  const root = registrableDomain(host);
  const emptyResult = { subdomains: [], sources: [], degraded: true };
  if (!root) return emptyResult;

  const cache = await readCache();
  const hit = cache[root];
  if (hit && Date.now() - hit.ts < CACHE_TTL_MS) {
    return { subdomains: hit.data || [], sources: hit.sources || ["cache"], degraded: false };
  }

  const [crt, spotter] = await Promise.all([
    queryCrtsh(root).catch(() => null),
    queryCertspotter(root).catch(() => null)
  ]);
  const sources = [];
  const merged = new Set();
  if (crt) { sources.push("crt.sh"); crt.forEach((n) => merged.add(n)); }
  if (spotter) { sources.push("certspotter"); spotter.forEach((n) => merged.add(n)); }

  // Scope filter + validation.
  const set = new Set();
  for (const name of merged) {
    if (!/^[a-z0-9.-]+$/.test(name)) continue;
    if (!name.endsWith(root)) continue;
    if (name === root) continue;
    set.add(name);
    if (set.size > 800) break;
  }

  const list = [...set].sort();
  const result = { subdomains: list, sources, degraded: sources.length === 0 };
  if (sources.length) {
    cache[root] = { ts: Date.now(), data: list, sources };
    await writeCache(cache);
  }
  return result;
}
