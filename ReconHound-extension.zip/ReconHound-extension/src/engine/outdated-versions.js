// ReconHound — Outdated-version & end-of-life detection

import { markSourceOk, markSourceDown } from "./source-status.js";
// Data sources (all free, no auth, CORS-friendly):
//   · endoflife.date          → 300+ products with cycle / EOL / latest data
//   · registry.npmjs.org      → latest published version of client-side libs
//   · api.wordpress.org       → current stable WordPress core
// Results are cached in chrome.storage.local for 24 h to avoid hammering.

// Map ReconHound tech names → endoflife.date product slugs.
const EOL_MAP = {
  "PHP": "php",
  "nginx": "nginx",
  "Apache": "apache",
  "MySQL": "mysql",
  "MariaDB": "mariadb",
  "PostgreSQL": "postgresql",
  "MongoDB": "mongodb",
  "Redis": "redis",
  "WordPress": "wordpress",
  "Drupal": "drupal",
  "Laravel": "laravel",
  "Django": "django",
  "Ruby on Rails": "rails",
  "Next.js": "nextjs",
  "Node.js": "nodejs",
  "Vue.js": "vue",
  "Angular": "angular",
  "Python": "python",
  "OpenSSL": "openssl",
  "Ruby": "ruby",
  "Kubernetes": "kubernetes",
  "Docker": "docker-engine",
  "ASP.NET": "aspnet",
  "Spring Boot": "spring-boot",
  "Elasticsearch": "elasticsearch",
  "RabbitMQ": "rabbitmq",
  "Kafka": "apache-kafka"
};

// Map ReconHound JS-library tech names → npm registry package names.
const NPM_MAP = {
  "jQuery": "jquery",
  "React": "react",
  "Vue.js": "vue",
  "lodash": "lodash",
  "Moment.js": "moment",
  "Axios": "axios",
  "D3.js": "d3",
  "Chart.js": "chart.js",
  "Three.js": "three",
  "Bootstrap": "bootstrap",
  "AngularJS": "angular"
};

// ── Semver-ish compare (returns -1 / 0 / 1) ─────────────────────────────
function semverCompare(a, b) {
  const norm = (v) => String(v || "0")
    .replace(/[^0-9.]/g, "")
    .split(".")
    .map((n) => parseInt(n, 10) || 0);
  const pa = norm(a), pb = norm(b);
  const len = Math.max(pa.length, pb.length);
  for (let i = 0; i < len; i++) {
    const av = pa[i] || 0, bv = pb[i] || 0;
    if (av > bv) return 1;
    if (av < bv) return -1;
  }
  return 0;
}
function majorOf(v) { return parseInt(String(v).split(".")[0], 10) || 0; }

// ── Cache layer (24 h) ──────────────────────────────────────────────────
const CACHE_KEY = "rh_outdated_cache";
const CACHE_TTL_MS = 24 * 60 * 60 * 1000;

async function readCache() {
  try {
    const d = await chrome.storage.local.get(CACHE_KEY);
    return d[CACHE_KEY] || {};
  } catch (_) { return {}; }
}
async function writeCache(cache) {
  try { await chrome.storage.local.set({ [CACHE_KEY]: cache }); } catch (_) {}
}
async function cached(key, fetcher) {
  const cache = await readCache();
  const entry = cache[key];
  if (entry && Date.now() - entry.ts < CACHE_TTL_MS) return entry.data;
  const data = await fetcher();
  if (data != null) {
    cache[key] = { ts: Date.now(), data };
    await writeCache(cache);
  }
  return data;
}

async function timedFetch(url, timeoutMs = 8000) {
  const controller = new AbortController();
  const t = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const res = await fetch(url, { credentials: "omit", signal: controller.signal });
    clearTimeout(t);
    if (!res.ok) return null;
    return await res.json();
  } catch (_) {
    clearTimeout(t);
    return null;
  }
}

async function fetchEol(product) {
  return cached("eol:" + product, async () => {
    const j = await timedFetch(`https://endoflife.date/api/${product}.json`);
    if (j) markSourceOk("endoflife"); else markSourceDown("endoflife", "unreachable");
    return j;
  });
}
async function fetchNpmLatest(pkg) {
  return cached("npm:" + pkg, async () => {
    const j = await timedFetch(`https://registry.npmjs.org/${pkg}/latest`);
    if (!j) { markSourceDown("npm", "unreachable"); return null; }
    markSourceOk("npm");
    return { version: j.version || null };
  });
}
async function fetchWpCore() {
  return cached("wpcore", async () => {
    const j = await timedFetch("https://api.wordpress.org/core/version-check/1.7/");
    if (!j) { markSourceDown("wpcore", "unreachable"); return null; }
    markSourceOk("wpcore");
    const offer = (j.offers || [])[0] || {};
    return { version: offer.current || offer.version || null };
  });
}

// Find the release cycle matching a version string, e.g. "7.4.33" → "7.4".
function matchCycle(cycles, version) {
  if (!Array.isArray(cycles) || !version) return null;
  const parts = String(version).split(".");
  const mm = parts.slice(0, 2).join(".");
  const m = parts[0];
  return cycles.find((c) => String(c.cycle) === mm)
      || cycles.find((c) => String(c.cycle) === m)
      || null;
}

// Assess a single tech entry. Returns null if nothing to report, else:
//   { latest, cycle, outdated, eol, eolDate, majorBehind, severity, note, sources }
export async function assessOutdated(tech) {
  if (!tech || !tech.tech || !tech.version) return null;
  const name = tech.tech;
  const version = tech.version;
  const result = { current: version, sources: [] };

  // WordPress core (definitive source).
  if (name === "WordPress") {
    const wp = await fetchWpCore();
    if (wp && wp.version && semverCompare(version, wp.version) < 0) {
      result.latest = wp.version;
      result.outdated = true;
      result.sources.push("wp-core");
    }
  }

  // endoflife.date (support cycles + EOL dates).
  const eolSlug = EOL_MAP[name];
  if (eolSlug) {
    const cycles = await fetchEol(eolSlug);
    if (cycles) {
      const cycle = matchCycle(cycles, version);
      if (cycle) {
        result.cycle = cycle.cycle;
        if (cycle.latest && semverCompare(version, cycle.latest) < 0) {
          result.outdated = true;
          if (!result.latest || semverCompare(cycle.latest, result.latest) > 0) {
            result.latest = cycle.latest;
          }
        }
        if (cycle.eol) {
          const eolIsPast = cycle.eol === true
            || (typeof cycle.eol === "string" && new Date(cycle.eol) < new Date());
          result.eolDate = cycle.eol === true ? "unsupported" : cycle.eol;
          if (eolIsPast) result.eol = true;
        }
        if (cycle.lts) result.lts = true;
        result.sources.push("endoflife.date");
      }
    }
  }

  // npm registry latest (client-side JS libs).
  const npmPkg = NPM_MAP[name];
  if (npmPkg) {
    const npm = await fetchNpmLatest(npmPkg);
    if (npm && npm.version) {
      if (semverCompare(version, npm.version) < 0) {
        result.outdated = true;
        if (!result.latest || semverCompare(npm.version, result.latest) > 0) {
          result.latest = npm.version;
        }
      }
      result.sources.push("npm");
    }
  }

  if (!result.outdated && !result.eol) return null;

  // Derive majorBehind + severity.
  if (result.latest) {
    result.majorBehind = Math.max(0, majorOf(result.latest) - majorOf(version));
  }
  if (result.eol) {
    result.severity = "HIGH";
    result.note = `${name} ${result.cycle || version} has reached end-of-life`
      + (result.eolDate && result.eolDate !== "unsupported" ? ` (${result.eolDate})` : "")
      + ". Vendor is no longer issuing security patches — upgrade to a supported branch.";
  } else if (result.majorBehind >= 2) {
    result.severity = "HIGH";
    result.note = `${name} ${version} is ${result.majorBehind} major versions behind ${result.latest}.`;
  } else if (result.majorBehind >= 1) {
    result.severity = "MEDIUM";
    result.note = `${name} ${version} is 1 major version behind ${result.latest}.`;
  } else {
    result.severity = "LOW";
    result.note = `${name} ${version} → newer patch/minor available (${result.latest}).`;
  }

  return result;
}

// Enrich a tech list in place. Returns { updated, eolCount, outdatedCount }.
export async function enrichOutdated(techList = []) {
  let outdatedCount = 0, eolCount = 0;
  await Promise.all(techList.map(async (t) => {
    try {
      const info = await assessOutdated(t);
      if (info) {
        t.outdated = info;
        outdatedCount++;
        if (info.eol) eolCount++;
      }
    } catch (_) {}
  }));
  return { outdatedCount, eolCount };
}
