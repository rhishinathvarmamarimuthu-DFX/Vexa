// ReconHound — .well-known/ discovery + OpenID Connect deep enumeration
// Author: Rhishinathvarma Marimuthu
//
// Probes RFC-registered and de-facto .well-known/ endpoints. Each hit unlocks
// specific attack surface:
//   · openid-configuration     → OIDC provider deep enum (auth/token/userinfo/jwks)
//   · oauth-authorization-server → OAuth AS metadata
//   · security.txt             → security-contact + policy exposure
//   · matrix / gpc             → federation identifiers
//   · apple-app-site-association / assetlinks.json → mobile-app deep-link surface
//   · host-meta / webfinger    → identity discovery
//   · change-password          → password-change URL (informational)
//
// Non-destructive GETs. No writes, no auth calls.

async function getJson(url, timeoutMs = 6000) {
  const controller = new AbortController();
  const t = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const res = await fetch(url, { credentials: "omit", redirect: "follow", signal: controller.signal });
    clearTimeout(t);
    if (!res.ok) return null;
    const ct = res.headers.get("content-type") || "";
    const text = (await res.text()).slice(0, 65536);
    if (/json/i.test(ct) || /^\s*[{[]/.test(text)) {
      try { return { status: res.status, ct, url: res.url, json: JSON.parse(text) }; }
      catch { return { status: res.status, ct, url: res.url, text }; }
    }
    return { status: res.status, ct, url: res.url, text };
  } catch (_) {
    clearTimeout(t);
    return null;
  }
}

const CATALOGUE = [
  // Auth / identity
  { path: "/.well-known/openid-configuration", id: "wk-oidc",
    severity: "MEDIUM", title: "OpenID Connect provider metadata exposed",
    note: "Full OIDC surface disclosed — endpoints for auth, token, userinfo, JWKS. Enumeration follows." },
  { path: "/.well-known/oauth-authorization-server", id: "wk-oauth-as",
    severity: "MEDIUM", title: "OAuth 2.0 Authorization Server metadata exposed",
    note: "OAuth AS metadata disclosed — grants, scopes, PKCE support." },
  { path: "/.well-known/oauth-protected-resource", id: "wk-oauth-pr",
    severity: "LOW", title: "OAuth 2.0 Protected Resource metadata exposed",
    note: "Protected-resource metadata — informational." },
  { path: "/.well-known/openid-federation", id: "wk-oidc-fed",
    severity: "MEDIUM", title: "OpenID Federation metadata exposed",
    note: "OIDC federation trust chain — verify entity registration constraints." },
  { path: "/.well-known/jwks.json", id: "wk-jwks",
    severity: "LOW", title: "JWKS keyset exposed at /.well-known/jwks.json",
    note: "Public JWKS at the standard path — informational unless a private key is mistakenly present." },

  // Security disclosure
  { path: "/.well-known/security.txt", id: "wk-security-txt",
    severity: "LOW", title: "security.txt present",
    note: "Security contact and disclosure policy disclosed — good hygiene, informational." },
  { path: "/security.txt", id: "wk-security-txt-legacy",
    severity: "LOW", title: "legacy security.txt present",
    note: "security.txt at root instead of /.well-known/ — RFC 9116 requires the .well-known/ location." },

  // Mobile / deep-links
  { path: "/.well-known/apple-app-site-association", id: "wk-aasa",
    severity: "MEDIUM", title: "Apple App Site Association exposed",
    note: "iOS universal-link map disclosed — attack surface for URL-scheme abuse, unverified deep-link handlers." },
  { path: "/apple-app-site-association", id: "wk-aasa-legacy",
    severity: "MEDIUM", title: "Apple AASA at root (legacy)",
    note: "Same as .well-known/aasa; discloses iOS universal-link map." },
  { path: "/.well-known/assetlinks.json", id: "wk-assetlinks",
    severity: "MEDIUM", title: "Android App Links (assetlinks.json) exposed",
    note: "Android app-links map disclosed — check for over-broad relation targets." },

  // Password / account
  { path: "/.well-known/change-password", id: "wk-change-password",
    severity: "LOW", title: "change-password redirect present",
    note: "Advertises the password-change URL to browsers. Informational." },

  // Federation / identity
  { path: "/.well-known/webfinger", id: "wk-webfinger",
    severity: "LOW", title: "WebFinger endpoint present",
    note: "Enumeration surface — arbitrary resource lookup. Verify rate limits." },
  { path: "/.well-known/host-meta", id: "wk-host-meta",
    severity: "LOW", title: "host-meta present",
    note: "XRD metadata — informational." },
  { path: "/.well-known/host-meta.json", id: "wk-host-meta-json",
    severity: "LOW", title: "host-meta.json present",
    note: "JSON XRD metadata — informational." },
  { path: "/.well-known/nodeinfo", id: "wk-nodeinfo",
    severity: "LOW", title: "NodeInfo endpoint present (fediverse)",
    note: "Server version, protocols, user counts disclosed." },
  { path: "/.well-known/matrix/client", id: "wk-matrix-client",
    severity: "LOW", title: "Matrix client discovery present",
    note: "Matrix homeserver client endpoint disclosed — informational." },
  { path: "/.well-known/matrix/server", id: "wk-matrix-server",
    severity: "LOW", title: "Matrix federation endpoint present",
    note: "Matrix homeserver federation endpoint disclosed." },

  // Privacy / consent
  { path: "/.well-known/gpc.json", id: "wk-gpc",
    severity: "LOW", title: "Global Privacy Control policy present",
    note: "GPC signal supported — informational." },
  { path: "/.well-known/dnt-policy.txt", id: "wk-dnt",
    severity: "LOW", title: "Do Not Track policy present",
    note: "DNT policy exposed — informational." },

  // Payments / trust
  { path: "/.well-known/stellar.toml", id: "wk-stellar",
    severity: "LOW", title: "Stellar TOML federation file",
    note: "Cryptocurrency federation metadata — verify addresses match expected wallet." },
  { path: "/.well-known/pki-validation/openssl.cnf", id: "wk-pki",
    severity: "MEDIUM", title: "PKI validation file exposed",
    note: "CA validation artifact reachable — investigate provenance." },

  // Misc common
  { path: "/humans.txt", id: "wk-humans-txt",
    severity: "LOW", title: "humans.txt present",
    note: "Team/authorship metadata — informational OSINT." },
  { path: "/ads.txt", id: "wk-ads-txt",
    severity: "LOW", title: "ads.txt present",
    note: "Authorised Digital Sellers list — informational." },
  { path: "/app-ads.txt", id: "wk-app-ads-txt",
    severity: "LOW", title: "app-ads.txt present",
    note: "Mobile-app ads sellers list — informational." }
];

// Verify a well-known hit — reject soft-404 HTML that pretends to be JSON.
function isReal(res, expectJson) {
  if (!res || res.status !== 200) return false;
  if (expectJson && !res.json && !/json/i.test(res.ct || "")) return false;
  if (res.text && /<html|<!doctype/i.test(res.text.slice(0, 200))) return false;
  return true;
}

// Return true if the item is meant to be JSON.
function expectsJson(entry) {
  return /openid|oauth|assetlinks|jwks|host-meta\.json|gpc|nodeinfo|matrix|aasa|apple-app-site-association/.test(entry.path);
}

// ── OpenID Connect deep enumeration ────────────────────────────────────
function analyzeOidc(oidc, origin) {
  if (!oidc) return [];
  const out = [];
  const url = origin + "/.well-known/openid-configuration";

  // Redirect-URI validation weakness: authorization_endpoint plus
  // registration_endpoint present ⇒ dynamic registration open.
  if (oidc.registration_endpoint) {
    out.push({
      id: "oidc-open-registration",
      title: "OIDC dynamic client registration endpoint enabled",
      severity: "MEDIUM",
      url: oidc.registration_endpoint,
      detail: "Dynamic-client-registration endpoint published. If unauthenticated, any party can register a client and obtain valid client_id/secret — verify authentication is required.",
      verified: true,
      needsManual: true
    });
  }

  // Implicit / hybrid flows deprecated → medium risk.
  const grants = oidc.grant_types_supported || [];
  if (grants.includes("implicit") || grants.includes("token")) {
    out.push({
      id: "oidc-implicit-flow",
      title: "OIDC implicit / hybrid flow supported",
      severity: "MEDIUM",
      url,
      detail: `grant_types_supported includes ${JSON.stringify(grants)} — implicit flow is deprecated (OAuth 2.1). Prefer authorization_code + PKCE.`,
      verified: true
    });
  }
  // PKCE not required.
  const codeChallenge = oidc.code_challenge_methods_supported || [];
  if (grants.includes("authorization_code") && !codeChallenge.length) {
    out.push({
      id: "oidc-no-pkce",
      title: "OIDC authorization_code without PKCE support",
      severity: "MEDIUM",
      url,
      detail: "OIDC provider declares authorization_code but not code_challenge_methods_supported — public clients cannot use PKCE.",
      verified: true
    });
  }
  // Missing / weak signing algorithms.
  const idAlgs = oidc.id_token_signing_alg_values_supported || [];
  if (idAlgs.includes("none")) {
    out.push({
      id: "oidc-alg-none",
      title: "OIDC advertises 'none' as id_token signing algorithm",
      severity: "HIGH",
      url,
      detail: "id_token_signing_alg_values_supported includes 'none' — unsigned tokens can be minted. Remove.",
      verified: true
    });
  }
  if (idAlgs.some((a) => /^HS/.test(a)) && !idAlgs.some((a) => /^(RS|PS|ES|EdDSA)/.test(a))) {
    out.push({
      id: "oidc-hs-only",
      title: "OIDC id_token signed with HMAC (HS*) only",
      severity: "MEDIUM",
      url,
      detail: "Only symmetric (HS256/HS384/HS512) signing supported — client-secret compromise = token forgery. Add asymmetric algs.",
      verified: true
    });
  }

  // Wildcard / permissive scopes
  const scopes = oidc.scopes_supported || [];
  if (scopes.includes("*")) {
    out.push({
      id: "oidc-wildcard-scope",
      title: "OIDC scopes_supported contains wildcard",
      severity: "MEDIUM",
      url,
      detail: "Wildcard scope indicates permissive authorisation model. Explicitly enumerate scopes.",
      verified: true
    });
  }

  return out;
}

// Concurrency-limited runner
export async function discoverWellKnown(origin, { concurrency = 6 } = {}) {
  const base = origin.replace(/\/$/, "");
  const queue = [...CATALOGUE];
  const findings = [];
  const data = { wellKnown: [], oidc: null };

  async function worker() {
    while (queue.length) {
      const entry = queue.shift();
      const res = await getJson(base + entry.path);
      if (!isReal(res, expectsJson(entry))) continue;

      findings.push({
        id: entry.id,
        title: entry.title,
        severity: entry.severity,
        url: base + entry.path,
        detail: entry.note,
        verified: true
      });

      // Deep OIDC follow-up if we hit the OIDC discovery document.
      if (entry.id === "wk-oidc" && res.json) {
        data.oidc = res.json;
        findings.push(...analyzeOidc(res.json, base));
      }
      // Basic OAuth AS metadata capture.
      if (entry.id === "wk-oauth-as" && res.json) {
        data.oauthAs = res.json;
      }
      // Sanity-cap findings so we don't drown.
      if (findings.length > 60) break;
    }
  }

  await Promise.all(Array.from({ length: concurrency }, worker));

  const w = { CRITICAL: 4, HIGH: 3, MEDIUM: 2, LOW: 1 };
  findings.sort((a, b) => (w[b.severity] || 0) - (w[a.severity] || 0));
  data.wellKnown = findings.filter((f) => f.id.startsWith("wk-")).map((f) => ({ url: f.url, title: f.title }));

  return { findings, data };
}
