// ReconHound — WAF-aware access-control-misconfiguration probe
// Author: Rhishinathvarma Marimuthu
//
// GOAL: identify cases where the fronting layer (WAF / reverse-proxy / CDN)
// denies a request but the backend origin actually serves the resource — a
// classic misconfiguration class documented by every major WAF vendor.
//
// This is RECONNAISSANCE. We do not modify server state. We do not brute-force
// credentials. We do not deliver injection payloads. We test whether the
// access-control layer is consistent with itself.
//
// Compared to a generic "try everything" tool:
//   1. Actively seeds candidates by probing paths that are typically 4xx-
//      protected on real applications, not just what the passive prober found
//   2. Fingerprints the fronting WAF and prioritises techniques with the
//      highest historical yield against that vendor's default config
//   3. Combines high-yield path variants WITH high-yield headers per WAF
//      (real bypasses often require this combination, not either alone)
//   4. Verifies each candidate with a second identical request to reject
//      flaky / rate-limited false positives
//   5. Handles 429 responses with jittered backoff
//   6. Includes a sanitised body preview in every finding so the operator
//      can visually confirm the response actually served something new

import { fingerprintWaf } from "./waf-fingerprint.js";
import { buildEvidence } from "./evidence.js";

const NETWORK_TIMEOUT_MS = 6000;
const PER_URL_VARIANT_CAP = 65;
const MAX_URLS = 12;
const CONCURRENCY = 4;
const VERIFY_ATTEMPTS = 2;         // re-fetch confirmed candidates this many times
const BACKOFF_ON_429_MS = 3000;

// ─── Curated seed paths ─────────────────────────────────────────────────
// Paths that are commonly 4xx-protected on real applications. We probe these
// FIRST to establish candidates for bypass, regardless of what the path-prober
// phase already found. This dramatically increases hit-rate on targets whose
// interesting paths were outside the passive prober's list.
const SEED_PATHS = [
  "/admin", "/admin/", "/administrator", "/admin/login", "/admin/index.php",
  "/admin.php", "/wp-admin/", "/wp-admin/admin.php",
  "/manager/html", "/manager/", "/host-manager/html",
  "/console", "/console/", "/console/login/LoginForm.jsp",
  "/jmx-console/", "/web-console/",
  "/actuator", "/actuator/env", "/actuator/heapdump", "/actuator/mappings",
  "/actuator/health", "/actuator/loggers", "/actuator/gateway/routes",
  "/api/admin", "/api/v1/admin", "/api/v2/admin", "/api/internal",
  "/api/private", "/api/users", "/api/config",
  "/graphql", "/graphiql", "/playground",
  "/swagger-ui.html", "/swagger/index.html", "/swagger", "/api-docs",
  "/phpmyadmin/", "/pma/", "/adminer.php",
  "/server-status", "/server-info", "/nginx_status",
  "/.env", "/.git/config", "/.git/HEAD",
  "/config", "/config.php", "/config.json",
  "/debug", "/_debug", "/debug/pprof/", "/debug/vars",
  "/telescope/requests", "/_profiler/",
  "/health", "/healthz", "/metrics", "/status",
  "/backup", "/backups/", "/dump.sql", "/db.sql"
];

// ─── Technique catalogue ────────────────────────────────────────────────
const TECHNIQUES = {
  // Path mutations
  "path-trailing-slash":    { label: "trailing /",         kind: "path",   build: (u, p) => req(u.origin + p + "/") },
  "path-double-slash":      { label: "trailing //",        kind: "path",   build: (u, p) => req(u.origin + p + "//") },
  "path-dot":               { label: "trailing /.",        kind: "path",   build: (u, p) => req(u.origin + p + "/.") },
  "path-dot-slash":         { label: "trailing /./",       kind: "path",   build: (u, p) => req(u.origin + p + "/./") },
  "path-star":              { label: "trailing /*",        kind: "path",   build: (u, p) => req(u.origin + p + "/*") },
  "path-space":             { label: "space suffix (%20)", kind: "path",   build: (u, p) => req(u.origin + p + "%20") },
  "path-tab":               { label: "tab suffix (%09)",   kind: "path",   build: (u, p) => req(u.origin + p + "%09") },
  "path-null":              { label: "null suffix (%00)",  kind: "path",   build: (u, p) => req(u.origin + p + "%00") },
  "path-question":          { label: "? suffix",           kind: "path",   build: (u, p) => req(u.origin + p + "?") },
  "path-hash":              { label: "# suffix",           kind: "path",   build: (u, p) => req(u.origin + p + "#") },
  "path-anchor-safe":       { label: "?param=1 suffix",    kind: "path",   build: (u, p) => req(u.origin + p + "?a=1") },
  "path-html":              { label: ".html suffix",       kind: "path",   build: (u, p) => req(u.origin + p + ".html") },
  "path-json":              { label: ".json suffix",       kind: "path",   build: (u, p) => req(u.origin + p + ".json") },
  "path-css":               { label: ".css suffix",        kind: "path",   build: (u, p) => req(u.origin + p + ".css") },
  "path-jpg":               { label: ";.jpg suffix",       kind: "path",   build: (u, p) => req(u.origin + p + ";.jpg") },
  "path-semi":              { label: ";/  suffix",         kind: "path",   build: (u, p) => req(u.origin + p + ";/") },
  "path-dot-semi":          { label: "..;/ suffix (Akamai)", kind: "path", build: (u, p) => req(u.origin + p + "..;/") },
  "path-encoded-slash":     { label: "%2f prefix",         kind: "path",   build: (u, p) => req(u.origin + "/%2f" + p.replace(/^\/+/, "")) },
  "path-encoded-dot":       { label: "/%2e/ prefix",       kind: "path",   build: (u, p) => req(u.origin + "/%2e/" + p.replace(/^\/+/, "")) },
  "path-double-slash-p":    { label: "// prefix",          kind: "path",   build: (u, p) => req(u.origin + "//" + p.replace(/^\/+/, "")) },
  "path-uppercase":         { label: "UPPERCASE path",     kind: "path",   build: (u, p) => req(u.origin + "/" + p.replace(/^\/+/, "").toUpperCase()) },
  "path-mixedcase":         { label: "MiXeD case",         kind: "path",   build: (u, p) => req(u.origin + "/" + [...p.replace(/^\/+/, "")].map((c, i) => i % 2 ? c.toUpperCase() : c).join("")) },
  "path-enc-first":         { label: "URL-encode 1st char", kind: "path",  build: (u, p) => req(u.origin + encFirstChar(p)) },
  "path-double-enc":        { label: "double-encode 1st",  kind: "path",   build: (u, p) => req(u.origin + doubleEncFirstChar(p)) },
  "path-traversal-wrap":    { label: "/x/../ wrap",        kind: "path",   build: (u, p) => req(u.origin + "/x/../" + p.replace(/^\/+/, "")) },
  "path-traversal-enc":     { label: "/x/%2e%2e/ wrap",    kind: "path",   build: (u, p) => req(u.origin + "/x/%2e%2e/" + p.replace(/^\/+/, "")) },

  // Methods (WAF rules very often GET-only)
  "method-head":            { label: "method HEAD",        kind: "method", build: (u, p) => req(u.origin + p, { method: "HEAD" }) },
  "method-options":         { label: "method OPTIONS",     kind: "method", build: (u, p) => req(u.origin + p, { method: "OPTIONS" }) },
  "method-post":            { label: "method POST",        kind: "method", build: (u, p) => req(u.origin + p, { method: "POST" }) },
  "method-put":             { label: "method PUT",         kind: "method", build: (u, p) => req(u.origin + p, { method: "PUT" }) },
  "method-patch":           { label: "method PATCH",       kind: "method", build: (u, p) => req(u.origin + p, { method: "PATCH" }) },
  "method-delete":          { label: "method DELETE",      kind: "method", build: (u, p) => req(u.origin + p, { method: "DELETE" }) },
  "method-propfind":        { label: "method PROPFIND",    kind: "method", build: (u, p) => req(u.origin + p, { method: "PROPFIND" }) },

  // Headers (attacker-controlled trust of source IP / URL rewrite)
  "hdr-original-url":       { label: "X-Original-URL",     kind: "header", build: (u, p) => req(u.origin + "/", { headers: { "X-Original-URL": p } }) },
  "hdr-rewrite-url":        { label: "X-Rewrite-URL",      kind: "header", build: (u, p) => req(u.origin + "/", { headers: { "X-Rewrite-URL": p } }) },
  "hdr-xff-loopback":       { label: "X-Forwarded-For:127.0.0.1", kind: "header", build: (u, p) => req(u.origin + p, { headers: { "X-Forwarded-For": "127.0.0.1" } }) },
  "hdr-xff-null":           { label: "X-Forwarded-For:0.0.0.0",   kind: "header", build: (u, p) => req(u.origin + p, { headers: { "X-Forwarded-For": "0.0.0.0" } }) },
  "hdr-xff-internal":       { label: "X-Forwarded-For:10.0.0.1",  kind: "header", build: (u, p) => req(u.origin + p, { headers: { "X-Forwarded-For": "10.0.0.1" } }) },
  "hdr-xff-lan":            { label: "X-Forwarded-For:192.168.1.1", kind: "header", build: (u, p) => req(u.origin + p, { headers: { "X-Forwarded-For": "192.168.1.1" } }) },
  "hdr-real-ip":            { label: "X-Real-IP:127.0.0.1", kind: "header", build: (u, p) => req(u.origin + p, { headers: { "X-Real-IP": "127.0.0.1" } }) },
  "hdr-client-ip":          { label: "X-Client-IP:127.0.0.1", kind: "header", build: (u, p) => req(u.origin + p, { headers: { "X-Client-IP": "127.0.0.1" } }) },
  "hdr-custom-auth-ip":     { label: "X-Custom-IP-Authorization", kind: "header", build: (u, p) => req(u.origin + p, { headers: { "X-Custom-IP-Authorization": "127.0.0.1" } }) },
  "hdr-cf-connecting":      { label: "CF-Connecting-IP",   kind: "header", build: (u, p) => req(u.origin + p, { headers: { "CF-Connecting-IP": "127.0.0.1" } }) },
  "hdr-true-client":        { label: "True-Client-IP",     kind: "header", build: (u, p) => req(u.origin + p, { headers: { "True-Client-IP": "127.0.0.1" } }) },
  "hdr-x-forwarded-host":   { label: "X-Forwarded-Host:localhost", kind: "header", build: (u, p) => req(u.origin + p, { headers: { "X-Forwarded-Host": "localhost" } }) },
  "hdr-x-forwarded-proto":  { label: "X-Forwarded-Proto:https", kind: "header", build: (u, p) => req(u.origin + p, { headers: { "X-Forwarded-Proto": "https" } }) },
  "hdr-x-cluster-client":   { label: "X-Cluster-Client-IP", kind: "header", build: (u, p) => req(u.origin + p, { headers: { "X-Cluster-Client-IP": "127.0.0.1" } }) },
  "hdr-xff-real-combo":     { label: "XFF + X-Real-IP combo", kind: "header", build: (u, p) => req(u.origin + p, { headers: { "X-Forwarded-For": "127.0.0.1", "X-Real-IP": "127.0.0.1" } }) },
  "hdr-x-http-method":      { label: "X-HTTP-Method-Override:GET", kind: "header", build: (u, p) => req(u.origin + p, { method: "POST", headers: { "X-HTTP-Method-Override": "GET" } }) },

  // Combined: path variant + header (many real WAF bypasses need both)
  "combo-uppercase-xff":    { label: "UPPERCASE + XFF:127.0.0.1", kind: "combo", build: (u, p) => req(u.origin + "/" + p.replace(/^\/+/, "").toUpperCase(), { headers: { "X-Forwarded-For": "127.0.0.1" } }) },
  "combo-trailing-slash-xff": { label: "trailing / + XFF:127.0.0.1", kind: "combo", build: (u, p) => req(u.origin + p + "/", { headers: { "X-Forwarded-For": "127.0.0.1" } }) },
  "combo-semi-xff":         { label: ";/ + XFF:127.0.0.1", kind: "combo", build: (u, p) => req(u.origin + p + ";/", { headers: { "X-Forwarded-For": "127.0.0.1" } }) },
  "combo-post-original":    { label: "POST + X-Original-URL", kind: "combo", build: (u, p) => req(u.origin + "/", { method: "POST", headers: { "X-Original-URL": p } }) },
  "combo-post-rewrite":     { label: "POST + X-Rewrite-URL", kind: "combo", build: (u, p) => req(u.origin + "/", { method: "POST", headers: { "X-Rewrite-URL": p } }) },
  "combo-double-enc-xff":   { label: "double-enc + XFF:127.0.0.1", kind: "combo", build: (u, p) => req(u.origin + doubleEncFirstChar(p), { headers: { "X-Forwarded-For": "127.0.0.1" } }) },
  "combo-uppercase-original": { label: "UPPERCASE + X-Original-URL", kind: "combo", build: (u, p) => req(u.origin + "/", { headers: { "X-Original-URL": p.toUpperCase() } }) }
};

// ─── WAF-specific technique priority tables ─────────────────────────────
const WAF_TECHNIQUE_PRIORITY = {
  cloudflare: [
    "hdr-xff-loopback", "hdr-cf-connecting", "hdr-true-client", "hdr-xff-null",
    "combo-uppercase-xff", "combo-trailing-slash-xff", "combo-post-original",
    "path-uppercase", "path-mixedcase", "path-enc-first", "path-double-enc",
    "method-post", "method-head", "method-options", "method-put",
    "path-html", "path-json", "path-jpg", "path-question", "path-hash",
    "hdr-original-url", "hdr-rewrite-url", "hdr-x-http-method"
  ],
  akamai: [
    "path-dot-semi", "path-semi",
    "combo-semi-xff", "combo-uppercase-xff",
    "path-trailing-slash", "path-double-slash", "path-double-slash-p",
    "path-encoded-slash", "path-encoded-dot", "path-traversal-enc",
    "method-post", "method-put", "method-options",
    "hdr-original-url", "hdr-rewrite-url", "hdr-xff-loopback", "hdr-true-client"
  ],
  "aws-cloudfront": [
    "path-uppercase", "path-mixedcase", "path-question", "path-hash",
    "path-html", "path-json", "path-css",
    "combo-uppercase-xff", "combo-post-original",
    "method-post", "method-head", "method-options", "method-patch",
    "hdr-original-url", "hdr-xff-loopback"
  ],
  "aws-alb-waf": [
    "method-post", "method-put", "method-patch", "method-options",
    "combo-post-original", "combo-trailing-slash-xff",
    "path-trailing-slash", "path-double-slash",
    "hdr-xff-loopback", "hdr-real-ip", "hdr-original-url"
  ],
  fastly: [
    "method-post", "method-options", "method-put",
    "combo-uppercase-xff", "combo-trailing-slash-xff",
    "path-trailing-slash", "path-encoded-slash",
    "hdr-xff-loopback", "hdr-real-ip",
    "path-uppercase", "path-mixedcase"
  ],
  sucuri: [
    "hdr-xff-loopback", "hdr-real-ip", "hdr-client-ip",
    "combo-uppercase-xff",
    "path-uppercase", "path-encoded-slash",
    "method-post", "method-options"
  ],
  "imperva-incapsula": [
    "hdr-xff-loopback", "hdr-custom-auth-ip", "hdr-real-ip",
    "combo-double-enc-xff", "combo-uppercase-xff",
    "path-uppercase", "path-double-enc", "path-enc-first",
    "method-post", "method-put", "method-patch",
    "path-html", "path-json"
  ],
  "f5-bigip-asm": [
    "path-semi", "path-dot-semi",
    "combo-semi-xff",
    "hdr-xff-loopback", "hdr-original-url", "hdr-x-http-method",
    "method-post", "method-options"
  ],
  "citrix-netscaler": [
    "path-semi", "path-double-slash", "path-encoded-slash",
    "combo-semi-xff",
    "hdr-xff-loopback", "hdr-real-ip",
    "method-post", "method-put"
  ],
  "fortinet-fortiweb": [
    "hdr-xff-loopback", "hdr-original-url",
    "combo-uppercase-xff",
    "path-uppercase", "path-double-enc",
    "method-post", "method-options"
  ],
  modsecurity: [
    "path-double-enc", "path-enc-first", "path-encoded-dot", "path-encoded-slash",
    "combo-double-enc-xff",
    "path-null", "path-tab", "path-space",
    "hdr-x-http-method",
    "method-post", "method-options"
  ],
  wordfence: [
    "method-post", "method-options",
    "hdr-xff-loopback", "hdr-original-url",
    "combo-post-original",
    "path-uppercase", "path-double-enc"
  ],
  default: [
    "path-trailing-slash", "path-double-slash", "path-dot", "path-dot-slash",
    "path-semi", "path-dot-semi", "path-star", "path-question", "path-hash",
    "path-html", "path-json", "path-jpg", "path-css",
    "path-uppercase", "path-mixedcase", "path-enc-first", "path-double-enc",
    "path-encoded-slash", "path-encoded-dot", "path-double-slash-p",
    "path-traversal-wrap", "path-traversal-enc",
    "method-head", "method-options", "method-post", "method-put",
    "method-patch", "method-delete", "method-propfind",
    "hdr-original-url", "hdr-rewrite-url",
    "hdr-xff-loopback", "hdr-xff-null", "hdr-xff-internal", "hdr-xff-lan",
    "hdr-real-ip", "hdr-client-ip", "hdr-custom-auth-ip",
    "hdr-cf-connecting", "hdr-true-client",
    "hdr-x-forwarded-host", "hdr-x-forwarded-proto", "hdr-x-cluster-client",
    "hdr-xff-real-combo", "hdr-x-http-method",
    "combo-uppercase-xff", "combo-trailing-slash-xff", "combo-post-original",
    "combo-semi-xff", "combo-double-enc-xff"
  ]
};

// ─── Helpers ─────────────────────────────────────────────────────────────
function req(url, opts = {}) { return { url, opts: { method: "GET", ...opts } }; }
function encFirstChar(p) {
  const bare = p.replace(/^\/+/, "");
  if (!bare.length) return p;
  return "/%" + bare.charCodeAt(0).toString(16).padStart(2, "0") + bare.slice(1);
}
function doubleEncFirstChar(p) {
  const bare = p.replace(/^\/+/, "");
  if (!bare.length) return p;
  return "/%25" + bare.charCodeAt(0).toString(16).padStart(2, "0") + bare.slice(1);
}
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

async function safeFetch(url, opts = {}) {
  const controller = new AbortController();
  const t = setTimeout(() => controller.abort(), NETWORK_TIMEOUT_MS);
  try {
    const res = await fetch(url, {
      credentials: "omit",
      redirect: "follow",
      signal: controller.signal,
      ...opts
    });
    clearTimeout(t);

    // 429 handling — back off once, then retry.
    if (res.status === 429) {
      const retryAfter = parseInt(res.headers.get("retry-after") || "", 10);
      const wait = Number.isFinite(retryAfter) && retryAfter > 0
        ? Math.min(retryAfter * 1000, 8000)
        : BACKOFF_ON_429_MS + Math.floor(Math.random() * 1000);
      await sleep(wait);
      const c2 = new AbortController();
      const t2 = setTimeout(() => c2.abort(), NETWORK_TIMEOUT_MS);
      try {
        const res2 = await fetch(url, {
          credentials: "omit", redirect: "follow", signal: c2.signal, ...opts
        });
        clearTimeout(t2);
        return res2;
      } catch (_) { clearTimeout(t2); return null; }
    }
    return res;
  } catch (_) {
    clearTimeout(t);
    return null;
  }
}

async function readSample(res) {
  try { return (await res.text()).slice(0, 16000); }
  catch { return ""; }
}

// Response classification
const POSITIVE_MARKERS = [
  /<title>(?!.*(forbidden|denied|error|blocked|access|login|sign[- ]?in|reject|attention))[^<]{3,80}<\/title>/i,
  /dashboard|admin\s*(panel|home|console|dashboard)/i,
  /welcome[,\s]+(admin|administrator|root|user)/i,
  /"users?"\s*:\s*\[/,
  /"data"\s*:\s*\[/,
  /"result"\s*:\s*\[/,
  /"status"\s*:\s*"?(ok|success|healthy|up)"?/i,
  /"version"\s*:\s*"/,
  /HTTP\s+API|swagger|openapi|"paths"\s*:/i,
  /<form[^>]*action="[^"]*logout/i,
  /csrf[_-]?token/i,
  /\bmanager\s+web\s+application/i,
  /server\s+information|server\s+status/i,
  /prometheus_|^# HELP |^# TYPE/m,
  /"_links"\s*:.*"health"/i,
  /"heapdump"|"threaddump"|"env"/i
];

const NEGATIVE_MARKERS = [
  /access\s*denied|forbidden|not\s*authori[sz]ed|unauthorized/i,
  /request\s*rejected|blocked\s*by\s*(waf|firewall)/i,
  /login|sign[- ]?in|please\s*(log|sign)\s*in/i,
  /captcha|cloudflare|attention\s*required/i,
  /support\s*(id|reference)\s*[:#]/i,
  /the\s*requested\s*url\s*was\s*rejected/i,
  /you\s*don't\s*have\s*permission/i,
  /error\s*code|error\s*\d{3}/i
];

function classifyResponse(body) {
  const pos = POSITIVE_MARKERS.reduce((n, r) => n + (r.test(body) ? 1 : 0), 0);
  const neg = NEGATIVE_MARKERS.reduce((n, r) => n + (r.test(body) ? 1 : 0), 0);
  if (pos >= 2 && pos > neg) return "positive-strong";
  if (pos >= 1 && neg === 0) return "positive-weak";
  if (neg >= 1 && pos === 0) return "negative";
  return "neutral";
}

function isBypass(baseline, cand) {
  if (!cand) return { ok: false, why: "no-response" };
  const bs = baseline.status, cs = cand.status;
  if (cs === 0) return { ok: false, why: "opaque-response" };
  if (cs === 429) return { ok: false, why: "rate-limited-429" };
  if (cs >= 400 && cs < 600) return { ok: false, why: `same-error-class-${cs}` };

  if (cs >= 300 && cs < 400) {
    const loc = (cand.location || "").toLowerCase();
    if (/login|signin|auth|sso|oauth|denied|blocked|reject/.test(loc)) return { ok: false, why: "redirect-to-login" };
    return { ok: true, why: "3xx-non-login" };
  }

  if (cand.class === "negative") return { ok: false, why: "still-block-page" };
  if (cand.finalUrl && baseline.finalUrl && cand.finalUrl === baseline.finalUrl) {
    return { ok: false, why: "same-final-url" };
  }
  if (cand.class === "positive-strong") return { ok: true, why: "positive-content" };
  if (cand.class === "positive-weak" && Math.abs(cand.bodyLen - baseline.bodyLen) > 100) {
    return { ok: true, why: "positive-content-and-length-delta" };
  }
  if (cand.class === "neutral" && Math.abs(cand.bodyLen - baseline.bodyLen) > 200 && cand.bodyLen > 200) {
    return { ok: true, why: "size-delta-neutral" };
  }
  return { ok: false, why: "not-different-enough" };
}

function severityFor(path) {
  const p = (path || "").toLowerCase();
  if (/admin|actuator|manager|console|jmx|internal|api\/private/.test(p)) return "HIGH";
  if (/wp-admin|phpmyadmin|adminer|graphql|kibana|grafana/.test(p)) return "HIGH";
  if (/backup|dump|config|env|\.git/.test(p)) return "HIGH";
  return "MEDIUM";
}

// Sanitise a body sample for the popup — strip HTML tags, collapse whitespace,
// cap at 200 chars. We're just showing "the response looked like X" to help
// the operator eyeball whether the bypass is real.
function sanitisePreview(body) {
  if (!body) return "";
  return String(body)
    .replace(/<script[\s\S]*?<\/script>/gi, "")
    .replace(/<style[\s\S]*?<\/style>/gi, "")
    .replace(/<[^>]+>/g, " ")
    .replace(/\s+/g, " ")
    .trim()
    .slice(0, 200);
}

// ─── Site-wide 404 / homepage fingerprint ───────────────────────────────
// Modern WAFs (esp. Cloudflare, Fastly) frequently return 404 instead of 403
// to hide protected paths — a "black-hole" configuration. To catch bypasses
// against those, we need a reference: what does a definitely-non-existent
// path look like on this site? We probe a random canary path and remember
// its body signature. If a bypass variant returns a page that differs
// meaningfully from BOTH the baseline block-page AND this 404 fingerprint,
// something new was served.
async function computeSiteFingerprints(origin) {
  const canary = "/rh-canary-" + Math.random().toString(36).slice(2, 14);
  const [notFoundRes, homeRes] = await Promise.all([
    safeFetch(origin + canary),
    safeFetch(origin + "/")
  ]);
  const nf = notFoundRes ? await readSample(notFoundRes) : "";
  const home = homeRes ? await readSample(homeRes) : "";
  return {
    notFound: notFoundRes ? {
      status: notFoundRes.status,
      finalUrl: notFoundRes.url,
      bodyLen: nf.length,
      body: nf
    } : null,
    home: homeRes ? {
      status: homeRes.status,
      finalUrl: homeRes.url,
      bodyLen: home.length,
      body: home
    } : null
  };
}

// True if `res` looks like the site's generic 404 page (black-hole WAF match)
function isBlackHole404(res, siteFP) {
  if (!res || !siteFP.notFound) return false;
  if (res.status !== siteFP.notFound.status) return false;
  return Math.abs(res.bodyLen - siteFP.notFound.bodyLen) < 100;
}

// True if `res` looks like the site's homepage (X-Original-URL false positive)
function looksLikeHomepage(res, siteFP) {
  if (!res || !siteFP.home) return false;
  if (res.status !== siteFP.home.status) return false;
  return Math.abs(res.bodyLen - siteFP.home.bodyLen) < 200;
}

// True if the response is a login page (either by URL or content)
function looksLikeLoginPage(res) {
  if (!res) return false;
  const finalUrl = (res.finalUrl || "").toLowerCase();
  if (/\/(login|signin|sign-in|auth|sso|oauth|account\/login|accounts\/login|user\/login|admin\/login)\b/.test(finalUrl)) return true;
  const body = res.body || "";
  const negMatches = NEGATIVE_MARKERS.filter((r) => r.test(body)).length;
  const posMatches = POSITIVE_MARKERS.filter((r) => r.test(body)).length;
  // Login page: several negative markers, no positive markers, small-ish body
  return negMatches >= 2 && posMatches === 0;
}

// ─── Active candidate discovery ─────────────────────────────────────────
// Probe each seed path with a lightweight GET. A path is a bypass candidate
// if it returns 4xx OR looks like a black-hole 404 (WAF hiding a real path).
async function discoverCandidates(origin, seedPaths, alreadyKnown, siteFP, telemetry) {
  const knownPaths = new Set(alreadyKnown.map((c) => c.path));
  const discovered = [];
  const queue = seedPaths.filter((p) => !knownPaths.has(p));
  telemetry.seedProbed = 0;
  telemetry.seedHit4xx = 0;
  telemetry.seedBlackHole404 = 0;

  const CONCURRENCY_SEED = 6;
  const workers = Array.from({ length: CONCURRENCY_SEED }, async () => {
    while (queue.length && discovered.length < MAX_URLS) {
      const p = queue.shift();
      telemetry.seedProbed++;
      const url = origin + p;
      const res = await safeFetch(url);
      if (!res) continue;
      // Real 4xx — always a candidate.
      if ([400, 401, 402, 403, 405].includes(res.status)) {
        discovered.push({ path: p, url, status: res.status });
        telemetry.seedHit4xx++;
        continue;
      }
      // Black-hole 404: matches site-wide 404 fingerprint — could be hidden path.
      if (res.status === 404 && siteFP.notFound) {
        const body = await readSample(res);
        if (Math.abs(body.length - siteFP.notFound.bodyLen) < 100) {
          discovered.push({ path: p, url, status: 404, blackHole: true });
          telemetry.seedBlackHole404++;
        }
      }
    }
  });
  await Promise.all(workers);
  return discovered;
}

// ─── Public entry-point ─────────────────────────────────────────────────
export async function bypassProbe(pathResults = [], options = {}) {
  // Passive candidates: real 4xx from the path-prober phase +
  // any "implicit" (status:0) entries — those get baselined fresh, and if the
  // baseline turns out to be protected (4xx / login-redirect / black-hole 404)
  // we include them.
  const passive = (pathResults || [])
    .filter((h) => h && (
      ([400, 401, 402, 403, 405].includes(h.status)) ||
      h.implicit === true
    ));

  // If we have too few, actively probe seed paths.
  let origin = null;
  if (passive.length) {
    try { origin = new URL(passive[0].url).origin; } catch { /* ignore */ }
  }
  if (!origin && options.origin) origin = options.origin;
  if (!origin) {
    return { findings: [], waf: null, telemetry: { skipped: "no-origin" } };
  }

  const telemetry = {
    origin,
    passiveCandidates: passive.length,
    seedProbed: 0,
    seedHit4xx: 0,
    activeCandidates: 0,
    urlsTested: 0,
    variantsTried: 0,
    variantsSuccess: 0,
    verifiedBypasses: 0,
    perUrl: []
  };

  // Fingerprint WAF once for the origin.
  const wafInfo = await fingerprintWaf(origin, options.observedCookies || [], options.observedHeaders || null);
  const primaryId = wafInfo.primary?.id || "default";
  const priority = WAF_TECHNIQUE_PRIORITY[primaryId] || WAF_TECHNIQUE_PRIORITY.default;
  telemetry.waf = wafInfo.primary;
  telemetry.detected = wafInfo.detected;

  // Compute site-wide 404 + homepage fingerprints so we can distinguish real
  // resources from generic 404 pages and homepage false-positives.
  const siteFP = await computeSiteFingerprints(origin);
  telemetry.siteFingerprint = {
    notFound: siteFP.notFound ? { status: siteFP.notFound.status, bodyLen: siteFP.notFound.bodyLen } : null,
    home:     siteFP.home     ? { status: siteFP.home.status,     bodyLen: siteFP.home.bodyLen }     : null
  };

  // Actively enumerate additional candidates (4xx + suspicious black-hole 404s).
  const active = await discoverCandidates(origin, SEED_PATHS, passive, siteFP, telemetry);
  const candidates = [...passive, ...active].slice(0, MAX_URLS);
  telemetry.activeCandidates = active.length;

  if (!candidates.length) {
    telemetry.skipped = "no-candidates-after-seed-probe";
    return { findings: [], waf: wafInfo, telemetry };
  }

  const allFindings = [];
  const diagnosticMode = options.diagnostic === true;

  for (const cand of candidates) {
    const urlObj = new URL(cand.url);
    const path = cand.path || urlObj.pathname;
    telemetry.urlsTested++;

    // Fresh baseline.
    const baseRes = await safeFetch(cand.url);
    if (!baseRes) {
      telemetry.perUrl.push({ path, skipped: "baseline-failed", tried: 0, hits: [], rejected: [] });
      continue;
    }
    const baseBody = await readSample(baseRes);
    const baseline = {
      status: baseRes.status,
      finalUrl: baseRes.url,
      ctype: baseRes.headers.get("content-type") || "",
      bodyLen: baseBody.length,
      class: classifyResponse(baseBody),
      body: baseBody
    };

    // Login-redirect awareness: a "follow" that lands on /login is still
    // protected — we should bypass it, not skip it.
    const baselineIsLoginRedirect = looksLikeLoginPage(baseline);
    // Black-hole 404: seed said "this looks like black-hole" — treat 404 as protected.
    const baselineIsBlackHole = cand.blackHole || isBlackHole404(baseline, siteFP);

    // Now decide: is the baseline "actually protected" (worth attempting bypass)?
    const baselineProtected =
      (baseline.status >= 400 && baseline.status < 500) ||   // real 4xx
      baselineIsLoginRedirect ||                             // 200 login page after redirect
      baselineIsBlackHole;                                   // 404 that matches site-wide 404

    if (!baselineProtected) {
      telemetry.perUrl.push({
        path,
        skipped: baseline.status >= 200 && baseline.status < 300 ? "baseline-open-not-protected" : `baseline-status-${baseline.status}`,
        tried: 0, hits: [], rejected: [], baseline
      });
      continue;
    }
    // Annotate baseline with detected condition (for diagnostic display).
    baseline.protectionKind = (baseline.status >= 400 && baseline.status < 500)
      ? `4xx-${baseline.status}`
      : baselineIsLoginRedirect ? "login-redirect"
      : baselineIsBlackHole ? "black-hole-404"
      : "unknown-protected";

    const techList = priority.slice(0, PER_URL_VARIANT_CAP);
    const urlTelemetry = { path, baseline, tried: 0, hits: [], rejected: [] };
    const queue = [...techList];

    const workers = Array.from({ length: CONCURRENCY }, async () => {
      while (queue.length) {
        const techId = queue.shift();
        const tech = TECHNIQUES[techId];
        if (!tech) continue;
        telemetry.variantsTried++;
        urlTelemetry.tried++;

        let attempt;
        try { attempt = tech.build(urlObj, path); } catch { continue; }
        const res = await safeFetch(attempt.url, attempt.opts);
        if (!res) {
          if (diagnosticMode && urlTelemetry.rejected.length < 30) {
            urlTelemetry.rejected.push({
              id: techId, label: tech.label, kind: tech.kind, why: "network-failed-or-blocked"
            });
          }
          continue;
        }

        const body = res.status >= 300 && res.status < 400 ? "" : await readSample(res);
        const cand2 = {
          status: res.status,
          finalUrl: res.url,
          bodyLen: body.length,
          location: res.headers.get("location") || "",
          class: classifyResponse(body),
          body
        };

        let verdict = isBypass(baseline, cand2);

        // Additional filters against real-world false positives:
        if (verdict.ok) {
          // 1. Redirect / server-served the SAME 404 body → probably still black-hole
          if (isBlackHole404(cand2, siteFP)) {
            verdict = { ok: false, why: "matches-site-404-fingerprint" };
          }
        }
        if (verdict.ok) {
          // 2. Header-rewrite techniques often make the server treat the request as
          //    "/" and serve the homepage. Reject if response looks like the homepage.
          if ((tech.kind === "header" || tech.kind === "combo")
              && /original-url|rewrite-url/.test(techId)
              && looksLikeHomepage(cand2, siteFP)) {
            verdict = { ok: false, why: "matches-homepage-fingerprint" };
          }
        }
        if (verdict.ok) {
          // 3. Response is a login page (URL or content) → still protected.
          if (looksLikeLoginPage(cand2)) {
            verdict = { ok: false, why: "response-is-login-page" };
          }
        }

        if (!verdict.ok) {
          if (diagnosticMode && urlTelemetry.rejected.length < 30) {
            urlTelemetry.rejected.push({
              id: techId, label: tech.label, kind: tech.kind,
              status: cand2.status, bodyLen: cand2.bodyLen, why: verdict.why
            });
          }
          continue;
        }

        // ── Verification pass: re-fetch VERIFY_ATTEMPTS times, confirm stable ──
        let verifiedCount = 0;
        for (let i = 0; i < VERIFY_ATTEMPTS; i++) {
          await sleep(200 + Math.floor(Math.random() * 300));
          const vres = await safeFetch(attempt.url, attempt.opts);
          if (!vres) continue;
          const vbody = vres.status >= 300 && vres.status < 400 ? "" : await readSample(vres);
          const vcand = {
            status: vres.status,
            finalUrl: vres.url,
            bodyLen: vbody.length,
            location: vres.headers.get("location") || "",
            class: classifyResponse(vbody),
            body: vbody
          };
          if (isBypass(baseline, vcand).ok) verifiedCount++;
        }
        // Require at least 1 of VERIFY_ATTEMPTS confirmations.
        if (verifiedCount < 1) continue;

        telemetry.variantsSuccess++;
        telemetry.verifiedBypasses++;
        urlTelemetry.hits.push({
          id: techId, label: tech.label, kind: tech.kind,
          why: verdict.why, status: cand2.status,
          verifiedCount, preview: sanitisePreview(cand2.body)
        });

        // Build courtroom-style evidence: exact request+response pair, timestamped.
        const evidence = buildEvidence(
          {
            method: attempt.opts?.method || "GET",
            url: attempt.url,
            headers: attempt.opts?.headers || {}
          },
          {
            status: cand2.status,
            finalUrl: cand2.finalUrl,
            headers: {},   // (fetch API can only expose CORS-safelisted; we keep it empty rather than mislead)
            body: cand2.body,
            bodyLen: cand2.bodyLen,
            ctype: ""
          },
          {
            baseline: {
              status: baseline.status,
              bodyLen: baseline.bodyLen,
              class: baseline.class
            },
            verdict: verdict.why,
            waf: wafInfo.primary,
            technique: { id: techId, label: tech.label, kind: tech.kind }
          }
        );

        allFindings.push({
          id: "bypass-40x-" + techId,
          title: `Access-control bypass on ${path} via ${tech.label}`,
          severity: severityFor(path),
          url: attempt.url,
          detail: `WAF: ${wafInfo.primary?.name || "not fingerprinted"}. `
                + `Baseline HTTP ${baseline.status} (${baseline.bodyLen}B, ${baseline.class}) → `
                + `HTTP ${cand2.status} (${cand2.bodyLen}B, ${cand2.class}) via technique "${tech.label}" [${verdict.why}, verified ${verifiedCount + 1}/${VERIFY_ATTEMPTS + 1}]. `
                + `Response preview: "${sanitisePreview(cand2.body)}"`,
          verified: true,
          needsManual: true,
          technique: tech.label,
          techniqueId: techId,
          techniqueKind: tech.kind,
          waf: wafInfo.primary,
          originalStatus: baseline.status,
          newStatus: cand2.status,
          why: verdict.why,
          preview: sanitisePreview(cand2.body),
          verificationScore: `${verifiedCount + 1}/${VERIFY_ATTEMPTS + 1}`,
          evidence
        });

        if (urlTelemetry.hits.length >= 8) return;
      }
    });
    await Promise.all(workers);
    telemetry.perUrl.push(urlTelemetry);
  }

  const w = { CRITICAL: 4, HIGH: 3, MEDIUM: 2, LOW: 1 };
  allFindings.sort((a, b) => (w[b.severity] || 0) - (w[a.severity] || 0));
  return { findings: allFindings, waf: wafInfo, telemetry };
}
