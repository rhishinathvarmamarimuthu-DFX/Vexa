// ReconHound — Attack-chain correlation engine
// Takes the full findings blob and correlates independent detections into
// coherent multi-stage attack chains. Each chain is a named kill-chain with:
//   · stages[]   — atomic steps an attacker would take, in order
//   · evidence[] — pointers back to the underlying findings that support it
//   · severity   — worst-case severity of the chain
//   · impact     — plain-English business impact
//
// This is CORRELATION, not exploitation: the engine identifies pre-conditions
// that already exist on the target. No payloads are generated or sent.

// Helper: does the report contain a finding whose id (or title) matches?
function has(findings, matcher) {
  return (findings || []).some((f) => matcher.test((f.id || "") + " " + (f.title || "")));
}
function pick(findings, matcher) {
  return (findings || []).filter((f) => matcher.test((f.id || "") + " " + (f.title || "")));
}
function techByName(tech, re) {
  return (tech || []).filter((t) => re.test(t.tech || ""));
}
function anyKevCve(tech) {
  for (const t of tech || []) {
    if ((t.cves || []).some((c) => c.kev)) return { tech: t.tech, cves: t.cves.filter((c) => c.kev) };
  }
  return null;
}
function anyEolTech(tech) {
  return (tech || []).filter((t) => t.outdated && (t.outdated.eol || (t.outdated.majorBehind || 0) >= 2));
}

const SEV_WEIGHT = { CRITICAL: 4, HIGH: 3, MEDIUM: 2, LOW: 1 };

// Build all applicable chains for a report.
export function buildAttackChains(report) {
  const chains = [];
  const exposures = report.exposures || [];
  const secrets = report.secrets || [];
  const security = report.security || [];
  const tech = report.tech || [];
  const jwts = report.jwts || [];

  // ── Chain 1: full source-code recovery via exposed .git ────────────
  const gitFindings = pick(exposures, /^(git-|source-map)/);
  if (gitFindings.length >= 2 || pick(exposures, /git-index/).length) {
    chains.push({
      id: "chain-git-recovery",
      title: "Full source-code disclosure → hard-coded secrets → credential theft",
      severity: "HIGH",
      stages: [
        "Read exposed /.git/HEAD + /.git/index to enumerate tracked files",
        "Download loose or packed objects from /.git/objects/",
        "Reconstruct working tree with `git cat-file`",
        "Grep recovered source for hard-coded credentials, API keys, JWT signing secrets",
        "Pivot: use recovered credentials against production APIs / cloud console"
      ],
      impact: "Complete recovery of application source, including any secrets committed to history. High risk of AWS/GCP/Azure account takeover if IaC or CI configs were ever committed.",
      evidence: gitFindings.map((f) => f.id || f.title)
    });
  }

  // ── Chain 2: env-file leak → immediate infra compromise ──────────
  const envFindings = pick(exposures, /^(env|env-local|env-prod|env-staging|env-dev|aws-creds|npmrc|pypirc|netrc)$/);
  if (envFindings.length) {
    const worst = envFindings.sort((a, b) => (SEV_WEIGHT[b.severity] || 0) - (SEV_WEIGHT[a.severity] || 0))[0];
    chains.push({
      id: "chain-env-infra",
      title: "Environment-file exposure → cloud / DB compromise",
      severity: worst.severity === "CRITICAL" ? "CRITICAL" : "HIGH",
      stages: [
        `Retrieve ${envFindings.map((f) => f.title).slice(0, 3).join(", ")}`,
        "Extract DB URIs, cloud access keys, third-party API tokens",
        "Authenticate directly against the disclosed services",
        "Escalate: use IAM permissions to enumerate & exfiltrate data"
      ],
      impact: "Immediate credentialed access to backing infrastructure. Rotation of every disclosed secret is mandatory even if only one attacker read it.",
      evidence: envFindings.map((f) => f.id || f.title)
    });
  }

  // ── Chain 3: WordPress plugin RCE chain ─────────────────────────────
  const wpRiskPlugin = pick(exposures, /^wp-plugin-risk-/);
  const wpVersion = techByName(tech, /^WordPress$/);
  if (wpRiskPlugin.length && wpVersion.length) {
    chains.push({
      id: "chain-wp-plugin-rce",
      title: `WordPress ${wpVersion[0].version || ""} + high-risk plugin → potential RCE`,
      severity: "HIGH",
      stages: [
        `Confirm WordPress core version (${wpVersion[0].version || "unknown"}) via /readme.html`,
        `Fingerprint vulnerable plugin(s): ${wpRiskPlugin.map((f) => (f.title || "").replace(/^High-risk plugin\s*/, "")).slice(0, 3).join("; ")}`,
        "Cross-reference exact plugin version against published advisories",
        "If vulnerable version detected, RCE / auth-bypass exploits often exist publicly"
      ],
      impact: "Compromise typically yields shell-level access on the web server hosting WordPress. From there, credential theft and lateral movement into the DB tier are common next steps.",
      evidence: wpRiskPlugin.map((f) => f.id || f.title)
    });
  }

  // ── Chain 4: KEV CVE + known-outdated component ─────────────────────
  const kev = anyKevCve(tech);
  if (kev) {
    chains.push({
      id: "chain-kev-exploitation",
      title: `Actively-exploited CVE on ${kev.tech}`,
      severity: "CRITICAL",
      stages: [
        `Confirm ${kev.tech} version reported by response headers / runtime globals`,
        `Reference CISA KEV entry: ${kev.cves.map((c) => c.id).slice(0, 3).join(", ")}`,
        "Locate public exploit (ExploitDB / Metasploit / Nuclei template)",
        "Attempt exploitation against a mirror of the target — do not fire directly at prod without written scope"
      ],
      impact: "Vulnerability is on CISA's Known Exploited list — real threat actors are already using it in the wild. Immediate patch or virtual patch required.",
      evidence: kev.cves.map((c) => c.id)
    });
  }

  // ── Chain 5: unauthenticated Spring Actuator → heap/env → secrets ──
  const actuator = pick(exposures, /^actuator-/);
  const heapdump = pick(exposures, /^actuator-heapdump$/);
  const actuatorEnv = pick(exposures, /^actuator-env(-legacy)?$/);
  if (actuator.length) {
    const stages = ["Enumerate /actuator index for reachable endpoints"];
    if (heapdump.length) stages.push("Download /actuator/heapdump — full JVM memory including live secrets");
    if (actuatorEnv.length) stages.push("Read /actuator/env — DB passwords, cloud tokens, encryption keys in property sources");
    stages.push("Optional: /actuator/mappings gives internal route map for further attack surface");
    stages.push("Optional: /actuator/loggers may be writable → toggle DEBUG logging to leak more");
    chains.push({
      id: "chain-actuator-secrets",
      title: "Spring Boot Actuator unauthenticated → secret exfiltration",
      severity: heapdump.length || actuatorEnv.length ? "CRITICAL" : "HIGH",
      stages,
      impact: "Actuator management endpoints are read-only in principle but on misconfigured instances they leak the entire application configuration, including every secret injected via Spring properties.",
      evidence: [...actuator, ...heapdump, ...actuatorEnv].map((f) => f.id || f.title)
    });
  }

  // ── Chain 6: subdomain takeover → phishing / session fixation ───────
  const takeovers = pick(exposures, /^takeover-/);
  if (takeovers.length) {
    chains.push({
      id: "chain-takeover-phishing",
      title: "Dangling-CNAME subdomain takeover → session hijack / phishing",
      severity: "MEDIUM",
      stages: [
        `DNS-verify the ${takeovers.length} candidate CNAME(s) point to unclaimed provider resources`,
        `Register the target on the provider (${[...new Set(takeovers.map((t) => t.service))].join(", ")})`,
        "Host attacker-controlled content on the reclaimed subdomain",
        "Session cookies scoped to the parent domain may be exposed if cookies use Domain=.<parent>",
        "OR: mount a highly-credible phishing page under the legitimate brand's DNS"
      ],
      impact: "Attacker gains a subdomain of the target's own DNS zone — bypasses most anti-phishing heuristics. If parent domain scopes cookies broadly, direct session theft is possible.",
      evidence: takeovers.map((t) => t.id || t.title)
    });
  }

  // ── Chain 7: JWT alg:none / kid-injection → auth bypass ─────────────
  const badJwts = (jwts || []).filter((j) => (j.issues || []).some(
    (i) => (i.severity === "CRITICAL" || (i.severity === "HIGH" && /kid|jku|x5u/i.test(i.text)))
  ));
  if (badJwts.length) {
    chains.push({
      id: "chain-jwt-bypass",
      title: "JWT algorithm confusion / key-injection → authentication bypass",
      severity: "HIGH",
      stages: [
        `Confirm token structure via observed JWT (alg=${badJwts[0].algorithm})`,
        "Craft token with alg=none or attacker-controlled kid/jku",
        "Submit to protected endpoint; check whether server validates alg allowlist",
        "If bypass succeeds, forge tokens for arbitrary users"
      ],
      impact: "Full authentication bypass — attacker can impersonate any user known to the server, including administrative accounts.",
      evidence: badJwts.map((j) => `jwt:${j.algorithm || "?"}`)
    });
  }

  // ── Chain 8: GraphQL introspection → business-logic mapping ────────
  const graphql = pick(exposures, /^graphql-introspection$/);
  if (graphql.length) {
    chains.push({
      id: "chain-graphql-map",
      title: "GraphQL introspection → unauthorised data-model mapping",
      severity: "MEDIUM",
      stages: [
        "Introspect complete schema (types, queries, mutations)",
        "Identify sensitive fields (users, tokens, internal fields)",
        "Craft queries against fields not exposed via the UI — often the least-authenticated path",
        "Test rate limits and field-level authorisation"
      ],
      impact: "Full disclosure of the API's data model reveals internal fields the UI never surfaces — a common source of IDOR / broken-auth bugs.",
      evidence: graphql.map((f) => f.id || f.title)
    });
  }

  // ── Chain 9: EOL tech + missing security headers → drive-by risk ────
  const eol = anyEolTech(tech);
  const missingCsp = has(security, /content-security-policy/i);
  if (eol.length && missingCsp) {
    chains.push({
      id: "chain-eol-drive-by",
      title: "End-of-life component + no CSP → client-side compromise risk",
      severity: "MEDIUM",
      stages: [
        `Identify unpatched EOL component(s): ${eol.map((t) => `${t.tech} ${t.version}`).join(", ")}`,
        "No Content-Security-Policy means injected scripts run unrestricted",
        "Any unpatched XSS in the EOL component gives full JS execution",
        "Chain with cookie theft or credential-harvest overlay"
      ],
      impact: "EOL software will never receive security patches. Combined with a missing CSP, one unpatched XSS bug is enough for account takeover of any visiting user.",
      evidence: [...eol.map((t) => `${t.tech}@${t.version}`), "missing-csp"]
    });
  }

  // ── Chain 10: 40x bypass on admin/mgmt path → unauthenticated access ──
  const bypasses = pick(exposures, /^bypass-40x-/);
  if (bypasses.length) {
    const highRisk = bypasses.filter((b) => b.severity === "HIGH" || b.severity === "CRITICAL");
    const primary = (highRisk[0] || bypasses[0]);
    chains.push({
      id: "chain-40x-bypass",
      title: "Access-control bypass → unauthenticated admin surface",
      severity: highRisk.length ? "HIGH" : "MEDIUM",
      stages: [
        `Baseline: ${bypasses.length} restricted path(s) returned 4xx (WAF/proxy denies)`,
        `Discover misconfiguration via ${primary.technique || "path/method/header trick"}`,
        `Backend serves the resource despite fronting-layer denial (URL: ${primary.url || "see finding"})`,
        "Enumerate the exposed admin/API surface without auth",
        "Chain with credential-less endpoints or IDOR to pivot deeper"
      ],
      impact: "Fronting WAF/reverse-proxy and origin server disagree on access control. Anything the WAF blocked is now reachable through the identified bypass vector.",
      evidence: bypasses.map((b) => b.title || b.id)
    });
  }

  // ── Chain 11: exposed backup → offline analysis → deeper attacks ───
  const backups = pick(exposures, /(backup|db-sql|dump-sql|site-zip|wp-backup)/);
  if (backups.length) {
    chains.push({
      id: "chain-backup-offline",
      title: "Downloadable backup → offline analysis → credential harvest",
      severity: backups.some((b) => b.severity === "CRITICAL") ? "CRITICAL" : "HIGH",
      stages: [
        `Download ${backups.length} exposed backup artefact(s)`,
        "Analyse offline — no rate limits, no logging",
        "Extract database schema + row data, hashed credentials, application secrets",
        "Crack any recovered password hashes against captured usernames",
        "Re-attack with valid credentials"
      ],
      impact: "Backups typically contain the entire dataset the application manages, plus configuration. Offline analysis defeats rate-limits, WAFs, and auth logging.",
      evidence: backups.map((f) => f.id || f.title)
    });
  }

  // Rank chains by severity so the most-important ones render first.
  chains.sort((a, b) => (SEV_WEIGHT[b.severity] || 0) - (SEV_WEIGHT[a.severity] || 0));
  return chains;
}
