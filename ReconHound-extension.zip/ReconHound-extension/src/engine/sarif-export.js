// ReconHound — SARIF v2.1.0 export
// Author: Rhishinathvarma Marimuthu
//
// Produces a schema-conformant SARIF (Static Analysis Results Interchange
// Format) 2.1.0 document from a ReconHound report. SARIF is the industry
// standard for security-tool interchange — GitHub Advanced Security, Azure
// DevOps, Splunk, and every mainstream SAST/DAST pipeline consumes it.
//
// Spec: https://docs.oasis-open.org/sarif/sarif/v2.1.0/sarif-v2.1.0.html
//
// This file has ONE dependency: taxonomy.js for OWASP/CWE/MITRE mapping.

import { classifyFinding } from "./taxonomy.js";

const SARIF_VERSION = "2.1.0";
const SARIF_SCHEMA = "https://raw.githubusercontent.com/oasis-tcs/sarif-spec/master/Schemata/sarif-schema-2.1.0.json";

function sevToLevel(sev) {
  switch (String(sev || "").toUpperCase()) {
    case "CRITICAL": case "HIGH": return "error";
    case "MEDIUM":                return "warning";
    case "LOW":                   return "note";
    default:                      return "none";
  }
}

// Assemble the unique rules array (SARIF wants each ruleId defined once in
// tool.driver.rules, then referenced by ruleId in each result).
function buildRules(findings) {
  const seen = new Map();
  for (const f of findings) {
    const id = f.id || "unknown";
    if (seen.has(id)) continue;
    const tax = classifyFinding(f) || {};
    seen.set(id, {
      id,
      name: id.replace(/-/g, "_"),
      shortDescription: { text: (f.title || id).slice(0, 200) },
      fullDescription:  { text: (f.detail || f.title || id).slice(0, 1000) },
      defaultConfiguration: { level: sevToLevel(f.severity) },
      properties: {
        "security-severity": severityToScore(f.severity),
        tags: [
          "security",
          ...(tax.cwe || []),
          tax.owasp ? `owasp:${tax.owasp.split(":")[0]}` : null,
          ...((tax.mitre || []).map((m) => `mitre:${m}`))
        ].filter(Boolean),
        owasp: tax.owasp || "Unclassified",
        cwe: tax.cwe || [],
        mitre: tax.mitre || []
      },
      help: {
        text: (f.detail || "").slice(0, 2000) + (tax.cwe?.length ? `\n\nCWE: ${tax.cwe.join(", ")}` : ""),
        markdown: buildRuleHelp(f, tax)
      }
    });
  }
  return [...seen.values()];
}

function buildRuleHelp(f, tax) {
  const lines = [`**${f.title || f.id}**`, "", f.detail || ""];
  if (tax.owasp) lines.push("", `**OWASP:** ${tax.owasp}`);
  if (tax.cwe?.length) lines.push(`**CWE:** ${tax.cwe.join(", ")}`);
  if (tax.mitre?.length) lines.push(`**MITRE ATT&CK:** ${tax.mitre.join(", ")}`);
  return lines.join("\n");
}

function severityToScore(sev) {
  switch (String(sev || "").toUpperCase()) {
    case "CRITICAL": return "9.5";
    case "HIGH":     return "7.5";
    case "MEDIUM":   return "5.0";
    case "LOW":      return "2.5";
    default:         return "0.0";
  }
}

function findingToResult(f) {
  const url = f.url || "";
  return {
    ruleId: f.id || "unknown",
    level: sevToLevel(f.severity),
    message: { text: f.detail || f.title || f.id || "" },
    locations: url ? [{
      physicalLocation: {
        artifactLocation: { uri: url },
        region: { startLine: 1 }
      }
    }] : [],
    properties: {
      severity: f.severity || "UNKNOWN",
      technique: f.technique || null,
      waf: f.waf?.name || null,
      verified: !!f.verified,
      needsManual: !!f.needsManual,
      verificationScore: f.verificationScore || null,
      evidence: f.evidence ? {
        capturedAt: f.evidence.capturedAt,
        request: f.evidence.request,
        response: {
          status: f.evidence.response?.status,
          bodyBytes: f.evidence.response?.bodyBytes,
          contentType: f.evidence.response?.contentType,
          headers: f.evidence.response?.headers,
          bodyPreview: f.evidence.response?.bodyPreview
        }
      } : null
    }
  };
}

export function buildSarif(report) {
  const findings = [
    ...(report.security || []),
    ...(report.secrets || []),
    ...(report.exposures || []),
    ...(report.activeScan || [])
  ];
  // CVEs flattened into results as well.
  for (const t of (report.tech || [])) {
    for (const cve of (t.cves || [])) {
      findings.push({
        id: "cve-" + cve.id.toLowerCase(),
        title: `${cve.id} affects ${t.tech}${t.version ? " " + t.version : ""}`,
        severity: cve.severity,
        url: cve.nvd,
        detail: `${cve.id} — CVSS ${cve.score ?? "?"}${cve.kev ? " · CISA KEV" : ""}${cve.epss ? ` · EPSS ${(cve.epss * 100).toFixed(1)}%` : ""}. ${cve.summary || ""}`,
        verified: !!cve.confidence,
        evidence: null
      });
    }
  }

  const results = findings.map(findingToResult);
  const rules   = buildRules(findings);

  return {
    version: SARIF_VERSION,
    $schema: SARIF_SCHEMA,
    runs: [{
      tool: {
        driver: {
          name: "ReconHound",
          version: "1.6.0",
          semanticVersion: "1.6.0",
          informationUri: "https://example.local/reconhound",
          organization: "Rhishinathvarma Marimuthu",
          shortDescription: {
            text: "Tech-stack fingerprinting, CVE + exploit intelligence, WAF-aware access-control probing, and misconfiguration verification for authorised assessments."
          },
          rules
        }
      },
      invocations: [{
        executionSuccessful: true,
        startTimeUtc: new Date().toISOString(),
        endTimeUtc: new Date().toISOString()
      }],
      results,
      originalUriBaseIds: report.url ? {
        "TARGET": { uri: safeOrigin(report.url) }
      } : undefined,
      properties: {
        riskGrade: report.risk?.grade || null,
        riskScore: report.risk?.score || null,
        counts:    report.risk?.counts || null,
        target:    report.url || null,
        waf:       report.waf?.primary?.name || null,
        author:    "Rhishinathvarma Marimuthu"
      }
    }]
  };
}

function safeOrigin(u) { try { return new URL(u).origin + "/"; } catch { return u; } }
