// ReconHound — DNS-over-HTTPS analyser
// Author: Rhishinathvarma Marimuthu
//
// Queries A / AAAA / MX / TXT / NS / CAA / DMARC / DKIM records via Cloudflare
// (1.1.1.1) and Google (8.8.8.8) DoH JSON endpoints. Both are CORS-friendly,
// no auth needed. We parse SPF/DMARC textual policies and flag common
// misconfigurations that bug-bounty and pentest reports highlight:
//   · SPF `+all` / missing hard-fail
//   · DMARC `p=none`, missing `rua`, subdomain policy weaker than parent
//   · DKIM absent on common selectors
//   · CAA missing
//   · Split-view / mixed NS providers

import { markSourceOk, markSourceDown } from "./source-status.js";

const DOH_ENDPOINTS = [
  "https://cloudflare-dns.com/dns-query",
  "https://dns.google/resolve"
];

const CACHE_KEY = "rh_dns_cache";
const CACHE_TTL_MS = 60 * 60 * 1000; // 1 h

async function readCache() {
  try { const d = await chrome.storage.session.get(CACHE_KEY); return d[CACHE_KEY] || {}; }
  catch { return {}; }
}
async function writeCache(c) {
  try { await chrome.storage.session.set({ [CACHE_KEY]: c }); } catch (_) {}
}

async function doh(name, type) {
  const cacheKey = `${name.toLowerCase()}|${type}`;
  const cache = await readCache();
  if (cache[cacheKey] && Date.now() - cache[cacheKey].ts < CACHE_TTL_MS) {
    return cache[cacheKey].data;
  }
  for (const endpoint of DOH_ENDPOINTS) {
    try {
      const controller = new AbortController();
      const t = setTimeout(() => controller.abort(), 6000);
      const res = await fetch(`${endpoint}?name=${encodeURIComponent(name)}&type=${type}`, {
        headers: { accept: "application/dns-json" },
        signal: controller.signal
      });
      clearTimeout(t);
      if (!res.ok) continue;
      const json = await res.json();
      markSourceOk("dns-doh");
      cache[cacheKey] = { ts: Date.now(), data: json };
      await writeCache(cache);
      return json;
    } catch (_) { /* try next endpoint */ }
  }
  markSourceDown("dns-doh", "all endpoints failed");
  return null;
}

// Extract answers of a given type. `TXT` answers come as concatenated segments.
function answers(json, filterType = null) {
  if (!json || !Array.isArray(json.Answer)) return [];
  const list = json.Answer.map((a) => ({
    name: a.name, type: a.type, ttl: a.TTL,
    data: typeof a.data === "string" ? a.data.replace(/^"|"$/g, "").replace(/"\s+"/g, "") : a.data
  }));
  return filterType == null ? list : list.filter((a) => a.type === filterType);
}

const TYPE = { A: 1, AAAA: 28, MX: 15, TXT: 16, NS: 2, CAA: 257, SOA: 6 };

// ── SPF parsing ────────────────────────────────────────────────────────────
function parseSpf(txt) {
  const tokens = txt.trim().split(/\s+/);
  const includes = tokens.filter((t) => /^include:/i.test(t)).map((t) => t.slice(8));
  const ipv4 = tokens.filter((t) => /^ip4:/i.test(t)).map((t) => t.slice(4));
  const ipv6 = tokens.filter((t) => /^ip6:/i.test(t)).map((t) => t.slice(4));
  const all = tokens.find((t) => /^([+\-~?])?all$/i.test(t)) || null;
  const qualifier = all ? (["+", "-", "~", "?"].includes(all[0]) ? all[0] : "+") : null;
  return { raw: txt, includes, ipv4, ipv6, allQualifier: qualifier };
}

// ── DMARC parsing ──────────────────────────────────────────────────────────
function parseDmarc(txt) {
  const out = {};
  txt.split(/;\s*/).forEach((part) => {
    const [k, v] = part.split("=").map((s) => (s || "").trim());
    if (k) out[k.toLowerCase()] = v || "";
  });
  return out;
}

// Analyse DNS records for a host and produce structured findings.
export async function analyzeDns(host) {
  const findings = [];
  const data = { host };
  if (!host) return { findings, data };

  // Registrable domain heuristic.
  const parts = host.split(".").filter(Boolean);
  const rootDomain = parts.length > 2 ? parts.slice(-2).join(".") : host;
  data.rootDomain = rootDomain;

  // Parallel record fetch.
  const [a, aaaa, mx, txt, ns, caa, dmarcTxt] = await Promise.all([
    doh(host, TYPE.A),
    doh(host, TYPE.AAAA),
    doh(rootDomain, TYPE.MX),
    doh(rootDomain, TYPE.TXT),
    doh(rootDomain, TYPE.NS),
    doh(rootDomain, TYPE.CAA),
    doh("_dmarc." + rootDomain, TYPE.TXT)
  ]);

  data.A     = answers(a, TYPE.A).map((r) => r.data);
  data.AAAA  = answers(aaaa, TYPE.AAAA).map((r) => r.data);
  data.MX    = answers(mx, TYPE.MX).map((r) => r.data);
  data.NS    = answers(ns, TYPE.NS).map((r) => r.data.replace(/\.$/, ""));
  data.CAA   = answers(caa, TYPE.CAA).map((r) => r.data);
  data.TXT   = answers(txt, TYPE.TXT).map((r) => r.data);
  data.DMARC = answers(dmarcTxt, TYPE.TXT).map((r) => r.data);

  // ── SPF ────────────────────────────────────────────────────────────────
  const spfRecords = data.TXT.filter((t) => /^v=spf1/i.test(t));
  if (!spfRecords.length) {
    findings.push({
      id: "dns-no-spf",
      title: `No SPF record on ${rootDomain}`,
      severity: "MEDIUM",
      url: rootDomain,
      detail: "Domain has no SPF record — email spoofing surface. Add v=spf1 with hard-fail ('-all').",
      verified: true
    });
  } else if (spfRecords.length > 1) {
    findings.push({
      id: "dns-multiple-spf",
      title: `Multiple SPF records on ${rootDomain}`,
      severity: "MEDIUM",
      url: rootDomain,
      detail: "RFC 7208 forbids multiple SPF records — receivers will treat SPF as PermError. Merge into one.",
      verified: true
    });
  } else {
    const spf = parseSpf(spfRecords[0]);
    data.spf = spf;
    if (spf.allQualifier === "+" || spf.allQualifier === "?") {
      findings.push({
        id: "dns-spf-permissive",
        title: `SPF policy permissive: "${spf.allQualifier}all"`,
        severity: "HIGH",
        url: rootDomain,
        detail: `SPF record ends in ${spf.allQualifier}all — permits any sender. Change to '-all' (hard fail).`,
        verified: true
      });
    } else if (!spf.allQualifier) {
      findings.push({
        id: "dns-spf-no-all",
        title: `SPF record missing 'all' mechanism`,
        severity: "MEDIUM",
        url: rootDomain,
        detail: "Terminate the SPF policy with '-all' (hard fail) or '~all' (soft fail) to prevent spoofing.",
        verified: true
      });
    }
  }

  // ── DMARC ──────────────────────────────────────────────────────────────
  const dmarcRecords = data.DMARC.filter((t) => /^v=DMARC1/i.test(t));
  if (!dmarcRecords.length) {
    findings.push({
      id: "dns-no-dmarc",
      title: `No DMARC record on _dmarc.${rootDomain}`,
      severity: "HIGH",
      url: rootDomain,
      detail: "No DMARC policy published — recipients have no instruction on how to handle SPF/DKIM failures. Add v=DMARC1; p=reject with rua= reporting.",
      verified: true
    });
  } else {
    const dmarc = parseDmarc(dmarcRecords[0]);
    data.dmarc = dmarc;
    if (!dmarc.p || dmarc.p.toLowerCase() === "none") {
      findings.push({
        id: "dns-dmarc-monitor-only",
        title: `DMARC in monitor-only mode (p=${dmarc.p || "unset"})`,
        severity: "MEDIUM",
        url: rootDomain,
        detail: "p=none means DMARC is monitoring only — failures still get delivered. Move to p=quarantine or p=reject once confident.",
        verified: true
      });
    }
    if (!dmarc.rua) {
      findings.push({
        id: "dns-dmarc-no-rua",
        title: `DMARC missing 'rua' aggregate-reporting address`,
        severity: "LOW",
        url: rootDomain,
        detail: "Without rua= there is no reporting stream — you cannot detect who is spoofing your domain.",
        verified: true
      });
    }
    if (dmarc.sp && dmarc.sp.toLowerCase() === "none" && dmarc.p && dmarc.p.toLowerCase() !== "none") {
      findings.push({
        id: "dns-dmarc-subdomain-weak",
        title: `DMARC subdomain policy weaker than parent (sp=none, p=${dmarc.p})`,
        severity: "MEDIUM",
        url: rootDomain,
        detail: "Subdomains do not inherit the parent's DMARC enforcement — subdomain-scoped spoofing possible.",
        verified: true
      });
    }
  }

  // ── DKIM (probe common selectors) ──────────────────────────────────────
  const DKIM_SELECTORS = ["default", "google", "selector1", "selector2", "k1", "mail", "dkim"];
  data.dkim = {};
  await Promise.all(DKIM_SELECTORS.map(async (sel) => {
    const res = await doh(`${sel}._domainkey.${rootDomain}`, TYPE.TXT);
    const recs = answers(res, TYPE.TXT).map((r) => r.data);
    if (recs.some((r) => /v=DKIM1/i.test(r))) data.dkim[sel] = recs;
  }));
  if (!Object.keys(data.dkim).length && data.MX.length) {
    findings.push({
      id: "dns-no-dkim",
      title: `No DKIM records found on common selectors for ${rootDomain}`,
      severity: "LOW",
      url: rootDomain,
      detail: `Probed selectors: ${DKIM_SELECTORS.join(", ")}. If email is used, at least one DKIM selector should be published.`,
      verified: false,
      needsManual: true
    });
  }

  // ── CAA ────────────────────────────────────────────────────────────────
  if (!data.CAA.length) {
    findings.push({
      id: "dns-no-caa",
      title: `No CAA record on ${rootDomain}`,
      severity: "LOW",
      url: rootDomain,
      detail: "No CAA record restricts which CAs may issue certificates for this domain. Add 'issue' + 'issuewild' rules.",
      verified: true
    });
  }

  // ── Mixed NS ───────────────────────────────────────────────────────────
  const nsProviders = new Set(data.NS.map((n) => {
    const parts = n.toLowerCase().split(".").filter(Boolean);
    return parts.slice(-2).join(".");
  }));
  data.nsProviders = [...nsProviders];
  if (nsProviders.size > 1) {
    findings.push({
      id: "dns-mixed-ns",
      title: `Mixed DNS providers (${nsProviders.size} distinct SLDs) on ${rootDomain}`,
      severity: "LOW",
      url: rootDomain,
      detail: `Name servers span ${[...nsProviders].join(", ")}. Verify this is intentional — accidental split can cause resolution inconsistencies.`,
      verified: true
    });
  }

  return { findings, data };
}
