// ReconHound — Session cookie structural decoder
// Author: Rhishinathvarma Marimuthu
//
// When a session-like cookie is observed we attempt STRUCTURAL decode only
// (no key recovery, no forgery). We identify the framework, split into
// {payload, signature}, and flag if the payload is base64/JSON (unencrypted)
// vs opaque (encrypted or HMACed).
//
// Supported formats (structural only):
//   · Flask / itsdangerous:  base64.base64.hmac
//   · Django:                base64:signature   (SHA1-HMAC by default)
//   · Rails signed:          base64--sig
//   · Rails encrypted:       base64--iv--tag
//   · Express (cookie-session): base64.hmac
//   · Laravel:               AES-encrypted opaque (we flag as encrypted)
//   · JWT-in-cookie:         eyJ.eyJ.sig

function b64urlDecode(s) {
  s = String(s || "").replace(/-/g, "+").replace(/_/g, "/");
  while (s.length % 4) s += "=";
  try {
    const bin = atob(s);
    const bytes = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
    return new TextDecoder().decode(bytes);
  } catch (_) { return null; }
}
function tryJson(s) { try { return JSON.parse(s); } catch { return null; } }

const KNOWN_NAMES = {
  "session":              { framework: "Flask (itsdangerous)" },
  "connect.sid":          { framework: "Express (express-session)" },
  "express:sess":         { framework: "Express (cookie-session)" },
  "express:sess.sig":     { framework: "Express (cookie-session signature)" },
  "session-id":           { framework: "generic" },
  "sessionid":            { framework: "Django" },
  "csrftoken":            { framework: "Django CSRF" },
  "_session_id":          { framework: "Rails" },
  "_rails_session":       { framework: "Rails" },
  "laravel_session":      { framework: "Laravel" },
  "ci_session":           { framework: "CodeIgniter" },
  "phpsessid":            { framework: "PHP" },
  "jsessionid":           { framework: "Java (JSP)" },
  "asp.net_sessionid":    { framework: "ASP.NET" },
  "aspxauth":             { framework: "ASP.NET Forms Auth" },
  ".aspxauth":            { framework: "ASP.NET Forms Auth" },
  "wordpress_logged_in":  { framework: "WordPress" }
};

function isJwt(v) {
  return typeof v === "string" && /^eyJ[A-Za-z0-9_-]+\.eyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+$/.test(v);
}

function inspectFlask(v) {
  // Flask session cookies: <base64-payload>.<base64-timestamp>.<hmac>
  // Or with compression: .<b64>.<b64>.<b64>
  const parts = v.split(".");
  if (parts.length !== 3 && parts.length !== 4) return null;
  const payloadRaw = parts.length === 3 ? parts[0] : parts[1];
  const decoded = b64urlDecode(payloadRaw.replace(/^\./, ""));
  if (!decoded) return null;
  const json = tryJson(decoded);
  return json ? {
    framework: "Flask (itsdangerous)",
    encrypted: false,
    payload: json,
    warnings: ["Session payload is base64-encoded JSON — NOT encrypted. Any observer can read (but not modify without the secret_key)."]
  } : null;
}

function inspectDjango(v) {
  // Django default: base64(pickle):hmac_sha1  (or ...:hmac_sha256 in newer)
  const parts = v.split(":");
  if (parts.length < 2) return null;
  const payload = parts[0];
  const decoded = b64urlDecode(payload);
  if (!decoded) return null;
  // If the payload starts with a JSON blob, it's newer Django (JSON serializer).
  const j = tryJson(decoded);
  const warnings = [];
  if (j) warnings.push("Django session uses JSON serializer — payload is HMAC-signed, not encrypted.");
  else warnings.push("Django session may be using the pickle serializer — verify serializer is 'json' (SECURE), never 'pickle' (deserialisation RCE risk).");
  return { framework: "Django", encrypted: false, payload: j || `<opaque: ${payload.length} bytes>`, warnings };
}

function inspectRails(v) {
  // Rails signed cookie: base64--hex_sig
  // Rails encrypted cookie: base64--base64_iv--base64_tag
  const parts = v.split("--");
  if (parts.length < 2) return null;
  if (parts.length === 2) {
    const decoded = b64urlDecode(parts[0]);
    const j = decoded ? tryJson(decoded) : null;
    return {
      framework: "Rails (signed)",
      encrypted: false,
      payload: j || `<opaque: ${parts[0].length} bytes>`,
      warnings: [
        j ? "Rails session is HMAC-signed but NOT encrypted — payload is visible."
          : "Rails session appears encoded but not JSON — could be Marshal (RCE risk if secret_key_base leaks)."
      ]
    };
  }
  if (parts.length >= 3) {
    return {
      framework: "Rails (encrypted)",
      encrypted: true,
      payload: `<encrypted, ${parts[0].length}B ciphertext + iv + tag>`,
      warnings: ["Rails encrypted cookie — payload not recoverable without secret_key_base."]
    };
  }
  return null;
}

function inspectLaravel(v) {
  // Laravel v5+: base64({"iv":"...","value":"...","mac":"...","tag":""})
  const json = tryJson(b64urlDecode(v) || "");
  if (json && json.iv && json.value && json.mac) {
    return {
      framework: "Laravel",
      encrypted: true,
      payload: `<AES-256-CBC, ${json.value.length}B ciphertext>`,
      warnings: ["Laravel encrypted session — payload not recoverable without APP_KEY. If APP_KEY leaks, RCE via unserialize is possible."]
    };
  }
  return null;
}

function inspectPhp(v) {
  // PHPSESSID is a session identifier only — no payload in the cookie itself.
  if (/^[a-z0-9]{20,40}$/i.test(v)) {
    return { framework: "PHP", encrypted: null, payload: `<opaque session identifier>`, warnings: ["PHPSESSID is an opaque server-side handle — no payload on the wire."] };
  }
  return null;
}

// Top-level: classify a name/value cookie into structured session data.
export function decodeSessionCookie(name, value) {
  const lname = String(name || "").toLowerCase();
  if (!value || !name) return null;

  // JWT in a cookie has a distinctive shape and beats everything else.
  if (isJwt(value)) {
    return { framework: "JWT-in-cookie", encrypted: false, payload: "<see JWT panel for full decode>", warnings: ["JWT payload is base64-JSON, not encrypted — decode via KEYS/JWT view."] };
  }

  const info = KNOWN_NAMES[lname] || null;

  // Try framework-specific decoders in an ordered dispatch.
  return inspectFlask(value)
      || inspectRails(value)
      || inspectDjango(value)
      || inspectLaravel(value)
      || inspectPhp(value)
      || (info ? { framework: info.framework, encrypted: null, payload: "<opaque>", warnings: [] } : null);
}

// Analyse an entire Set-Cookie header (single value) and produce findings.
// Callers pass observed Set-Cookie strings captured via chrome.webRequest.
export function analyzeSetCookie(rawSetCookie, url = "") {
  if (!rawSetCookie) return { findings: [], decoded: null };
  const findings = [];
  const parts = rawSetCookie.split(";").map((s) => s.trim());
  const [name, ...valBits] = (parts[0] || "").split("=");
  const value = valBits.join("=");
  const flags = new Set(parts.slice(1).map((p) => p.toLowerCase().split("=")[0]));
  const secure = flags.has("secure");
  const httpOnly = flags.has("httponly");
  const sameSite = (parts.slice(1).find((p) => /^samesite/i.test(p)) || "").split("=")[1] || null;

  const decoded = decodeSessionCookie(name, value);
  if (decoded) {
    findings.push({
      id: "session-decoded-" + (name || "unknown").toLowerCase(),
      title: `Session cookie "${name}" identified as ${decoded.framework}`,
      severity: decoded.encrypted === true ? "LOW" : decoded.encrypted === false ? "MEDIUM" : "LOW",
      url,
      detail: (decoded.warnings || []).join(" ") + (decoded.encrypted === false ? " Do not put PII in the payload." : ""),
      verified: true,
      needsManual: true,
      decoded
    });
  }
  // Flag flag hygiene
  if (name && /session|auth|csrf|sid|token/i.test(name)) {
    if (!secure) findings.push({
      id: "cookie-no-secure-" + name.toLowerCase(),
      title: `Cookie "${name}" missing Secure flag`,
      severity: "MEDIUM",
      url,
      detail: "Session/auth-related cookie lacks Secure — will be sent over cleartext HTTP.",
      verified: true
    });
    if (!httpOnly) findings.push({
      id: "cookie-no-httponly-" + name.toLowerCase(),
      title: `Cookie "${name}" missing HttpOnly flag`,
      severity: "MEDIUM",
      url,
      detail: "Session/auth-related cookie readable via document.cookie — XSS can steal it.",
      verified: true
    });
    if (!sameSite || /none/i.test(sameSite)) findings.push({
      id: "cookie-samesite-none-" + name.toLowerCase(),
      title: `Cookie "${name}" SameSite=${sameSite || "unset"}`,
      severity: sameSite ? "LOW" : "MEDIUM",
      url,
      detail: sameSite ? "Explicit SameSite=None means the cookie is sent cross-site — verify CSRF defence is in place."
                       : "SameSite not set — browser default varies. Set SameSite=Lax or Strict explicitly.",
      verified: true
    });
  }

  return { findings, decoded };
}
