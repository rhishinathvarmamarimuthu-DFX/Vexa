// ReconHound — Deep Content-Security-Policy analyser
// Author: Rhishinathvarma Marimuthu
//
// Parses a CSP header string and flags known-bypass classes. Assigns a grade
// A/B/C/D/F based on how much realistic XSS defence the policy actually
// provides. Signatures come from published web-security research.
//
// Key checks:
//   · 'unsafe-inline' in script-src              → biggest single weakness
//   · 'unsafe-eval'                              → eval-based sinks unblocked
//   · Wildcard sources (*)                       → almost no defence
//   · JSONP endpoint whitelisting (known-bad hosts) → script-gadget XSS
//   · AngularJS CDN whitelisted                  → template-injection XSS
//   · Missing frame-ancestors / object-src       → clickjacking + Flash
//   · Missing base-uri                           → base-tag injection
//   · Nonce reuse / short nonces                 → predictability
//   · report-only without enforcement            → policy is advisory only

// Well-known JSONP hosts that turn a CSP allowlist into an XSS bypass surface.
// Curated from google/csp-evaluator (Apache-2.0), reduced to worst offenders.
const JSONP_BYPASS_HOSTS = [
  "www.google.com", "ajax.googleapis.com", "ajax.aspnetcdn.com",
  "cdnjs.cloudflare.com", "code.jquery.com", "unpkg.com", "jsdelivr.net",
  "cdn.jsdelivr.net", "yastatic.net", "cdn.rawgit.com", "rawgit.com",
  "s3.amazonaws.com", "storage.googleapis.com"
];

// Angular / other frameworks whose CDNs enable template-injection XSS.
const ANGULAR_BYPASS_HOSTS = [
  "ajax.googleapis.com", "cdnjs.cloudflare.com", "cdn.jsdelivr.net", "unpkg.com"
];

const CRITICAL_DIRECTIVES = ["script-src", "script-src-elem", "default-src", "object-src", "base-uri", "frame-ancestors"];

function parseCsp(header) {
  const directives = {};
  header.split(";").forEach((chunk) => {
    const parts = chunk.trim().split(/\s+/);
    if (!parts[0]) return;
    directives[parts[0].toLowerCase()] = parts.slice(1);
  });
  return directives;
}

function pickSources(directives, name) {
  return directives[name] || directives["default-src"] || [];
}

function isHostSource(src) {
  return /^https?:\/\/|^([a-z0-9-]+\.)+[a-z]{2,}/i.test(src)
      || (!src.startsWith("'") && !src.startsWith("data:") && !src.startsWith("blob:"));
}

export function analyzeCSP(cspHeader, reportOnly = false) {
  if (!cspHeader) {
    return {
      grade: "F",
      issues: [{
        severity: "HIGH",
        text: "No Content-Security-Policy header present — page has no CSP-level XSS defence."
      }],
      directives: {}
    };
  }
  const directives = parseCsp(cspHeader);
  const issues = [];
  const scoreDelta = { A: 0 };
  let score = 100;

  const scriptSrc = pickSources(directives, "script-src");
  const scriptSrcElem = pickSources(directives, "script-src-elem");
  const styleSrc = pickSources(directives, "style-src");
  const objectSrc = directives["object-src"];
  const baseUri = directives["base-uri"];
  const frameAncestors = directives["frame-ancestors"];

  // Report-only is advisory
  if (reportOnly) {
    issues.push({
      severity: "MEDIUM",
      text: "CSP is delivered as `Content-Security-Policy-Report-Only` — violations are logged but NOT blocked. Move to enforcing header once tuned."
    });
    score -= 20;
  }

  // ── script-src / default-src ────────────────────────────────────────────
  const combinedScript = [...scriptSrc, ...scriptSrcElem];
  if (!combinedScript.length && !directives["default-src"]) {
    issues.push({ severity: "HIGH", text: "No script-src (and no default-src) — inline scripts unrestricted." });
    score -= 40;
  }
  if (combinedScript.includes("'unsafe-inline'")) {
    issues.push({
      severity: "HIGH",
      text: "'unsafe-inline' in script-src — inline `<script>` and event handlers are allowed. Single biggest CSP weakness. Use nonces or hashes instead."
    });
    score -= 30;
  }
  if (combinedScript.includes("'unsafe-eval'")) {
    issues.push({
      severity: "MEDIUM",
      text: "'unsafe-eval' in script-src — eval / new Function / setTimeout(string) are allowed. Necessary for legacy frameworks but expands XSS surface."
    });
    score -= 10;
  }
  if (combinedScript.some((s) => s === "*" || s === "https:" || s === "http:" || s === "data:" || s === "blob:")) {
    issues.push({
      severity: "HIGH",
      text: "Overly broad script-src (contains *, https:, data:, or blob:) — attackers can host malicious script on any complying host."
    });
    score -= 25;
  }
  // JSONP host whitelisting
  const jsonpHits = combinedScript.filter((s) =>
    JSONP_BYPASS_HOSTS.some((h) => new RegExp(`(^|//)([a-z0-9-]+\\.)?${h.replace(/\./g, "\\.")}(\\/|$)`, "i").test(s))
  );
  if (jsonpHits.length) {
    issues.push({
      severity: "HIGH",
      text: `script-src whitelists JSONP-capable host(s): ${jsonpHits.join(", ")}. Attackers can use script-gadgets on those hosts to execute arbitrary JS bypassing CSP.`
    });
    score -= 20;
  }
  // AngularJS gadget hosts
  const angHits = combinedScript.filter((s) =>
    ANGULAR_BYPASS_HOSTS.some((h) => new RegExp(`(^|//)([a-z0-9-]+\\.)?${h.replace(/\./g, "\\.")}(\\/|$)`, "i").test(s))
  );
  if (angHits.length && !jsonpHits.length) {
    issues.push({
      severity: "MEDIUM",
      text: `script-src whitelists Angular-hosting CDN(s): ${angHits.join(", ")}. If Angular is loaded and a template injection sink exists, CSP won't stop it.`
    });
    score -= 10;
  }
  // strict-dynamic without nonce
  if (combinedScript.includes("'strict-dynamic'") && !combinedScript.some((s) => s.startsWith("'nonce-") || s.startsWith("'sha"))) {
    issues.push({
      severity: "MEDIUM",
      text: "'strict-dynamic' without a nonce or hash — nothing seeds the trust chain. Add a per-response nonce."
    });
    score -= 10;
  }
  // Nonce quality
  const nonces = combinedScript.filter((s) => s.startsWith("'nonce-")).map((s) => s.slice(7, -1));
  for (const n of nonces) {
    if (n.length < 16) {
      issues.push({ severity: "MEDIUM", text: `CSP nonce shorter than 16 chars (${n.length}) — predictable if PRNG is weak.` });
      score -= 5;
    }
  }

  // ── object-src ──────────────────────────────────────────────────────────
  if (!objectSrc && !directives["default-src"]) {
    issues.push({ severity: "MEDIUM", text: "object-src not set — legacy Flash/Java plugins can be embedded." });
    score -= 10;
  } else if (objectSrc && !objectSrc.includes("'none'")) {
    issues.push({ severity: "LOW", text: `object-src is "${objectSrc.join(" ")}", not 'none' — best practice is to explicitly disable plugins.` });
    score -= 3;
  }

  // ── base-uri ────────────────────────────────────────────────────────────
  if (!baseUri) {
    issues.push({
      severity: "MEDIUM",
      text: "base-uri not set — an attacker can inject a `<base>` tag to redirect all relative script paths to their own host, bypassing script-src."
    });
    score -= 12;
  } else if (!baseUri.includes("'none'") && !baseUri.includes("'self'")) {
    issues.push({ severity: "LOW", text: `base-uri is "${baseUri.join(" ")}", broader than recommended 'none' or 'self'.` });
    score -= 4;
  }

  // ── frame-ancestors ─────────────────────────────────────────────────────
  if (!frameAncestors) {
    issues.push({
      severity: "MEDIUM",
      text: "frame-ancestors not set — clickjacking defence relies solely on X-Frame-Options (deprecated). Add frame-ancestors 'none' or 'self'."
    });
    score -= 8;
  } else if (frameAncestors.includes("*") || frameAncestors.includes("'*'")) {
    issues.push({ severity: "HIGH", text: "frame-ancestors '*' — any site can iframe this page, enabling clickjacking." });
    score -= 15;
  }

  // ── form-action ─────────────────────────────────────────────────────────
  if (!directives["form-action"]) {
    issues.push({ severity: "LOW", text: "form-action not set — a CSP-safe injection could still submit forms cross-origin." });
    score -= 4;
  }

  // ── style-src ──────────────────────────────────────────────────────────
  if (styleSrc.includes("'unsafe-inline'")) {
    issues.push({ severity: "LOW", text: "'unsafe-inline' in style-src — enables CSS-based data-exfiltration in some scenarios." });
    score -= 3;
  }

  // Grade
  score = Math.max(0, Math.min(100, score));
  const grade = score >= 90 ? "A" : score >= 75 ? "B" : score >= 55 ? "C" : score >= 30 ? "D" : "F";

  return { grade, score, issues, directives, reportOnly };
}

// Build ReconHound-style findings from a CSP analysis
export function cspAnalysisToFindings(analysis, url) {
  if (!analysis) return [];
  const out = [];
  for (const issue of analysis.issues) {
    out.push({
      id: "csp-" + slugify(issue.text.slice(0, 40)),
      title: "CSP: " + issue.text.split(" ").slice(0, 8).join(" ") + "…",
      severity: issue.severity,
      url: url || "",
      detail: issue.text,
      verified: true
    });
  }
  // Grade summary as its own low-severity informational finding.
  out.push({
    id: "csp-grade",
    title: `CSP grade ${analysis.grade} (${analysis.score}/100)`,
    severity: analysis.grade === "F" ? "HIGH" : analysis.grade === "D" ? "MEDIUM" : analysis.grade === "C" ? "LOW" : "LOW",
    url: url || "",
    detail: `Aggregate CSP quality score is ${analysis.score}/100 (grade ${analysis.grade}). Deductions summarised in the individual CSP findings above.`,
    verified: true
  });
  return out;
}

function slugify(s) {
  return String(s).toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "").slice(0, 40);
}
