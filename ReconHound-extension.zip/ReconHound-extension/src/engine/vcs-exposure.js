// ReconHound — Enhanced VCS/metadata exposure probe (ACTIVE)
// Beyond a plain "/.git/config → 200" check, this parses the artefacts that
// are actually present to confirm the exposure is real (not a soft-404) and to
// pull useful metadata: remote URL, active branch, commit hash tips, index
// entries (filenames), etc. All reads are non-destructive HEAD/GET requests.

async function get(url, { timeoutMs = 6000, asBinary = false } = {}) {
  const controller = new AbortController();
  const t = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const res = await fetch(url, { credentials: "omit", redirect: "follow", signal: controller.signal });
    clearTimeout(t);
    if (res.status >= 400) return null;
    const ctype = res.headers.get("content-type") || "";
    // HTML soft-404 detection.
    if (/text\/html/i.test(ctype)) {
      const t2 = (await res.text()).slice(0, 512);
      if (/<html|<!doctype/i.test(t2)) return null;
      return { status: res.status, text: t2, ctype, url: res.url };
    }
    if (asBinary) {
      const buf = new Uint8Array(await res.arrayBuffer());
      return { status: res.status, buf, ctype, url: res.url };
    }
    const text = (await res.text()).slice(0, 200000);
    return { status: res.status, text, ctype, url: res.url };
  } catch (_) {
    clearTimeout(t);
    return null;
  }
}

// Parse /.git/config INI-ish content → { remotes: [...] }
function parseGitConfig(text) {
  const remotes = [];
  const branches = [];
  const sectionRe = /\[([^\]]+)\]/g;
  const lines = text.split(/\r?\n/);
  let cur = null;
  for (const line of lines) {
    const m = line.match(/^\[([^\]]+)\]\s*$/);
    if (m) { cur = m[1]; continue; }
    const kv = line.match(/^\s*([A-Za-z0-9_.-]+)\s*=\s*(.+)\s*$/);
    if (!kv || !cur) continue;
    if (/^remote\s+"([^"]+)"/.test(cur)) {
      const name = cur.match(/"([^"]+)"/)[1];
      if (kv[1] === "url") remotes.push({ name, url: kv[2] });
    }
    if (/^branch\s+"([^"]+)"/.test(cur)) {
      const name = cur.match(/"([^"]+)"/)[1];
      branches.push(name);
    }
  }
  return { remotes, branches };
}

// Parse /.git/HEAD → active branch (ref) or detached commit.
function parseGitHead(text) {
  const t = text.trim();
  const ref = t.match(/^ref:\s+(refs\/heads\/.+)$/m);
  if (ref) return { branch: ref[1].replace(/^refs\/heads\//, ""), commit: null };
  if (/^[0-9a-f]{40}$/i.test(t)) return { branch: null, commit: t };
  return null;
}

// Parse /.git/logs/HEAD → commit hash tips (each line: fromSha toSha ...)
function parseGitLogs(text) {
  const hashes = new Set();
  for (const line of text.split(/\r?\n/)) {
    const m = line.match(/^([0-9a-f]{40})\s+([0-9a-f]{40})\s/);
    if (m) { hashes.add(m[1]); hashes.add(m[2]); }
  }
  return [...hashes].slice(0, 40);
}

// Parse /.git/index binary → sampled paths. The DIRC index format has entries
// with 12 bytes of stat, 20-byte sha1, 2 bytes of flags, then a null-padded
// path. We scan for readable ASCII path fragments — good enough to demonstrate
// the exposure without a full parser.
function parseGitIndex(buf) {
  if (!buf || buf.length < 12) return [];
  const magic = String.fromCharCode(buf[0], buf[1], buf[2], buf[3]);
  if (magic !== "DIRC") return [];
  const paths = new Set();
  // walk the buffer looking for ASCII runs of >=4 chars, likely filenames.
  let start = -1;
  for (let i = 12; i < buf.length; i++) {
    const b = buf[i];
    const printable = b >= 0x20 && b < 0x7f;
    if (printable) {
      if (start < 0) start = i;
    } else {
      if (start >= 0 && i - start >= 4) {
        const s = new TextDecoder().decode(buf.subarray(start, i));
        if (/^[A-Za-z0-9_./+ -]+\.[A-Za-z0-9]{1,6}$/.test(s) || /^[A-Za-z0-9_./-]+\/$/.test(s)) {
          paths.add(s);
        }
      }
      start = -1;
    }
    if (paths.size > 200) break;
  }
  return [...paths];
}

// Parse /.svn/wc.db (SQLite) — we don't decode SQLite in-browser; presence of
// the header + a reasonable size is enough evidence.
function isSvnWcDb(buf) {
  if (!buf || buf.length < 16) return false;
  const magic = new TextDecoder().decode(buf.subarray(0, 15));
  return magic.startsWith("SQLite format 3");
}

export async function probeVCS(origin) {
  const base = origin.replace(/\/$/, "");
  const findings = [];
  let branch = null, commit = null, remotes = [], indexPaths = [];

  // 1. /.git/config
  const cfg = await get(base + "/.git/config");
  if (cfg && (/\[core\]/i.test(cfg.text) || /\[remote/i.test(cfg.text))) {
    const parsed = parseGitConfig(cfg.text);
    remotes = parsed.remotes;
    findings.push({
      id: "git-config",
      title: "Exposed .git/config",
      severity: "HIGH",
      url: base + "/.git/config",
      detail: remotes.length
        ? `Public .git/config discloses remote(s): ${remotes.map((r) => r.url).join(", ")}`
        : "Public .git/config — repository config disclosed.",
      verified: true,
      remotes,
      branches: parsed.branches
    });
  }

  // 2. /.git/HEAD → active branch / commit
  const head = await get(base + "/.git/HEAD");
  if (head) {
    const parsed = parseGitHead(head.text);
    if (parsed) {
      branch = parsed.branch;
      commit = parsed.commit;
      findings.push({
        id: "git-head",
        title: "Exposed .git/HEAD",
        severity: "HIGH",
        url: base + "/.git/HEAD",
        detail: branch
          ? `HEAD → branch "${branch}". Full source history may be reconstructable from .git/objects/*.`
          : `HEAD → detached commit ${commit}.`,
        verified: true,
        branch, commit
      });
    }
  }

  // 3. /.git/logs/HEAD → historical commit hashes
  const logs = await get(base + "/.git/logs/HEAD");
  if (logs && /^[0-9a-f]{40}\s/m.test(logs.text)) {
    const hashes = parseGitLogs(logs.text);
    findings.push({
      id: "git-logs",
      title: `Exposed .git/logs/HEAD (${hashes.length} commit tip(s))`,
      severity: "HIGH",
      url: base + "/.git/logs/HEAD",
      detail: "Git reflog readable — commit hashes enable direct object retrieval.",
      verified: true,
      hashes: hashes.slice(0, 10)
    });
  }

  // 4. /.git/index → binary file inventory
  const idx = await get(base + "/.git/index", { asBinary: true });
  if (idx && idx.buf) {
    indexPaths = parseGitIndex(idx.buf);
    if (indexPaths.length) {
      findings.push({
        id: "git-index",
        title: `Exposed .git/index (${indexPaths.length} tracked path(s) recoverable)`,
        severity: "CRITICAL",
        url: base + "/.git/index",
        detail: "Git index reachable — file inventory recoverable. Sample paths: "
          + indexPaths.slice(0, 12).join(", ")
          + (indexPaths.length > 12 ? " …" : ""),
        verified: true,
        paths: indexPaths.slice(0, 60)
      });
    }
  }

  // 5. /.git/refs/heads/<branch> if we identified a branch
  if (branch) {
    const ref = await get(`${base}/.git/refs/heads/${branch}`);
    if (ref && /^[0-9a-f]{40}\s*$/i.test(ref.text.trim())) {
      findings.push({
        id: "git-ref",
        title: `Exposed .git/refs/heads/${branch}`,
        severity: "HIGH",
        url: `${base}/.git/refs/heads/${branch}`,
        detail: `Branch ${branch} tip: ${ref.text.trim()}`,
        verified: true
      });
    }
  }

  // 6. /.git/packed-refs
  const packed = await get(base + "/.git/packed-refs");
  if (packed && /^[0-9a-f]{40}\s+refs\//m.test(packed.text)) {
    findings.push({
      id: "git-packed-refs",
      title: "Exposed .git/packed-refs",
      severity: "MEDIUM",
      url: base + "/.git/packed-refs",
      detail: "Packed refs disclose branch/tag list and commit tips.",
      verified: true
    });
  }

  // 7. /.git/description
  const desc = await get(base + "/.git/description");
  if (desc && desc.text.length && !/<html/i.test(desc.text)) {
    // Only flag if not the default placeholder, or as LOW otherwise.
    const isDefault = /Unnamed repository/i.test(desc.text);
    findings.push({
      id: "git-description",
      title: "Exposed .git/description",
      severity: "LOW",
      url: base + "/.git/description",
      detail: isDefault
        ? "Default Git description exposed — confirms /.git/ is served."
        : `Custom .git/description: "${desc.text.trim().slice(0, 200)}"`,
      verified: true
    });
  }

  // 8. Common object pack (existence check — recovery would be manual)
  const packDir = await get(base + "/.git/objects/info/packs");
  if (packDir && /^P pack-[0-9a-f]{40}\.pack/m.test(packDir.text)) {
    const packNames = [...packDir.text.matchAll(/pack-[0-9a-f]{40}\.pack/g)].map((m) => m[0]).slice(0, 6);
    findings.push({
      id: "git-packs",
      title: `Exposed Git pack index (${packNames.length} pack file(s))`,
      severity: "HIGH",
      url: base + "/.git/objects/info/packs",
      detail: "Packed object files reachable — full history extractable.",
      verified: true,
      packs: packNames
    });
  }

  // ── SVN ─────────────────────────────────────────────────────────────────
  const svnEntries = await get(base + "/.svn/entries");
  if (svnEntries && (/^\d+\s*$/m.test(svnEntries.text) || /svn:/i.test(svnEntries.text))) {
    findings.push({
      id: "svn-entries",
      title: "Exposed .svn/entries",
      severity: "HIGH",
      url: base + "/.svn/entries",
      detail: "Subversion metadata readable — source disclosure.",
      verified: true
    });
  }
  const svnWcDb = await get(base + "/.svn/wc.db", { asBinary: true });
  if (svnWcDb && isSvnWcDb(svnWcDb.buf)) {
    findings.push({
      id: "svn-wc-db",
      title: "Exposed .svn/wc.db (SQLite working-copy database)",
      severity: "CRITICAL",
      url: base + "/.svn/wc.db",
      detail: "Modern SVN working copy SQLite reachable — full working-copy metadata recoverable.",
      verified: true
    });
  }

  // ── Mercurial ───────────────────────────────────────────────────────────
  const hg = await get(base + "/.hg/store/00manifest.i", { asBinary: true });
  if (hg && hg.buf && hg.buf.length > 4) {
    findings.push({
      id: "hg-manifest",
      title: "Exposed Mercurial (.hg) repository metadata",
      severity: "HIGH",
      url: base + "/.hg/store/00manifest.i",
      detail: "Mercurial store readable — source history recoverable.",
      verified: true
    });
  }

  // ── .bzr ────────────────────────────────────────────────────────────────
  const bzr = await get(base + "/.bzr/branch/branch.conf");
  if (bzr && /parent_location|append_revisions_only/i.test(bzr.text)) {
    findings.push({
      id: "bzr-conf",
      title: "Exposed Bazaar (.bzr) branch config",
      severity: "MEDIUM",
      url: base + "/.bzr/branch/branch.conf",
      detail: "Bazaar branch metadata readable.",
      verified: true
    });
  }

  const weight = { CRITICAL: 4, HIGH: 3, MEDIUM: 2, LOW: 1 };
  findings.sort((a, b) => (weight[b.severity] || 0) - (weight[a.severity] || 0));

  return { findings, meta: { branch, commit, remotes, indexPaths } };
}
