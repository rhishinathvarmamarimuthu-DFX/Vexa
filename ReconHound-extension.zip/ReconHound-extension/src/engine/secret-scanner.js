// ReconHound — Secret scanner
// Scans REAL page HTML, inline scripts, and fetched JS bundles for leaked
// credentials and high-entropy keys. Each detector targets a concrete provider
// pattern; generic matches are gated by a Shannon-entropy check to cut false
// positives.

// detectors: { id, name, severity, re, entropy? }
// `re` must be global; capture group 1 (if present) is treated as the secret.
const DETECTORS = [
  // ── Cloud: AWS ──────────────────────────────────────────────────────────
  { id: "aws-access-key", name: "AWS Access Key ID", severity: "HIGH",
    re: /\b(AKIA|ASIA|AGPA|AIDA|AROA|AIPA|ANPA|ANVA|ASCA)[0-9A-Z]{16}\b/g },
  { id: "aws-secret-key", name: "AWS Secret Access Key", severity: "CRITICAL",
    re: /\baws(.{0,20})?(secret|access)[_-]?key\s*[=:]\s*['"]?([A-Za-z0-9/+=]{40})['"]?/gi },
  { id: "aws-session", name: "AWS Session Token", severity: "HIGH",
    re: /\baws_session_token\s*[=:]\s*['"]?([A-Za-z0-9/+=]{100,})['"]?/gi },
  { id: "aws-mws", name: "AWS MWS Auth Token", severity: "HIGH",
    re: /\bamzn\.mws\.[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}\b/g },

  // ── Cloud: Google / GCP ─────────────────────────────────────────────────
  { id: "google-api", name: "Google API Key", severity: "HIGH",
    re: /\bAIza[0-9A-Za-z\-_]{35}\b/g },
  { id: "google-oauth", name: "Google OAuth Token", severity: "HIGH",
    re: /\bya29\.[0-9A-Za-z\-_]+\b/g },
  { id: "gcp-service-acct", name: "GCP Service-Account JSON", severity: "CRITICAL",
    re: /"type"\s*:\s*"service_account"[\s\S]{0,200}"private_key"/g },
  { id: "gcp-oauth-client", name: "GCP OAuth Client Secret", severity: "HIGH",
    re: /\bGOCSPX-[0-9A-Za-z\-_]{28}\b/g },
  { id: "firebase-db", name: "Firebase Database URL", severity: "LOW",
    re: /https:\/\/[a-z0-9-]+\.firebaseio\.com/g },
  { id: "firebase-cloud-msg", name: "Firebase Cloud Messaging Key", severity: "HIGH",
    re: /\bAAAA[A-Za-z0-9_-]{7}:[A-Za-z0-9_-]{140}\b/g },

  // ── Cloud: Azure ────────────────────────────────────────────────────────
  { id: "azure-storage", name: "Azure Storage Account Key", severity: "CRITICAL",
    re: /\bDefaultEndpointsProtocol=https;AccountName=[a-z0-9]+;AccountKey=([A-Za-z0-9+/=]{88})/g },
  { id: "azure-sas", name: "Azure SAS Token", severity: "HIGH",
    re: /\bsig=[A-Za-z0-9%]{40,}&(se|sv|sr)=/g },
  { id: "azure-connection", name: "Azure Connection String", severity: "HIGH",
    re: /\bEndpoint=sb:\/\/[^;]+;SharedAccessKey(Name)?=[^;\s'"]+/g },

  // ── Cloud: DigitalOcean / Linode / Heroku ───────────────────────────────
  { id: "do-pat", name: "DigitalOcean Personal Access Token", severity: "HIGH",
    re: /\bdop_v1_[0-9a-f]{64}\b/g },
  { id: "do-oauth", name: "DigitalOcean OAuth Token", severity: "HIGH",
    re: /\bdoo_v1_[0-9a-f]{64}\b/g },
  { id: "linode", name: "Linode Personal Access Token", severity: "HIGH",
    re: /\blinode[a-z0-9_ ]{0,20}['"]?[=:]['"]?([a-f0-9]{64})/gi },
  { id: "heroku", name: "Heroku API Key", severity: "HIGH",
    re: /heroku[a-z0-9_ ]{0,20}['"]?[=:]['"]?([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12})/gi },

  // ── Source-code hosts ───────────────────────────────────────────────────
  { id: "github-pat", name: "GitHub Personal Access Token", severity: "CRITICAL",
    re: /\b(ghp|gho|ghu|ghs|ghr)_[0-9A-Za-z]{36,251}\b/g },
  { id: "github-fine", name: "GitHub Fine-grained Token", severity: "CRITICAL",
    re: /\bgithub_pat_[0-9A-Za-z_]{82}\b/g },
  { id: "github-oauth", name: "GitHub OAuth Access Token", severity: "CRITICAL",
    re: /\bgho_[0-9a-zA-Z]{36}\b/g },
  { id: "github-app", name: "GitHub App Token", severity: "CRITICAL",
    re: /\b(ghs|ghu)_[0-9a-zA-Z]{36}\b/g },
  { id: "gitlab-pat", name: "GitLab Personal Access Token", severity: "CRITICAL",
    re: /\bglpat-[0-9A-Za-z\-_]{20}\b/g },
  { id: "gitlab-runner", name: "GitLab Runner Registration Token", severity: "HIGH",
    re: /\bGR1348941[0-9A-Za-z\-_]{20}\b/g },
  { id: "bitbucket", name: "Bitbucket Client ID/Secret", severity: "HIGH",
    re: /bitbucket[a-z0-9_ ]{0,20}['"]?[=:]['"]?([a-zA-Z0-9]{32,64})/gi },

  // ── Messaging ───────────────────────────────────────────────────────────
  { id: "slack-token", name: "Slack Token", severity: "HIGH",
    re: /\bxox[baprs]-[0-9]{10,13}-[0-9]{10,13}-[0-9A-Za-z]{24,34}\b/g },
  { id: "slack-webhook", name: "Slack Webhook", severity: "MEDIUM",
    re: /https:\/\/hooks\.slack\.com\/services\/T[A-Z0-9]{8,}\/B[A-Z0-9]{8,}\/[A-Za-z0-9]{24,}/g },
  { id: "discord-bot", name: "Discord Bot Token", severity: "CRITICAL",
    re: /\b[MN][A-Za-z\d]{23,26}\.[\w-]{6}\.[\w-]{27,38}\b/g },
  { id: "discord-webhook", name: "Discord Webhook", severity: "MEDIUM",
    re: /https:\/\/(?:canary\.|ptb\.)?discord(?:app)?\.com\/api\/webhooks\/\d{17,20}\/[A-Za-z0-9_-]{60,}/g },
  { id: "telegram-bot", name: "Telegram Bot Token", severity: "HIGH",
    re: /\b\d{8,10}:AA[A-Za-z0-9_-]{33,34}\b/g },
  { id: "microsoft-teams", name: "Microsoft Teams Webhook", severity: "MEDIUM",
    re: /https:\/\/[a-z0-9]+\.webhook\.office\.com\/webhookb2\/[a-z0-9-]+@[a-z0-9-]+\/IncomingWebhook\/[a-z0-9]+\/[a-z0-9-]+/gi },

  // ── Payments ────────────────────────────────────────────────────────────
  { id: "stripe-secret", name: "Stripe Secret Key", severity: "CRITICAL",
    re: /\b(sk|rk)_(live|test)_[0-9a-zA-Z]{24,99}\b/g },
  { id: "stripe-pub", name: "Stripe Publishable Key", severity: "LOW",
    re: /\bpk_(live|test)_[0-9a-zA-Z]{24,99}\b/g },
  { id: "stripe-webhook", name: "Stripe Webhook Signing Secret", severity: "HIGH",
    re: /\bwhsec_[A-Za-z0-9]{32,}\b/g },
  { id: "square-token", name: "Square Access Token", severity: "HIGH",
    re: /\b(sq0atp|sq0csp|EAAA[A-Za-z0-9_-])[0-9A-Za-z\-_]{20,60}\b/g },
  { id: "paypal-braintree", name: "PayPal / Braintree Access Token", severity: "HIGH",
    re: /\baccess_token\$production\$[0-9a-z]{16}\$[0-9a-f]{32}\b/g },
  { id: "coinbase", name: "Coinbase API Key", severity: "HIGH",
    re: /\bcoinbase[a-z0-9_ ]{0,20}['"]?[=:]['"]?([A-Za-z0-9]{64})/gi },

  // ── Email / SMS providers ───────────────────────────────────────────────
  { id: "sendgrid", name: "SendGrid API Key", severity: "CRITICAL",
    re: /\bSG\.[A-Za-z0-9_\-]{22}\.[A-Za-z0-9_\-]{43}\b/g },
  { id: "mailgun", name: "Mailgun API Key", severity: "HIGH",
    re: /\b(key|pubkey)-[0-9a-zA-Z]{32}\b/g },
  { id: "mailchimp", name: "Mailchimp API Key", severity: "HIGH",
    re: /\b[0-9a-f]{32}-us[0-9]{1,2}\b/g },
  { id: "postmark", name: "Postmark Server Token", severity: "HIGH",
    re: /\bpostmark[a-z0-9_ ]{0,20}['"]?[=:]['"]?([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})/gi },
  { id: "twilio-sid", name: "Twilio Account SID", severity: "MEDIUM",
    re: /\bAC[0-9a-fA-F]{32}\b/g },
  { id: "twilio-key", name: "Twilio API Key", severity: "HIGH",
    re: /\bSK[0-9a-fA-F]{32}\b/g },
  { id: "nexmo", name: "Vonage/Nexmo API Secret", severity: "HIGH",
    re: /\bnexmo[a-z0-9_ ]{0,20}['"]?[=:]['"]?([A-Za-z0-9]{16})/gi },

  // ── AI / LLM providers ──────────────────────────────────────────────────
  { id: "openai-key", name: "OpenAI API Key", severity: "CRITICAL",
    re: /\bsk-(?:proj-)?[A-Za-z0-9_-]{20,200}\b/g },
  { id: "anthropic-key", name: "Anthropic API Key", severity: "CRITICAL",
    re: /\bsk-ant-(?:api|admin)[0-9]{2}-[A-Za-z0-9_-]{80,120}\b/g },
  { id: "huggingface", name: "Hugging Face Token", severity: "HIGH",
    re: /\bhf_[A-Za-z0-9]{34}\b/g },
  { id: "replicate", name: "Replicate API Token", severity: "HIGH",
    re: /\br8_[A-Za-z0-9]{37}\b/g },
  { id: "cohere", name: "Cohere API Key", severity: "HIGH",
    re: /cohere[a-z0-9_ ]{0,20}['"]?[=:]['"]?([A-Za-z0-9]{40})/gi },

  // ── DevOps / SaaS ───────────────────────────────────────────────────────
  { id: "npm-token", name: "npm Access Token", severity: "HIGH",
    re: /\bnpm_[0-9A-Za-z]{36}\b/g },
  { id: "pypi-token", name: "PyPI Upload Token", severity: "HIGH",
    re: /\bpypi-AgEIcHlwaS5vcmc[A-Za-z0-9_-]{50,}\b/g },
  { id: "dockerhub-pat", name: "Docker Hub PAT", severity: "HIGH",
    re: /\bdckr_pat_[A-Za-z0-9_-]{20,}\b/g },
  { id: "terraform-cloud", name: "Terraform Cloud Token", severity: "HIGH",
    re: /\b[A-Za-z0-9]{14}\.atlasv1\.[A-Za-z0-9_-]{60,80}\b/g },
  { id: "circleci", name: "CircleCI Personal Token", severity: "HIGH",
    re: /\bCCIPAT_[A-Za-z0-9_]{40}_[a-f0-9]{40}\b/g },
  { id: "netlify", name: "Netlify Access Token", severity: "HIGH",
    re: /\bnfp_[A-Za-z0-9_]{36,}\b/g },
  { id: "vercel", name: "Vercel Access Token", severity: "HIGH",
    re: /\b[A-Za-z0-9]{24}\.vercel\b|vercel[a-z0-9_ ]{0,20}['"]?[=:]['"]?([A-Za-z0-9]{24})/gi },
  { id: "cloudflare-api", name: "Cloudflare API Token", severity: "HIGH",
    re: /\bcloudflare[a-z0-9_ ]{0,20}['"]?[=:]['"]?([A-Za-z0-9_-]{40})/gi },
  { id: "sentry-dsn", name: "Sentry DSN", severity: "LOW",
    re: /https:\/\/[a-f0-9]{32}@[a-z0-9.]+\.ingest\.sentry\.io\/[0-9]+/g },
  { id: "datadog", name: "Datadog API Key", severity: "HIGH",
    re: /datadog[a-z0-9_ ]{0,20}['"]?[=:]['"]?([a-f0-9]{32})/gi },
  { id: "newrelic", name: "New Relic License Key", severity: "MEDIUM",
    re: /\bNRAK-[A-Z0-9]{27}\b/g },
  { id: "pagerduty", name: "PagerDuty Integration Key", severity: "MEDIUM",
    re: /\bR2[A-Z0-9]{30}\b/g },
  { id: "algolia", name: "Algolia Admin API Key", severity: "HIGH",
    re: /algolia[a-z0-9_ ]{0,20}['"]?[=:]['"]?([a-f0-9]{32})/gi },
  { id: "shopify", name: "Shopify Access Token", severity: "HIGH",
    re: /\bshp(at|ca|pa|ss)_[a-fA-F0-9]{32}\b/g },
  { id: "atlassian-api", name: "Atlassian API Token", severity: "HIGH",
    re: /\bATATT3[A-Za-z0-9_-]{180,240}\b/g },
  { id: "okta-api", name: "Okta API Token", severity: "HIGH",
    re: /\b00[A-Za-z0-9_-]{40}\b/g, entropy: 4.0 },
  { id: "dropbox", name: "Dropbox Access Token", severity: "HIGH",
    re: /\bsl\.[A-Za-z0-9_-]{130,152}\b/g },
  { id: "asana", name: "Asana Personal Access Token", severity: "HIGH",
    re: /\b\d\/\d{16}:[A-Za-z0-9]{32}\b/g },
  { id: "linear", name: "Linear API Key", severity: "HIGH",
    re: /\blin_api_[A-Za-z0-9]{40}\b/g },
  { id: "notion", name: "Notion Integration Token", severity: "HIGH",
    re: /\bsecret_[A-Za-z0-9]{43}\b/g },
  { id: "clickup", name: "ClickUp API Token", severity: "HIGH",
    re: /\bpk_[0-9]{7,9}_[A-Z0-9]{32}\b/g },
  { id: "zendesk", name: "Zendesk API Token", severity: "HIGH",
    re: /zendesk[a-z0-9_ ]{0,20}['"]?[=:]['"]?([A-Za-z0-9]{40})/gi },
  { id: "figma", name: "Figma Personal Access Token", severity: "HIGH",
    re: /\bfigd_[A-Za-z0-9_-]{30,}\b/g },
  { id: "grafana", name: "Grafana Service Account Token", severity: "HIGH",
    re: /\bglsa_[A-Za-z0-9]{32}_[a-f0-9]{8}\b/g },
  { id: "readme-io", name: "ReadMe.io API Key", severity: "MEDIUM",
    re: /\brdme_[A-Za-z0-9]{70,80}\b/g },

  // ── Social ──────────────────────────────────────────────────────────────
  { id: "facebook-token", name: "Facebook Access Token", severity: "HIGH",
    re: /\bEAA[A-Za-z0-9]{80,}\b/g },
  { id: "facebook-app", name: "Facebook OAuth App Secret", severity: "HIGH",
    re: /\bfacebook[a-z0-9_ ]{0,20}['"]?[=:]['"]?([a-f0-9]{32})/gi },
  { id: "twitter", name: "Twitter/X Bearer Token", severity: "HIGH",
    re: /\bAAAA[A-Za-z0-9%]{80,}\b/g, entropy: 4.5 },
  { id: "instagram-token", name: "Instagram Access Token", severity: "HIGH",
    re: /\bIGQV[A-Za-z0-9_-]{100,}\b/g },
  { id: "linkedin", name: "LinkedIn Client Secret", severity: "HIGH",
    re: /linkedin[a-z0-9_ ]{0,20}['"]?[=:]['"]?([A-Za-z0-9]{16})/gi },

  // ── Generic keys / secrets in code ──────────────────────────────────────
  { id: "private-key", name: "Private Key Block", severity: "CRITICAL",
    re: /-----BEGIN (?:RSA |EC |DSA |OPENSSH |PGP |ENCRYPTED )?PRIVATE KEY( BLOCK)?-----/g },
  { id: "putty-key", name: "PuTTY Private Key", severity: "CRITICAL",
    re: /PuTTY-User-Key-File-[23]:\s/g },
  { id: "pkcs12", name: "PKCS#12 Container", severity: "HIGH",
    re: /-----BEGIN PKCS12-----/g },
  { id: "jwt", name: "JSON Web Token (JWT)", severity: "MEDIUM",
    re: /\beyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\b/g },
  { id: "db-uri", name: "Database Connection String w/ Credentials", severity: "CRITICAL",
    re: /\b(?:mongodb(?:\+srv)?|postgres(?:ql)?|mysql|redis|amqp|clickhouse|cassandra):\/\/[^\s:@/]+:[^\s:@/]+@[^\s/'"]+/gi },
  { id: "basic-auth-url", name: "Credentials in URL", severity: "HIGH",
    re: /\bhttps?:\/\/[^\s:@/]+:[^\s:@/]+@[^\s/'"]+/gi },
  { id: "bearer", name: "Authorization Bearer Token", severity: "MEDIUM",
    re: /\bBearer\s+([A-Za-z0-9\-._~+/]{20,}=*)/g },
  { id: "basic-auth-header", name: "HTTP Basic Auth Header", severity: "MEDIUM",
    re: /\bAuthorization:\s*Basic\s+([A-Za-z0-9+/=]{20,})/g },
  { id: "docker-registry", name: "Docker Registry Auth", severity: "HIGH",
    re: /"auths"\s*:\s*\{[\s\S]{0,300}"auth"\s*:\s*"([A-Za-z0-9+/=]{20,})"/g },
  { id: "kube-config", name: "Kubeconfig Certificate Data", severity: "CRITICAL",
    re: /client-certificate-data:\s*[A-Za-z0-9+/=]{100,}/g },
  { id: "generic-oauth", name: "OAuth 2 Client Secret Field", severity: "HIGH",
    re: /\bclient[_-]?secret\s*[=:]\s*['"]([A-Za-z0-9_\-\.]{20,80})['"]/gi, entropy: 3.5 },

  // Generic high-entropy assignment (entropy-gated to reduce noise)
  { id: "generic-secret", name: "Generic API Key / Secret", severity: "MEDIUM",
    re: /\b(?:api[_-]?key|secret|token|passwd|password|access[_-]?key|auth[_-]?token)\s*[=:]\s*['"]([A-Za-z0-9_\-+/=]{16,64})['"]/gi,
    entropy: 3.8 }
];

// Shannon entropy of a string (bits per char).
function entropy(str) {
  const freq = {};
  for (const ch of str) freq[ch] = (freq[ch] || 0) + 1;
  let e = 0;
  const len = str.length;
  for (const ch in freq) {
    const p = freq[ch] / len;
    e -= p * Math.log2(p);
  }
  return e;
}

// Produce a stable, non-reversible fingerprint. We DO NOT reveal any
// characters of the raw secret — even a 4-char prefix can be enough to bruteforce
// short tokens. Instead we hash it with FNV-1a and return a 10-hex-char
// fingerprint plus the length. Deterministic (same secret ⇒ same fingerprint)
// so dedup across sources still works.
function fingerprint(secret) {
  const s = String(secret);
  const len = s.length;
  // FNV-1a 32-bit — good enough for a display fingerprint (not for security).
  let h1 = 0x811c9dc5, h2 = 0xdeadbeef;
  for (let i = 0; i < s.length; i++) {
    const c = s.charCodeAt(i);
    h1 = Math.imul(h1 ^ c, 16777619);
    h2 = Math.imul(h2 ^ c, 2246822507);
  }
  const hex = (n) => (n >>> 0).toString(16).padStart(8, "0");
  return `fp:${hex(h1).slice(0, 5)}${hex(h2).slice(0, 5)} · ${len} chars`;
}
function redact(secret) { return fingerprint(secret); }

// Scan a blob of text. `source` labels where it came from (URL or "page HTML").
// `customRules` is an optional array of user-defined detectors:
//   { id, title|name, severity, pattern (string), entropy? }
export function scanText(text, source = "page", customRules = []) {
  if (!text) return [];
  const out = [];
  const seen = new Set();

  const detectors = DETECTORS.concat(compileCustomRules(customRules));

  for (const det of detectors) {
    det.re.lastIndex = 0;
    let m;
    while ((m = det.re.exec(text)) !== null) {
      const secret = m[1] || m[0];
      if (det.entropy && entropy(secret) < det.entropy) continue;

      const dedupe = `${det.id}:${secret}`;
      if (seen.has(dedupe)) continue;
      seen.add(dedupe);

      out.push({
        id: det.id,
        title: det.name,
        severity: det.severity,
        match: redact(secret),
        entropy: Number(entropy(secret).toFixed(2)),
        source,
        custom: !!det.custom
      });
      if (out.length > 400) return out; // safety cap
    }
  }
  return out;
}

// Turn user-supplied rules into safe, global-flagged detectors.
function compileCustomRules(rules = []) {
  const compiled = [];
  for (const r of rules) {
    if (!r || !r.pattern) continue;
    try {
      const wantI = (r.flags || "").includes("i") || r.ignoreCase === true;
      const re = new RegExp(r.pattern, wantI ? "gi" : "g");
      compiled.push({
        id: r.id || "custom-" + (r.title || "rule").toLowerCase().replace(/\s+/g, "-"),
        name: r.title || r.name || "Custom Rule",
        severity: (r.severity || "MEDIUM").toUpperCase(),
        re,
        entropy: r.entropy || 0,
        custom: true
      });
    } catch (_) {
      // invalid regex — skip silently
    }
  }
  return compiled;
}
