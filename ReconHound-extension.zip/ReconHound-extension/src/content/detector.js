// ReconHound — In-page detector (content script)
// Detects client-side frameworks and scrapes the DOM for DB error leaks.

(function () {
  function detectFrontend() {
    const stack = [];

    if (window.__REACT_DEVTOOLS_GLOBAL_HOOK__ || document.querySelector("[data-reactroot]")) {
      stack.push({ tech: "React", version: null, category: "frontend" });
    }
    if (window.__VUE__ || document.querySelector("[data-v-app]") || window.Vue) {
      stack.push({ tech: "Vue.js", version: window.Vue?.version || null, category: "frontend" });
    }
    const ng = document.querySelector("[ng-version]");
    if (ng) stack.push({ tech: "Angular", version: ng.getAttribute("ng-version"), category: "frontend" });

    if (window.jQuery?.fn?.jquery) {
      stack.push({ tech: "jQuery", version: window.jQuery.fn.jquery, category: "frontend" });
    }
    if (document.querySelector("[data-svelte-h], [class*='svelte-']")) {
      stack.push({ tech: "Svelte", version: null, category: "frontend" });
    }
    if (window.__NEXT_DATA__ || document.querySelector("#__next")) {
      stack.push({ tech: "Next.js", version: null, category: "frontend" });
    }
    if (window.__NUXT__ || document.querySelector("#__nuxt")) {
      stack.push({ tech: "Nuxt.js", version: null, category: "frontend" });
    }
    if (window.Backbone) {
      stack.push({ tech: "Backbone.js", version: window.Backbone.VERSION || null, category: "frontend" });
    }
    if (window.bootstrap || document.querySelector("[class*='col-'], .navbar-toggler")) {
      stack.push({ tech: "Bootstrap", version: null, category: "frontend" });
    }
    return stack;
  }

  function scrapeBody() {
    return document.body?.innerText?.slice(0, 50000) || "";
  }

  // Collect REAL loaded resource URLs (scripts + stylesheets) for library scan.
  function collectResourceUrls() {
    const urls = [];
    document.querySelectorAll("script[src]").forEach((s) => urls.push(s.src));
    document.querySelectorAll("link[rel='stylesheet'][href]").forEach((l) => urls.push(l.href));
    // Also include performance entries (catches dynamically loaded scripts).
    try {
      performance.getEntriesByType("resource").forEach((e) => {
        if (/\.(js|css)(\?|$)/i.test(e.name)) urls.push(e.name);
      });
    } catch (_) {}
    return [...new Set(urls)];
  }

  // Collect inline <script> contents + raw HTML for passive secret scanning.
  function collectInlineCode() {
    let code = "";
    document.querySelectorAll("script:not([src])").forEach((s) => {
      code += "\n" + (s.textContent || "");
    });
    return code.slice(0, 500000);
  }

  // Detection runs in an isolated world, so window.* checks for page globals
  // can be unreliable. We inject a small script into the page world to read
  // them. On CSP-restricted pages the injection is silently dropped — we
  // detect that and report `cspBlocked: true` so the popup can surface it.
  let pageProbeAnswered = false;
  function injectPageProbe() {
    try {
      const script = document.createElement("script");
      script.textContent = `(${pageProbe.toString()})();`;
      (document.head || document.documentElement).appendChild(script);
      script.remove();
    } catch (_) {
      reportCspBlocked("inline-injection-threw");
      return;
    }
    // If we don't hear back within 900ms, assume CSP dropped the script.
    setTimeout(() => {
      if (!pageProbeAnswered) reportCspBlocked("no-page-world-response");
    }, 900);
  }
  function reportCspBlocked(reason) {
    try {
      chrome.runtime.sendMessage({
        type: "RH_CSP_BLOCKED",
        url: location.href,
        reason
      });
    } catch (_) {}
  }

  function pageProbe() {
    const found = [];
    if (window.React?.version) found.push({ tech: "React", version: window.React.version, category: "js-library" });
    if (window.Vue?.version) found.push({ tech: "Vue.js", version: window.Vue.version, category: "js-library" });
    if (window.jQuery?.fn?.jquery) found.push({ tech: "jQuery", version: window.jQuery.fn.jquery, category: "js-library" });
    if (window.angular?.version?.full) found.push({ tech: "AngularJS", version: window.angular.version.full, category: "js-library" });
    if (window._?.VERSION) found.push({ tech: "lodash", version: window._.VERSION, category: "js-library" });
    if (window.moment?.version) found.push({ tech: "Moment.js", version: window.moment.version, category: "js-library" });
    if (window.axios?.VERSION) found.push({ tech: "Axios", version: window.axios.VERSION, category: "js-library" });
    if (window.d3?.version) found.push({ tech: "D3.js", version: window.d3.version, category: "js-library" });
    if (window.Chart?.version) found.push({ tech: "Chart.js", version: window.Chart.version, category: "js-library" });
    if (window.bootstrap?.Tooltip?.VERSION) found.push({ tech: "Bootstrap", version: window.bootstrap.Tooltip.VERSION, category: "js-library" });
    if (window.THREE?.REVISION) found.push({ tech: "Three.js", version: String(window.THREE.REVISION), category: "js-library" });
    window.postMessage({ __reconhound: true, globals: found }, "*");
  }

  window.addEventListener("message", (e) => {
    if (e.source === window && e.data?.__reconhound) {
      pageProbeAnswered = true;
      chrome.runtime.sendMessage({
        type: "RH_GLOBALS",
        url: location.href,
        globals: e.data.globals || []
      });
    }
  });

  injectPageProbe();

  // ── Form catalog ────────────────────────────────────────────────────
  // Enumerate every <form> on the page and record its security-relevant
  // attributes. This runs in the isolated world (DOM access works fine).
  function catalogForms() {
    const forms = [];
    document.querySelectorAll("form").forEach((f, i) => {
      if (forms.length >= 40) return;
      const action = f.getAttribute("action") || location.href;
      let absAction = action;
      try { absAction = new URL(action, location.href).href; } catch (_) {}
      let crossOrigin = false;
      try { crossOrigin = new URL(absAction).origin !== location.origin; } catch (_) {}

      const method = (f.getAttribute("method") || "GET").toUpperCase();
      const inputs = [...f.querySelectorAll("input, select, textarea")].map((el) => ({
        name: (el.getAttribute("name") || "").slice(0, 80),
        type: (el.getAttribute("type") || el.tagName.toLowerCase()).slice(0, 20),
        autocomplete: el.getAttribute("autocomplete") || null
      }));
      const hasPassword = inputs.some((x) => x.type === "password");
      const hasCsrf = inputs.some((x) =>
        /csrf|_token|authenticity_token|__requestverificationtoken|_csrf/i.test(x.name || "")
      );
      const autocomplete = f.getAttribute("autocomplete");
      forms.push({
        idx: i,
        action: absAction.slice(0, 300),
        method,
        crossOrigin,
        hasPassword,
        hasCsrf,
        autocomplete,
        inputs: inputs.slice(0, 30)
      });
    });
    return forms;
  }

  // ── DOM sink scanner ────────────────────────────────────────────────
  // Static text scan of INLINE scripts for dangerous sink patterns. This
  // is purely lexical (regex) — safe, no code execution. Complements the
  // secret-scanner text pass in the background.
  function scanDomSinks() {
    const findings = [];
    const scripts = document.querySelectorAll("script:not([src])");
    const SINK_PATTERNS = [
      { re: /\beval\s*\(/g, name: "eval()", severity: "MEDIUM" },
      { re: /new\s+Function\s*\(/g, name: "new Function()", severity: "MEDIUM" },
      { re: /\.innerHTML\s*=/g, name: "innerHTML= assignment", severity: "MEDIUM" },
      { re: /\.outerHTML\s*=/g, name: "outerHTML= assignment", severity: "MEDIUM" },
      { re: /\bdocument\.write(?:ln)?\s*\(/g, name: "document.write()", severity: "MEDIUM" },
      { re: /\bdocument\.domain\s*=/g, name: "document.domain= assignment", severity: "HIGH" },
      { re: /\bdangerouslySetInnerHTML\b/g, name: "React dangerouslySetInnerHTML", severity: "MEDIUM" },
      { re: /\bv-html\s*=/g, name: "Vue v-html directive", severity: "MEDIUM" },
      { re: /\[innerHTML\]\s*=/g, name: "Angular [innerHTML] binding", severity: "MEDIUM" },
      { re: /\bsetTimeout\s*\(\s*["'`]/g, name: "setTimeout(string) — eval-equivalent", severity: "MEDIUM" },
      { re: /\bsetInterval\s*\(\s*["'`]/g, name: "setInterval(string) — eval-equivalent", severity: "MEDIUM" },
      { re: /\blocation\s*=\s*[^=]/g, name: "location= assignment", severity: "LOW" },
      { re: /\blocation\.href\s*=/g, name: "location.href= assignment", severity: "LOW" }
    ];
    const seen = new Set();
    scripts.forEach((s, i) => {
      const src = s.textContent || "";
      if (!src || src.length > 200000) return;
      for (const { re, name, severity } of SINK_PATTERNS) {
        re.lastIndex = 0;
        const m = re.exec(src);
        if (!m) continue;
        const key = name + ":" + i;
        if (seen.has(key)) continue;
        seen.add(key);
        // Grab a small surrounding context for evidence.
        const start = Math.max(0, m.index - 30);
        const end = Math.min(src.length, m.index + name.length + 60);
        const context = src.slice(start, end).replace(/\s+/g, " ").slice(0, 120);
        findings.push({ name, severity, scriptIndex: i, context });
        if (findings.length >= 30) return;
      }
    });
    // Also scan attributes for on* handlers.
    let onAttrCount = 0;
    document.querySelectorAll("*").forEach((el) => {
      if (onAttrCount >= 30) return;
      for (const attr of el.attributes || []) {
        if (/^on/i.test(attr.name)) {
          onAttrCount++;
          if (onAttrCount <= 30) {
            findings.push({
              name: "inline " + attr.name + " handler",
              severity: "LOW",
              scriptIndex: null,
              context: `<${el.tagName.toLowerCase()} ${attr.name}="${(attr.value || "").slice(0, 60)}">`
            });
          }
        }
      }
    });
    return findings;
  }

  // ── postMessage listener detection ─────────────────────────────────
  // We look for calls to window.addEventListener("message", ...) or
  // onmessage= assignments in inline scripts (static). Detecting live
  // listeners requires page-world hooking; the static approach catches
  // 90% and stays CSP-safe.
  function scanPostMessageListeners() {
    const findings = [];
    const scripts = document.querySelectorAll("script:not([src])");
    scripts.forEach((s, i) => {
      const src = s.textContent || "";
      if (!src) return;
      // Find message-listener registrations.
      const listenerRe = /addEventListener\s*\(\s*["'`]message["'`]\s*,\s*([^)]+?)\)/g;
      const onmessageRe = /(?:window|self)\.onmessage\s*=\s*/g;
      let m;
      while ((m = listenerRe.exec(src)) !== null) {
        // Check if the handler validates event.origin
        const handlerBody = src.slice(m.index, Math.min(src.length, m.index + 800));
        const validatesOrigin = /event\.origin|e\.origin|msg\.origin/.test(handlerBody);
        findings.push({
          scriptIndex: i,
          hasOriginCheck: validatesOrigin,
          preview: src.slice(m.index, Math.min(src.length, m.index + 100)).replace(/\s+/g, " ")
        });
        if (findings.length >= 15) return;
      }
      if (onmessageRe.test(src)) {
        findings.push({ scriptIndex: i, hasOriginCheck: false, preview: "window.onmessage = <handler>" });
      }
    });
    return findings;
  }

  function runScan() {
    injectPageProbe();
    let forms = [], sinks = [], postMsg = [];
    try { forms = catalogForms(); } catch (_) {}
    try { sinks = scanDomSinks(); } catch (_) {}
    try { postMsg = scanPostMessageListeners(); } catch (_) {}
    chrome.runtime.sendMessage({
      type: "RH_FRONTEND",
      url: location.href,
      frontend: detectFrontend(),
      scriptUrls: collectResourceUrls(),
      inlineCode: collectInlineCode(),
      bodyText: scrapeBody(),
      forms,
      domSinks: sinks,
      postMessageListeners: postMsg
    });
  }

  runScan();

  // Only wire SPA hooks & listeners once, even if the script is re-injected
  // (the popup re-injects this file to force a fresh scan).
  if (!window.__reconhoundWired) {
    window.__reconhoundWired = true;

    let rescanTimer = null;
    function scheduleRescan() {
      clearTimeout(rescanTimer);
      rescanTimer = setTimeout(runScan, 800);
    }
    const _push = history.pushState;
    const _replace = history.replaceState;
    history.pushState = function (...args) { _push.apply(this, args); scheduleRescan(); };
    history.replaceState = function (...args) { _replace.apply(this, args); scheduleRescan(); };
    window.addEventListener("popstate", scheduleRescan);
    window.addEventListener("hashchange", scheduleRescan);

    // Expose for re-injection so executeScript can just call rescan.
    window.__reconhoundRescan = runScan;
  } else if (typeof window.__reconhoundRescan === "function") {
    window.__reconhoundRescan();
  }
})();

