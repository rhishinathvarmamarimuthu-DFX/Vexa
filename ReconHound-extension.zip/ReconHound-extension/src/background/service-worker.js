// ReconHound — Service worker (background)
// Captures headers/cookies, merges with content-script data, runs CVE matching.

import { HEADER_SIGNATURES, COOKIE_SIGNATURES, DB_ERROR_SIGNATURES } from "../engine/fingerprints.js";
import { lookupCVEs } from "../engine/cve-matcher.js";
import { analyzeSecurityHeaders, analyzeCookies, analyzeCors } from "../engine/security-analyzer.js";
import { scanScriptUrls, mergeGlobals } from "../engine/js-libraries.js";
import { probePaths } from "../engine/path-prober.js";
import { scanText } from "../engine/secret-scanner.js";
import { checkExposures } from "../engine/exposure-checker.js";
import { extractEndpoints, extractSubdomains, extractParams } from "../engine/endpoint-extractor.js";
import { checkSourceMaps, checkGraphQL } from "../engine/probe-advanced.js";
import { computeRisk } from "../engine/risk-score.js";
import { saveSnapshot, listSnapshots, diffSnapshots, snapshotOf, clearHistory } from "../engine/history.js";
import { enrichCves } from "../engine/exploit-intel.js";
import { reflectionProbe, directoryListingProbe } from "../engine/safe-checks.js";
import { probeWordPress } from "../engine/wordpress-probe.js";
import { probeWebApp } from "../engine/webapp-probe.js";
import { probeVCS } from "../engine/vcs-exposure.js";
import { runBrain } from "../engine/ai-brain.js";
import { enrichOutdated } from "../engine/outdated-versions.js";
import { scanJwts } from "../engine/jwt-analyzer.js";
import { enumerateSubdomains } from "../engine/cert-transparency.js";
import { analyzeSupplyChain } from "../engine/supply-chain.js";
import { buildAttackChains } from "../engine/attack-chain.js";
import { getSourceStatus } from "../engine/source-status.js";
import { bypassProbe } from "../engine/bypass-40x.js";
import { analyzeDns } from "../engine/dns-doh.js";
import { discoverWellKnown } from "../engine/well-known.js";
import { enumerateWayback } from "../engine/wayback.js";
import { analyzeCSP, cspAnalysisToFindings } from "../engine/csp-analyzer.js";
import { analyzeSetCookie } from "../engine/session-decoder.js";
import { analyzeForms, analyzeDomSinks, analyzePostMessageListeners } from "../engine/form-analyzer.js";
import { enrichWithTaxonomy } from "../engine/taxonomy.js";
import { buildSarif } from "../engine/sarif-export.js";
import { buildXssSurface, analyzeXssHeaders } from "../engine/xss-surface.js";

const SEVERITY_WEIGHT = { CRITICAL: 4, HIGH: 3, MEDIUM: 2, LOW: 1, UNKNOWN: 0 };

const tabData = {}; // { tabId: { url, tech: [], security: [] } }

// MV3 service workers sleep and lose memory. Mirror tabData to session storage
// so results survive worker restarts within the browsing session.
const SESSION_KEY = "rh_tabs";
let persistTimer = null;
function persistTabs() {
  clearTimeout(persistTimer);
  persistTimer = setTimeout(() => {
    try { chrome.storage.session.set({ [SESSION_KEY]: tabData }); } catch (_) {}
  }, 300);
}
// Guard against prototype pollution when merging session-storage content
// back into an internal object. Storage IS same-origin to the extension, but
// this is defence-in-depth in case any popup XSS ever poisons the storage.
function safeAssignFromStorage(target, source) {
  if (!source || typeof source !== "object") return;
  for (const key of Object.keys(source)) {
    if (key === "__proto__" || key === "prototype" || key === "constructor") continue;
    target[key] = source[key];
  }
}

// Rehydrate on startup.
const ready = (async () => {
  try {
    const d = await chrome.storage.session.get(SESSION_KEY);
    if (d[SESSION_KEY]) safeAssignFromStorage(tabData, d[SESSION_KEY]);
  } catch (_) {}
})();

// Cached settings (kept in sync with chrome.storage.local)
const settings = {
  nvdApiKey: "",
  enableCves: true,
  enableSecurity: true,
  enableSecrets: true,
  enableBadge: true,
  globalAuth: false,
  enableActiveDeep: true,
  enableBypass40x: true,
  bypassDiagnostic: true,
  enableAutoBypass: true,
  customSecretRules: []
};

chrome.storage.local.get(settings).then((cfg) => Object.assign(settings, cfg));
chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== "local") return;
  for (const [k, { newValue }] of Object.entries(changes)) {
    if (k in settings) settings[k] = newValue;
  }
});

function ensureTab(tabId) {
  tabData[tabId] ??= { tech: [], security: [] };
  return tabData[tabId];
}

function addTech(tabId, entry) {
  if (tabId == null || tabId < 0) return;
  const d = ensureTab(tabId);
  const exists = d.tech.find(
    (t) => t.tech === entry.tech && t.category === entry.category
  );
  if (!exists) d.tech.push(entry);
  else if (entry.version && !exists.version) exists.version = entry.version;
  persistTabs();
}

function addJwts(tabId, jwts) {
  if (!jwts?.length) return;
  const d = ensureTab(tabId);
  d.jwts ??= [];
  const seen = new Set(d.jwts.map((j) => j.header && j.payloadSample
    ? JSON.stringify(j.header) + JSON.stringify(j.payloadSample)
    : Math.random()));
  for (const j of jwts) {
    const key = JSON.stringify(j.header) + JSON.stringify(j.payloadSample);
    if (!seen.has(key)) {
      seen.add(key);
      d.jwts.push(j);
    }
  }
  const w = { CRITICAL: 4, HIGH: 3, MEDIUM: 2, LOW: 1 };
  d.jwts.sort((a, b) => (w[b.verdict] || 0) - (w[a.verdict] || 0));
  persistTabs();
}

function addSecrets(tabId, secrets) {
  if (!secrets?.length) return;
  const d = ensureTab(tabId);
  d.secrets ??= [];
  const seen = new Set(d.secrets.map((s) => s.id + s.match));
  for (const s of secrets) {
    const key = s.id + s.match;
    if (!seen.has(key)) {
      seen.add(key);
      d.secrets.push(s);
    }
  }
  const weight = { CRITICAL: 4, HIGH: 3, MEDIUM: 2, LOW: 1, UNKNOWN: 0 };
  d.secrets.sort((a, b) => (weight[b.severity] || 0) - (weight[a.severity] || 0));
  persistTabs();
}

// Fetch external same-origin JS bundles (capped) and scan them for secrets.
async function scanExternalScripts(tabId, scriptUrls, pageOrigin) {
  const jsUrls = (scriptUrls || []).filter((u) => /\.js(\?|$)/i.test(u)).slice(0, 8);
  await Promise.all(
    jsUrls.map(async (url) => {
      try {
        const res = await fetch(url, { credentials: "omit" });
        if (!res.ok) return;
        const text = (await res.text()).slice(0, 1000000);
        addSecrets(tabId, scanText(text, shortenUrl(url), settings.customSecretRules));
        addJwts(tabId, scanJwts(text, shortenUrl(url)));
        addEndpoints(tabId, extractEndpoints(text, shortenUrl(url)));
        addRecon(tabId, {
          subdomains: extractSubdomains(text, baseHostOf(pageOrigin)),
          params: extractParams(text)
        });
        updateBadge(tabId);
      } catch (_) {}
    })
  );
}

function addEndpoints(tabId, endpoints) {
  if (!endpoints?.length) return;
  const d = ensureTab(tabId);
  d.endpoints ??= [];
  const seen = new Set(d.endpoints.map((e) => e.path));
  for (const e of endpoints) {
    if (!seen.has(e.path)) {
      seen.add(e.path);
      d.endpoints.push(e);
    }
  }
  const order = { graphql: 0, admin: 1, auth: 2, api: 3, data: 4, link: 5 };
  d.endpoints.sort((a, b) => (order[a.type] ?? 9) - (order[b.type] ?? 9));
  persistTabs();
}

function addRecon(tabId, { subdomains = [], params = [] }) {
  const d = ensureTab(tabId);
  d.subdomains ??= [];
  d.params ??= [];
  const subSet = new Set(d.subdomains);
  subdomains.forEach((s) => subSet.add(s));
  d.subdomains = [...subSet].sort().slice(0, 300);
  const paramSet = new Set(d.params);
  params.forEach((p) => paramSet.add(p));
  d.params = [...paramSet].sort().slice(0, 300);
  persistTabs();
}

function baseHostOf(url) {
  try { return new URL(url).hostname; } catch (_) { return ""; }
}

// Header fallback: when the worker missed onHeadersReceived (e.g. page was
// already open or worker was asleep), re-fetch the page and fingerprint headers.
async function headerFallback(tabId, url) {
  try {
    const res = await fetch(url, { credentials: "omit", redirect: "follow" });
    const headers = [];
    res.headers.forEach((value, name) => headers.push({ name, value }));

    for (const h of headers) {
      const name = h.name.toLowerCase();
      const sigs = HEADER_SIGNATURES[name];
      if (sigs) {
        for (const sig of sigs) {
          const m = (h.value || "").match(sig.regex);
          if (m) addTech(tabId, { tech: sig.tech, version: m[1] || null, category: sig.category });
        }
      }
    }

    if (settings.enableSecurity) {
      const d = ensureTab(tabId);
      const sec = [
        ...analyzeSecurityHeaders(headers),
        ...analyzeCors(headers)
      ].sort((a, b) => (SEVERITY_WEIGHT[b.severity] || 0) - (SEVERITY_WEIGHT[a.severity] || 0));
      // Only set if we don't already have richer header-listener data.
      if (!d.security || d.security.length === 0) d.security = sec;
    }
    persistTabs();
  } catch (_) {}
}

// Force a fresh scan on demand (popup open). Re-injects the content detector to
// re-collect DOM/JS, and runs the header fallback if needed.
async function ensureFreshScan(tabId, url) {
  if (!url || /^(chrome|edge|about|chrome-extension|view-source):/i.test(url)) return;
  const d = ensureTab(tabId);
  d.url = url;

  // 1. Re-run the in-page detector (DOM frameworks, script URLs, inline secrets).
  try {
    await chrome.scripting.executeScript({
      target: { tabId },
      files: ["src/content/detector.js"]
    });
  } catch (_) {}

  // 2. Give the content script a moment to message back, then header fallback.
  await new Promise((r) => setTimeout(r, 350));
  const hasHeaderTech = (d.tech || []).some((t) =>
    ["web-server", "language", "backend", "cms"].includes(t.category)
  );
  if (!hasHeaderTech || !d.security || d.security.length === 0) {
    await headerFallback(tabId, url);
  }
}

// Fast LOCAL report — no network. Tech (no CVEs yet) + headers + secrets + recon.
function buildLocalReport(tabId) {
  const data = tabData[tabId] || { tech: [], security: [] };
  const report = {
    url: data.url,
    tech: (data.tech || []).map((t) => ({ ...t, cves: [] })),
    security: data.security || [],
    secrets: data.secrets || [],
    jwts: data.jwts || [],
    endpoints: data.endpoints || [],
    subdomains: data.subdomains || [],
    ctSubdomains: data.ctSubdomains || [],
    params: data.params || [],
    exposures: data.exposures || [],
    activeScan: data.activeScan || [],
    supplyChain: data.supplyChain || null,
    waf: data.waf || null,
    bypassTelemetry: data.bypassTelemetry || null,
    autoBypassFindings: data.autoBypassFindings || [],
    autoBypassTelemetry: data.autoBypassTelemetry || [],
    cspBlocked: !!data.cspBlocked,
    cspBlockedReason: data.cspBlockedReason || null,
    partial: true
  };
  report.risk = computeRisk(report);
  try { report.attackChains = buildAttackChains(report); } catch (_) { report.attackChains = []; }
  try { enrichWithTaxonomy(report); } catch (_) {}
  report.dns = data.dns || null;
  report.wellKnown = data.wellKnown || null;
  report.wayback = data.wayback || null;
  report.forms = data.forms || [];
  report.domSinks = data.domSinks || [];
  report.postMessageListeners = data.postMessageListeners || [];
  report.cspAnalysis = data.cspAnalysis || null;
  try {
    report.xssSurface = buildXssSurface(report, {
      inlineCode: data.inlineCode || "",
      scriptUrls: data.scriptUrls || [],
      responseHeaders: data.responseHeaders || []
    });
  } catch (_) { report.xssSurface = null; }
  return report;
}

// Build the complete report (tech + CVEs + recon + risk + brain) for a tab.
async function buildFullReport(tabId) {
  const data = tabData[tabId] || { tech: [], security: [] };
  const withCves = await Promise.all(
    (data.tech || []).map(async (t) => {
      try {
        const isScannable = ["web-server", "language", "backend", "frontend", "cms", "js-library"].includes(t.category);
        if (!settings.enableCves || !isScannable) return { ...t, cves: [] };
        const cves = await lookupCVEs(t.tech, t.version, settings.nvdApiKey || null);
        const enriched = await enrichCves(cves);
        return { ...t, cves: enriched };
      } catch (_) {
        return { ...t, cves: [] };
      }
    })
  );

  // Outdated / EOL enrichment (endoflife.date + npm + WP core, cached 24 h).
  try { await enrichOutdated(withCves); } catch (_) {}

  const report = {
    url: data.url,
    tech: withCves,
    security: data.security || [],
    secrets: data.secrets || [],
    jwts: data.jwts || [],
    endpoints: data.endpoints || [],
    subdomains: data.subdomains || [],
    ctSubdomains: data.ctSubdomains || [],
    params: data.params || [],
    exposures: data.exposures || [],
    activeScan: data.activeScan || [],
    supplyChain: data.supplyChain || null,
    waf: data.waf || null,
    bypassTelemetry: data.bypassTelemetry || null,
    autoBypassFindings: data.autoBypassFindings || [],
    autoBypassTelemetry: data.autoBypassTelemetry || [],
    cspBlocked: !!data.cspBlocked,
    cspBlockedReason: data.cspBlockedReason || null
  };
  report.risk = computeRisk(report);
  try { await runBrain(report); } catch (_) {}
  try { report.attackChains = buildAttackChains(report); } catch (_) { report.attackChains = []; }
  try { enrichWithTaxonomy(report); } catch (_) {}
  // Expose DNS / .well-known / Wayback / forms so the popup can render them.
  const d = tabData[tabId] || {};
  report.dns = d.dns || null;
  report.wellKnown = d.wellKnown || null;
  report.wayback = d.wayback || null;
  report.forms = d.forms || [];
  report.domSinks = d.domSinks || [];
  report.postMessageListeners = d.postMessageListeners || [];
  report.cspAnalysis = d.cspAnalysis || null;
  // Build the consolidated XSS attack-surface map from everything above.
  try {
    report.xssSurface = buildXssSurface(report, {
      inlineCode: d.inlineCode || "",
      scriptUrls: d.scriptUrls || [],
      responseHeaders: d.responseHeaders || []
    });
    // Add header-level XSS findings to the security bucket.
    const hdrFindings = analyzeXssHeaders(d.responseHeaders || []);
    if (hdrFindings.length) report.security = [...(report.security || []), ...hdrFindings];
  } catch (_) { report.xssSurface = null; }
  return report;
}

function shortenUrl(u) {
  try {
    const { pathname, host } = new URL(u);
    return host + pathname.split("/").pop();
  } catch (_) {
    return u;
  }
}

// Update the toolbar badge with the count of security findings + secrets.
// Auto-bypass hits take priority: badge turns bright green "⚡" so the user
// notices without having to open the popup first.
function updateBadge(tabId) {
  if (!settings.enableBadge) {
    chrome.action.setBadgeText({ tabId, text: "" });
    return;
  }
  const d = tabData[tabId];
  const autoBypassHits = (d?.autoBypassFindings?.length || 0);
  if (autoBypassHits > 0) {
    chrome.action.setBadgeText({ tabId, text: "⚡" + autoBypassHits });
    chrome.action.setBadgeBackgroundColor({ tabId, color: "#00ff8c" });
    return;
  }
  const count = (d?.security?.length || 0) + (d?.secrets?.length || 0);
  const text = count > 0 ? String(count) : "";
  const hasHigh =
    (d?.security || []).some((f) => f.severity === "HIGH" || f.severity === "CRITICAL") ||
    (d?.secrets || []).some((f) => f.severity === "HIGH" || f.severity === "CRITICAL");
  chrome.action.setBadgeText({ tabId, text });
  chrome.action.setBadgeBackgroundColor({ tabId, color: hasHigh ? "#f85149" : "#d29922" });
}

// 1. Capture response headers (tech fingerprint + security analysis)
chrome.webRequest.onHeadersReceived.addListener(
  (details) => {
    if (details.type !== "main_frame") return;
    const setCookies = [];

    for (const h of details.responseHeaders || []) {
      const name = h.name.toLowerCase();
      const sigs = HEADER_SIGNATURES[name];
      if (sigs) {
        for (const sig of sigs) {
          const m = (h.value || "").match(sig.regex);
          if (m) addTech(details.tabId, { tech: sig.tech, version: m[1] || null, category: sig.category });
        }
      }
      if (name === "set-cookie") {
        setCookies.push(h.value || "");
        for (const c of COOKIE_SIGNATURES) {
          if (c.regex.test(h.value || "")) addTech(details.tabId, { tech: c.tech, version: null, category: c.category });
        }
      }
    }

    // Security findings: missing headers, info leaks, weak cookies, CORS
    const d = ensureTab(details.tabId);
    // Remember the raw response headers for cross-cutting analysers.
    d.responseHeaders = (details.responseHeaders || []).map((h) => ({
      name: String(h.name || "").toLowerCase(),
      value: String(h.value || "")
    }));
    const cspHeader = (details.responseHeaders || []).find((h) => /^content-security-policy(-report-only)?$/i.test(h.name || ""));
    const cspAnalysis = cspHeader ? analyzeCSP(cspHeader.value || "", /report-only/i.test(cspHeader.name || "")) : null;
    d.cspAnalysis = cspAnalysis;

    // Session-cookie structural analysis on every Set-Cookie observed.
    const cookieFindings = [];
    for (const raw of setCookies) {
      try {
        const r = analyzeSetCookie(raw, details.url);
        if (r?.findings?.length) cookieFindings.push(...r.findings);
      } catch (_) {}
    }

    d.security = settings.enableSecurity
      ? [
          ...analyzeSecurityHeaders(details.responseHeaders || []),
          ...analyzeCookies(setCookies),
          ...analyzeCors(details.responseHeaders || []),
          ...cookieFindings,
          ...(cspAnalysis ? cspAnalysisToFindings(cspAnalysis, details.url) : [])
        ].sort((a, b) => (SEVERITY_WEIGHT[b.severity] || 0) - (SEVERITY_WEIGHT[a.severity] || 0))
      : [];

    updateBadge(details.tabId);
  },
  { urls: ["<all_urls>"] },
  ["responseHeaders", "extraHeaders"]
);

// ─── AUTO-BYPASS: watch every 403/401/400 on authorized hosts and fire the
//     WAF-aware bypass techniques against them in the background. Results push
//     into the tab's exposures + badge so the user sees hits the moment they
//     open the popup — no click required.
const _autoBypassInFlight = new Set();      // in-flight URLs (prevent parallel dup)
chrome.webRequest.onHeadersReceived.addListener(
  (details) => {
    if (!settings.enableAutoBypass) return;
    // Only main_frame + sub_frame — don't fire on every image/CSS 403.
    if (details.type !== "main_frame" && details.type !== "sub_frame" && details.type !== "xmlhttprequest") return;
    // Only interesting protection statuses.
    if (![400, 401, 402, 403, 405].includes(details.statusCode)) return;

    (async () => {
      // Authorization gate — same rules as the manual active scan.
      let host;
      try { host = new URL(details.url).host; } catch { return; }
      const { authorizedHosts = [], globalAuth = false } = await chrome.storage.local.get({
        authorizedHosts: [], globalAuth: false
      });
      if (!globalAuth && !authorizedHosts.includes(host)) return;

      // De-dup: only try each URL once per tab-lifetime.
      const d = ensureTab(details.tabId);
      d.autoBypassSeen ??= [];
      if (d.autoBypassSeen.includes(details.url)) return;
      if (_autoBypassInFlight.has(details.url)) return;
      d.autoBypassSeen.push(details.url);
      _autoBypassInFlight.add(details.url);

      try {
        const origin = new URL(details.url).origin;
        const path = new URL(details.url).pathname;
        // Synthesise a path-prober-shaped candidate so bypassProbe treats it
        // as a first-class target (not just a seed).
        const seed = [{ url: details.url, path, status: details.statusCode }];
        const result = await bypassProbe(seed, {
          origin,
          observedCookies: [],
          observedHeaders: details.responseHeaders || [],
          diagnostic: settings.bypassDiagnostic !== false
        });
        if (result?.findings?.length) {
          d.exposures = [...(d.exposures || []), ...result.findings];
          d.autoBypassFindings ??= [];
          d.autoBypassFindings.push(...result.findings);
          d.waf = result.waf || d.waf;
          persistTabs();
          updateBadge(details.tabId);
        }
        // Even if no hit, remember the telemetry — the popup shows what was tried.
        d.autoBypassTelemetry ??= [];
        d.autoBypassTelemetry.push({
          url: details.url,
          status: details.statusCode,
          ts: Date.now(),
          telemetry: result?.telemetry || null,
          hits: result?.findings?.length || 0
        });
        // Cap telemetry buffer.
        if (d.autoBypassTelemetry.length > 20) d.autoBypassTelemetry = d.autoBypassTelemetry.slice(-20);
        persistTabs();
      } catch (_) { /* swallow — auto flow must never break the browsing tab */ }
      finally { _autoBypassInFlight.delete(details.url); }
    })();
  },
  { urls: ["<all_urls>"] },
  ["responseHeaders", "extraHeaders"]
);

// Reset tab data on a fresh navigation
chrome.webNavigation?.onBeforeNavigate?.addListener((details) => {
  if (details.frameId === 0) delete tabData[details.tabId];
});

// 2. Receive content-script findings
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  const tabId = sender.tab?.id;

  if (msg.type === "RH_FRONTEND" && tabId != null) {
    const d = ensureTab(tabId);
    d.url = msg.url;
    d.scriptUrls = msg.scriptUrls || [];
    d.inlineCode = (msg.inlineCode || "").slice(0, 200000); // capped for xss-surface later
    (msg.frontend || []).forEach((f) => addTech(tabId, f));

    // Real JS-library detection from actually-loaded script/style URLs.
    scanScriptUrls(msg.scriptUrls || []).forEach((lib) => addTech(tabId, lib));

    // Passive secret scan: inline scripts + visible page text.
    if (settings.enableSecrets !== false) {
      addSecrets(tabId, scanText(msg.inlineCode || "", "inline script", settings.customSecretRules));
      addSecrets(tabId, scanText(msg.bodyText || "", "page HTML", settings.customSecretRules));
      // JWT auto-analysis: decode + score any JWTs spotted in inline/HTML.
      addJwts(tabId, scanJwts(msg.inlineCode || "", "inline script"));
      addJwts(tabId, scanJwts(msg.bodyText || "", "page HTML"));
      updateBadge(tabId);
      // Deep scan: fetch external JS bundles and scan them (async, non-blocking).
      scanExternalScripts(tabId, msg.scriptUrls, msg.url);
    }

    // Supply-chain / third-party inventory + subdomain-takeover surface.
    try {
      const sc = analyzeSupplyChain(msg.scriptUrls || [], msg.url || "");
      d.supplyChain = sc;
      if (sc.findings?.length) {
        d.exposures = [...(d.exposures || []), ...sc.findings];
      }
    } catch (_) {}

    // Form / DOM-sink / postMessage analysis from the content-script probe.
    try {
      if (Array.isArray(msg.forms) && msg.forms.length) {
        d.forms = msg.forms;
        const formFindings = analyzeForms(msg.forms, msg.url || "");
        if (formFindings.length) d.exposures = [...(d.exposures || []), ...formFindings];
      }
      if (Array.isArray(msg.domSinks) && msg.domSinks.length) {
        d.domSinks = msg.domSinks;
        const sinkFindings = analyzeDomSinks(msg.domSinks, msg.url || "");
        if (sinkFindings.length) d.exposures = [...(d.exposures || []), ...sinkFindings];
      }
      if (Array.isArray(msg.postMessageListeners) && msg.postMessageListeners.length) {
        d.postMessageListeners = msg.postMessageListeners;
        const pmFindings = analyzePostMessageListeners(msg.postMessageListeners, msg.url || "");
        if (pmFindings.length) d.exposures = [...(d.exposures || []), ...pmFindings];
      }
    } catch (_) {}
    // Endpoint extraction from inline code (external handled in deep scan).
    addEndpoints(tabId, extractEndpoints(msg.inlineCode || "", "inline script"));
    addRecon(tabId, {
      subdomains: extractSubdomains((msg.inlineCode || "") + " " + (msg.bodyText || ""), baseHostOf(msg.url)),
      params: extractParams(msg.inlineCode || "")
    });

    for (const db of DB_ERROR_SIGNATURES) {
      if (db.regex.test(msg.bodyText || "")) {
        addTech(tabId, { tech: db.tech, version: null, category: db.category });
      }
    }
  }

  // Page-world globals carry real runtime versions (React.version, etc.)
  if (msg.type === "RH_GLOBALS" && tabId != null) {
    mergeGlobals(msg.globals || []).forEach((lib) => addTech(tabId, lib));
    const d = ensureTab(tabId);
    d.cspBlocked = false;  // page-world script executed → CSP allowed us
    persistTabs();
  }

  // Content script signals that the page-world probe was blocked (CSP).
  if (msg.type === "RH_CSP_BLOCKED" && tabId != null) {
    const d = ensureTab(tabId);
    d.cspBlocked = true;
    d.cspBlockedReason = msg.reason || "unknown";
    persistTabs();
  }

  // 3. Popup requests the full report (with CVEs)
  if (msg.type === "RH_GET_REPORT") {
    (async () => {
      const data = tabData[msg.tabId] || { tech: [], security: [] };
      const withCves = await Promise.all(
        data.tech.map(async (t) => ({
          ...t,
          cves: settings.enableCves && ["web-server", "language", "backend", "frontend", "cms", "js-library"].includes(t.category)
            ? await lookupCVEs(t.tech, t.version, settings.nvdApiKey || null)
            : []
        }))
      );
      sendResponse({ url: data.url, tech: withCves, security: data.security || [], secrets: data.secrets || [], endpoints: data.endpoints || [] });
    })();
    return true; // keep channel open for async response
  }

  // 3b. Full report including recon + computed risk score.
  if (msg.type === "RH_GET_FULL") {
    (async () => {
      try {
        await ready;
        sendResponse(await buildFullReport(msg.tabId));
      } catch (err) {
        sendResponse(buildLocalReport(msg.tabId));
      }
    })();
    return true;
  }

  // 3a. Force a fresh scan (called by the popup on open) then return the report.
  if (msg.type === "RH_ENSURE") {
    (async () => {
      try {
        await ready;
        await ensureFreshScan(msg.tabId, msg.url);
        // Return FAST local data (no network) so the UI populates immediately.
        sendResponse(buildLocalReport(msg.tabId));
      } catch (err) {
        sendResponse({ tech: [], security: [], url: msg.url, error: String(err && err.message || err) });
      }
    })();
    return true;
  }

  // 3c. History: save snapshot of current full report.
  if (msg.type === "RH_SAVE_SNAPSHOT") {
    (async () => {
      const report = await buildFullReport(msg.tabId);
      const snap = await saveSnapshot(report);
      sendResponse({ saved: true, snap });
    })();
    return true;
  }

  // 3d. History: list snapshots for a host + diff current vs previous.
  if (msg.type === "RH_GET_HISTORY") {
    (async () => {
      const report = await buildFullReport(msg.tabId);
      const host = (() => { try { return new URL(report.url).host; } catch { return ""; } })();
      const snaps = await listSnapshots(host);
      const current = snapshotOf(report);
      const previous = snaps[0] || null;
      const diff = previous ? diffSnapshots(current, previous) : null;
      sendResponse({ host, current, snapshots: snaps, diff });
    })();
    return true;
  }

  // 3f. Popup asks for upstream data-source health so it can render an
  //     offline/degraded banner. Cheap read from session storage.
  if (msg.type === "RH_GET_SOURCE_STATUS") {
    (async () => {
      try { sendResponse(await getSourceStatus()); }
      catch (_) { sendResponse({}); }
    })();
    return true;
  }

  // 3e. Return only the previous-snapshot signature set so the popup can
  //     flash "new since last snapshot" markers without fetching everything.
  if (msg.type === "RH_GET_PREV_SIGS") {
    (async () => {
      try {
        const url = msg.url || tabData[msg.tabId]?.url || "";
        const host = (() => { try { return new URL(url).host; } catch { return ""; } })();
        const snaps = host ? await listSnapshots(host) : [];
        sendResponse({ host, prevSigs: snaps.length ? (snaps[0].sigs || []) : [] });
      } catch (_) {
        sendResponse({ host: "", prevSigs: [] });
      }
    })();
    return true;
  }

  if (msg.type === "RH_CLEAR_HISTORY") {
    (async () => { await clearHistory(); sendResponse({ cleared: true }); })();
    return true;
  }

  // Note: the popup runs the active scan via the streaming port channel
  // "rh-active-scan" (see chrome.runtime.onConnect below). The legacy
  // single-shot RH_ACTIVE_SCAN handler was removed on 2026-07-03 to eliminate
  // a landmine — it referenced `pushExposures` and `post` symbols that only
  // exist inside the port handler's scope.
});

chrome.tabs.onRemoved.addListener((tabId) => delete tabData[tabId]);

// ─── SARIF export handler ───────────────────────────────────────────────
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type !== "RH_EXPORT_SARIF") return;
  (async () => {
    try {
      const report = await buildFullReport(msg.tabId);
      const sarif = buildSarif(report);
      sendResponse({ ok: true, sarif });
    } catch (err) {
      sendResponse({ ok: false, error: String(err && err.message || err) });
    }
  })();
  return true;
});

// ─── Bulk scan across all open tabs ─────────────────────────────────────
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type !== "RH_BULK_SCAN") return;
  (async () => {
    try {
      const { authorizedHosts = [], globalAuth = false } = await chrome.storage.local.get({
        authorizedHosts: [], globalAuth: false
      });
      const tabs = await chrome.tabs.query({});
      // Scope filter: only http(s) tabs the user has explicitly authorised.
      // Even with globalAuth on, we skip common personal-account hosts unless
      // the user has explicitly added them — defence-in-depth against accidents.
      const isAuthorised = (u) => {
        try {
          const host = new URL(u).host;
          if (authorizedHosts.includes(host)) return true;
          if (globalAuth) return true;
          return false;
        } catch { return false; }
      };
      const allHttpTabs = tabs.filter((t) => t.url && /^https?:/i.test(t.url));
      const httpTabs = allHttpTabs.filter((t) => isAuthorised(t.url));
      const skipped = allHttpTabs.length - httpTabs.length;
      const results = [];
      // Concurrency limit to be gentle on the browser.
      const CONCURRENCY = 3;
      const queue = [...httpTabs];
      const workers = Array.from({ length: CONCURRENCY }, async () => {
        while (queue.length) {
          const t = queue.shift();
          try {
            await ensureFreshScan(t.id, t.url);
            await new Promise((r) => setTimeout(r, 400));
            const report = await buildFullReport(t.id);
            results.push({
              tabId: t.id,
              url: t.url,
              title: t.title,
              grade: report.risk?.grade || "?",
              score: report.risk?.score || 0,
              counts: report.risk?.counts || {},
              exposureCount: (report.exposures || []).length,
              secretCount: (report.secrets || []).length,
              cveCount: (report.tech || []).reduce((n, x) => n + (x.cves || []).length, 0)
            });
          } catch (_) {
            results.push({ tabId: t.id, url: t.url, error: true });
          }
        }
      });
      await Promise.all(workers);
      sendResponse({ ok: true, count: httpTabs.length, skipped, results });
    } catch (err) {
      sendResponse({ ok: false, error: String(err && err.message || err) });
    }
  })();
  return true;
});

// ─── Right-click context menu ───────────────────────────────────────────
function registerContextMenus() {
  if (!chrome.contextMenus) return;
  chrome.contextMenus.removeAll(() => {
    try {
      chrome.contextMenus.create({
        id: "rh-scan-link", title: "🐕 ReconHound: Scan this link",
        contexts: ["link"]
      });
      chrome.contextMenus.create({
        id: "rh-authorize-domain", title: "🐕 ReconHound: Authorize this domain for active scanning",
        contexts: ["page", "link"]
      });
      chrome.contextMenus.create({
        id: "rh-check-selection-jwt", title: "🐕 ReconHound: Analyze selection as JWT",
        contexts: ["selection"]
      });
    } catch (_) {}
  });
}
try { registerContextMenus(); } catch (_) {}
chrome.runtime.onInstalled?.addListener(() => { try { registerContextMenus(); } catch (_) {} });

// Small helper: authorization check honoured by every user-initiated scan action.
async function isHostAuthorized(url) {
  try {
    const host = new URL(url).host;
    const { authorizedHosts = [], globalAuth = false } = await chrome.storage.local.get({
      authorizedHosts: [], globalAuth: false
    });
    return { authorized: globalAuth || authorizedHosts.includes(host), host };
  } catch { return { authorized: false, host: "" }; }
}

chrome.contextMenus?.onClicked.addListener(async (info, tab) => {
  try {
    if (info.menuItemId === "rh-scan-link" && info.linkUrl) {
      // Enforce scope: only scan authorized hosts.
      const { authorized, host } = await isHostAuthorized(info.linkUrl);
      if (!authorized) {
        // Surface the block in the badge so the user notices.
        try {
          chrome.action.setBadgeText({ tabId: tab?.id, text: "🚫" });
          chrome.action.setBadgeBackgroundColor({ tabId: tab?.id, color: "#d29922" });
          setTimeout(() => chrome.action.setBadgeText({ tabId: tab?.id, text: "" }), 2500);
        } catch (_) {}
        return; // silently refuse (also visible via badge)
      }
      const newTab = await chrome.tabs.create({ url: info.linkUrl, active: false });
      setTimeout(() => ensureFreshScan(newTab.id, info.linkUrl).catch(() => {}), 2000);
    } else if (info.menuItemId === "rh-authorize-domain") {
      const url = info.linkUrl || info.pageUrl || tab?.url;
      let host = ""; try { host = new URL(url).host; } catch (_) {}
      if (!host) return;
      const { authorizedHosts = [] } = await chrome.storage.local.get({ authorizedHosts: [] });
      if (!authorizedHosts.includes(host)) {
        authorizedHosts.push(host);
        await chrome.storage.local.set({ authorizedHosts });
      }
    } else if (info.menuItemId === "rh-check-selection-jwt" && info.selectionText) {
      // Store the selection for the popup to analyze on next open.
      await chrome.storage.session.set({ rh_pending_jwt: info.selectionText.trim() });
      // openPopup() is Chrome 127+. On older versions the optional-call
      // returns undefined and .catch on undefined throws; guard explicitly.
      try {
        const p = chrome.action.openPopup?.();
        if (p && typeof p.catch === "function") p.catch(() => {});
      } catch (_) {}
    }
  } catch (_) { /* never break the browser flow */ }
});

// ─── Streaming active-scan channel ──────────────────────────────────────
// The popup opens a long-lived port named "rh-active-scan". The worker
// pushes each phase's results as it completes so the UI can render
// progressively — no more staring at a 40s spinner.
chrome.runtime.onConnect.addListener((port) => {
  if (port.name !== "rh-active-scan") return;
  port.onMessage.addListener(async (msg) => {
    if (msg.type !== "START") return;
    const { tabId, url } = msg;
    try {
      await ready;
      const origin = new URL(url).origin;
      const host = new URL(url).host;
      const d = ensureTab(tabId);
      const scriptUrls = d.scriptUrls || [];
      const graphqlPaths = (d.endpoints || [])
        .filter((e) => e.type === "graphql")
        .map((e) => { try { return new URL(e.path, origin).pathname; } catch { return null; } })
        .filter(Boolean);
      const deep = settings.enableActiveDeep !== false;

      const post = (phase, data) => {
        try { port.postMessage({ type: "PHASE", phase, ...data }); } catch (_) {}
      };
      const bypassEnabled = settings.enableBypass40x !== false;
      post("started", { phases: deep
        ? ["paths", "exposures", "sourcemaps", "graphql", "reflect", ...(bypassEnabled ? ["bypass"] : []), "webapp", "wordpress", "vcs", "wellknown", "dns", "wayback", "ct"]
        : ["paths", "exposures", "sourcemaps", "graphql", "reflect", ...(bypassEnabled ? ["bypass"] : [])] });

      const aggregate = { exposures: [], findings: [] };
      const pushExposures = (arr) => {
        aggregate.exposures.push(...(arr || []));
        d.exposures = aggregate.exposures;
      };

      // ── Phase 1: local-origin fast probes (paths + exposures) ──
      const [paths, exposures] = await Promise.all([
        probePaths(origin).catch(() => []),
        checkExposures(origin).catch(() => [])
      ]);
      aggregate.findings = paths;
      d.activeScan = paths;
      pushExposures(exposures);
      post("paths", { findings: paths });
      post("exposures", { exposures });

      // ── Phase 2: source-maps + GraphQL (script-URL-dependent) ──
      const [sourceMaps, graphql] = await Promise.all([
        checkSourceMaps(scriptUrls).catch(() => []),
        checkGraphQL(origin, graphqlPaths).catch(() => [])
      ]);
      pushExposures(sourceMaps);
      pushExposures(graphql);
      post("sourcemaps", { exposures: sourceMaps });
      post("graphql", { exposures: graphql });

      // ── Phase 3: canary reflection + directory listing ──
      const [reflections, dirListings] = await Promise.all([
        reflectionProbe(d.url || url, d.params || []).catch(() => []),
        directoryListingProbe(origin).catch(() => [])
      ]);
      pushExposures(reflections);
      pushExposures(dirListings);
      post("reflect", { exposures: [...reflections, ...dirListings] });

      // ── Phase 3b: 40x access-control bypass probe (WAF-aware).
      // Fingerprints the fronting WAF first, then prioritises techniques known
      // to expose that vendor's typical misconfigurations. Reports only
      // variants that produced a demonstrably-different response.
      if (bypassEnabled) {
        const observedCookies = (d.security || [])
          .filter((s) => /cookie/i.test(s.title || ""))
          .map((s) => s.detail || "");
        // Always add the current-tab URL as an implicit candidate — it's the
        // page the operator is looking at, so it should be tested every scan
        // even if the passive prober didn't classify it as 4xx.
        const currentUrl = d.url || url;
        const currentPath = (() => { try { return new URL(currentUrl).pathname; } catch { return "/"; } })();
        const augmentedPaths = [
          ...paths,
          // status 0 signals bypassProbe to baseline it fresh and decide
          { url: currentUrl, path: currentPath, status: 0, implicit: true }
        ];
        const bypassResult = await bypassProbe(augmentedPaths, {
          origin,
          observedCookies,
          observedHeaders: null,
          diagnostic: settings.bypassDiagnostic !== false
        }).catch(() => ({ findings: [], waf: null, telemetry: {} }));

        pushExposures(bypassResult.findings);
        d.waf = bypassResult.waf || null;
        d.bypassTelemetry = bypassResult.telemetry || null;
        persistTabs();

        post("bypass", {
          exposures: bypassResult.findings,
          waf: bypassResult.waf,
          telemetry: bypassResult.telemetry
        });
      }

      // ── Phase 4 (deep only): webapp, wordpress, vcs — parallel ──
      if (deep) {
        const [webappFindings, wpResult, vcsResult] = await Promise.all([
          probeWebApp(origin).catch(() => []),
          probeWordPress(origin).catch(() => ({ present: false, findings: [] })),
          probeVCS(origin).catch(() => ({ findings: [], meta: {} }))
        ]);
        pushExposures(webappFindings);
        pushExposures(wpResult.findings || []);
        pushExposures(vcsResult.findings || []);
        d.vcs = vcsResult.meta || null;
        if (wpResult.present) {
          d.wordpress = { version: wpResult.version };
          addTech(tabId, { tech: "WordPress", version: wpResult.version || null, category: "cms" });
        }
        post("webapp", { exposures: webappFindings });
        post("wordpress", {
          exposures: wpResult.findings || [],
          detected: wpResult.present,
          version: wpResult.version || null
        });
        post("vcs", { exposures: vcsResult.findings || [], meta: vcsResult.meta || null });

        // ── Phase 5 (slowest, most flaky): certificate-transparency ──
        const ctResult = await enumerateSubdomains(host).catch(() => ({
          subdomains: [], sources: [], degraded: true
        }));
        const ctSubs = ctResult.subdomains || [];
        if (ctSubs.length) {
          const subSet = new Set(d.subdomains || []);
          ctSubs.forEach((s) => subSet.add(s));
          d.subdomains = [...subSet].sort().slice(0, 500);
          d.ctSubdomains = ctSubs;
        }
        d.ctMeta = { sources: ctResult.sources || [], degraded: !!ctResult.degraded };
        post("ct", {
          subdomains: d.subdomains || [],
          ctSubdomains: ctSubs,
          meta: d.ctMeta
        });
      }

      // De-dupe aggregated exposures for the final payload.
      const seen = new Set();
      const deduped = aggregate.exposures
        .sort((a, b) => (SEVERITY_WEIGHT[b.severity] || 0) - (SEVERITY_WEIGHT[a.severity] || 0))
        .filter((e) => {
          const k = (e.id || e.title) + "|" + (e.url || "");
          if (seen.has(k)) return false;
          seen.add(k);
          return true;
        });
      d.exposures = deduped;
      persistTabs();

      port.postMessage({
        type: "DONE",
        origin,
        findings: aggregate.findings,
        exposures: deduped,
        wordpress: d.wordpress || null,
        vcs: d.vcs || null,
        ctSubdomains: d.ctSubdomains || [],
        ctMeta: d.ctMeta || null,
        subdomains: d.subdomains || [],
        supplyChain: d.supplyChain || null
      });
    } catch (err) {
      try { port.postMessage({ type: "ERROR", error: String(err && err.message || err) }); } catch (_) {}
    }
  });
});

