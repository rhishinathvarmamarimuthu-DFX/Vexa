// ReconHound — Popup UI controller

let lastReport = null;
let currentTab = null;
let prevSigs = new Set();  // signatures from the last saved snapshot, for delta highlight

// Mirror of history.js signature helpers — kept in sync when history schema changes.
function sigFor(kind, f) {
  switch (kind) {
    case "tech": return `tech:${f.tech}@${f.version || "?"}`;
    case "cve": return `cve:${f.id}`;
    case "security": return `sec:${f.title}`;
    case "secret": return `key:${f.id}:${f.match}`;
    case "exposure": return `exp:${f.id || f.title}`;
    case "endpoint": return `ep:${f.path}`;
    default: return `${kind}:${JSON.stringify(f)}`;
  }
}
function isNew(kind, item) {
  if (!prevSigs || !prevSigs.size) return false;
  return !prevSigs.has(sigFor(kind, item));
}

// Matrix-rain intro splash — plays briefly on open, then fades out.
function runMatrixSplash() {
  const canvas = document.getElementById("matrix");
  if (!canvas) return;
  const ctx = canvas.getContext("2d");
  const W = (canvas.width = 380);
  const H = (canvas.height = Math.max(380, document.body.scrollHeight || 480));
  const chars = "01░▒▓<>/\\{}[]#$%&*ｱｲｳｴｵｶｷｸ".split("");
  const fontSize = 13;
  const cols = Math.floor(W / fontSize);
  const drops = Array(cols).fill(0).map(() => Math.random() * -20);

  let frames = 0;
  const maxFrames = 60; // ~1.6s at ~37fps
  function draw() {
    ctx.fillStyle = "rgba(5,8,7,0.18)";
    ctx.fillRect(0, 0, W, H);
    ctx.fillStyle = "#00ff8c";
    ctx.font = fontSize + "px monospace";
    for (let i = 0; i < cols; i++) {
      const ch = chars[(Math.random() * chars.length) | 0];
      const x = i * fontSize;
      const y = drops[i] * fontSize;
      ctx.shadowColor = "#00ff8c";
      ctx.shadowBlur = 6;
      ctx.fillText(ch, x, y);
      if (y > H && Math.random() > 0.975) drops[i] = 0;
      drops[i] += 0.7;
    }
    frames++;
    if (frames < maxFrames) {
      requestAnimationFrame(draw);
    } else {
      canvas.classList.add("fade");
      setTimeout(() => canvas.remove(), 800);
    }
  }
  draw();
}

async function init() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  currentTab = tab;
  // Fire-and-forget: fetch the last snapshot's signatures for this host so
  // we can flash "new since last snapshot" on findings as they render.
  chrome.runtime.sendMessage({ type: "RH_GET_PREV_SIGS", url: tab.url }, (res) => {
    if (res && res.prevSigs) prevSigs = new Set(res.prevSigs);
  });
  // Context-menu selection → JWT analysis handoff.
  try {
    const stored = await chrome.storage.session.get("rh_pending_jwt");
    if (stored && stored.rh_pending_jwt) {
      await chrome.storage.session.remove("rh_pending_jwt");
      // Delay slightly so the KEYS panel exists.
      setTimeout(() => analyzeSelectionAsJwt(stored.rh_pending_jwt), 800);
    }
  } catch (_) {}
  const stackPanel = document.getElementById("stack");
  const securityPanel = document.getElementById("security");
  const urlEl = document.getElementById("url");
  const secCount = document.getElementById("secCount");

  // Show the target URL immediately, regardless of scan result.
  urlEl.textContent = tab.url || "unknown target";

  // Guard against a restricted page where we can't scan.
  if (/^(chrome|edge|about|chrome-extension|view-source|devtools):/i.test(tab.url || "")) {
    stackPanel.innerHTML = `<p class="empty">// cannot scan browser/system pages — open a normal http(s) site</p>`;
    wireUi(tab);
    return;
  }

  chrome.runtime.sendMessage({ type: "RH_ENSURE", tabId: tab.id, url: tab.url }, (report) => {
    if (chrome.runtime.lastError) {
      stackPanel.innerHTML = `<p class="empty">// engine error: ${chrome.runtime.lastError.message}<br/>try reloading the page</p>`;
      return;
    }
    lastReport = report || { tech: [], security: [] };
    urlEl.textContent = lastReport.url || tab.url;

    renderRisk(lastReport.risk);
    renderBrain(lastReport.brain);

    // Tech stack
    const cspBanner = lastReport.cspBlocked
      ? `<div class="csp-warning">
           <b>⚠ page-world probe blocked</b> — this target has a strict
           Content-Security-Policy that dropped the inline detection script.
           Fingerprinting continues via response headers, resource URLs and DOM
           markers, but framework runtime versions (React.version, jQuery.fn.jquery,
           …) may be missing.
         </div>`
      : "";
    const autoBypassBanner = renderAutoBypassBanner(lastReport);
    if (!lastReport.tech?.length) {
      stackPanel.innerHTML = autoBypassBanner + cspBanner + `<p class="empty">// no technologies detected — reload target</p>`;
    } else {
      stackPanel.innerHTML = autoBypassBanner + cspBanner + lastReport.tech.map(renderTech).join("");
    }

    // Security findings
    const findings = lastReport.security || [];
    secCount.textContent = String(findings.length);
    securityPanel.innerHTML = findings.length
      ? findings.map(renderFinding).join("")
      : `<p class="empty">// no security findings</p>`;

    // Secret + JWT findings
    const secrets = lastReport.secrets || [];
    const jwts = lastReport.jwts || [];
    document.getElementById("secretCount").textContent = String(secrets.length + jwts.length);
    const jwtBlock = jwts.length
      ? `<div class="section-label">decoded JWTs (${jwts.length})</div>` + jwts.map(renderJwt).join("")
      : "";
    const secretBlock = secrets.length
      ? `<div class="section-label">credential detections (${secrets.length})</div>` + secrets.map(renderSecret).join("")
      : "";
    document.getElementById("secrets").innerHTML =
      (jwtBlock + secretBlock) || `<p class="empty">// no secrets or JWTs detected</p>`;

    // Extracted endpoints
    const endpoints = lastReport.endpoints || [];
    document.getElementById("endpointCount").textContent = String(endpoints.length);
    document.getElementById("endpoints").innerHTML = endpoints.length
      ? endpoints.map(renderEndpoint).join("")
      : `<p class="empty">// no routes extracted — reload to deep-scan scripts</p>`;

    // Recon: subdomains + params + CT-log subs + supply-chain inventory
    renderRecon(
      lastReport.subdomains || [],
      lastReport.params || [],
      lastReport.ctSubdomains || [],
      lastReport.supplyChain || null,
      lastReport.ctMeta || null
    );

    // Attack-chain correlation
    renderChains(lastReport.attackChains || []);
    // XSS surface (defence posture + reflections by context + sinks + pm)
    renderXssSurface(lastReport.xssSurface);

    // Detection is shown instantly above. Now load CVE + exploit-intel in the
    // background (NVD/KEV/EPSS) and refresh the affected panels when ready.
    if (lastReport.partial) {
      document.getElementById("brain").innerHTML = `<p class="empty">// 🧠 analyzing exploit intelligence (NVD · KEV · EPSS)…</p>`;
      loadCveIntel();
    }
  });

  wireUi(tab);
}

// Background load of full CVE + brain data; refreshes stack, brain and risk.
function loadCveIntel() {
  chrome.runtime.sendMessage({ type: "RH_GET_FULL", tabId: currentTab.id }, (full) => {
    if (chrome.runtime.lastError || !full) return;
    lastReport = full;
    renderRisk(full.risk);
    renderBrain(full.brain);
    const stackPanel = document.getElementById("stack");
    const cspBanner = full.cspBlocked
      ? `<div class="csp-warning"><b>⚠ page-world probe blocked (CSP)</b> — runtime versions may be missing.</div>`
      : "";
    const autoBypassBanner = renderAutoBypassBanner(full);
    if (full.tech?.length) stackPanel.innerHTML = autoBypassBanner + cspBanner + full.tech.map(renderTech).join("");
    // Chains recompute after CVE/outdated enrichment lands.
    renderChains(full.attackChains || []);
    renderXssSurface(full.xssSurface);
  });
}

// ─── XSS attack-surface panel ────────────────────────────────────────
// Shows: defence posture grade, reflected params by context, DOM sinks,
// postMessage listeners, sanitizers detected. All discovery-only — the
// operator hands off to a dedicated XSS-verification tool for confirmation.
function renderXssSurface(surface) {
  const panel = document.getElementById("xss");
  const badge = document.getElementById("xssCount");
  if (!panel) return;
  if (!surface) {
    if (badge) badge.textContent = "?";
    panel.innerHTML = `<p class="empty">// no XSS surface analysis yet — reload the target or run active scan</p>`;
    return;
  }
  const reflections = surface.reflections || [];
  const sinks = surface.sinks || [];
  const pmListeners = surface.postMessageListeners || [];
  const headerFindings = surface.headerFindings || [];
  const sanitizers = surface.sanitizers || [];
  const defence = surface.defence || { score: 0, grade: "?" };
  const total = reflections.length + sinks.length + pmListeners.length;
  if (badge) badge.textContent = String(total);

  const gradeCls = "g-" + (defence.grade === "A+" ? "Aplus" : defence.grade);
  const reflHtml = reflections.length
    ? reflections.map((r) => `
        <div class="xss-refl sev-${r.worstSeverity}">
          <div class="xss-refl-top">
            <b>${escapeHtml(r.param)}</b>
            <span class="badge sev-${r.worstSeverity}">${r.worstSeverity}</span>
            <span class="muted">×${r.reflections}${r.encoded ? " · partial encoding" : ""}</span>
          </div>
          <div class="xss-refl-ctx">
            ${[...new Set(r.contexts)].map((c) => `<span class="chip xss-ctx-${c}">${escapeHtml(c)}</span>`).join("")}
          </div>
          <div class="muted"><a href="${safeHref(r.url)}" target="_blank" rel="noreferrer noopener">${escapeHtml(shortenForDisplay(r.url))}</a></div>
        </div>`).join("")
    : `<p class="muted">// no reflected parameters found (scan URL had none, or none reflect)</p>`;

  const sinkHtml = sinks.length
    ? sinks.map((s) => `
        <div class="xss-sink sev-${s.severity}">
          <b>${escapeHtml(s.vector)}</b>
          <span class="badge sev-${s.severity}">${s.severity}</span>
          <span class="muted">${escapeHtml(s.name)} · ${s.count}× occurrence${s.count !== 1 ? "s" : ""}</span>
          ${s.samples?.length
            ? `<details><summary class="muted">show samples</summary>${s.samples.map((x) => `<div class="xss-sample">${escapeHtml(x)}</div>`).join("")}</details>`
            : ""}
        </div>`).join("")
    : `<p class="muted">// no DOM sinks detected in inline scripts</p>`;

  const pmHtml = pmListeners.length
    ? pmListeners.map((l) => `
        <div class="xss-pm sev-${l.risk}">
          <span class="badge sev-${l.risk}">${l.risk}</span>
          origin-check: <b>${l.hasOriginCheck ? "yes" : "NO"}</b>
          <div class="xss-sample muted">${escapeHtml(l.preview || "")}</div>
        </div>`).join("")
    : `<p class="muted">// no postMessage listeners detected</p>`;

  const hdrHtml = headerFindings.length
    ? headerFindings.map((h) => `
        <div class="xss-hdr sev-${h.severity}">
          <span class="badge sev-${h.severity}">${h.severity}</span>
          <b>${escapeHtml(h.title)}</b>
          <div class="muted">${escapeHtml(h.detail)}</div>
        </div>`).join("")
    : "";

  const sanHtml = sanitizers.length
    ? sanitizers.map((s) => `<span class="chip xss-san">${escapeHtml(s.name)}</span>`).join("")
    : `<span class="muted">// no sanitizer libraries detected</span>`;

  panel.innerHTML = `
    <div class="xss-header">
      <div class="grade ${gradeCls}">${escapeHtml(defence.grade)}</div>
      <div>
        <div class="xss-score">XSS-DEFENCE POSTURE · <b>${defence.score}/100</b></div>
        <div class="muted">consolidated from CSP, headers, framework, sanitizers, and observed surface</div>
      </div>
    </div>
    <div class="section-label">sanitizer / defence libraries in scope</div>
    <div>${sanHtml}</div>
    ${hdrHtml ? `<div class="section-label">defence-header findings</div>${hdrHtml}` : ""}
    <div class="section-label">reflected parameters by output context (${reflections.length})</div>
    ${reflHtml}
    <div class="section-label">DOM-XSS sinks (${sinks.length})</div>
    ${sinkHtml}
    <div class="section-label">postMessage listeners (${pmListeners.length})</div>
    ${pmHtml}
    <div class="xss-footer muted">
      // discovery only — for verification, use the "XSS-tool handoff" export ⤴
      to feed these targets into your XSS-verification tool of choice.
    </div>`;
}

function shortenForDisplay(u) {
  try {
    const url = new URL(u);
    const p = url.pathname + url.search;
    return url.host + (p.length > 60 ? p.slice(0, 60) + "…" : p);
  } catch { return String(u).slice(0, 80); }
}

function renderAutoBypassBanner(report) {
  const hits = (report && report.autoBypassFindings) || [];
  const telemetry = (report && report.autoBypassTelemetry) || [];
  // Prefer hits — biggest signal.
  if (hits.length) {
    const first = hits[0];
    const others = hits.length > 1 ? ` <span class="muted">(+${hits.length - 1} more)</span>` : "";
    return `<div class="auto-bypass-banner hit">
      <div class="ab-title">🎯 AUTO-BYPASS SUCCEEDED — ${hits.length} finding${hits.length > 1 ? "s" : ""}${others}</div>
      <div class="ab-body">
        <b>${escapeHtml(first.title || "")}</b><br/>
        <span class="muted">technique:</span> <code>${escapeHtml(first.technique || "?")}</code>
        ${first.waf ? ` · <span class="muted">WAF:</span> ${escapeHtml(first.waf.name)}` : ""}
        ${first.verificationScore ? ` · <span class="muted">verified:</span> ${escapeHtml(first.verificationScore)}` : ""}
        ${first.preview ? `<div class="ab-preview">${escapeHtml(first.preview)}${first.preview.length >= 200 ? " …" : ""}</div>` : ""}
        <div class="muted" style="margin-top:4px">see EXPLOIT tab for full details</div>
      </div>
    </div>`;
  }
  // No hits but we tried — show what happened.
  if (telemetry.length) {
    const tried = telemetry.reduce((n, t) => n + (t.telemetry?.variantsTried || 0), 0);
    const paths = new Set(telemetry.map((t) => {
      try { return new URL(t.url).pathname; } catch { return t.url; }
    }));
    if (!tried) return "";
    return `<div class="auto-bypass-banner miss">
      <div class="ab-title">⚡ AUTO-BYPASS ran on ${telemetry.length} 4xx response${telemetry.length > 1 ? "s" : ""}</div>
      <div class="ab-body">
        <span class="muted">Detected 4xx on: ${[...paths].slice(0, 3).map(escapeHtml).join(", ")}${paths.size > 3 ? "…" : ""}</span><br/>
        <span class="muted">Tried ${tried} technique variants — no bypass found. See EXPLOIT tab for per-variant rejection log.</span>
      </div>
    </div>`;
  }
  return "";
}

function renderChains(chains) {
  const panel = document.getElementById("chains");
  const badge = document.getElementById("chainCount");
  if (badge) badge.textContent = String(chains.length);
  if (!chains.length) {
    panel.innerHTML = `<p class="empty">// no multi-stage attack chains correlated — deeper findings may unlock more</p>`;
    return;
  }
  panel.innerHTML = chains.map(renderChain).join("");
}

function renderChain(c) {
  const stages = c.stages || [];
  const evidence = (c.evidence || []).slice(0, 8)
    .map((e) => `<span class="chip">${escapeHtml(String(e))}</span>`).join("");

  // ─── SVG kill-chain diagram ─────────────────────────────────────────
  const NODE_W = 320, NODE_H_BASE = 46, GAP_Y = 24;
  const nodeHeights = stages.map((s) => Math.max(NODE_H_BASE, 24 + Math.ceil(s.length / 46) * 16));
  const rowYs = [];
  let cursorY = 12;
  for (const h of nodeHeights) { rowYs.push(cursorY); cursorY += h + GAP_Y; }
  const svgH = cursorY + 8;
  const svgW = NODE_W + 40;

  const sevClass = "sev-" + c.severity;
  const seed = chainSeed(c);
  const useGlow = c.severity === "CRITICAL" || c.severity === "HIGH";
  const defs = `
    ${useGlow ? `<filter id="glow-${seed}" x="-20%" y="-20%" width="140%" height="140%">
       <feGaussianBlur stdDeviation="2.5" result="b"/>
       <feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge>
     </filter>` : ""}
    <marker id="arr-${seed}" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="6" markerHeight="6" orient="auto">
      <path d="M0,0 L10,5 L0,10 Z" fill="currentColor"/>
    </marker>`;

  const nodesSvg = stages.map((s, i) => {
    const y = rowYs[i];
    const h = nodeHeights[i];
    const num = String(i + 1).padStart(2, "0");
    const wrapped = wrapText(s, 44, y + 22, NODE_W - 34, 14);
    return `<g class="chain-node ${sevClass}" ${useGlow ? `filter="url(#glow-${seed})"` : ""}>
      <rect x="20" y="${y}" width="${NODE_W}" height="${h}" rx="6" ry="6" class="node-box"/>
      <text x="34" y="${y + 22}" class="node-num">${num}</text>
      ${wrapped}
    </g>`;
  }).join("");

  const arrowsSvg = stages.slice(0, -1).map((_, i) => {
    const y1 = rowYs[i] + nodeHeights[i];
    const y2 = rowYs[i + 1];
    const midX = 20 + NODE_W / 2;
    return `<path d="M${midX},${y1} L${midX},${y2 - 2}" class="chain-arrow ${sevClass}" marker-end="url(#arr-${seed})"/>`;
  }).join("");

  const svg = `<svg viewBox="0 0 ${svgW} ${svgH}" width="100%" preserveAspectRatio="xMidYMin meet" class="chain-svg ${sevClass}">
    <defs>${defs}</defs>
    ${arrowsSvg}
    ${nodesSvg}
  </svg>`;

  return `
    <div class="chain-card sev-${c.severity}">
      <div class="chain-title">
        ${escapeHtml(c.title)}
        <span class="badge sev-${c.severity}">${escapeHtml(c.severity)}</span>
      </div>
      ${svg}
      <div class="chain-impact"><b>Impact:</b> ${escapeHtml(c.impact || "")}</div>
      ${evidence ? `<div class="chain-impact" style="margin-top:6px"><b>Evidence:</b> <span class="chips">${evidence}</span></div>` : ""}
    </div>`;
}

function chainSeed(c) {
  const s = String(c.id || c.title || "");
  let h = 0;
  for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) | 0;
  return "c" + Math.abs(h).toString(36).slice(0, 6);
}

function wrapText(text, x, y, widthPx, lineHeight) {
  const maxChars = Math.floor(widthPx / 6.2);
  const words = String(text).split(/\s+/);
  const lines = [];
  let cur = "";
  for (const w of words) {
    if ((cur + " " + w).trim().length > maxChars && cur) { lines.push(cur); cur = w; }
    else cur = (cur ? cur + " " : "") + w;
  }
  if (cur) lines.push(cur);
  return lines.map((ln, i) =>
    `<text x="${x}" y="${y + i * lineHeight}" class="node-text">${escapeHtml(ln)}</text>`
  ).join("");
}

function wireUi(tab) {
  // Tab switching
  document.querySelectorAll(".tab").forEach((btn) => {
    btn.addEventListener("click", () => {
      document.querySelectorAll(".tab").forEach((b) => b.classList.remove("active"));
      document.querySelectorAll(".panel").forEach((p) => p.classList.remove("active"));
      btn.classList.add("active");
      document.getElementById(btn.dataset.tab).classList.add("active");
      if (btn.dataset.tab === "history") loadHistory();
    });
  });

  document.getElementById("saveSnap").addEventListener("click", () => {
    chrome.runtime.sendMessage({ type: "RH_SAVE_SNAPSHOT", tabId: currentTab.id }, () => loadHistory());
  });

  // Active-scan consent + run.
  //  · If the global "I only scan authorized targets" toggle is on → checkbox
  //    is hidden and EXECUTE is enabled immediately.
  //  · Otherwise: remembered per-host so you confirm each domain only once.
  const authConfirm = document.getElementById("authConfirm");
  const authRow = document.getElementById("authRow");
  const runActive = document.getElementById("runActive");
  const host = (() => { try { return new URL(tab.url).host; } catch { return ""; } })();
  chrome.storage.local.get({ authorizedHosts: [], globalAuth: false }, ({ authorizedHosts, globalAuth }) => {
    if (globalAuth) {
      if (authRow) authRow.style.display = "none";
      authConfirm.checked = true;
      runActive.disabled = false;
      return;
    }
    if (host && authorizedHosts.includes(host)) {
      authConfirm.checked = true;
      runActive.disabled = false;
    }
  });
  authConfirm.addEventListener("change", () => {
    runActive.disabled = !authConfirm.checked;
    if (host) {
      chrome.storage.local.get({ authorizedHosts: [] }, ({ authorizedHosts }) => {
        const set = new Set(authorizedHosts);
        if (authConfirm.checked) set.add(host); else set.delete(host);
        chrome.storage.local.set({ authorizedHosts: [...set] });
      });
    }
  });
  runActive.addEventListener("click", runActiveScan);

  document.getElementById("export").addEventListener("click", exportJson);
  document.getElementById("exportHtml").addEventListener("click", exportHtml);
  document.getElementById("settings").addEventListener("click", () => chrome.runtime.openOptionsPage());

  // Handoff export dropdown
  const menuBtn = document.getElementById("exportMenuBtn");
  const menuPanel = document.getElementById("exportMenuPanel");
  if (menuBtn && menuPanel) {
    menuBtn.addEventListener("click", (e) => {
      e.stopPropagation();
      menuPanel.classList.toggle("open");
    });
    document.addEventListener("click", () => menuPanel.classList.remove("open"));
    menuPanel.querySelectorAll("button[data-export]").forEach((btn) => {
      btn.addEventListener("click", (e) => {
        e.stopPropagation();
        const kind = btn.getAttribute("data-export");
        if (kind === "nuclei")     exportNuclei();
        if (kind === "metasploit") exportMetasploit();
        if (kind === "markdown")   exportMarkdown();
        if (kind === "sarif")      exportSarif();
        if (kind === "bulk")       runBulkScan();
        if (kind === "xss-handoff") exportXssHandoff();
        menuPanel.classList.remove("open");
      });
    });
  }
  const openSettings = document.getElementById("openSettings");
  if (openSettings) openSettings.addEventListener("click", (e) => {
    e.preventDefault();
    chrome.runtime.openOptionsPage();
  });

  // Data-source health strip in the footer. Poll every 3 s while the popup
  // is open so the operator can see when NVD / KEV / crt.sh degrade.
  refreshSourceStatus();
  const statusTimer = setInterval(refreshSourceStatus, 3000);
  window.addEventListener("unload", () => clearInterval(statusTimer));

  // ─── Live watch mode ────────────────────────────────────────────────
  // Poll the target's report every 15 s. Any finding that wasn't in the
  // previous snapshot flashes with the .rh-new animation + NEW tag so the
  // operator can see changes in real time. Toggle-able via the header.
  startWatchMode();
}

let watchTimer = null;
let watchPrevSigs = new Set();

function startWatchMode() {
  const toggle = document.getElementById("watchToggle");
  if (!toggle) return;
  chrome.storage.local.get({ enableWatchMode: false }, ({ enableWatchMode }) => {
    toggle.checked = !!enableWatchMode;
    if (enableWatchMode) beginPolling();
  });
  toggle.addEventListener("change", () => {
    chrome.storage.local.set({ enableWatchMode: toggle.checked });
    if (toggle.checked) beginPolling();
    else stopPolling();
  });
}
function beginPolling() {
  stopPolling();
  // Seed the "previous" set with the current report's signatures so we only
  // flash *future* changes, not the initial paint.
  watchPrevSigs = collectSignatures(lastReport);
  // Visual indicator
  const badge = document.getElementById("watchBadge");
  if (badge) badge.classList.add("active");
  watchTimer = setInterval(async () => {
    if (!currentTab) return;
    try {
      // Force a fresh scan on the target, then diff.
      chrome.runtime.sendMessage(
        { type: "RH_ENSURE", tabId: currentTab.id, url: currentTab.url },
        () => {
          chrome.runtime.sendMessage(
            { type: "RH_GET_FULL", tabId: currentTab.id },
            (report) => {
              if (chrome.runtime.lastError || !report) return;
              const nowSigs = collectSignatures(report);
              const newOnes = [...nowSigs].filter((s) => !watchPrevSigs.has(s));
              if (newOnes.length) {
                // Repaint using nowSigs as the "prev" so isNew() marks the new items.
                prevSigs = watchPrevSigs;
                lastReport = report;
                repaintAll(report);
                flashWatchBadge(newOnes.length);
              }
              watchPrevSigs = nowSigs;
            }
          );
        }
      );
    } catch (_) { /* keep polling regardless */ }
  }, 15000);
}
function stopPolling() {
  if (watchTimer) { clearInterval(watchTimer); watchTimer = null; }
  const badge = document.getElementById("watchBadge");
  if (badge) badge.classList.remove("active");
}
function flashWatchBadge(n) {
  const badge = document.getElementById("watchBadge");
  if (!badge) return;
  badge.textContent = "+" + n;
  badge.classList.add("burst");
  setTimeout(() => badge.classList.remove("burst"), 3000);
  setTimeout(() => { badge.textContent = ""; }, 6000);
}
function collectSignatures(report) {
  const s = new Set();
  if (!report) return s;
  (report.tech || []).forEach((t) => s.add(sigFor("tech", t)));
  (report.tech || []).forEach((t) => (t.cves || []).forEach((c) => s.add(sigFor("cve", c))));
  (report.security || []).forEach((f) => s.add(sigFor("security", f)));
  (report.secrets || []).forEach((f) => s.add(sigFor("secret", f)));
  (report.exposures || []).forEach((f) => s.add(sigFor("exposure", f)));
  (report.endpoints || []).forEach((f) => s.add(sigFor("endpoint", f)));
  return s;
}
function repaintAll(r) {
  const stackPanel = document.getElementById("stack");
  const secPanel = document.getElementById("security");
  const cspBanner = r.cspBlocked
    ? `<div class="csp-warning"><b>⚠ page-world probe blocked (CSP)</b></div>` : "";
  const autoBypassBanner = renderAutoBypassBanner(r);
  if (r.tech?.length) stackPanel.innerHTML = autoBypassBanner + cspBanner + r.tech.map(renderTech).join("");
  secPanel.innerHTML = (r.security || []).map(renderFinding).join("") || `<p class="empty">// none</p>`;
  document.getElementById("secretCount").textContent = String((r.secrets || []).length + (r.jwts || []).length);
  document.getElementById("secrets").innerHTML =
    ((r.jwts || []).map(renderJwt).join("") + (r.secrets || []).map(renderSecret).join(""))
    || `<p class="empty">// none</p>`;
  document.getElementById("endpointCount").textContent = String((r.endpoints || []).length);
  document.getElementById("endpoints").innerHTML = (r.endpoints || []).map(renderEndpoint).join("")
    || `<p class="empty">// none</p>`;
  renderRecon(r.subdomains || [], r.params || [], r.ctSubdomains || [], r.supplyChain || null, r.ctMeta || null);
  renderChains(r.attackChains || []);
  renderRisk(r.risk);
  renderBrain(r.brain);
}

const SOURCE_LABELS = {
  nvd:         "NVD",
  kev:         "KEV",
  epss:        "EPSS",
  crtsh:       "crt.sh",
  certspotter: "certspot",
  endoflife:   "EOL",
  npm:         "npm",
  wpcore:      "WP"
};
function refreshSourceStatus() {
  chrome.runtime.sendMessage({ type: "RH_GET_SOURCE_STATUS" }, (s) => {
    if (chrome.runtime.lastError || !s) return;
    const box = document.getElementById("sourceStatus");
    if (!box) return;
    const dots = Object.entries(SOURCE_LABELS).map(([k, label]) => {
      const entry = s[k] || {};
      const cls = entry.ok === true ? "ok"
                : entry.ok === false ? "down"
                : "unknown";
      const title = entry.ok === false
        ? `${label} unreachable — ${entry.lastError || "no data"}`
        : entry.ok === true
        ? `${label} healthy`
        : `${label} not yet contacted`;
      return `<span class="src-dot ${cls}" title="${escapeHtml(title)}">${escapeHtml(label)}</span>`;
    }).join("");
    box.innerHTML = dots;
  });
}

const PHASE_LABELS = {
  paths: "sensitive-path probe",
  exposures: "VCS / env / backup exposure",
  sourcemaps: "source-map exposure",
  graphql: "GraphQL introspection",
  reflect: "reflected-input canary",
  bypass: "40x access-control bypass",
  webapp: "framework / actuator / API-docs",
  wordpress: "WordPress deep audit",
  vcs: "Git / SVN structural parse",
  wellknown: ".well-known / OIDC discovery",
  dns: "DNS / SPF / DMARC / DKIM",
  wayback: "Wayback Machine historical URLs",
  ct: "certificate-transparency subs"
};

function runActiveScan() {
  const runActive = document.getElementById("runActive");
  const out = document.getElementById("activeResults");
  runActive.disabled = true;
  runActive.textContent = "⏳ EXECUTING…";

  const phaseState = {}; // phase → 'running' | 'done'
  const startedPhases = [];
  const aggregatedExposures = [];
  let paths = [];

  const renderProgress = () => {
    const lines = startedPhases.map((p) => {
      const state = phaseState[p] || "pending";
      const icon = state === "done" ? "✓" : state === "running" ? "⏳" : "·";
      return `<div class="phase-row ${state}">${icon} ${PHASE_LABELS[p] || p}</div>`;
    }).join("");

    // WAF fingerprint banner (shown once bypass phase reports)
    const waf = lastReport && lastReport.waf;
    const wafBanner = waf && waf.primary
      ? `<div class="waf-banner">
           <b>WAF detected:</b> ${escapeHtml(waf.primary.name)}
           ${waf.detected && waf.detected.length > 1
             ? ` <span class="muted">(also: ${waf.detected.slice(1).map((d) => escapeHtml(d.name)).join(", ")})</span>`
             : ""}
           <div class="muted" style="margin-top:2px">bypass techniques prioritised for this vendor</div>
         </div>`
      : (phaseState.bypass === "done" && lastReport && lastReport.bypassTelemetry
         ? `<div class="waf-banner neutral">
              <b>WAF fingerprint:</b> none matched — using default technique ordering.
              ${renderBypassTelemetry(lastReport.bypassTelemetry)}
            </div>`
         : "");

    const exposuresHtml = aggregatedExposures.length
      ? `<div class="section-label">verified exposures (${aggregatedExposures.length})</div>` +
        aggregatedExposures.map(renderExposure).join("")
      : "";
    const pathsHtml = paths.length
      ? `<div class="section-label">reachable paths (${paths.length})</div>` + paths.map(renderPathHit).join("")
      : "";
    out.innerHTML = `<div class="phase-list">${lines}</div>` + wafBanner + exposuresHtml + pathsHtml;
  };

  function renderBypassTelemetry(t) {
    if (!t) return "";
    const seedInfo = (t.seedProbed || 0) > 0
      ? `<div class="muted">· seeded ${t.seedProbed} common paths → ${t.seedHit4xx} returned 4xx${t.seedBlackHole404 ? `, ${t.seedBlackHole404} matched black-hole 404 fingerprint` : ""}</div>`
      : "";
    const passiveInfo = `<div class="muted">· passive prober contributed ${t.passiveCandidates || 0} 4xx path(s)</div>`;
    const fpInfo = t.siteFingerprint
      ? `<div class="muted">· site 404 fingerprint: ${t.siteFingerprint.notFound ? `HTTP ${t.siteFingerprint.notFound.status}, ${t.siteFingerprint.notFound.bodyLen}B` : "unavailable"} · homepage: ${t.siteFingerprint.home ? `HTTP ${t.siteFingerprint.home.status}, ${t.siteFingerprint.home.bodyLen}B` : "unavailable"}</div>`
      : "";
    const totalCandidates = (t.passiveCandidates || 0) + (t.activeCandidates || 0);
    if (!totalCandidates) {
      return `<div class="bypass-telemetry">
        ${seedInfo}${passiveInfo}${fpInfo}
        <div class="muted">· no 4xx candidates on this target — nothing to bypass</div>
      </div>`;
    }
    const tried = t.variantsTried || 0;
    const hits = t.verifiedBypasses || t.variantsSuccess || 0;
    const perUrl = (t.perUrl || []).map((u) => {
      if (u.skipped) return `<div class="muted">· ${escapeHtml(u.path || "?")}: skipped (${escapeHtml(u.skipped)})</div>`;
      const protection = u.baseline?.protectionKind
        ? ` <span class="chip" style="font-size:8px">${escapeHtml(u.baseline.protectionKind)}</span>`
        : "";
      const summary = `<div class="muted">· <b>${escapeHtml(u.path || "?")}</b>${protection}: ${u.tried} tried, ${u.hits.length} hit${u.rejected?.length ? `, ${u.rejected.length} rejected (see below)` : ""}</div>`;
      // Diagnostic per-variant log — collapsible <details>
      const rejectedRows = (u.rejected || []).slice(0, 20).map((r) =>
        `<div class="rej-row"><span class="rej-tech">${escapeHtml(r.label || r.id || "?")}</span> <span class="chip" style="font-size:8px">${escapeHtml(r.kind || "?")}</span> → <span class="rej-why">${escapeHtml(r.why || "?")}</span>${r.status ? ` <span class="muted">(HTTP ${r.status}${r.bodyLen ? `, ${r.bodyLen}B` : ""})</span>` : ""}</div>`
      ).join("");
      const details = u.rejected && u.rejected.length
        ? `<details class="rej-details"><summary>show rejected variants (${u.rejected.length})</summary>${rejectedRows}</details>`
        : "";
      return summary + details;
    }).join("");
    return `<div class="bypass-telemetry">
      ${seedInfo}${passiveInfo}${fpInfo}
      <div class="muted">· ${tried} variant(s) across ${t.urlsTested || 0} URL(s) → <b>${hits} verified bypass(es)</b></div>
      ${perUrl}
    </div>`;
  }

  const port = chrome.runtime.connect({ name: "rh-active-scan" });
  port.postMessage({
    type: "START",
    tabId: currentTab.id,
    url: lastReport?.url || currentTab.url
  });

  port.onMessage.addListener((msg) => {
    if (msg.type === "PHASE" && msg.phase === "started") {
      msg.phases.forEach((p) => {
        startedPhases.push(p);
        phaseState[p] = "running";
      });
      renderProgress();
      return;
    }
    if (msg.type === "PHASE") {
      phaseState[msg.phase] = "done";
      if (msg.exposures) aggregatedExposures.push(...msg.exposures);
      if (msg.findings) paths = msg.findings;
      if (msg.phase === "bypass" && lastReport) {
        lastReport.waf = msg.waf || null;
        lastReport.bypassTelemetry = msg.telemetry || null;
      }
      if (msg.phase === "ct" && lastReport) {
        if (msg.subdomains) lastReport.subdomains = msg.subdomains;
        if (msg.ctSubdomains) lastReport.ctSubdomains = msg.ctSubdomains;
        if (msg.meta) lastReport.ctMeta = msg.meta;
        renderRecon(
          lastReport.subdomains || [],
          lastReport.params || [],
          lastReport.ctSubdomains || [],
          lastReport.supplyChain || null,
          lastReport.ctMeta || null
        );
      }
      renderProgress();
      return;
    }
    if (msg.type === "DONE") {
      runActive.disabled = false;
      runActive.textContent = "⚡ EXECUTE ACTIVE SCAN";
      if (lastReport) {
        lastReport.activeScan = msg.findings;
        lastReport.exposures = msg.exposures || [];
        if (msg.subdomains) lastReport.subdomains = msg.subdomains;
        if (msg.ctSubdomains) lastReport.ctSubdomains = msg.ctSubdomains;
        if (msg.ctMeta) lastReport.ctMeta = msg.ctMeta;
        if (msg.supplyChain) lastReport.supplyChain = msg.supplyChain;
        renderRecon(
          lastReport.subdomains || [],
          lastReport.params || [],
          lastReport.ctSubdomains || [],
          lastReport.supplyChain || null,
          lastReport.ctMeta || null
        );
      }
      // Use the deduped final payload for the display.
      aggregatedExposures.length = 0;
      aggregatedExposures.push(...(msg.exposures || []));
      paths = msg.findings || [];
      renderProgress();
      refreshReport(); // recompute risk grade with new exposures
      try { port.disconnect(); } catch (_) {}
      return;
    }
    if (msg.type === "ERROR") {
      runActive.disabled = false;
      runActive.textContent = "⚡ EXECUTE ACTIVE SCAN";
      out.innerHTML = `<p class="empty">// scan error: ${escapeHtml(msg.error || "unknown")}</p>`;
      try { port.disconnect(); } catch (_) {}
    }
  });

  port.onDisconnect.addListener(() => {
    if (runActive.disabled) {
      runActive.disabled = false;
      runActive.textContent = "⚡ EXECUTE ACTIVE SCAN";
    }
  });
}

function renderExposure(e) {
  const fresh = isNew("exposure", e);
  const isBypass = typeof e.id === "string" && e.id.startsWith("bypass-40x-");
  const bypassExtra = isBypass
    ? `<div class="bypass-preview">
         <div class="bypass-preview-label">
           technique: <b>${escapeHtml(e.technique || "?")}</b>
           ${e.techniqueKind ? `<span class="chip">${escapeHtml(e.techniqueKind)}</span>` : ""}
           ${e.verificationScore ? `<span class="chip ver">verified ${escapeHtml(e.verificationScore)}</span>` : ""}
           ${e.waf ? `<span class="chip waf">${escapeHtml(e.waf.name)}</span>` : ""}
         </div>
         ${e.preview
            ? `<div class="bypass-preview-body">${escapeHtml(e.preview)}${e.preview.length >= 200 ? " …" : ""}</div>`
            : ""}
       </div>`
    : "";
  const evidenceBlock = e.evidence ? renderEvidence(e.evidence) : "";
  return `
    <div class="finding sev-${e.severity}${fresh ? " rh-new" : ""}${isBypass ? " bypass" : ""}">
      <div class="finding-title">
        <a href="${safeHref(e.url)}" target="_blank" rel="noreferrer noopener">${escapeHtml(e.title)}</a>
        <span class="badge sev-${e.severity}">${e.severity}</span>
        <span class="conf ${e.needsManual ? "unconfirmed" : "confirmed"}">${e.needsManual ? "verify manually" : "verified"}</span>
        ${fresh ? `<span class="rh-new-tag">NEW</span>` : ""}
      </div>
      <div class="finding-detail">${escapeHtml(e.detail)}</div>
      ${bypassExtra}
      ${evidenceBlock}
    </div>`;
}

function renderEvidence(ev) {
  if (!ev || (!ev.request && !ev.response)) return "";
  const req = ev.request || {};
  const res = ev.response || {};
  const reqHeaders = Object.entries(req.headers || {})
    .map(([k, v]) => `<div class="hdr-row"><span class="hdr-name">${escapeHtml(k)}:</span> <span class="hdr-val">${escapeHtml(String(v))}</span></div>`)
    .join("");
  const resHeaders = Object.entries(res.headers || {})
    .map(([k, v]) => `<div class="hdr-row"><span class="hdr-name">${escapeHtml(k)}:</span> <span class="hdr-val">${escapeHtml(String(v))}</span></div>`)
    .join("");
  const evId = "ev-" + Math.random().toString(36).slice(2, 8);
  // Stash the raw evidence in a global map so the copy button can retrieve it
  // (data attributes get escaped-truncated in nested innerHTML).
  window.__rh_evidence = window.__rh_evidence || {};
  window.__rh_evidence[evId] = ev;
  return `
    <details class="evidence-block">
      <summary>📎 evidence · captured ${escapeHtml(ev.capturedAtDisplay || ev.capturedAt || "?")}</summary>
      <div class="ev-section">
        <div class="ev-label">REQUEST</div>
        <div class="ev-line"><b>${escapeHtml(req.method || "GET")}</b> <span class="ev-url">${escapeHtml(req.url || "")}</span></div>
        <div class="ev-headers">${reqHeaders || `<div class="muted">(no custom headers captured)</div>`}</div>
      </div>
      <div class="ev-section">
        <div class="ev-label">RESPONSE</div>
        <div class="ev-line">HTTP <b>${escapeHtml(String(res.status ?? "?"))}</b>
          <span class="muted">${escapeHtml(String(res.bodyBytes ?? 0))}B</span>
          ${res.finalUrl && res.finalUrl !== req.url
            ? ` → <span class="ev-url">${escapeHtml(res.finalUrl)}</span>`
            : ""}
        </div>
        <div class="ev-headers">${resHeaders || `<div class="muted">(headers not captured — fetch API restricts CORS-safe headers only)</div>`}</div>
        ${res.bodyPreview
          ? `<div class="ev-body-label">body preview (up to 4 KB, secrets redacted):</div>
             <div class="ev-body">${escapeHtml(res.bodyPreview)}</div>`
          : ""}
      </div>
      <button class="ev-copy" data-evid="${evId}">📋 copy raw HTTP transcript</button>
    </details>`;
}

// Delegated click handler for evidence "copy raw" buttons.
document.addEventListener("click", (e) => {
  const btn = e.target.closest && e.target.closest(".ev-copy");
  if (!btn) return;
  const evId = btn.getAttribute("data-evid");
  const ev = (window.__rh_evidence || {})[evId];
  if (!ev) return;
  const transcript = evidenceToTranscript(ev);
  navigator.clipboard.writeText(transcript).then(() => {
    btn.textContent = "✓ copied";
    setTimeout(() => { btn.textContent = "📋 copy raw HTTP transcript"; }, 1500);
  }).catch(() => {
    btn.textContent = "clipboard blocked — select text below";
  });
});

// Client-side copy of evidence.js's evidenceToTranscript (kept in sync).
function evidenceToTranscript(ev) {
  if (!ev) return "";
  const req = ev.request || {};
  const res = ev.response || {};
  const reqHeaders = Object.entries(req.headers || {})
    .map(([k, v]) => `${headerCase(k)}: ${v}`).join("\n");
  const resHeaders = Object.entries(res.headers || {})
    .map(([k, v]) => `${headerCase(k)}: ${v}`).join("\n");
  let urlPath = req.url || "/";
  let host = "";
  try { const u = new URL(req.url); urlPath = u.pathname + u.search; host = u.host; } catch (_) {}
  return [
    `# captured at ${ev.capturedAtDisplay || ev.capturedAt}`,
    `# ─── REQUEST ─────────────────────────────`,
    `${req.method || "GET"} ${urlPath} HTTP/1.1`,
    `Host: ${host}`,
    reqHeaders,
    ``,
    `# ─── RESPONSE ────────────────────────────`,
    `HTTP/1.1 ${res.status || "?"} `,
    resHeaders,
    ``,
    res.bodyPreview ? `[body ${res.bodyBytes || 0} bytes]` : `[no body captured]`,
    res.bodyPreview || ""
  ].join("\n");
}
function headerCase(name) {
  return String(name).split("-").map((p) => p.charAt(0).toUpperCase() + p.slice(1)).join("-");
}

function renderSecret(s) {
  const fresh = isNew("secret", s);
  return `
    <div class="finding sev-${s.severity}${fresh ? " rh-new" : ""}">
      <div class="finding-title">
        ${escapeHtml(s.title)}
        <span class="badge sev-${s.severity}">${s.severity}</span>
        ${fresh ? `<span class="rh-new-tag">NEW</span>` : ""}
      </div>
      <div class="finding-detail">
        <code>${escapeHtml(s.match)}</code><br/>
        <span class="muted">source: ${escapeHtml(s.source)} · entropy ${s.entropy}</span>
      </div>
    </div>`;
}

function renderJwt(j) {
  const issues = (j.issues || []).map((i) =>
    `<div class="cve"><span class="sev-${i.severity}">${i.severity}</span> ${escapeHtml(i.text)}</div>`
  ).join("");
  const meta = [
    j.algorithm ? `alg <b>${escapeHtml(j.algorithm)}</b>` : null,
    j.issuer ? `iss ${escapeHtml(String(j.issuer))}` : null,
    j.audience ? `aud ${escapeHtml(String(j.audience))}` : null,
    j.subject ? `sub ${escapeHtml(String(j.subject))}` : null,
    j.expiresAt ? `exp ${escapeHtml(j.expiresAt)}` : null
  ].filter(Boolean).join(" · ");
  return `
    <div class="finding sev-${j.verdict || "LOW"}">
      <div class="finding-title">
        JWT decoded
        <span class="badge sev-${j.verdict || "LOW"}">${j.verdict || "LOW"}</span>
        <span class="conf">${escapeHtml(j.source || "unknown")}</span>
      </div>
      <div class="finding-detail">
        <span class="muted">${meta || "no standard claims"}</span>
        ${issues || `<div class="cve"><span class="sev-LOW">OK</span> No structural weaknesses flagged.</div>`}
      </div>
    </div>`;
}

function renderEndpoint(e) {
  const fresh = isNew("endpoint", e);
  return `
    <div class="endpoint${fresh ? " rh-new" : ""}">
      <span class="etype ${e.type}">${e.type}</span>
      <a href="${safeHref(e.path)}" target="_blank" rel="noreferrer noopener">${escapeHtml(e.path)}</a>
      ${fresh ? `<span class="rh-new-tag">NEW</span>` : ""}
      <div class="muted">${escapeHtml(e.source)}</div>
    </div>`;
}

function renderPathHit(h) {
  return `
    <div class="finding sev-${h.severity}">
      <div class="finding-title">
        <a href="${safeHref(h.url)}" target="_blank" rel="noreferrer noopener">${escapeHtml(h.path)}</a>
        <span class="badge sev-${h.severity}">${h.severity}</span>
        <span class="conf">HTTP ${h.status}</span>
      </div>
      <div class="finding-detail">${escapeHtml(h.note)}</div>
    </div>`;
}

function renderTech(t) {
  const cves = (t.cves || []).slice(0, 6).map((c) => {
    const tags = [];
    if (c.ransomware) tags.push(`<span class="xtag rw">☣ RANSOMWARE</span>`);
    if (c.kev) tags.push(`<span class="xtag kev">⚡ ACTIVELY EXPLOITED</span>`);
    else if (c.exploitAvailable) tags.push(`<span class="xtag exp">⚑ EXPLOIT LIKELY</span>`);

    const links = [
      `<a href="${safeHref(c.exploitDb)}" target="_blank" rel="noreferrer noopener">ExploitDB</a>`,
      `<a href="${safeHref(c.metasploit)}" target="_blank" rel="noreferrer noopener">Metasploit</a>`,
      `<a href="${safeHref(c.nuclei)}" target="_blank" rel="noreferrer noopener">Nuclei</a>`,
      `<a href="${safeHref(c.githubPoc)}" target="_blank" rel="noreferrer noopener">PoC</a>`
    ].join(" · ");

    return `
      <div class="cve ${c.kev ? "kev-row" : ""}">
        <a href="${safeHref(c.nvd)}" target="_blank" rel="noreferrer noopener">${escapeHtml(c.id)}</a>
        <span class="sev-${c.severity}">${c.severity}${c.score != null ? " (" + c.score + ")" : ""}</span>
        ${c.confidence ? `<span class="conf ${c.confidence}">${c.confidence}</span>` : ""}
        ${tags.join(" ")}
        <div class="xlinks">${links}</div>
      </div>`;
  }).join("");

  // Outdated / EOL badge — surfaced right next to the version.
  let outdatedBadge = "";
  let outdatedRow = "";
  if (t.outdated) {
    const o = t.outdated;
    if (o.eol) {
      outdatedBadge = `<span class="badge sev-HIGH" title="End-of-life">☠ EOL</span>`;
    } else if (o.majorBehind >= 2) {
      outdatedBadge = `<span class="badge sev-HIGH" title="${o.majorBehind} major versions behind">⏫ OUTDATED</span>`;
    } else if (o.majorBehind >= 1) {
      outdatedBadge = `<span class="badge sev-MEDIUM" title="1 major version behind">⏫ OUTDATED</span>`;
    } else {
      outdatedBadge = `<span class="badge sev-LOW" title="Newer minor/patch available">⏫ UPDATE</span>`;
    }
    outdatedRow = `<div class="finding-detail">${escapeHtml(o.note || "")}${o.latest ? ` <span class="muted">· latest ${escapeHtml(String(o.latest))}</span>` : ""}${o.eolDate && o.eolDate !== "unsupported" ? ` <span class="muted">· EOL ${escapeHtml(String(o.eolDate))}</span>` : ""}</div>`;
  }

  const fresh = isNew("tech", t);
  return `
    <div class="tech${fresh ? " rh-new" : ""}">
      <div class="tech-name">${escapeHtml(t.tech)}${t.version ? ` <span class="ver">v${escapeHtml(t.version)}</span>` : ""} ${outdatedBadge}${fresh ? ` <span class="rh-new-tag">NEW</span>` : ""}</div>
      <div class="cat">${escapeHtml(t.category)}</div>
      ${outdatedRow}
      ${cves}
    </div>`;
}

function renderFinding(f) {
  const fresh = isNew("security", f);
  return `
    <div class="finding sev-${f.severity}${fresh ? " rh-new" : ""}">
      <div class="finding-title">
        ${escapeHtml(f.title)}
        <span class="badge sev-${f.severity}">${f.severity}</span>
        ${fresh ? `<span class="rh-new-tag">NEW</span>` : ""}
      </div>
      <div class="finding-detail">${escapeHtml(f.detail)}</div>
    </div>`;
}

function renderRisk(risk) {
  if (!risk) return;
  const gradeEl = document.getElementById("grade");
  const cls = "g-" + (risk.grade === "A+" ? "Aplus" : risk.grade);
  gradeEl.className = "grade " + cls;
  gradeEl.textContent = risk.grade;

  document.getElementById("scoreVal").textContent = `${risk.score}/100`;
  document.getElementById("barFill").style.width = risk.score + "%";

  const c = risk.counts || {};
  document.getElementById("sevLegend").innerHTML =
    `<span class="lg-c">C:<b>${c.CRITICAL || 0}</b></span>
     <span class="lg-h">H:<b>${c.HIGH || 0}</b></span>
     <span class="lg-m">M:<b>${c.MEDIUM || 0}</b></span>
     <span class="lg-l">L:<b>${c.LOW || 0}</b></span>`;
}

function renderBrain(brain) {
  const panel = document.getElementById("brain");
  if (!panel) return;
  if (!brain || !brain.top) {
    panel.innerHTML = `<p class="empty">// no exploit-intelligence data — reload target</p>`;
    return;
  }
  const cls = brain.counts.weaponized ? "weaponized" : brain.counts.likely ? "likely" : "low";
  const head = `
    <div class="brain-head ${cls}">
      <div class="brain-meter">
        <div class="brain-score">${brain.overall}</div>
        <div class="brain-score-l">EXPLOITABILITY</div>
      </div>
      <div class="brain-headline">${escapeHtml(brain.headline)}</div>
    </div>
    <div class="brain-stats">
      <span class="vbadge weaponized">${brain.counts.weaponized} WEAPONIZED</span>
      <span class="vbadge likely">${brain.counts.likely} LIKELY</span>
      <span class="muted">${brain.counts.total} CVE(s) analyzed · NVD + KEV + EPSS</span>
    </div>`;

  const rows = brain.top.length
    ? brain.top.map(renderBrainRow).join("")
    : `<p class="empty">// no CVEs correlated to detected stack</p>`;

  panel.innerHTML = head + `<div class="section-label">prioritized exploit targets</div>` + rows;
}

function renderBrainRow(r) {
  const epssPct = r.epss != null ? (r.epss * 100).toFixed(1) + "%" : "—";
  const tags = [];
  if (r.ransomware) tags.push(`<span class="xtag rw">☣ RANSOMWARE</span>`);
  if (r.kev) tags.push(`<span class="xtag kev">⚡ KEV</span>`);
  return `
    <div class="brain-row v-${r.verdictClass}">
      <div class="brain-row-top">
        <a href="${safeHref(r.nvd)}" target="_blank" rel="noreferrer noopener">${escapeHtml(r.id)}</a>
        <span class="vbadge ${r.verdictClass}">${r.verdict}</span>
        <span class="brain-exp">${r.exploitability}</span>
      </div>
      <div class="muted">${escapeHtml(r.tech)} · ${r.severity}${r.score != null ? " (" + r.score + ")" : ""} · EPSS ${epssPct} ${tags.join(" ")}</div>
      <div class="brain-reason">${escapeHtml(r.reasoning)}</div>
      <div class="brain-action">▸ ${escapeHtml(r.action)}</div>
      <div class="xlinks">
        <a href="${safeHref(r.metasploit)}" target="_blank" rel="noreferrer noopener">Metasploit</a> ·
        <a href="${safeHref(r.nuclei)}" target="_blank" rel="noreferrer noopener">Nuclei</a> ·
        <a href="${safeHref(r.exploitDb)}" target="_blank" rel="noreferrer noopener">ExploitDB</a> ·
        <a href="${safeHref(r.githubPoc)}" target="_blank" rel="noreferrer noopener">PoC</a>
      </div>
    </div>`;
}

function renderRecon(subdomains, params, ctSubdomains, supplyChain, ctMeta) {
  const supply = supplyChain || (lastReport && lastReport.supplyChain) || null;
  const ct = ctSubdomains || (lastReport && lastReport.ctSubdomains) || [];
  const meta = ctMeta || (lastReport && lastReport.ctMeta) || null;
  const ctSet = new Set(ct);
  const supplyItems = (supply && supply.inventory) || [];

  const total = subdomains.length + params.length + supplyItems.length;
  document.getElementById("reconCount").textContent = String(total);
  const panel = document.getElementById("recon");

  if (!total) {
    panel.innerHTML = `<p class="empty">// no subdomains, params or third parties detected yet</p>`;
    return;
  }

  const subChips = subdomains.map((s) => {
    const src = ctSet.has(s) ? ' title="from certificate-transparency logs"' : "";
    const cls = ctSet.has(s) ? "chip ct" : "chip";
    return `<span class="${cls}"${src}>${escapeHtml(s)}${ctSet.has(s) ? " ⓒ" : ""}</span>`;
  }).join("");

  const paramChips = params.map((p) => `<span class="chip">${escapeHtml(p)}</span>`).join("");

  const supplyByCat = {};
  for (const item of supplyItems) {
    (supplyByCat[item.category] ??= []).push(item);
  }
  const supplyHtml = Object.entries(supplyByCat).map(([cat, items]) => {
    const chips = items.map((i) =>
      `<span class="chip" title="${escapeHtml(i.hosts.join(', '))}">${escapeHtml(i.tech)}</span>`
    ).join("");
    return `<div class="section-sub muted">${escapeHtml(cat)} (${items.length})</div><div class="chips">${chips}</div>`;
  }).join("");

  const ctBanner = meta && meta.degraded
    ? `<div class="degraded-note">// CT sources unreachable — subdomain enum degraded</div>`
    : (meta && meta.sources && meta.sources.length
       ? `<div class="muted">// CT sources: ${meta.sources.map(escapeHtml).join(", ")}</div>`
       : "");

  panel.innerHTML =
    `<div class="section-label">subdomains (${subdomains.length}${ct.length ? ` · ${ct.length} from CT logs` : ""})</div>` +
    ctBanner +
    (subChips ? `<div class="chips">${subChips}</div>` : `<p class="muted">none</p>`) +
    (supplyHtml
      ? `<div class="section-label">third-party services (${supplyItems.length})</div>${supplyHtml}`
      : "") +
    `<div class="section-label">query params (${params.length})</div>` +
    (paramChips ? `<div class="chips">${paramChips}</div>` : `<p class="muted">none</p>`);
}

function refreshReport() {
  chrome.runtime.sendMessage({ type: "RH_GET_FULL", tabId: currentTab.id }, (report) => {
    if (chrome.runtime.lastError || !report) return;
    lastReport = report;
    renderRisk(report.risk);
    renderChains(report.attackChains || []);
  });
}

function loadHistory() {
  const diffBox = document.getElementById("diffBox");
  const list = document.getElementById("historyList");
  chrome.runtime.sendMessage({ type: "RH_GET_HISTORY", tabId: currentTab.id }, (res) => {
    if (chrome.runtime.lastError || !res) {
      list.innerHTML = `<p class="empty">// history unavailable</p>`;
      return;
    }
    // Diff vs most recent saved snapshot
    if (res.diff) {
      const d = res.diff;
      const deltaCls = d.scoreDelta > 0 ? "delta-up" : d.scoreDelta < 0 ? "delta-down" : "delta-flat";
      const deltaTxt = (d.scoreDelta > 0 ? "+" : "") + d.scoreDelta;
      const added = d.added.slice(0, 30).map((x) => `<div class="diff-item add">${escapeHtml(x)}</div>`).join("");
      const removed = d.removed.slice(0, 30).map((x) => `<div class="diff-item rem">${escapeHtml(x)}</div>`).join("");
      diffBox.innerHTML = `
        <div class="diff">
          <div class="diff-head">DIFF vs last snapshot — grade ${escapeHtml(d.gradeFrom)} → ${escapeHtml(d.gradeTo)}
            · score <span class="${deltaCls}">${deltaTxt}</span></div>
          ${added || removed
            ? added + removed
            : `<div class="diff-item">// no changes since last snapshot</div>`}
        </div>`;
    } else {
      diffBox.innerHTML = `<p class="muted">// no prior snapshot for ${escapeHtml(res.host)} — save one to start tracking</p>`;
    }

    // History list for this host
    list.innerHTML = res.snapshots.length
      ? res.snapshots.map(renderSnap).join("")
      : `<p class="empty">// no saved snapshots</p>`;
  });
}

function renderSnap(s) {
  const cls = "g-" + (s.grade === "A+" ? "Aplus" : s.grade);
  const when = new Date(s.ts).toLocaleString();
  const c = s.counts || {};
  return `
    <div class="snap-row">
      <span class="snap-grade grade ${cls}">${escapeHtml(s.grade)}</span>
      <div style="flex:1;margin:0 10px">
        <div>${s.score}/100 · C:${c.CRITICAL || 0} H:${c.HIGH || 0} M:${c.MEDIUM || 0} L:${c.LOW || 0}</div>
        <div class="snap-meta">${escapeHtml(when)}</div>
      </div>
    </div>`;
}

function exportJson() {
  if (!lastReport) return;
  download(
    new Blob([JSON.stringify(lastReport, null, 2)], { type: "application/json" }),
    `reconhound-report-${Date.now()}.json`
  );
}

function exportHtml() {
  if (!lastReport) return;
  const r = lastReport;
  const risk = r.risk || { grade: "—", score: 0, counts: {} };
  const c = risk.counts || {};
  const now = new Date();
  const reportId = "RH-" + now.getTime().toString(36).toUpperCase();

  const sevTag = (s) => `<span class="sev sev-${s}">${s}</span>`;

  const techRows = (r.tech || []).map((t) => {
    const cves = (t.cves || []).map((c2) => {
      const flags = [];
      if (c2.ransomware) flags.push('<b style="color:#c0392b">RANSOMWARE</b>');
      if (c2.kev) flags.push('<b style="color:#b1006b">KEV / ACTIVELY EXPLOITED</b>');
      else if (c2.exploitAvailable) flags.push('<span style="color:#b8860b">exploit likely</span>');
      const links = [
        `<a href="${safeHref(c2.exploitDb)}" rel="noreferrer noopener">ExploitDB</a>`,
        `<a href="${safeHref(c2.metasploit)}" rel="noreferrer noopener">Metasploit</a>`,
        `<a href="${safeHref(c2.nuclei)}" rel="noreferrer noopener">Nuclei</a>`,
        `<a href="${safeHref(c2.githubPoc)}" rel="noreferrer noopener">PoC</a>`
      ].join(" · ");
      return `<li><a href="${safeHref(c2.nvd)}" rel="noreferrer noopener">${esc(c2.id)}</a> ${sevTag(c2.severity)}${c2.score != null ? " " + c2.score : ""}
        ${c2.confidence ? `<em>${esc(c2.confidence)}</em>` : ""} ${flags.join(" ")}<br><small>${links}</small></li>`;
    }).join("");
    return `<tr><td>${esc(t.tech)}</td><td>${esc(t.version || "—")}</td><td>${esc(t.category)}</td>
            <td>${cves ? `<ul>${cves}</ul>` : "—"}</td></tr>`;
  }).join("");

  const findingRows = (arr, cols) => (arr || []).map(cols).join("");

  const secRows = findingRows(r.security, (f) =>
    `<tr><td>${sevTag(f.severity)}</td><td>${esc(f.title)}</td><td>${esc(f.detail)}</td></tr>`);
  const secretRows = findingRows(r.secrets, (s) =>
    `<tr><td>${sevTag(s.severity)}</td><td>${esc(s.title)}</td><td><code>${esc(s.match)}</code></td><td>${esc(s.source)}</td></tr>`);
  const exposureRows = findingRows(r.exposures, (e) =>
    `<tr><td>${sevTag(e.severity)}</td><td><a href="${safeHref(e.url)}" rel="noreferrer noopener">${esc(e.title)}</a></td><td>${esc(e.detail)}</td></tr>`);
  const endpointRows = findingRows(r.endpoints, (e) =>
    `<tr><td>${esc(e.type)}</td><td><a href="${safeHref(e.path)}" rel="noreferrer noopener">${esc(e.path)}</a></td><td>${esc(e.source)}</td></tr>`);
  const activeRows = findingRows(r.activeScan, (h) =>
    `<tr><td>${sevTag(h.severity)}</td><td><a href="${safeHref(h.url)}" rel="noreferrer noopener">${esc(h.path)}</a></td><td>HTTP ${h.status}</td><td>${esc(h.note)}</td></tr>`);

  const subChips = (r.subdomains || []).map((s) => `<span class="chip">${esc(s)}</span>`).join("") || "—";
  const paramChips = (r.params || []).map((p) => `<span class="chip">${esc(p)}</span>`).join("") || "—";

  const total = risk.total || 0;
  const summary = buildExecSummary(risk, r);
  const brainBlock = buildBrainBlock(r.brain);

  const html = `<!DOCTYPE html><html lang="en"><head><meta charset="utf-8">
<title>ReconHound Assessment Report — ${esc(r.url || "")}</title>
<style>
  :root{--crit:#c0392b;--high:#e67e22;--med:#d4a017;--low:#27ae60;--ink:#1a2027;--soft:#5b6770;--line:#e4e8ec;--bg:#f5f7f9;}
  *{box-sizing:border-box}
  body{font-family:-apple-system,Segoe UI,Roboto,Helvetica,Arial,sans-serif;margin:0;color:var(--ink);background:var(--bg);font-size:14px;line-height:1.55}
  .page{max-width:900px;margin:0 auto;background:#fff;box-shadow:0 1px 4px rgba(0,0,0,.08)}
  .cover{background:linear-gradient(135deg,#0b1f17,#10362a);color:#eafff5;padding:40px}
  .cover h1{margin:0;font-size:30px;letter-spacing:1px}
  .cover .sub{color:#7fdcb4;margin-top:4px;font-size:13px}
  .cover .target{margin-top:20px;font-size:16px;word-break:break-all}
  .meta-grid{display:flex;gap:30px;flex-wrap:wrap;margin-top:18px;font-size:12px;color:#b9e8d4}
  .meta-grid b{display:block;color:#eafff5;font-size:13px}
  .gradewrap{display:flex;align-items:center;gap:24px;margin-top:24px}
  .gradebig{font-size:64px;font-weight:800;line-height:1;padding:8px 22px;border-radius:12px;background:rgba(255,255,255,.08)}
  .g-A,.g-Aplus{color:#3ddc84}.g-B{color:#48d1ff}.g-C{color:#ffcf3a}.g-D{color:#ff9a3a}.g-F{color:#ff5a5a}
  .scoreline{font-size:13px;color:#b9e8d4}
  .scorebar{height:10px;width:280px;background:rgba(255,255,255,.12);border-radius:6px;overflow:hidden;margin-top:6px}
  .scorebar > i{display:block;height:100%;background:linear-gradient(90deg,#3ddc84,#ffcf3a 60%,#ff5a5a)}
  section{padding:26px 40px;border-top:1px solid var(--line)}
  h2{font-size:18px;margin:0 0 14px;padding-bottom:8px;border-bottom:2px solid var(--ink)}
  h3{font-size:14px;margin:18px 0 8px;color:var(--soft);text-transform:uppercase;letter-spacing:.5px}
  p{margin:8px 0}
  table{border-collapse:collapse;width:100%;margin-top:8px;font-size:13px}
  th,td{border:1px solid var(--line);padding:7px 9px;text-align:left;vertical-align:top}
  th{background:var(--bg);font-size:12px;text-transform:uppercase;letter-spacing:.4px;color:var(--soft)}
  ul{margin:0;padding-left:18px}
  code{background:#f0f2f4;border:1px solid var(--line);border-radius:3px;padding:1px 5px;font-size:12px;word-break:break-all}
  .sev{font-weight:700;font-size:11px;padding:2px 8px;border-radius:10px;color:#fff;display:inline-block;text-transform:uppercase}
  .sev-CRITICAL{background:var(--crit)}.sev-HIGH{background:var(--high)}.sev-MEDIUM{background:var(--med)}.sev-LOW{background:var(--low)}.sev-UNKNOWN{background:#90a0ab}
  .cards{display:flex;gap:12px;flex-wrap:wrap;margin:10px 0}
  .card{flex:1;min-width:120px;border:1px solid var(--line);border-radius:8px;padding:12px;text-align:center}
  .card .n{font-size:28px;font-weight:800}
  .card.crit .n{color:var(--crit)}.card.high .n{color:var(--high)}.card.med .n{color:var(--med)}.card.low .n{color:var(--low)}
  .card .l{font-size:11px;color:var(--soft);text-transform:uppercase;letter-spacing:.5px}
  .chip{display:inline-block;background:#eef4f1;border:1px solid var(--line);border-radius:4px;padding:2px 7px;margin:2px;font-size:12px;font-family:monospace}
  .callout{background:#fff8e6;border-left:4px solid var(--med);padding:12px 14px;border-radius:0 6px 6px 0;font-size:13px}
  .disclaimer{background:#fbecec;border-left:4px solid var(--crit);padding:12px 14px;border-radius:0 6px 6px 0;font-size:12px;color:#7a2b2b}
  footer{padding:18px 40px;font-size:11px;color:var(--soft);text-align:center;border-top:1px solid var(--line)}
  /* Floating report toolbar */
  .rh-toolbar{position:fixed;top:14px;right:14px;display:flex;gap:8px;z-index:10}
  .rh-toolbar button{font-family:inherit;font-size:12px;padding:7px 12px;border-radius:6px;border:1px solid var(--line);background:#fff;color:var(--ink);cursor:pointer;box-shadow:0 1px 3px rgba(0,0,0,.12)}
  .rh-toolbar button:hover{background:var(--bg)}
  /* Dark theme overrides */
  body.dark{--ink:#cfe9dd;--soft:#7fa493;--line:#1e3a2c;--bg:#0a0f0c}
  body.dark .page{background:#0c130f}
  body.dark .rh-toolbar button{background:#0c130f;color:#cfe9dd;border-color:#1e3a2c}
  body.dark th{background:#0a0f0c}
  body.dark code{background:#0a1810;border-color:#1e3a2c;color:#ffb000}
  body.dark .callout{background:#1c1604;border-color:#d4a017}
  body.dark .disclaimer{background:#1c0c0c;border-color:#c0392b;color:#ff9d9d}
  body.dark .chip{background:#0a1810;border-color:#1e3a2c}
  @media print{body{background:#fff}.page{box-shadow:none}.rh-toolbar{display:none}body.dark{--ink:#1a2027;--soft:#5b6770;--line:#e4e8ec;--bg:#f5f7f9}body.dark .page{background:#fff}}
</style></head><body><div class="page">

  <div class="rh-toolbar">
    <button onclick="document.body.classList.toggle('dark')">🌓 Dark / Light</button>
    <button onclick="window.print()">🖨 Print / PDF</button>
  </div>

  <div class="cover">
    <h1>🛡 SECURITY ASSESSMENT REPORT</h1>
    <div class="sub">ReconHound · Automated Reconnaissance & Vulnerability Assessment</div>
    <div class="target"><b>Target:</b> ${esc(r.url || "n/a")}</div>
    <div class="meta-grid">
      <div><b>${esc(reportId)}</b>Report ID</div>
      <div><b>${now.toLocaleString()}</b>Generated</div>
      <div><b>${total}</b>Total Findings</div>
      <div><b>${(r.tech || []).length}</b>Technologies</div>
    </div>
    <div class="gradewrap">
      <div class="gradebig ${risk.grade === "A+" ? "g-Aplus" : "g-" + risk.grade}">${esc(risk.grade)}</div>
      <div>
        <div class="scoreline">Overall Risk Score: <b>${risk.score}/100</b></div>
        <div class="scorebar"><i style="width:${risk.score}%"></i></div>
        <div class="scoreline" style="margin-top:8px">
          ${sevTag("CRITICAL")} ${c.CRITICAL || 0} &nbsp; ${sevTag("HIGH")} ${c.HIGH || 0} &nbsp;
          ${sevTag("MEDIUM")} ${c.MEDIUM || 0} &nbsp; ${sevTag("LOW")} ${c.LOW || 0}
        </div>
      </div>
    </div>
  </div>

  <section>
    <h2>1. Executive Summary</h2>
    ${summary}
    <div class="cards">
      <div class="card crit"><div class="n">${c.CRITICAL || 0}</div><div class="l">Critical</div></div>
      <div class="card high"><div class="n">${c.HIGH || 0}</div><div class="l">High</div></div>
      <div class="card med"><div class="n">${c.MEDIUM || 0}</div><div class="l">Medium</div></div>
      <div class="card low"><div class="n">${c.LOW || 0}</div><div class="l">Low</div></div>
    </div>
  </section>

  <section>
    <h2>2. Exploit Intelligence (AI Brain)</h2>
    ${brainBlock}
  </section>

  <section>
    <h2>3. Methodology & Scope</h2>
    <p>This assessment was produced by the ReconHound browser extension using a
    combination of <b>passive fingerprinting</b> (HTTP response headers, loaded
    resources, runtime globals) and, where explicitly authorized, <b>active
    probing</b> (sensitive-path discovery, VCS/secret-file exposure verification,
    source-map and GraphQL introspection checks). CVE correlation is performed
    against the NIST NVD database with CPE version-range matching. Findings marked
    <em>confirmed</em> were validated against the detected version; <em>unconfirmed</em>
    are name-only matches requiring manual verification.</p>
    <div class="callout">Severity ratings follow CVSS-aligned bands
    (Critical ≥ 9.0, High 7.0–8.9, Medium 4.0–6.9, Low &lt; 4.0). The overall grade
    is a weighted aggregate; any Critical finding caps the grade at <b>F</b>.</div>
  </section>

  <section>
    <h2>4. Technology Stack & Known Vulnerabilities</h2>
    <table><thead><tr><th>Technology</th><th>Version</th><th>Category</th><th>CVEs</th></tr></thead>
    <tbody>${techRows || "<tr><td colspan=4>None detected</td></tr>"}</tbody></table>
  </section>

  <section>
    <h2>5. Security Misconfigurations</h2>
    <table><thead><tr><th>Severity</th><th>Issue</th><th>Detail</th></tr></thead>
    <tbody>${secRows || "<tr><td colspan=3>None identified</td></tr>"}</tbody></table>
  </section>

  <section>
    <h2>6. Credential & Secret Exposure</h2>
    <table><thead><tr><th>Severity</th><th>Type</th><th>Match (redacted)</th><th>Source</th></tr></thead>
    <tbody>${secretRows || "<tr><td colspan=4>None identified</td></tr>"}</tbody></table>
  </section>

  <section>
    <h2>7. Verified Exposures (Active)</h2>
    <table><thead><tr><th>Severity</th><th>Exposure</th><th>Detail</th></tr></thead>
    <tbody>${exposureRows || "<tr><td colspan=3>Active scan not run / none verified</td></tr>"}</tbody></table>
    <h3>Reachable Sensitive Paths</h3>
    <table><thead><tr><th>Severity</th><th>Path</th><th>Status</th><th>Note</th></tr></thead>
    <tbody>${activeRows || "<tr><td colspan=4>Active scan not run</td></tr>"}</tbody></table>
  </section>

  <section>
    <h2>8. Attack Surface — Endpoints & Recon</h2>
    <table><thead><tr><th>Type</th><th>Path / URL</th><th>Source</th></tr></thead>
    <tbody>${endpointRows || "<tr><td colspan=3>None extracted</td></tr>"}</tbody></table>
    <h3>Discovered Subdomains</h3><p>${subChips}</p>
    <h3>Observed Query Parameters</h3><p>${paramChips}</p>
  </section>

  <section>
    <h2>9. Recommendations</h2>
    <ol>
      ${buildRecommendations(r)}
    </ol>
  </section>

  <footer>
    <div class="disclaimer"><b>Legal Disclaimer:</b> This report is intended solely
    for authorized security assessment of systems you own or have explicit written
    permission to test. Unauthorized use may violate computer-misuse laws.
    ReconHound and its authors accept no liability for misuse.</div>
    <p style="margin-top:12px">Generated by ReconHound · Report ${esc(reportId)} · ${now.toISOString()}</p>
  </footer>

</div></body></html>`;

  download(new Blob([html], { type: "text/html" }), `ReconHound_Report_${reportId}.html`);
}

function buildBrainBlock(brain) {
  if (!brain || !brain.top || !brain.top.length) {
    return `<p>No CVEs were correlated to the detected stack, so no exploit-intelligence
      ranking is available. Manual testing is still recommended.</p>`;
  }
  const rows = brain.top.map((r) => {
    const epss = r.epss != null ? (r.epss * 100).toFixed(1) + "%" : "—";
    const flags = [];
    if (r.ransomware) flags.push('<b style="color:#c0392b">RANSOMWARE</b>');
    if (r.kev) flags.push('<b style="color:#b1006b">KEV</b>');
    const links = `<a href="${safeHref(r.metasploit)}" rel="noreferrer noopener">Metasploit</a> · <a href="${safeHref(r.nuclei)}" rel="noreferrer noopener">Nuclei</a> · <a href="${safeHref(r.exploitDb)}" rel="noreferrer noopener">ExploitDB</a> · <a href="${safeHref(r.githubPoc)}" rel="noreferrer noopener">PoC</a>`;
    return `<tr>
      <td><b>${esc(String(r.exploitability))}</b></td>
      <td>${esc(r.verdict)}</td>
      <td><a href="${safeHref(r.nvd)}" rel="noreferrer noopener">${esc(r.id)}</a> ${flags.join(" ")}</td>
      <td>${esc(r.tech)}</td>
      <td>${esc(epss)}</td>
      <td>${esc(r.reasoning)}<br><small>▸ ${esc(r.action)}</small><br><small>${links}</small></td>
    </tr>`;
  }).join("");

  return `
    <p><b>${esc(brain.headline)}</b></p>
    <p>Overall exploitability index: <b>${brain.overall}/100</b> · Weaponized: <b>${brain.counts.weaponized}</b>
       · Likely exploitable: <b>${brain.counts.likely}</b> · CVEs analyzed: ${brain.counts.total}.
       Scoring fuses NVD severity, CISA KEV (active exploitation), EPSS (exploitation probability)
       and public exploit-tool availability.</p>
    <table><thead><tr><th>Exploit&nbsp;Idx</th><th>Verdict</th><th>CVE</th><th>Component</th><th>EPSS</th><th>Reasoning &amp; Action</th></tr></thead>
    <tbody>${rows}</tbody></table>`;
}

function buildExecSummary(risk, r) {
  const c = risk.counts || {};
  const grade = risk.grade;
  let posture;
  if (grade === "F") posture = "a <b>critical</b> security posture requiring immediate remediation";
  else if (grade === "D") posture = "a <b>poor</b> security posture with serious weaknesses";
  else if (grade === "C") posture = "a <b>moderate</b> security posture with notable gaps";
  else if (grade === "B") posture = "a <b>fair</b> security posture with minor issues";
  else posture = "a <b>strong</b> security posture";

  const highlights = [];
  if ((r.secrets || []).length) highlights.push(`${r.secrets.length} potential credential/secret leak(s)`);
  if ((r.exposures || []).length) highlights.push(`${r.exposures.length} verified file/VCS exposure(s)`);
  const cveCount = (r.tech || []).reduce((n, t) => n + (t.cves || []).length, 0);
  if (cveCount) highlights.push(`${cveCount} known CVE(s) across the stack`);
  const kevCount = (r.tech || []).reduce((n, t) => n + (t.cves || []).filter((c) => c.kev).length, 0);
  if (kevCount) highlights.push(`<b style="color:#b1006b">${kevCount} actively-exploited (CISA KEV) CVE(s)</b>`);
  if (c.CRITICAL) highlights.push(`${c.CRITICAL} critical-severity issue(s)`);

  const list = highlights.length
    ? `Key concerns include ${highlights.join(", ")}.`
    : "No high-impact issues were automatically identified, though manual testing is still recommended.";

  return `<p>The target <code>${esc(r.url || "")}</code> was assessed and assigned an
    overall risk grade of <b>${esc(grade)}</b> (score ${risk.score}/100), indicating
    ${posture}. ${list}</p>`;
}

function buildRecommendations(r) {
  const recs = [];
  if ((r.security || []).some((f) => /content-security-policy/i.test(f.title)))
    recs.push("Implement a strict Content-Security-Policy to mitigate XSS.");
  if ((r.security || []).some((f) => /hsts|strict-transport/i.test(f.title)))
    recs.push("Enable HTTP Strict Transport Security (HSTS) with a long max-age.");
  if ((r.secrets || []).length)
    recs.push("Rotate any exposed credentials immediately and remove secrets from client-side code.");
  if ((r.exposures || []).length)
    recs.push("Block public access to VCS metadata (.git/.svn), .env and backup files at the web-server level.");
  if ((r.tech || []).some((t) => (t.cves || []).length))
    recs.push("Upgrade outdated components to patched versions to remediate known CVEs.");
  if ((r.security || []).some((f) => /cors/i.test(f.title)))
    recs.push("Tighten CORS policy — avoid wildcard origins combined with credentials.");
  if (!recs.length)
    recs.push("Maintain current controls and schedule periodic re-assessment.");
  recs.push("Conduct manual penetration testing to validate and expand on these automated findings.");
  return recs.map((x) => `<li>${esc(x)}</li>`).join("");
}

// ─── Handoff exports ────────────────────────────────────────────────────
// Package the current report so the operator can hand it off to specialised
// exploitation tooling. ReconHound finds; these files give downstream tools
// (Nuclei, Metasploit, or humans reading a Markdown bug-bounty writeup) the
// exact starting point without re-running discovery.

function targetOrigin() {
  try { return new URL(lastReport?.url || currentTab?.url || "").origin; }
  catch { return ""; }
}
function slug() {
  try { return new URL(lastReport?.url || currentTab?.url || "").host.replace(/[^\w.-]/g, "_"); }
  catch { return "target"; }
}

// A. Nuclei targets file.
// Emits both a targets.txt and a run.sh script showing recommended template
// selection based on what ReconHound already fingerprinted.
function exportNuclei() {
  if (!lastReport) return;
  const origin = targetOrigin();
  const exposures = lastReport.exposures || [];
  const tech = lastReport.tech || [];
  const wp = lastReport.wordpress;
  const waf = lastReport.waf?.primary;

  const targets = new Set([origin]);
  exposures.forEach((e) => { if (e.url) targets.add(e.url); });
  (lastReport.activeScan || []).forEach((e) => { if (e.url) targets.add(e.url); });

  // Build a recommended template selector.
  const tags = new Set();
  if (wp?.version || tech.some((t) => t.tech === "WordPress")) tags.add("wordpress");
  if (tech.some((t) => /Actuator|Spring/i.test(t.tech))) tags.add("spring");
  if (tech.some((t) => /Tomcat|JBoss|WebLogic/i.test(t.tech))) tags.add("tomcat");
  if (exposures.some((e) => /git|svn|hg/i.test(e.id || ""))) tags.add("exposed-panels,exposures");
  if (exposures.some((e) => /swagger|openapi|graphql/i.test(e.id || ""))) tags.add("api");
  if (exposures.some((e) => /actuator/i.test(e.id || ""))) tags.add("spring,exposures");
  if (exposures.some((e) => /takeover/i.test(e.id || ""))) tags.add("takeover");
  if (waf) tags.add("waf-detect");
  if (!tags.size) tags.add("technologies,exposures,default-logins,cves");

  const cveTags = tech.flatMap((t) => (t.cves || []).slice(0, 3).map((c) => c.id.toLowerCase())).slice(0, 20);

  const targetsTxt = [...targets].join("\n") + "\n";
  const cmd = `# ReconHound → Nuclei handoff · ${new Date().toISOString()}
# target: ${origin}
# WAF: ${waf ? waf.name : "not fingerprinted"}
#
# Run against the enumerated targets:
nuclei -l targets.txt \\
  -tags ${[...tags].join(",")} \\
  -severity medium,high,critical \\
  -rate-limit 30 \\
  -stats
${cveTags.length ? `\n# Or check the specific CVEs ReconHound correlated:\nnuclei -l targets.txt -id ${cveTags.join(",")} -stats\n` : ""}
# Attack chains ReconHound identified (see markdown for full context):
${(lastReport.attackChains || []).map((c) => `#  · ${c.severity} · ${c.title}`).join("\n")}
`;

  const packName = `reconhound-nuclei-${slug()}.txt`;
  const zip = `${cmd}\n\n# ─── targets.txt ────────────────────────────────\n${targetsTxt}`;
  download(new Blob([zip], { type: "text/plain" }), packName);
}

// B. Metasploit resource script (.rc)
// Only generates use commands for CVEs that are on CISA KEV — real modules
// exist for those. We do NOT auto-set RHOSTS to the target; the operator
// must uncomment the SET commands. This forces a human review before firing.
function exportMetasploit() {
  if (!lastReport) return;
  const host = (() => { try { return new URL(lastReport.url).host; } catch { return "TARGET"; } })();
  const port = (() => { try { const u = new URL(lastReport.url); return u.port || (u.protocol === "https:" ? 443 : 80); } catch { return 443; } })();
  const scheme = (() => { try { return new URL(lastReport.url).protocol.replace(":", ""); } catch { return "https"; } })();

  const kevRows = [];
  for (const t of (lastReport.tech || [])) {
    for (const c of (t.cves || [])) {
      if (!c.kev) continue;
      kevRows.push({
        cve: c.id,
        tech: t.tech,
        version: t.version || "?",
        epss: c.epss ? (c.epss * 100).toFixed(1) + "%" : "-",
        exploitDb: c.exploitDb || `https://www.exploit-db.com/search?cve=${c.id}`
      });
    }
  }

  const header = `# ReconHound → Metasploit handoff · ${new Date().toISOString()}
# target: ${lastReport.url}
# author: Rhishinathvarma Marimuthu
#
# This resource file lists KEV-flagged CVEs correlated by ReconHound. It is
# INTENTIONALLY inert: the "use" lines are commented, and RHOSTS is not set.
# The operator must:
#   1. locate the correct module for each CVE (search cve:CVE-YYYY-NNNN)
#   2. review the module's targets/options
#   3. confirm scope authorisation
#   4. uncomment + set RHOSTS/RPORT before running
#
# Then load with:  msfconsole -r ${slug()}.rc
#
# ─── setup ──────────────────────────────────────
setg RHOSTS ${host}
setg RPORT ${port}
setg SSL ${scheme === "https" ? "true" : "false"}
setg VHOST ${host}
# setg PROXIES socks5:127.0.0.1:9050    # uncomment if pivoting through Tor/proxy

# ─── KEV CVEs correlated on this target ─────────
`;

  if (!kevRows.length) {
    const body = `# No CISA KEV entries were correlated for the detected stack.
# ReconHound found ${(lastReport.tech || []).reduce((n, t) => n + (t.cves || []).length, 0)} CVE(s)
# — cross-reference them manually via 'search cve:...' inside msfconsole.
`;
    download(new Blob([header + body], { type: "text/plain" }), `reconhound-msf-${slug()}.rc`);
    return;
  }

  const rows = kevRows.map((r) => `
# ${r.cve} · ${r.tech} ${r.version} · EPSS ${r.epss} · KEV ✓
# ExploitDB refs: ${r.exploitDb}
# search cve:${r.cve}
# use exploit/...           # <— locate module manually, then uncomment below
# set RHOSTS ${host}
# set RPORT ${port}
# check
# exploit -j
`).join("");

  download(new Blob([header + rows], { type: "text/plain" }), `reconhound-msf-${slug()}.rc`);
}

// C. Markdown bug-bounty writeup — structured for pasting into HackerOne /
// Bugcrowd / Jira / GitHub Issues. Includes evidence blocks + attack chains.
function exportMarkdown() {
  if (!lastReport) return;
  const r = lastReport;
  const risk = r.risk || {};
  const now = new Date();
  const lines = [];

  lines.push(`# Security Assessment — ${r.url || "target"}`);
  lines.push(``);
  lines.push(`**Report ID:** RH-${now.getTime().toString(36).toUpperCase()}  `);
  lines.push(`**Generated:** ${now.toISOString()}  `);
  lines.push(`**Author:** Rhishinathvarma Marimuthu (ReconHound v1.6)  `);
  lines.push(`**Overall risk:** ${risk.grade || "?"} — ${risk.score || 0}/100  `);
  lines.push(``);
  if (r.waf?.primary) {
    lines.push(`**Fronting WAF:** ${r.waf.primary.name}`);
    lines.push(``);
  }

  // Summary
  const c = risk.counts || {};
  lines.push(`## Summary`);
  lines.push(``);
  lines.push(`| Severity | Count |`);
  lines.push(`|----------|------:|`);
  lines.push(`| CRITICAL | ${c.CRITICAL || 0} |`);
  lines.push(`| HIGH     | ${c.HIGH || 0} |`);
  lines.push(`| MEDIUM   | ${c.MEDIUM || 0} |`);
  lines.push(`| LOW      | ${c.LOW || 0} |`);
  lines.push(``);

  // Attack chains
  if ((r.attackChains || []).length) {
    lines.push(`## Attack Chains`);
    lines.push(``);
    for (const ch of r.attackChains) {
      lines.push(`### ${ch.title}  \`${ch.severity}\``);
      lines.push(``);
      ch.stages.forEach((s, i) => lines.push(`${i + 1}. ${s}`));
      lines.push(``);
      lines.push(`**Impact:** ${ch.impact || ""}`);
      lines.push(``);
      if (ch.evidence?.length) {
        lines.push(`**Evidence:** ${ch.evidence.map((e) => "`" + e + "`").join(", ")}`);
        lines.push(``);
      }
    }
  }

  // Findings by category
  const withEvidence = (e) => {
    if (!e.evidence) return "";
    const ev = e.evidence;
    const reqH = Object.entries(ev.request?.headers || {}).map(([k, v]) => `${k}: ${v}`).join("\n") || "(none)";
    const resH = Object.entries(ev.response?.headers || {}).map(([k, v]) => `${k}: ${v}`).join("\n") || "(none)";
    return `

<details><summary>📎 Evidence — captured ${ev.capturedAtDisplay || ev.capturedAt}</summary>

**Request**
\`\`\`http
${ev.request?.method || "GET"} ${ev.request?.url || ""}
${reqH}
\`\`\`

**Response** — HTTP ${ev.response?.status ?? "?"} (${ev.response?.bodyBytes ?? 0}B)
\`\`\`http
${resH}
\`\`\`

${ev.response?.bodyPreview ? "```\n" + ev.response.bodyPreview + "\n```" : ""}

</details>
`;
  };

  const sections = [
    { title: "Verified Exposures & Bypasses", items: r.exposures || [] },
    { title: "Security Header / Cookie Findings", items: r.security || [] },
    { title: "Credential & Secret Detections", items: r.secrets || [] }
  ];
  for (const sec of sections) {
    if (!sec.items.length) continue;
    lines.push(`## ${sec.title}`);
    lines.push(``);
    for (const f of sec.items) {
      lines.push(`### \`${f.severity}\` ${f.title}`);
      lines.push(``);
      if (f.url) lines.push(`- **URL:** ${f.url}`);
      if (f.detail) lines.push(`- **Detail:** ${f.detail}`);
      if (f.technique) lines.push(`- **Technique:** \`${f.technique}\``);
      if (f.verificationScore) lines.push(`- **Verification:** ${f.verificationScore}`);
      lines.push(``);
      lines.push(withEvidence(f));
    }
  }

  // Tech stack + CVEs
  if ((r.tech || []).length) {
    lines.push(`## Detected Stack & CVEs`);
    lines.push(``);
    for (const t of r.tech) {
      lines.push(`### ${t.tech}${t.version ? " " + t.version : ""}`);
      if (t.outdated) {
        const o = t.outdated;
        lines.push(`- ⚠️  ${o.eol ? "**END-OF-LIFE**" : "outdated"}${o.latest ? ` (latest: ${o.latest})` : ""}${o.eolDate && o.eolDate !== "unsupported" ? ` — EOL ${o.eolDate}` : ""}`);
      }
      if (t.cves?.length) {
        lines.push(``);
        for (const cve of t.cves.slice(0, 10)) {
          const tags = [cve.severity, cve.kev ? "**KEV**" : null, cve.ransomware ? "**RANSOMWARE**" : null].filter(Boolean).join(", ");
          lines.push(`- [${cve.id}](${cve.nvd}) — ${tags}${cve.score ? ` · CVSS ${cve.score}` : ""}${cve.epss ? ` · EPSS ${(cve.epss * 100).toFixed(1)}%` : ""}`);
        }
      }
      lines.push(``);
    }
  }

  // Footer
  lines.push(`---`);
  lines.push(``);
  lines.push(`_Generated by ReconHound v1.6 — Rhishinathvarma Marimuthu. Authorised assessments only._`);

  const blob = new Blob([lines.join("\n")], { type: "text/markdown" });
  download(blob, `reconhound-${slug()}-${now.toISOString().slice(0, 10)}.md`);
}

// XSS-tool handoff export.
// ReconHound does DETECTION (context-classified reflections, DOM sinks,
// postMessage listeners, defence-posture score). Actual XSS payload delivery
// and verification is the job of a dedicated tool operating in the operator's
// test environment. This export packages the surface we identified into the
// standard input formats those tools accept:
//
//   · a plain URL-with-parameters target list (universal — accepted by every
//     XSS scanner as `-l targets.txt` or piped in)
//   · a per-parameter position file with contexts (for a fuzzer that
//     understands where each param lands)
//   · a Burp Intruder-style payload-position file (§marker§ placeholders)
//
// We do NOT embed payloads. We do NOT reference specific vendor tools.
function exportXssHandoff() {
  if (!lastReport) return;
  const r = lastReport;
  const surface = (r.xssSurface) || null;

  // 1. Universal targets list (URLs + params + context)
  const now = new Date();
  const targets = new Set();
  const perParam = [];
  // Reflection findings from active scan
  for (const e of (r.exposures || [])) {
    if (!e.xssSurface || !e.xssSurface.param) continue;
    targets.add(e.url);
    perParam.push({
      url: e.url,
      param: e.xssSurface.param,
      context: e.xssSurface.context,
      reflections: e.xssSurface.reflections || 1,
      severity: e.severity
    });
  }
  // Endpoint routes discovered by the endpoint extractor that carry query params
  for (const ep of (r.endpoints || [])) {
    try {
      const u = new URL(ep.path, r.url);
      if (u.search) targets.add(u.href);
    } catch (_) {}
  }

  const preamble = [
    `# ReconHound → XSS-verification-tool handoff`,
    `# generated: ${now.toISOString()}`,
    `# target: ${r.url || ""}`,
    `# author: Rhishinathvarma Marimuthu`,
    `#`,
    `# ReconHound identified the following XSS-attack surface. Payload delivery`,
    `# and confirmation is intentionally NOT done here — feed this file to a`,
    `# dedicated XSS verification tool of your choice, running against a target`,
    `# you are authorised to test.`,
    `#`,
    `# Defence posture: ${surface?.defence?.grade || "?"} (${surface?.defence?.score || 0}/100)`,
    `# Sanitizers detected: ${(surface?.sanitizers || []).map((s) => s.name).join(", ") || "none"}`,
    ``
  ].join("\n");

  // A. targets.txt (plain URL list)
  const targetsTxt = [...targets].join("\n") + "\n";

  // B. per-parameter TSV with context
  const tsvLines = ["url\tparameter\tcontext\treflections\tseverity"];
  for (const p of perParam) tsvLines.push(`${p.url}\t${p.param}\t${p.context}\t${p.reflections}\t${p.severity}`);
  const tsv = tsvLines.join("\n") + "\n";

  // C. §-marker (Burp Intruder-compatible) URLs
  const markerLines = [];
  for (const p of perParam) {
    try {
      const u = new URL(p.url);
      const value = u.searchParams.get(p.param);
      // Wrap the parameter's value with § markers so an operator running an
      // Intruder-family tool can drop payloads at that position directly.
      u.searchParams.set(p.param, `§${value || ""}§`);
      markerLines.push(u.toString().replace(/%C2%A7/g, "§"));
    } catch (_) {}
  }

  // D. DOM-XSS + postMessage summary (informational — for the operator's plan)
  const domLines = ["# DOM-XSS sinks worth manually tracing user-input flow to:"];
  for (const s of (surface?.sinks || [])) {
    domLines.push(`#   [${s.severity}] ${s.vector} — ${s.name} (${s.count} occurrence${s.count !== 1 ? "s" : ""})`);
  }
  const pmLines = ["# postMessage listeners:"];
  for (const l of (surface?.postMessageListeners || [])) {
    pmLines.push(`#   [${l.risk}] origin-check=${l.hasOriginCheck ? "yes" : "NO"} — ${(l.preview || "").slice(0, 80)}`);
  }

  const combined = [
    preamble,
    `# ─── section A · target URL list (one per line) ────────────────────`,
    targetsTxt,
    ``,
    `# ─── section B · per-parameter TSV (url, param, context, reflections, severity) ───`,
    tsv,
    ``,
    `# ─── section C · Intruder-style position URLs (§value§ marks the parameter) ───`,
    markerLines.join("\n"),
    ``,
    ``,
    `# ─── section D · DOM-XSS attack-surface intel ─────────────────────`,
    domLines.join("\n"),
    ``,
    pmLines.join("\n"),
    ``,
    `# ─── verification checklist for the operator ─────────────────────`,
    `#`,
    `# For each row in section B, in your XSS verification tool of choice:`,
    `#   · html-text        → confirm '<', '>', '"' encoding`,
    `#   · attr-quoted      → confirm the quote character is encoded`,
    `#   · attr-unquoted    → confirm whitespace / '=' / '>' is encoded (highest risk)`,
    `#   · attr-event       → confirm no ' or " is allowed to escape the on* handler`,
    `#   · attr-href-src    → confirm javascript: / data: schemes are rejected`,
    `#   · attr-style       → confirm expression() and url(javascript:) are blocked`,
    `#   · js-string        → confirm '"'  and  '\\' are escaped inside the JS string`,
    `#   · js-block         → confirm the value is contextually-encoded, not templated raw`,
    `#   · css-block        → confirm CSS expression / @import is blocked`,
    `#   · html-comment     → verify server never renders comments unescaped`,
    `#`,
    `# Never fire payloads against production without written authorisation.`
  ].join("\n");

  download(new Blob([combined], { type: "text/plain" }), `reconhound-xss-handoff-${slug()}-${now.toISOString().slice(0,10)}.txt`);
}

// D. SARIF v2.1.0 export — enterprise pipelines (GitHub Advanced Security,
// Azure DevOps) ingest this format directly. Report generation is done in
// the service worker so we get the full enriched taxonomy.
// Context-menu handoff: user selected text and chose "Analyze as JWT".
// We inline a lightweight base64url decode + display in the KEYS panel.
function analyzeSelectionAsJwt(tokenText) {
  if (!tokenText || typeof tokenText !== "string") return;
  // Basic JWT shape check.
  const parts = tokenText.trim().split(".");
  if (parts.length !== 3) return;
  function b64uDecode(s) {
    let str = String(s || "").replace(/-/g, "+").replace(/_/g, "/");
    while (str.length % 4) str += "=";
    try {
      const bin = atob(str);
      const bytes = new Uint8Array(bin.length);
      for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
      return new TextDecoder().decode(bytes);
    } catch { return null; }
  }
  const h = b64uDecode(parts[0]);
  const p = b64uDecode(parts[1]);
  if (!h || !p) return;
  let header, payload;
  try { header = JSON.parse(h); payload = JSON.parse(p); } catch { return; }
  // Click the KEYS tab, then paint a synthetic JWT into it.
  const keysTab = document.querySelector('.tab[data-tab="secrets"]');
  if (keysTab) keysTab.click();
  const panel = document.getElementById("secrets");
  if (!panel) return;
  const synthetic = {
    algorithm: header.alg || "unknown",
    typ: header.typ || null,
    kid: header.kid || null,
    issuer: payload.iss || null,
    subject: payload.sub || null,
    audience: payload.aud || null,
    issuedAt: typeof payload.iat === "number" ? new Date(payload.iat * 1000).toISOString() : null,
    expiresAt: typeof payload.exp === "number" ? new Date(payload.exp * 1000).toISOString() : null,
    header, payloadSample: payload, issues: [], verdict: "LOW",
    source: "context-menu selection"
  };
  panel.innerHTML = `<div class="section-label">JWT from context menu</div>` + renderJwt(synthetic) + panel.innerHTML;
}

function exportSarif() {
  if (!currentTab) return;
  chrome.runtime.sendMessage(
    { type: "RH_EXPORT_SARIF", tabId: currentTab.id },
    (res) => {
      if (chrome.runtime.lastError || !res || !res.ok) {
        console.warn("[ReconHound] SARIF export failed:", chrome.runtime.lastError || res?.error);
        return;
      }
      const blob = new Blob([JSON.stringify(res.sarif, null, 2)], { type: "application/sarif+json" });
      download(blob, `reconhound-${slug()}-${new Date().toISOString().slice(0,10)}.sarif.json`);
    }
  );
}

// E. Bulk scan — iterate every open tab and produce a combined markdown roll-up.
function runBulkScan() {
  const out = document.getElementById("activeResults") || document.getElementById("stack");
  if (out) out.innerHTML = `<p class="empty">// scanning all open tabs — hold tight (up to 30s)…</p>`;
  chrome.runtime.sendMessage({ type: "RH_BULK_SCAN" }, (res) => {
    if (chrome.runtime.lastError || !res || !res.ok) {
      if (out) out.innerHTML = `<p class="empty">// bulk scan failed: ${escapeHtml(chrome.runtime.lastError?.message || res?.error || "unknown")}</p>`;
      return;
    }
    const now = new Date();
    const lines = [];
    lines.push(`# ReconHound Bulk Scan — ${now.toISOString()}`);
    lines.push(``);
    lines.push(`**Tabs scanned:** ${res.count}  `);
    if (res.skipped) lines.push(`**Tabs skipped (unauthorised host):** ${res.skipped}  `);
    lines.push(`**Author:** Rhishinathvarma Marimuthu (ReconHound v1.6)`);
    lines.push(``);
    lines.push(`| Grade | Score | C | H | M | L | Exposures | Secrets | CVEs | URL |`);
    lines.push(`|-------|------:|--:|--:|--:|--:|----------:|--------:|-----:|-----|`);
    // Sort by risk score descending.
    (res.results || []).sort((a, b) => (b.score || 0) - (a.score || 0));
    for (const r of (res.results || [])) {
      if (r.error) { lines.push(`| ? | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | ${r.url} (error) |`); continue; }
      const c = r.counts || {};
      lines.push(`| ${r.grade} | ${r.score} | ${c.CRITICAL||0} | ${c.HIGH||0} | ${c.MEDIUM||0} | ${c.LOW||0} | ${r.exposureCount} | ${r.secretCount} | ${r.cveCount} | ${r.url} |`);
    }
    lines.push(``);
    lines.push(`---`);
    lines.push(`_Generated by ReconHound v1.6 — authorised assessments only._`);
    const blob = new Blob([lines.join("\n")], { type: "text/markdown" });
    download(blob, `reconhound-bulk-${now.toISOString().slice(0,10)}.md`);
    if (out) out.innerHTML = `<p class="empty">// bulk scan complete — ${res.count} tab(s) scanned${res.skipped ? `, ${res.skipped} skipped (not authorised)` : ""}, roll-up downloaded</p>`;
  });
}

function download(blob, filename) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

function esc(s) {
  return String(s).replace(/[&<>"']/g, (c) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
  }[c]));
}

// safeHref: refuse anything that isn't http/https or a same-page fragment.
// This defends the extension popup (a privileged chrome-extension:// origin)
// from `javascript:` / `data:text/html,` URIs smuggled in via target-derived
// URLs (endpoint extractor, exposure URLs, path prober, etc.).
function safeHref(u) {
  if (u == null) return "#";
  const s = String(u).trim();
  if (!s || s === "#") return "#";
  try {
    const parsed = new URL(s, "https://placeholder.invalid/");
    if (parsed.protocol === "http:" || parsed.protocol === "https:") {
      return parsed.href.startsWith("https://placeholder.invalid/") ? "#" : parsed.href;
    }
    return "#";
  } catch { return "#"; }
}

function escapeHtml(s) {
  return String(s).replace(/[&<>"']/g, (c) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
  }[c]));
}

try { runMatrixSplash(); } catch (_) {}
init().catch((e) => {
  const s = document.getElementById("stack");
  if (s) s.innerHTML = `<p class="empty">// init error: ${String(e && e.message || e)}</p>`;
});

