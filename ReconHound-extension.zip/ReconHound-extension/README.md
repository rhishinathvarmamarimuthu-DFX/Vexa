# 🐕 ReconHound

**Author:** Rhishinathvarma Marimuthu
**Version:** 1.6.0

**Tech-stack fingerprinting & CVE reconnaissance browser extension** for authorized security assessments and penetration testing.

ReconHound passively fingerprints the technologies powering any website — frontend frameworks, backend stacks, web servers, CMSs, and inferred databases — then correlates detected versions against known CVEs from the NVD, with direct links to ExploitDB and GitHub Security Advisories.

---

## ✨ Features

- **Frontend detection** — React, Vue.js, Angular/AngularJS, jQuery (with version), Svelte, Next.js, Nuxt.js, Backbone, Bootstrap
- **Backend / server detection** — nginx, Apache, IIS, LiteSpeed, Caddy, PHP, Express, ASP.NET, Java Servlet (versions via headers)
- **CMS detection** — WordPress, Drupal, Shopify
- **Database inference** — MySQL, PostgreSQL, Oracle, SQLite, MongoDB, MS SQL Server (from error-string leaks)
- **🧩 JS-library scanner** — identifies bundled libraries **and real versions** from actually-loaded `<script>`/`<link>` URLs and live runtime globals (jQuery, lodash, Moment, Axios, D3, Chart.js, Three.js, GSAP, …)
- **🎯 Real CVE correlation** — NVD 2.0 lookup with **true CPE version-range matching**; only CVEs that actually affect the detected version are shown (`confirmed`), name-only matches are flagged `unconfirmed`
- **Exploit references** — one-click links to ExploitDB and GHSA
- **🔑 Secret & credential scanning** — 70+ provider detectors (AWS, Azure, GCP, GitHub/GitLab, Stripe, Slack, Discord, OpenAI, Anthropic, Twilio, npm, PyPI, Kubernetes, private keys, JWT, DB URIs, Bearer tokens…) with Shannon-entropy gating; scans inline scripts, page HTML, and fetched JS bundles (secrets redacted)
- **🗂️ VCS & config exposure verification** — content-verified `/.git` (with structural parsing: HEAD, config, logs, index), `/.svn`, `/.hg`, `/.bzr`, `/.env` variants, `/.aws/credentials`, `/.ssh/id_rsa`, `wp-config.php.bak` and more
- **🕸️ WordPress deep audit** — version + user + plugin + theme enumeration, XML-RPC surface, debug-log exposure, backup archives, high-risk-plugin advisory flagging
- **⚙️ Web-app framework probes** — Spring Actuator (`/env`, `/heapdump`, `/mappings`), phpinfo, Tomcat/JBoss/WebLogic consoles, Laravel Telescope, Symfony profiler, Go pprof/expvar, Adminer/phpMyAdmin, Docker registry, Kubernetes API, Swagger/OpenAPI
- **🔗 Endpoint/API extraction** — pulls API paths & URLs from fetched JS, classified (graphql/admin/auth/api/data)
- **🗺️ Source-map leak detection** — finds exposed `.map` files that disclose original client source
- **🧬 GraphQL introspection check** — detects open introspection on common GraphQL endpoints
- **🌐 CORS misconfiguration analysis** — flags `ACAO:*` + credentials, `null` origin, credentialed reflection
- **🛡️ Security-header analysis** — flags missing CSP, HSTS, X-Frame-Options, X-Content-Type-Options, Referrer-Policy, Permissions-Policy, and weak CSP
- **🍪 Cookie security analysis** — flags cookies missing HttpOnly / Secure / SameSite
- **🔎 Info-leak detection** — surfaces version-disclosing headers (Server, X-Powered-By, etc.)
- **⚡ Active scan (consent-gated)** — probes real sensitive paths + verifies VCS/secret-file exposure, source maps, and GraphQL introspection
- **🔢 Toolbar badge** — live count of security findings + secrets (red = High/Critical)
- **📜 Scan history & diff** — saves compact snapshots per target and shows what changed (added/removed findings, grade & score delta) between scans
- **🧩 Custom secret rules** — define your own `Name | SEVERITY | regex` detectors in settings
- **⚙️ Settings page** — NVD API key + feature toggles + custom rules + clear-history
- **📄 Export** — JSON, or a **professionally graded HTML report** (cover page, exec summary, methodology, recommendations) with **dark/light + print/PDF** toggles

> **Real data only:** every result is derived from live signals — actual response
> headers, real loaded resource URLs, runtime globals, and live NVD data. There is
> no mock/sample data anywhere in the pipeline.

---

## 📦 Installation (Developer Mode)

Browsers can't install a raw `.zip` directly in dev mode — you load the *unpacked*
folder. Use the prebuilt `ReconHound-extension.zip`:

1. **Unzip** `ReconHound-extension.zip` to a folder (it already contains `manifest.json` at the root).
2. Open `chrome://extensions` (or `edge://extensions`).
3. Enable **Developer mode** (top-right).
4. Click **Load unpacked** and select the unzipped folder.
5. Browse to a target and click the 🛡 toolbar icon.

### Or install the signed package (`.crx`)

1. Open `chrome://extensions` and enable **Developer mode**.
2. **Drag `reconhound.crx`** onto the page and confirm **Add extension**.

> `reconhound.pem` is the private signing key — keep it secret and reuse it to
> publish updates so the extension keeps the same ID. Outside of Developer mode,
> Chrome only auto-installs CRX packages from the Web Store.

> Icons are pre-generated, so it works immediately with no extra steps.

---

## 🗂️ Project Structure

```
reconhound/
├── manifest.json                 # Manifest V3 config
├── src/
│   ├── background/
│   │   └── service-worker.js     # Header/cookie capture + CVE matching
│   ├── content/
│   │   └── detector.js           # In-page framework detection
│   ├── popup/
│   │   ├── popup.html
│   │   ├── popup.css
│   │   └── popup.js              # UI (Stack + Security tabs) + JSON export
│   ├── options/
│   │   ├── options.html
│   │   └── options.js            # Settings: NVD key + toggles
│   └── engine/
│       ├── fingerprints.js       # Header/cookie/DB signature database
│       ├── js-libraries.js       # JS-library URL/global scanner
│       ├── cve-matcher.js        # NVD 2.0 client + CPE version-range matching
│       ├── security-analyzer.js  # Header/cookie/CORS security checks
│       ├── secret-scanner.js     # Provider-specific secret detectors (+custom rules)
│       ├── wordpress-probe.js    # WordPress fingerprint & safe verification probes
│       ├── webapp-probe.js       # Framework/actuator/backup/API-docs exposure
│       ├── vcs-exposure.js       # .git/.svn/.hg structural exposure parsing
│       ├── exposure-checker.js   # Content-verified .git/.env exposure checks
│       ├── endpoint-extractor.js # Endpoint/subdomain/param extraction
│       ├── probe-advanced.js     # Source-map & GraphQL introspection probes
│       ├── risk-score.js         # Weighted risk grade (A–F)
│       ├── history.js            # Scan history snapshots & diff
│       └── path-prober.js        # Active sensitive-path probing
└── assets/icons/                 # icon16/48/128.png (auto-generated)
```

---

## 🔑 NVD API Key (optional)

The NVD API allows 5 requests / 30s without a key and 50 / 30s with one.
Get a free key at <https://nvd.nist.gov/developers/request-an-api-key> and pass it
to `lookupCVEs(product, version, apiKey)` in `src/engine/cve-matcher.js`.

---

## ⚠️ Legal & Ethical Use

ReconHound is intended **only** for systems you own or are **explicitly authorized**
to test. Unauthorized scanning or exploitation may be illegal. You are responsible
for complying with all applicable laws and rules of engagement.

