# Changelog

## [1.6.0] — 2026-06-26 · "Visibility" release

**Author:** Rhishinathvarma Marimuthu

### Added — detection breadth
- **CDN / WAF fingerprinting**: Akamai, Fastly, AWS CloudFront, Imperva Incapsula,
  Sucuri, Azure Front Door, Vercel, Netlify — via dedicated edge headers
  (`cf-ray`, `x-served-by`, `x-amz-cf-id`, `x-iinfo`, `x-sucuri-id`, …).
- **SaaS / analytics / payment / auth fingerprinting** (`SAAS_SIGNATURES`):
  Google Tag Manager, Google Analytics (UA + GA4), Segment, Mixpanel, Hotjar,
  Amplitude, Stripe.js, Stripe Checkout, PayPal, Braintree, Razorpay, Auth0,
  Okta, Firebase Auth, Clerk, Sentry, Intercom, Zendesk, Google Maps, reCAPTCHA,
  Cloudflare Turnstile. Detected from loaded script URLs + inline code.
- **Favicon-hash fingerprinting** (`favicon-hash.js`): computes the Shodan-
  compatible MurmurHash3 of `/favicon.ico` (verified against the Python `mmh3`
  reference vector), matches a curated default-favicon table (Tomcat, phpMyAdmin,
  GitLab, Jenkins, Grafana, pfSense, FortiGate, Citrix, …), and emits a ready
  `http.favicon.hash:` Shodan pivot link. Runs in the consent-gated active scan.
- **More app/infra hint headers**: Envoy, Kong, Rails (`x-runtime`), Rack,
  LiteSpeed Cache, Wix.

### Added — confidence scoring (`confidence.js`)
- Every technology detection now carries a **0–100 confidence score** computed by
  corroborating distinct signals (HTTP header, cookie, runtime global, DOM marker,
  versioned resource URL, SaaS signature, DB-error leak) plus a bonus for a
  concrete extracted version. The same tech seen via multiple independent signals
  scores higher (e.g. React via DOM marker + runtime global + version = 100%).
- Confidence label (high / medium / low / tentative) and the contributing signal
  list are shown as a badge in the popup and exported in JSON/CSV. Directly serves
  the true-positive goal: low-confidence detections are visually distinguishable.

### Added — passive posture checks (`security-analyzer.js`, `detector.js`)
- **Subresource Integrity (SRI) coverage**: flags cross-origin `<script>`/`<link>`
  loaded without an `integrity=` hash (supply-chain risk).
- **Mixed-content detection**: HTTP subresources on an HTTPS page.
- **Insecure form detection**: forms posting to `http://` or password fields on
  non-HTTPS paths.
- **Cookie-prefix validation** (`__Secure-` / `__Host-`): flags cookies using a
  security prefix without meeting its browser-enforced requirements.

### Added — AI Brain cross-correlation (`ai-brain.js`)
- **Correlated attack paths**: reasons over the whole report to surface multi-
  finding chains (e.g. exposed `.env` + detected backend → credential-to-backend
  path; exposed `.git` → source recovery → secret mining; weaponized CVE +
  reachable admin endpoint; no-CSP + reflected input → XSS likelihood; client
  secrets + permissive CORS → amplified exposure). Each chain lists steps and a
  recommendation. **No execution — explanation only.**
- **Remediation prioritization**: orders fixes by *impact ÷ effort* so the fastest
  risk-reducing wins surface above strictly-higher-severity-but-painful items.

### Added — reporting / visibility
- **CSV export** button (SIEM / spreadsheet ingestion): flat findings table across
  CVEs, technologies, misconfigurations, secrets, exposures, endpoints, paths.
- Report now includes **Correlated Attack Paths**, **Remediation Priority table**,
  and the **favicon Shodan pivot** in the attack-surface section.

### Notes
- All new capability is detection / intelligence / reporting. No autonomous
  exploitation, no payload firing, and the per-host active-scan consent gate is
  unchanged. Favicon fetch and all active checks remain behind that gate.

---

## [1.5.0] — 2026-06-26

**Author:** Rhishinathvarma Marimuthu

### Fixed
- **CRITICAL** — `src/engine/safe-checks.js` had a stray `m` character at byte 0,
  causing `ReferenceError: m is not defined` at module evaluation and killing the
  service worker. Extension was completely non-functional in v1.4.0.
- **HIGH** — Repackaged distribution ZIP using POSIX forward-slash paths.
  Previous packaging used Windows backslashes that broke `Load unpacked` on some
  extractors.
- **HIGH** — XSS via unescaped URLs in `href` attributes throughout the popup
  and the exported HTML report. New `safeAttr()` / `safeHref()` helpers apply
  a scheme allow-list (`https:`, `http:`, `mailto:`, `#`) and HTML-attribute
  encoding to every interpolated URL. Affected: `renderExposure`,
  `renderEndpoint`, `renderPathHit`, `renderTech` (×5), `renderBrainRow` (×5),
  the report's `exportHtml` and `buildBrainBlock`.

### Added
- **Author attribution** — `Rhishinathvarma Marimuthu` is now declared in
  `manifest.json` (`author` field), the popup footer, the options-page header,
  and the exported report's cover page, footer, and metadata block.
- **Content-Security-Policy meta tags** on `popup.html` and `options.html` for
  defense-in-depth XSS mitigation (`default-src 'self'`).
- **MITRE ATT&CK technique mapping** in the exported report (§9), correlating
  detected finding classes to T1190, T1192, T1213, T1552.001, T1592.002, T1595.002.
- **CWE mapping** per finding in the misconfiguration and secret tables.
- **CVSS vector strings** alongside CVE scores in the report.
- **Reproducibility commands** — every active finding now ships with a one-line
  `curl` command for evidence collection.
- **Lower-Confidence CVE Appendix** (§A) — name-only matches are now segregated
  from version-confirmed matches in the headline counts.
- **Confidence Tiers explainer** (§3) explicitly documents what
  `confirmed` / `possible` / `unconfirmed` mean and how to act on each.
- **Severity-distribution SVG bar** on the report cover for at-a-glance posture.
- **Table of Contents** with anchor links in the report.

### Changed
- **Path-prober is now status-aware.** A 200 on `/admin` is reported at the
  original severity with the note "reachable — content accessible"; a 401/403 is
  downgraded one severity tier and noted as "present but access-controlled —
  endpoint confirmed, content protected." 3xx / 5xx get analyst-useful
  annotations rather than being silently lumped into "exists."
- **Report cover redesigned** — gradient header, six-cell metadata grid,
  prominent grade box with embedded severity chip strip.
- **Section structure expanded** from 9 to 11 (added Methodology & Confidence
  Model, MITRE ATT&CK Coverage, and Lower-Confidence Appendix).

### Retained
- Per-host consent gate on the EXPLOIT (active) tab. This is the load-bearing
  ethical control of the tool; see `SECURITY_REVIEW.md` finding RH-008.
- Non-destructive probe philosophy. No payload-firing, no auth-bypass attempts,
  no autoexploit. The tool surfaces and links to ExploitDB / Metasploit /
  Nuclei / public PoCs so the human operator can take the manual step.

---

## [1.4.0] — 2026-06-23

Original release by Rhishinathvarma Marimuthu. Feature set documented in `README.md`.
