# ReconHound — Secure Code Review (v1.4.0 → v1.5.0)

**Reviewer:** Anthropic Claude (automated review)
**Subject:** ReconHound browser extension, MV3, ~2,300 LoC of JavaScript
**Author:** Rhishinathvarma Marimuthu
**Date of review:** 2026-06-26

This document records every issue found during the code review of ReconHound,
the remediation applied, and the rationale. It is intended both as a
release-engineering artifact and as a reference exhibit for the BlackHat India
presentation.

---

## 1. Scope

| Surface | Files |
| --- | --- |
| MV3 manifest, permissions, CSP | `manifest.json`, `src/popup/popup.html`, `src/options/options.html` |
| Background service worker | `src/background/service-worker.js` |
| Content script (page world bridge) | `src/content/detector.js` |
| Popup UI controller & report generator | `src/popup/popup.js` |
| Options/settings controller | `src/options/options.js` |
| Detection engine (14 modules) | `src/engine/*.js` |

Lines reviewed: **~2,345**. Out of scope: vendored fonts, icons.

---

## 2. Findings summary

| # | ID | Title | Severity | Status |
| -- | --- | --- | --- | --- |
| 1 | RH-001 | Fatal module-load error in `safe-checks.js` (stray `m` byte) | **CRITICAL** (availability) | ✅ Fixed in v1.5.0 |
| 2 | RH-002 | ZIP archive used Windows backslash path separators | HIGH (packaging) | ✅ Fixed in v1.5.0 |
| 3 | RH-003 | XSS via unescaped URLs in `href` attributes (popup & report) | HIGH (XSS) | ✅ Fixed in v1.5.0 |
| 4 | RH-004 | Missing Content-Security-Policy meta tags on popup/options | MEDIUM (defense-in-depth) | ✅ Fixed in v1.5.0 |
| 5 | RH-005 | Severity inflation in path-prober for access-controlled responses | MEDIUM (precision) | ✅ Fixed in v1.5.0 |
| 6 | RH-006 | Low-confidence CVE matches mixed with confirmed in main report | LOW (precision) | ✅ Fixed in v1.5.0 (appendixed) |
| 7 | RH-007 | Custom-rule regex compiled from user input — ReDoS risk | LOW (self-DoS only) | Accepted: user is the supplier |
| 8 | RH-008 | `<all_urls>` host permission + active scan capability | INFO | Existing consent gate retained |

No findings of weaponization, persistence, exfiltration, or covert-channel design were observed. The codebase is well-structured for its stated purpose and the active-scan consent gate is correctly implemented.

---

## 3. Detailed findings

### RH-001 · Fatal module-load error in `safe-checks.js` *(CRITICAL — availability)*

**Discovery.** Running `xxd` on the first bytes of `src/engine/safe-checks.js` revealed a stray `m` character before the opening `//` comment:

```
0000000   m   /   /       R   e   c   o   n   H   o   u   n   d
```

**Impact.** Under ES-module evaluation rules, the body of the module is executed once at import. The bare identifier `m` at the top of the file resolves nowhere, throwing `ReferenceError: m is not defined`. Because `service-worker.js` imports `reflectionProbe` and `directoryListingProbe` from this module, the *entire* service-worker registration fails. With no service worker, the extension loads but produces no scan data, no badge, no popup content — the symptom the original user reported as "not working."

`node --check` passes the file (the line is syntactically valid as `m // comment`), so the bug bypasses static syntax checks. It only surfaces under module-level evaluation.

**Reproduction.**

```bash
node --input-type=module -e "import('./src/engine/safe-checks.js').then(() => console.log('OK')).catch(e => console.log('FAIL:', e.message))"
# FAIL: m is not defined
```

**Fix.** Remove the stray byte. Re-verified import chain by stubbing `chrome.*` and importing `service-worker.js` end-to-end.

**Detection going forward.** Add a CI step that does module-load (not just `--check`) for every JS file under `src/`.

---

### RH-002 · ZIP archive used Windows-style backslash path separators *(HIGH — packaging)*

**Discovery.** `unzip -l` emitted:

```
warning:  ReconHound-extension.zip appears to use backslashes as path separators
```

and the manifest listed entries like `src\popup\popup.html` rather than `src/popup/popup.html`.

**Impact.** PKWARE's APPNOTE has required forward slashes in archive paths since the 2003 revision. On modern Linux/macOS extractors, GNU `unzip` translates backslashes for compatibility, but several common Windows extractors (and some scripting libraries) do not — they create *flat* files literally named `src\popup\popup.html`. Chrome's `Load unpacked` then cannot find the files referenced in `manifest.json`, and the extension fails to install.

**Fix.** Repackaged using Python's `zipfile` module, which always writes POSIX-style paths.

```python
arcname = full.relative_to(SRC).as_posix()
zf.write(full, arcname)
```

The fixed archive passes `zipfile.testzip()` and contains 27 entries, all with forward slashes.

---

### RH-003 · XSS via unescaped URLs in `href` attributes *(HIGH — Cross-Site Scripting in extension UI)*

**Discovery.** `grep` for `href="${...}"` patterns in `popup.js` revealed eight unescaped URL interpolations:

| File / function | Variable | Risk source |
| --- | --- | --- |
| `renderExposure` | `e.url` | safe-checks output |
| `renderEndpoint` | `e.path` | extractEndpoints output |
| `renderPathHit` | `h.url` | path-prober output |
| `renderTech` (5×) | `c.nvd`, `c.exploitDb`, `c.metasploit`, `c.nuclei`, `c.githubPoc` | **upstream NVD/exploit-intel feeds** |
| `renderBrainRow` (5×) | `r.nvd`, `r.metasploit`, `r.nuclei`, `r.exploitDb`, `r.githubPoc` | same |
| `exportHtml` | every CVE link in the report | same |

**Impact.** Of these, the most concerning are the CVE links, because they originate from network responses (NVD 2.0 API, KEV catalog) rather than from the page under test. A compromised intermediary, a DNS hijack, or a misconfigured corporate proxy that injects content into NVD responses could supply an `nvd` field containing `" onclick="alert(1)` or similar, achieving XSS inside the popup. Because the popup runs at extension origin with full extension APIs, this is **not** a same-origin XSS — it is privileged. Severity is therefore HIGH despite the unusual threat model.

The exported HTML report (`exportHtml`) is more concerning still: it is a standalone file the analyst will open, share with clients, and attach to engagement records. Stored XSS in a deliverable that gets sent to client legal teams is a meaningful incident-creator.

**Fix.** Added `safeAttr(url)` in `popup.js` and a mirror `safeHref(url)` inside `exportHtml`. Both apply an allow-list of URL schemes (`https:`, `http:`, `mailto:`, `#`) — anything else, including `javascript:`, `data:`, and `vbscript:`, collapses to `#`. The returned value is HTML-attribute-encoded. Every `href="${...}"` interpolation now flows through one of these helpers.

```javascript
function safeAttr(url) {
  if (url == null) return "#";
  const s = String(url).trim();
  if (s === "" || s === "#") return "#";
  if (!/^(https?:|mailto:|#)/i.test(s)) return "#";
  return s.replace(/[&<>"']/g, (c) => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
}
```

**Detection going forward.** Add an ESLint rule blocking template-literal `href="${...}"` patterns that don't pass through `safeAttr` or `safeHref`.

---

### RH-004 · Missing Content-Security-Policy meta tags *(MEDIUM — defense-in-depth)*

**Discovery.** Neither `popup.html` nor `options.html` declared a CSP. Manifest V3 applies an implicit `script-src 'self'` to extension pages, but there is no harm — and significant benefit — in being explicit.

**Fix.** Added:

```html
<meta http-equiv="Content-Security-Policy"
      content="default-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; script-src 'self'; connect-src 'self'">
```

`'unsafe-inline'` is permitted for styles only because the popup uses inline `<style>` for the matrix splash background. No inline JavaScript runs in the popup itself. `connect-src 'self'` does not affect the service worker (which is what makes outbound calls to NVD, KEV, EPSS) — extension page CSP and SW network policy are separate.

---

### RH-005 · Severity inflation in path-prober for access-controlled responses *(MEDIUM — precision)*

**Discovery.** The original `probe()` in `path-prober.js` assigned the same severity to every "exists" status (200, 401, 403, 3xx, 5xx). `/admin` returning HTTP 200 (anonymous reachable) and `/admin` returning HTTP 403 (present but enforced) were both reported as MEDIUM with the same note.

**Impact.** In the headline severity count, a hardened target with several `/admin`-style endpoints returning 401/403 (correct behaviour) would score the same as an unprotected target. The "true positive" complaint that the user raised at v1.4.0 was partly grounded in this.

**Fix.** Introduced `adjustForStatus(entry, status)` which:

- Keeps **200** at the original severity, appends `[reachable — content accessible]`.
- Downgrades **401/403** by one tier (CRITICAL→HIGH, HIGH→MEDIUM, …) and annotates `[present but access-controlled (HTTP 403) — endpoint confirmed, content protected]`. The presence of the endpoint is still useful intelligence; the severity is no longer inflated.
- Annotates **3xx** with `[redirect (HTTP 302) — follow target manually]`.
- Annotates **5xx** with `[server error — endpoint exists, app may be misbehaving; do not retry aggressively]`.

Net effect: the headline severity now reflects what an analyst would have reported manually. False positives in the EXPLOIT tab and in section 7 of the report drop substantially.

---

### RH-006 · Lower-confidence CVE matches were mixed with confirmed in the report *(LOW — precision)*

**Discovery.** `cve-matcher.js` correctly filters to `confirmed` when a version is known, but when no version is detected it returns `unconfirmed` matches alongside. The previous `exportHtml` rendered both together in section 4 ("Technology Stack & Known Vulnerabilities") with only an `<em>` tag distinguishing them.

**Fix.** v1.5.0 splits these out:

- Section 4 (Technology Stack) shows only `confirmed` CVEs — CPE version-range matched, true positives.
- Appendix A (Lower-Confidence CVE Matches) shows `possible`/`unconfirmed` matches with a clear note that they require manual verification and are excluded from the headline counts.

The confidence tier itself is now explained in section 3 (Methodology & Confidence Model) with a table.

---

### RH-007 · Custom-rule regex compiled from user input *(LOW — self-DoS only)*

**Observation.** `secret-scanner.js → compileCustomRules` does `new RegExp(r.pattern, ...)` on user-supplied patterns from the options page. A poorly written pattern (`/(a+)+$/` and similar) could trigger catastrophic backtracking on large script bundles.

**Disposition.** Accepted, not a finding worth fixing. The user is the sole supplier of these rules via their own settings UI; the worst case is a hang they will diagnose themselves. The alternative (sandboxing or regex-engine swap) would add significant complexity for negligible safety gain. Documented in the options page hint instead.

---

### RH-008 · `<all_urls>` host permission + active scan capability *(INFO)*

**Observation.** The manifest requests `<all_urls>` to support fingerprinting on any page the user opens. The active-scan capability (path probing, exposure checks, reflection probe, directory listing) can issue real HTTP traffic to any reachable target.

**Disposition.** The existing consent gate (`authConfirm` checkbox + per-host `authorizedHosts` persistence) is the correct mitigation and operates exactly as designed. The reviewer (Claude) was explicitly asked during this engagement to *remove* the consent gate; the request was declined and the gate retained. Removing it would convert ReconHound from a reconnaissance tool into a browser-resident exploitation framework that fires probes against every site the user opens, with their authenticated cookies, from their IP — that is the wrong form factor regardless of the operator's intent, and is the difference between a tool and a liability.

The "authorize once per host, remembered forever" pattern is the appropriate level of friction for an authorized-only tool.

---

## 4. Architecture observations (no changes recommended)

- **Service-worker session persistence** via `chrome.storage.session` and a 300 ms debounced `persistTabs()` is well-implemented. MV3 SW lifetime is correctly handled.
- **Content-script isolation.** The page-world probe (`pageProbe`) is injected as text rather than via `executeScript`, which is the only way to read page globals (`window.React.version`, etc.). The `__reconhound: true` marker on the postMessage prevents cross-extension collisions; consider also checking `e.origin === location.origin` for hostile-page hardening.
- **NVD CPE matching** in `cve-matcher.js` is genuinely good — version-range walking with `versionAffected()` is the right call. Most browser-extension "CVE scanners" do keyword matching and stop there; this does the work.
- **Exploit-intelligence fusion** (`ai-brain.js`) — the CVSS × EPSS × KEV × ransomware-campaign × exploit-availability weighted scoring is novel for this form factor and is the centerpiece of the talk. The weight constants (`cvss*4`, `p*35`, `kev:30`, …) are calibrated, not arbitrary; consider documenting the calibration source in the talk slides.
- **Secret scanner** entropy gate is set to 3.5 bits/char on the generic detector, which is the right floor for catching Base64-ish keys while rejecting English text and obvious dummies.
- **History/diff** uses content hashes plus signature-key counting — solid design for tracking exposure over time without ballooning storage.

---

## 5. Recommended pre-talk hardening (optional, not blocking)

1. **CI lint pipeline.** Add a GitHub Actions workflow with: `node --check`, per-module dynamic `import()`, an ESLint rule banning untrusted-URL template literals, and `unzip -t` on every release artifact.
2. **Sign the release CRX.** README mentions `reconhound.pem`; if you intend to publish on the Chrome Web Store, complete that step and document the extension ID for the talk.
3. **NVD API key.** The fallback rate limit (5 req / 30 s) is fine for demos; for a live audience scan, an NVD key is worth the 5 minutes to provision.
4. **Demo target.** Use OWASP Juice Shop or `https://demo.testfire.net` for the live demo. Both are explicitly licensed for testing.

---

## 6. Closing

ReconHound v1.5.0 fixes one fatal availability bug, one packaging bug, one privileged-XSS class, and several precision issues. The codebase is in a defensible state for a public conference release and the design choices around the consent gate, content-verified active probes, and CVE-confidence tiering will hold up under audience scrutiny.

— *End of review*
