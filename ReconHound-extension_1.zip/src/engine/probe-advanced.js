// ReconHound — Source-map & GraphQL introspection probes (ACTIVE)
// Source maps (.map) frequently expose full original source code.
// Open GraphQL introspection reveals the entire API schema.

async function fetchSample(url, opts = {}, timeoutMs = 6000) {
  const controller = new AbortController();
  const t = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const res = await fetch(url, { credentials: "omit", redirect: "manual", signal: controller.signal, ...opts });
    clearTimeout(t);
    return res;
  } catch (_) {
    clearTimeout(t);
    return null;
  }
}

// Probe `${scriptUrl}.map` for each JS bundle; confirm it's a real source map.
export async function checkSourceMaps(scriptUrls = []) {
  const jsUrls = [...new Set((scriptUrls || []).filter((u) => /\.js(\?|$)/i.test(u)))].slice(0, 12);
  const results = [];

  await Promise.all(
    jsUrls.map(async (u) => {
      const mapUrl = u.split("?")[0] + ".map";
      const res = await fetchSample(mapUrl);
      if (!res || res.status >= 400) return;
      const text = (await res.text()).slice(0, 4096);
      if (/"version"\s*:\s*3/.test(text) && /"sources"\s*:/.test(text)) {
        const hasContent = /"sourcesContent"\s*:/.test(text);
        results.push({
          id: "source-map",
          title: "Exposed JavaScript source map",
          severity: hasContent ? "MEDIUM" : "LOW",
          url: mapUrl,
          detail: hasContent
            ? "Source map includes original source code (sourcesContent) — full client source disclosure."
            : "Source map exposes original file paths/structure.",
          verified: true
        });
      }
    })
  );
  return results;
}

const INTROSPECTION_QUERY = JSON.stringify({
  query: "query{__schema{queryType{name} types{name}}}"
});

// Test common GraphQL endpoints for open introspection.
export async function checkGraphQL(origin, extraPaths = []) {
  const base = origin.replace(/\/$/, "");
  const candidates = [...new Set(["/graphql", "/api/graphql", "/v1/graphql", "/query", ...extraPaths])];
  const results = [];

  await Promise.all(
    candidates.map(async (p) => {
      const url = base + p;
      const res = await fetchSample(url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: INTROSPECTION_QUERY
      });
      if (!res || res.status >= 400) return;
      let json;
      try {
        json = await res.json();
      } catch (_) {
        return;
      }
      if (json?.data?.__schema?.types) {
        results.push({
          id: "graphql-introspection",
          title: "Open GraphQL introspection",
          severity: "MEDIUM",
          url,
          detail: `Introspection enabled — full API schema disclosed (${json.data.__schema.types.length} types).`,
          verified: true
        });
      }
    })
  );
  return results;
}

