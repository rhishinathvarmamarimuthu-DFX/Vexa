// ReconHound — Secret scanner
// Inspired by TruffleHog / gitleaks detector sets. Scans REAL page HTML, inline
// scripts, and fetched JS bundles for leaked credentials and high-entropy keys.
// Each detector targets a concrete provider pattern; generic matches are gated
// by a Shannon-entropy check to cut false positives.

// detectors: { id, name, severity, re, entropy? }
// `re` must be global; capture group 1 (if present) is treated as the secret.
const DETECTORS = [
  { id: "aws-access-key", name: "AWS Access Key ID", severity: "HIGH",
    re: /\b(AKIA|ASIA)[0-9A-Z]{16}\b/g },
  { id: "aws-secret-key", name: "AWS Secret Access Key", severity: "CRITICAL",
    re: /\baws_secret_access_key\s*[=:]\s*['"]?([A-Za-z0-9/+=]{40})['"]?/gi },
  { id: "github-pat", name: "GitHub Personal Access Token", severity: "CRITICAL",
    re: /\b(ghp|gho|ghu|ghs|ghr)_[0-9A-Za-z]{36}\b/g },
  { id: "github-fine", name: "GitHub Fine-grained Token", severity: "CRITICAL",
    re: /\bgithub_pat_[0-9A-Za-z_]{82}\b/g },
  { id: "gitlab-pat", name: "GitLab Personal Access Token", severity: "CRITICAL",
    re: /\bglpat-[0-9A-Za-z\-_]{20}\b/g },
  { id: "slack-token", name: "Slack Token", severity: "HIGH",
    re: /\bxox[baprs]-[0-9A-Za-z-]{10,48}\b/g },
  { id: "slack-webhook", name: "Slack Webhook", severity: "MEDIUM",
    re: /https:\/\/hooks\.slack\.com\/services\/[A-Za-z0-9/]+/g },
  { id: "stripe-secret", name: "Stripe Secret Key", severity: "CRITICAL",
    re: /\b(sk|rk)_live_[0-9a-zA-Z]{24,}\b/g },
  { id: "google-api", name: "Google API Key", severity: "HIGH",
    re: /\bAIza[0-9A-Za-z\-_]{35}\b/g },
  { id: "google-oauth", name: "Google OAuth Token", severity: "HIGH",
    re: /\bya29\.[0-9A-Za-z\-_]+\b/g },
  { id: "firebase-db", name: "Firebase Database URL", severity: "LOW",
    re: /https:\/\/[a-z0-9-]+\.firebaseio\.com/g },
  { id: "sendgrid", name: "SendGrid API Key", severity: "CRITICAL",
    re: /\bSG\.[A-Za-z0-9_\-]{22}\.[A-Za-z0-9_\-]{43}\b/g },
  { id: "mailgun", name: "Mailgun API Key", severity: "HIGH",
    re: /\bkey-[0-9a-zA-Z]{32}\b/g },
  { id: "twilio-sid", name: "Twilio Account SID", severity: "MEDIUM",
    re: /\bAC[0-9a-fA-F]{32}\b/g },
  { id: "twilio-key", name: "Twilio API Key", severity: "HIGH",
    re: /\bSK[0-9a-fA-F]{32}\b/g },
  { id: "npm-token", name: "npm Access Token", severity: "HIGH",
    re: /\bnpm_[0-9A-Za-z]{36}\b/g },
  { id: "heroku", name: "Heroku API Key", severity: "HIGH",
    re: /heroku[a-z0-9_ ]{0,20}['"]?[=:]['"]?([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12})/gi },
  { id: "private-key", name: "Private Key Block", severity: "CRITICAL",
    re: /-----BEGIN (?:RSA |EC |DSA |OPENSSH |PGP )?PRIVATE KEY-----/g },
  { id: "jwt", name: "JSON Web Token (JWT)", severity: "MEDIUM",
    re: /\beyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\b/g },
  { id: "db-uri", name: "Database Connection String w/ Credentials", severity: "CRITICAL",
    re: /\b(?:mongodb(?:\+srv)?|postgres(?:ql)?|mysql|redis|amqp):\/\/[^\s:@/]+:[^\s:@/]+@[^\s/'"]+/gi },
  { id: "basic-auth-url", name: "Credentials in URL", severity: "HIGH",
    re: /\bhttps?:\/\/[^\s:@/]+:[^\s:@/]+@[^\s/'"]+/gi },
  { id: "bearer", name: "Authorization Bearer Token", severity: "MEDIUM",
    re: /\bBearer\s+([A-Za-z0-9\-._~+/]{20,}=*)/g },
  { id: "facebook-token", name: "Facebook Access Token", severity: "HIGH",
    re: /\bEAACEdEose0cBA[0-9A-Za-z]+\b/g },
  { id: "square-token", name: "Square Access Token", severity: "HIGH",
    re: /\bsq0atp-[0-9A-Za-z\-_]{22}\b/g },
  // Generic high-entropy assignment (entropy-gated to reduce noise)
  { id: "generic-secret", name: "Generic API Key / Secret", severity: "MEDIUM",
    re: /\b(?:api[_-]?key|secret|token|passwd|password|access[_-]?key)\s*[=:]\s*['"]([A-Za-z0-9_\-+/=]{16,64})['"]/gi,
    entropy: 3.5 }
];

// Shannon entropy of a string (bits per char).
function entropy(str) {
  const freq = {};
  for (const ch of str) freq[ch] = (freq[ch] || 0) + 1;
  let e = 0;
  const len = str.length;
  for (const ch in freq) {
    const p = freq[ch] / len;
    e -= p * Math.log2(p);
  }
  return e;
}

function redact(secret) {
  const s = String(secret);
  if (s.length <= 10) return s[0] + "***";
  return s.slice(0, 4) + "…" + s.slice(-4) + ` (${s.length} chars)`;
}

// Scan a blob of text. `source` labels where it came from (URL or "page HTML").
// `customRules` is an optional array of user-defined detectors:
//   { id, title|name, severity, pattern (string), entropy? }
export function scanText(text, source = "page", customRules = []) {
  if (!text) return [];
  const out = [];
  const seen = new Set();

  const detectors = DETECTORS.concat(compileCustomRules(customRules));

  for (const det of detectors) {
    det.re.lastIndex = 0;
    let m;
    while ((m = det.re.exec(text)) !== null) {
      const secret = m[1] || m[0];
      if (det.entropy && entropy(secret) < det.entropy) continue;

      const dedupe = `${det.id}:${secret}`;
      if (seen.has(dedupe)) continue;
      seen.add(dedupe);

      out.push({
        id: det.id,
        title: det.name,
        severity: det.severity,
        match: redact(secret),
        entropy: Number(entropy(secret).toFixed(2)),
        source,
        custom: !!det.custom
      });
      if (out.length > 200) return out; // safety cap
    }
  }
  return out;
}

// Turn user-supplied rules into safe, global-flagged detectors.
function compileCustomRules(rules = []) {
  const compiled = [];
  for (const r of rules) {
    if (!r || !r.pattern) continue;
    try {
      const wantI = (r.flags || "").includes("i") || r.ignoreCase === true;
      const re = new RegExp(r.pattern, wantI ? "gi" : "g");
      compiled.push({
        id: r.id || "custom-" + (r.title || "rule").toLowerCase().replace(/\s+/g, "-"),
        name: r.title || r.name || "Custom Rule",
        severity: (r.severity || "MEDIUM").toUpperCase(),
        re,
        entropy: r.entropy || 0,
        custom: true
      });
    } catch (_) {
      // invalid regex — skip silently
    }
  }
  return compiled;
}

