// ReconHound — Fingerprint signature database
// Maps response headers, cookies, and DOM markers to technologies.

export const HEADER_SIGNATURES = {
  "server": [
    { regex: /nginx\/?([\d.]+)?/i, tech: "nginx", category: "web-server" },
    { regex: /apache\/?([\d.]+)?/i, tech: "Apache", category: "web-server" },
    { regex: /microsoft-iis\/?([\d.]+)?/i, tech: "IIS", category: "web-server" },
    { regex: /litespeed/i, tech: "LiteSpeed", category: "web-server" },
    { regex: /caddy/i, tech: "Caddy", category: "web-server" },
    { regex: /cloudflare/i, tech: "Cloudflare", category: "cdn-waf" },
    { regex: /akamai(?:ghost|netstorage)?/i, tech: "Akamai", category: "cdn-waf" },
    { regex: /\bAmazonS3\b/i, tech: "Amazon S3", category: "cloud" },
    { regex: /\bgoogle\s?frontend\b|\bgfe\b/i, tech: "Google Frontend", category: "cdn-waf" },
    { regex: /\bgws\b/i, tech: "Google Web Server", category: "web-server" },
    { regex: /\bvercel\b/i, tech: "Vercel", category: "cloud" },
    { regex: /\bnetlify\b/i, tech: "Netlify", category: "cloud" },
    { regex: /\bsucuri(?:\/cloudproxy)?\b/i, tech: "Sucuri WAF", category: "cdn-waf" },
    { regex: /\bcloudfront\b/i, tech: "AWS CloudFront", category: "cdn-waf" }
  ],
  "x-powered-by": [
    { regex: /php\/?([\d.]+)?/i, tech: "PHP", category: "language" },
    { regex: /express/i, tech: "Express", category: "backend" },
    { regex: /asp\.net/i, tech: "ASP.NET", category: "backend" },
    { regex: /next\.js/i, tech: "Next.js", category: "frontend" },
    { regex: /servlet/i, tech: "Java Servlet", category: "backend" }
  ],
  "x-aspnet-version": [
    { regex: /([\d.]+)/, tech: "ASP.NET", category: "backend" }
  ],
  "x-generator": [
    { regex: /drupal\s?([\d.]+)?/i, tech: "Drupal", category: "cms" },
    { regex: /wordpress\s?([\d.]+)?/i, tech: "WordPress", category: "cms" }
  ],
  "x-drupal-cache": [
    { regex: /.*/i, tech: "Drupal", category: "cms" }
  ],
  "x-shopify-stage": [
    { regex: /.*/i, tech: "Shopify", category: "cms" }
  ],
  // ---- CDN / WAF / edge detection (header presence is the signal) ----
  "cf-ray": [{ regex: /.*/i, tech: "Cloudflare", category: "cdn-waf" }],
  "cf-cache-status": [{ regex: /.*/i, tech: "Cloudflare", category: "cdn-waf" }],
  "x-akamai-transformed": [{ regex: /.*/i, tech: "Akamai", category: "cdn-waf" }],
  "x-served-by": [{ regex: /cache.*fastly|fastly/i, tech: "Fastly", category: "cdn-waf" }],
  "x-fastly-request-id": [{ regex: /.*/i, tech: "Fastly", category: "cdn-waf" }],
  "x-amz-cf-id": [{ regex: /.*/i, tech: "AWS CloudFront", category: "cdn-waf" }],
  "x-amz-cf-pop": [{ regex: /.*/i, tech: "AWS CloudFront", category: "cdn-waf" }],
  "x-iinfo": [{ regex: /.*/i, tech: "Imperva Incapsula WAF", category: "cdn-waf" }],
  "x-cdn": [{ regex: /incapsula/i, tech: "Imperva Incapsula WAF", category: "cdn-waf" }],
  "x-sucuri-id": [{ regex: /.*/i, tech: "Sucuri WAF", category: "cdn-waf" }],
  "x-sucuri-cache": [{ regex: /.*/i, tech: "Sucuri WAF", category: "cdn-waf" }],
  "x-vercel-id": [{ regex: /.*/i, tech: "Vercel", category: "cloud" }],
  "x-vercel-cache": [{ regex: /.*/i, tech: "Vercel", category: "cloud" }],
  "x-nf-request-id": [{ regex: /.*/i, tech: "Netlify", category: "cloud" }],
  "x-azure-ref": [{ regex: /.*/i, tech: "Azure Front Door", category: "cdn-waf" }],
  "x-cache": [{ regex: /cloudfront/i, tech: "AWS CloudFront", category: "cdn-waf" }],
  // ---- App / framework hint headers ----
  "x-turbo-charged-by": [{ regex: /litespeed/i, tech: "LiteSpeed", category: "web-server" }],
  "x-runtime": [{ regex: /.*/i, tech: "Ruby on Rails", category: "backend" }],
  "x-rack-cache": [{ regex: /.*/i, tech: "Rack (Ruby)", category: "backend" }],
  "x-litespeed-cache": [{ regex: /.*/i, tech: "LiteSpeed Cache", category: "cms" }],
  "x-shopify-stage-2": [{ regex: /.*/i, tech: "Shopify", category: "cms" }],
  "x-wix-request-id": [{ regex: /.*/i, tech: "Wix", category: "cms" }],
  "x-envoy-upstream-service-time": [{ regex: /.*/i, tech: "Envoy Proxy", category: "infra" }],
  "x-kong-upstream-latency": [{ regex: /.*/i, tech: "Kong API Gateway", category: "infra" }]
};

// Page-content / script-URL signatures for analytics, tag managers, and SaaS.
// Each tests against the combined inline-code + resource-URL text blob.
// These leak architecture (who handles auth, payments, analytics) — useful recon
// context, mostly INFO severity unless they expose IDs.
export const SAAS_SIGNATURES = [
  { regex: /www\.googletagmanager\.com\/gtm\.js|GTM-[A-Z0-9]{4,}/i, tech: "Google Tag Manager", category: "analytics" },
  { regex: /www\.google-analytics\.com\/analytics\.js|gtag\/js|G-[A-Z0-9]{8,}|UA-\d{4,}-\d+/i, tech: "Google Analytics", category: "analytics" },
  { regex: /cdn\.segment\.com\/analytics\.js|analytics\.segment\.io/i, tech: "Segment", category: "analytics" },
  { regex: /cdn\.mxpnl\.com|mixpanel/i, tech: "Mixpanel", category: "analytics" },
  { regex: /static\.hotjar\.com|hotjar/i, tech: "Hotjar", category: "analytics" },
  { regex: /js\.stripe\.com\/v\d/i, tech: "Stripe.js", category: "payment" },
  { regex: /checkout\.stripe\.com/i, tech: "Stripe Checkout", category: "payment" },
  { regex: /www\.paypalobjects\.com|paypal\.com\/sdk/i, tech: "PayPal SDK", category: "payment" },
  { regex: /js\.braintreegateway\.com/i, tech: "Braintree", category: "payment" },
  { regex: /checkout\.razorpay\.com/i, tech: "Razorpay", category: "payment" },
  { regex: /[a-z0-9-]+\.auth0\.com|cdn\.auth0\.com/i, tech: "Auth0", category: "auth-saas" },
  { regex: /[a-z0-9-]+\.okta\.com|okta-cdn/i, tech: "Okta", category: "auth-saas" },
  { regex: /www\.gstatic\.com\/firebasejs|firebaseapp\.com|identitytoolkit\.googleapis/i, tech: "Firebase Auth", category: "auth-saas" },
  { regex: /clerk\.[a-z.]+\/npm|clerk\.accounts\.dev/i, tech: "Clerk", category: "auth-saas" },
  { regex: /js\.sentry-cdn\.com|browser\.sentry-cdn|@sentry/i, tech: "Sentry", category: "observability" },
  { regex: /cdn\.amplitude\.com|amplitude/i, tech: "Amplitude", category: "analytics" },
  { regex: /widget\.intercom\.io|intercomcdn/i, tech: "Intercom", category: "support-saas" },
  { regex: /static\.zdassets\.com|zendesk/i, tech: "Zendesk", category: "support-saas" },
  { regex: /maps\.googleapis\.com\/maps/i, tech: "Google Maps API", category: "saas" },
  { regex: /www\.recaptcha\.net|google\.com\/recaptcha|grecaptcha/i, tech: "Google reCAPTCHA", category: "saas" },
  { regex: /challenges\.cloudflare\.com\/turnstile/i, tech: "Cloudflare Turnstile", category: "saas" }
];

export const COOKIE_SIGNATURES = [
  { regex: /laravel_session/i, tech: "Laravel", category: "backend" },
  { regex: /csrftoken|sessionid/i, tech: "Django", category: "backend" },
  { regex: /JSESSIONID/i, tech: "Java/JSP", category: "backend" },
  { regex: /PHPSESSID/i, tech: "PHP", category: "language" },
  { regex: /ci_session/i, tech: "CodeIgniter", category: "backend" },
  { regex: /_rails|_session_id/i, tech: "Ruby on Rails", category: "backend" },
  { regex: /connect\.sid/i, tech: "Express", category: "backend" },
  { regex: /wordpress_logged_in|wp-settings/i, tech: "WordPress", category: "cms" }
];

// DB inference (best-effort, from error strings on the page)
export const DB_ERROR_SIGNATURES = [
  { regex: /sqlstate|mysql_fetch|you have an error in your sql|mysqli/i, tech: "MySQL", category: "database" },
  { regex: /pg_query|psql|postgresql|pg_connect/i, tech: "PostgreSQL", category: "database" },
  { regex: /ora-\d{5}/i, tech: "Oracle", category: "database" },
  { regex: /sqlite_|sqlite3/i, tech: "SQLite", category: "database" },
  { regex: /mongodb|bson|mongoose/i, tech: "MongoDB", category: "database" },
  { regex: /microsoft sql server|sql server|incorrect syntax near/i, tech: "Microsoft SQL Server", category: "database" }
];

