// ReconHound — Risk scoring
// Aggregates all findings into a single weighted risk score (0-100) and a
// letter grade, so an operator gets an at-a-glance threat read on a target.

const WEIGHTS = { CRITICAL: 40, HIGH: 20, MEDIUM: 8, LOW: 3, UNKNOWN: 1 };

export function computeRisk(report = {}) {
  const buckets = [
    ...(report.security || []),
    ...(report.secrets || []),
    ...(report.exposures || [])
  ];

  // Confirmed CVEs add weight too.
  let cveWeight = 0;
  const counts = { CRITICAL: 0, HIGH: 0, MEDIUM: 0, LOW: 0, UNKNOWN: 0 };

  for (const f of buckets) {
    const sev = (f.severity || "UNKNOWN").toUpperCase();
    counts[sev] = (counts[sev] || 0) + 1;
  }

  for (const t of report.tech || []) {
    for (const c of t.cves || []) {
      const sev = (c.severity || "UNKNOWN").toUpperCase();
      const factor = c.confidence === "confirmed" ? 1 : 0.3;
      let w = (WEIGHTS[sev] || 0) * factor;
      // Actively exploited in the wild dramatically raises real-world risk.
      if (c.kev) w += 30;
      if (c.ransomware) w += 50;
      cveWeight += w;
      counts[sev] = (counts[sev] || 0) + 1;
    }
  }

  let raw = cveWeight;
  for (const [sev, n] of Object.entries(counts)) {
    if (sev === "UNKNOWN") continue;
    raw += (WEIGHTS[sev] || 0) * n;
  }

  // Logarithmic compression into 0-100 so a few criticals dominate but the
  // scale never saturates trivially.
  const score = Math.min(100, Math.round(20 * Math.log2(1 + raw / 10)));
  const grade = gradeFor(score, counts);

  return {
    score,
    grade,
    counts,
    total: Object.values(counts).reduce((a, b) => a + b, 0)
  };
}

function gradeFor(score, counts) {
  if (counts.CRITICAL > 0 || score >= 80) return "F";
  if (score >= 60) return "D";
  if (score >= 40) return "C";
  if (score >= 20) return "B";
  if (score > 0) return "A";
  return "A+";
}

