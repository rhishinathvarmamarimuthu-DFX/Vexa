// ReconHound — JS library scanner
// Parses REAL loaded <script> URLs (and known globals) to identify bundled
// libraries and their versions. Versions come from the actual filenames/CDN
// paths the page loaded, not from any static list.

// Each entry: name + regex that captures the version in group 1 (when present).
const URL_PATTERNS = [
  { tech: "jQuery", re: /jquery[-.](\d+\.\d+(?:\.\d+)?)(?:\.min)?\.js/i },
  { tech: "jQuery UI", re: /jquery-ui[-.](\d+\.\d+(?:\.\d+)?)/i },
  { tech: "React", re: /react(?:\.production|\.development)?[-.@](\d+\.\d+(?:\.\d+)?)/i },
  { tech: "React DOM", re: /react-dom[-.@](\d+\.\d+(?:\.\d+)?)/i },
  { tech: "Vue.js", re: /vue(?:\.global|\.runtime)?[-.@](\d+\.\d+(?:\.\d+)?)/i },
  { tech: "AngularJS", re: /angular[-.](\d+\.\d+(?:\.\d+)?)(?:\.min)?\.js/i },
  { tech: "Bootstrap", re: /bootstrap[-.@](\d+\.\d+(?:\.\d+)?)/i },
  { tech: "lodash", re: /lodash[-.@](\d+\.\d+(?:\.\d+)?)/i },
  { tech: "Moment.js", re: /moment[-.@](\d+\.\d+(?:\.\d+)?)/i },
  { tech: "Axios", re: /axios[-.@](\d+\.\d+(?:\.\d+)?)/i },
  { tech: "D3.js", re: /d3[-.@](\d+\.\d+(?:\.\d+)?)/i },
  { tech: "Chart.js", re: /chart(?:\.js)?[-.@](\d+\.\d+(?:\.\d+)?)/i },
  { tech: "Underscore.js", re: /underscore[-.@](\d+\.\d+(?:\.\d+)?)/i },
  { tech: "Handlebars", re: /handlebars[-.@](\d+\.\d+(?:\.\d+)?)/i },
  { tech: "Three.js", re: /three[-.@](\d+\.\d+(?:\.\d+)?)/i },
  { tech: "Swiper", re: /swiper[-.@](\d+\.\d+(?:\.\d+)?)/i },
  { tech: "Font Awesome", re: /font-?awesome[-.@](\d+\.\d+(?:\.\d+)?)/i },
  { tech: "GSAP", re: /gsap[-.@](\d+\.\d+(?:\.\d+)?)/i },
  // Name-only fallbacks (no version in URL)
  { tech: "React", re: /\breact\b/i },
  { tech: "Vue.js", re: /\bvue(?:\.js)?\b/i },
  { tech: "jQuery", re: /\bjquery\b/i },
  { tech: "Bootstrap", re: /\bbootstrap\b/i }
];

// Parse an array of real script-src URLs into library findings.
export function scanScriptUrls(urls = []) {
  const found = new Map(); // tech -> { tech, version, category, source }

  for (const url of urls) {
    if (!url) continue;
    for (const p of URL_PATTERNS) {
      const m = url.match(p.re);
      if (m) {
        const version = m[1] || null;
        const prev = found.get(p.tech);
        // Prefer an entry that has a real version over a name-only match.
        if (!prev || (version && !prev.version)) {
          found.set(p.tech, {
            tech: p.tech,
            version,
            category: "js-library",
            source: url
          });
        }
        break; // first matching pattern per URL wins
      }
    }
  }
  return [...found.values()];
}

// Merge globals reported from the page world (already include real versions).
export function mergeGlobals(globals = []) {
  return globals.map((g) => ({
    tech: g.tech,
    version: g.version || null,
    category: "js-library",
    source: "window global"
  }));
}

