// ReconHound — Detection confidence scoring
// Author: Rhishinathvarma Marimuthu
//
// A single signal ("saw the word jquery in a URL") is weak. The same tech seen
// across a header AND a cookie AND a runtime global is strong. This module turns
// the set of signals behind each detection into a 0-100 confidence score plus a
// human-readable list of WHY, so an analyst can judge the finding instead of
// trusting a binary "detected / not detected". This directly serves the
// true-positive goal: low-confidence detections can be visually de-emphasized
// and excluded from headline counts.

// Signal weights. A detection's raw score is the sum of distinct signal weights,
// capped at 100. Having a concrete version is itself corroborating (you don't get
// a version string from a coincidence).
const SIGNAL_WEIGHTS = {
  "header":          45,  // response header signature (server, x-powered-by, …)
  "cookie":          35,  // framework cookie name (PHPSESSID, laravel_session, …)
  "runtime-global":  50,  // window.React.version etc. — read from the live page
  "dom-marker":      30,  // [ng-version], #__next, [data-reactroot], …
  "script-url":      30,  // versioned library file in a loaded <script src>
  "saas-signature":  35,  // GTM/Stripe/Auth0 pattern in page or script
  "db-error":        25,  // DB engine inferred from an error string (best-effort)
  "version-present": 20   // a concrete version was extracted (bonus signal)
};

// Map a tech entry's (category, source) to the signal kind that produced it.
// We infer the signal from how the detection was recorded across the pipeline.
function signalKind(entry) {
  const cat = (entry.category || "").toLowerCase();
  const src = (entry.source || "").toLowerCase();
  if (src.includes("window global")) return "runtime-global";
  if (src.startsWith("http") || /\.js(\?|$)/.test(src)) return "script-url";
  if (cat === "analytics" || cat === "payment" || cat === "auth-saas" ||
      cat === "support-saas" || cat === "observability" || cat === "saas") return "saas-signature";
  if (cat === "database") return "db-error";
  // Header-derived categories
  if (["web-server", "language", "backend", "cms", "cdn-waf", "cloud", "infra"].includes(cat)) return "header";
  if (cat === "frontend") return "dom-marker";
  if (cat === "js-library") return "script-url";
  return "header";
}

// Given the full list of tech entries for a tab (which may contain the SAME tech
// recorded multiple times from different signals before de-dup), compute a
// confidence object per unique tech. Signals seen for a tech under ANY category
// corroborate each other (React via DOM marker + React via runtime global is
// the same finding seen two ways → higher confidence).
//
// Returns Map keyed by tech name -> { score, label, signals: [] }
export function scoreConfidence(techEntries = []) {
  const groups = new Map();

  for (const e of techEntries) {
    const key = e.tech; // group by tech across all categories
    if (!groups.has(key)) groups.set(key, { tech: e.tech, signals: new Set(), hasVersion: false, categories: new Set() });
    const g = groups.get(key);
    g.signals.add(signalKind(e));
    if (e.category) g.categories.add(e.category);
    if (e.version) g.hasVersion = true;
  }

  const out = new Map();
  for (const [key, g] of groups) {
    let raw = 0;
    const reasons = [];
    for (const sig of g.signals) {
      raw += SIGNAL_WEIGHTS[sig] || 0;
      reasons.push(prettySignal(sig));
    }
    if (g.hasVersion) {
      raw += SIGNAL_WEIGHTS["version-present"];
      reasons.push("concrete version extracted");
    }
    const score = Math.min(100, raw);
    out.set(key, {
      tech: g.tech,
      score,
      label: confidenceLabel(score),
      signalCount: g.signals.size,
      signals: reasons
    });
  }
  return out;
}

function prettySignal(sig) {
  return ({
    "header": "HTTP response header",
    "cookie": "framework cookie name",
    "runtime-global": "live runtime global (window.*)",
    "dom-marker": "DOM marker element",
    "script-url": "versioned resource URL",
    "saas-signature": "embedded SaaS/script signature",
    "db-error": "database error-string leak"
  })[sig] || sig;
}

export function confidenceLabel(score) {
  if (score >= 80) return "high";
  if (score >= 50) return "medium";
  if (score >= 25) return "low";
  return "tentative";
}

// Attach a `detConfidence` field to each entry in a deduped tech array, using a
// precomputed score map (keyed by tech name). Returns a new array.
export function annotateConfidence(dedupedTech = [], scoreMap) {
  return dedupedTech.map((t) => {
    const c = scoreMap.get(t.tech);
    return c
      ? { ...t, detConfidence: c.score, detConfidenceLabel: c.label, detSignals: c.signals }
      : { ...t, detConfidence: 50, detConfidenceLabel: "medium", detSignals: [] };
  });
}
