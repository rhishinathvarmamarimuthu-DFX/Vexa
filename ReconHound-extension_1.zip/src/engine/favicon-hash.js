// ReconHound — Favicon hash fingerprinting
// Author: Rhishinathvarma Marimuthu
//
// Many appliances, admin panels, and frameworks ship a default favicon. Shodan
// indexes the MurmurHash3 (mmh3) of the base64-encoded favicon, so a single hash
// can identify the product behind a login page that otherwise leaks nothing.
// This module fetches /favicon.ico, computes the same mmh3 value Shodan uses, and
// matches it against a small table of well-known defaults. It also emits a
// ready-to-use Shodan search link so the operator can pivot to internet-wide
// host discovery for that same appliance.

// ---- MurmurHash3 (32-bit), matching the mmh3.hash() Shodan/Python convention ----
// Shodan computes: mmh3.hash(base64.encodebytes(favicon_bytes)) as a SIGNED int.
function mmh3_32(key, seed = 0) {
  const remainder = key.length & 3;
  const bytes = key.length - remainder;
  let h1 = seed;
  const c1 = 0xcc9e2d51, c2 = 0x1b873593;
  let i = 0;

  while (i < bytes) {
    let k1 =
      (key.charCodeAt(i) & 0xff) |
      ((key.charCodeAt(i + 1) & 0xff) << 8) |
      ((key.charCodeAt(i + 2) & 0xff) << 16) |
      ((key.charCodeAt(i + 3) & 0xff) << 24);
    i += 4;

    k1 = Math.imul(k1, c1);
    k1 = (k1 << 15) | (k1 >>> 17);
    k1 = Math.imul(k1, c2);

    h1 ^= k1;
    h1 = (h1 << 13) | (h1 >>> 19);
    h1 = (Math.imul(h1, 5) + 0xe6546b64) | 0;
  }

  let k1 = 0;
  switch (remainder) {
    case 3: k1 ^= (key.charCodeAt(i + 2) & 0xff) << 16; // falls through
    case 2: k1 ^= (key.charCodeAt(i + 1) & 0xff) << 8;  // falls through
    case 1:
      k1 ^= key.charCodeAt(i) & 0xff;
      k1 = Math.imul(k1, c1);
      k1 = (k1 << 15) | (k1 >>> 17);
      k1 = Math.imul(k1, c2);
      h1 ^= k1;
  }

  h1 ^= key.length;
  h1 ^= h1 >>> 16;
  h1 = Math.imul(h1, 0x85ebca6b);
  h1 ^= h1 >>> 13;
  h1 = Math.imul(h1, 0xc2b2ae35);
  h1 ^= h1 >>> 16;

  return h1 | 0; // signed 32-bit, as Shodan reports
}

// Standard base64 with newline every 76 chars + trailing newline, matching
// Python's base64.encodebytes() which Shodan uses as mmh3 input.
function base64Encode(bytes) {
  const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
  let out = "";
  for (let i = 0; i < bytes.length; i += 3) {
    const b0 = bytes[i], b1 = bytes[i + 1], b2 = bytes[i + 2];
    out += chars[b0 >> 2];
    out += chars[((b0 & 3) << 4) | (b1 === undefined ? 0 : b1 >> 4)];
    out += b1 === undefined ? "=" : chars[((b1 & 15) << 2) | (b2 === undefined ? 0 : b2 >> 6)];
    out += b2 === undefined ? "=" : chars[b2 & 63];
  }
  // Insert newline every 76 output chars (encodebytes behaviour) + trailing \n
  let wrapped = "";
  for (let i = 0; i < out.length; i += 76) wrapped += out.slice(i, i + 76) + "\n";
  return wrapped;
}

// Known default-favicon hashes (signed mmh3). Curated, conservative subset.
const KNOWN_FAVICONS = {
  "116323821":  "Apache Tomcat (default)",
  "-235701012": "phpMyAdmin",
  "708578229":  "GitLab",
  "-1255347784":"Jenkins",
  "81586312":   "Grafana",
  "-1521704845":"Spring Boot (default whitelabel)",
  "-2055231165":"Jira / Atlassian",
  "1198142049": "Kibana",
  "999357577":  "pfSense",
  "-1010568750":"Citrix Gateway",
  "-628548156": "Fortinet FortiGate",
  "1768726119": "Cisco appliance"
};

// Fetch and hash the target's favicon. Returns a tech entry (or null on failure).
// PASSIVE: a favicon fetch is an ordinary resource request a browser makes anyway.
export async function faviconFingerprint(origin, timeoutMs = 6000) {
  let base;
  try { base = new URL(origin).origin; } catch (_) { return null; }
  const url = base + "/favicon.ico";

  const controller = new AbortController();
  const t = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const res = await fetch(url, { credentials: "omit", signal: controller.signal });
    clearTimeout(t);
    if (!res.ok) return null;
    const buf = new Uint8Array(await res.arrayBuffer());
    if (!buf.length) return null;

    const b64 = base64Encode(buf);
    const hash = mmh3_32(b64);
    const product = KNOWN_FAVICONS[String(hash)] || null;

    return {
      faviconHash: hash,
      shodanQuery: `http.favicon.hash:${hash}`,
      shodanUrl: `https://www.shodan.io/search?query=${encodeURIComponent("http.favicon.hash:" + hash)}`,
      product,
      // If we recognized it, also surface as a tech detection.
      tech: product ? { tech: product, version: null, category: "appliance", source: "favicon mmh3 hash" } : null
    };
  } catch (_) {
    clearTimeout(t);
    return null;
  }
}

// Exposed for unit testing the hash against known vectors.
export const _internal = { mmh3_32, base64Encode };
