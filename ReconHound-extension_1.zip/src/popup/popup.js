// ReconHound — Popup UI controller
// Author: Rhishinathvarma Marimuthu

const RH_AUTHOR = "Rhishinathvarma Marimuthu";
const RH_VERSION = "1.6.0";

let lastReport = null;
let currentTab = null;

// =============================================================================
// SECURITY HELPERS
// safeAttr — sanitizes a URL for use inside an href/src attribute.
// Defense-in-depth against XSS where attacker-influenced data (e.g. a CVE record
// from an upstream feed) might contain attribute-breaking characters.
// Allow: http(s), mailto, anchor (#). Anything else collapses to "#".
// =============================================================================
function safeAttr(url) {
  if (url == null) return "#";
  const s = String(url).trim();
  if (s === "" || s === "#") return "#";
  // Reject any scheme outside the allow-list (blocks javascript:, data:, vbscript:, etc.)
  const allowed = /^(https?:|mailto:|#)/i;
  if (!allowed.test(s)) return "#";
  // HTML-attribute-encode the rest
  return s.replace(/[&<>"']/g, (c) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
  }[c]));
}

// =============================================================================
// MAPPING TABLES (for the presentation-grade report)
// CWE and MITRE ATT&CK references are informational metadata only — they help
// the analyst understand the finding class and pivot to the right manual test.
// =============================================================================
const CWE_MAP = {
  "Missing Content-Security-Policy": { cwe: "CWE-693", name: "Protection Mechanism Failure" },
  "Missing Strict-Transport-Security": { cwe: "CWE-319", name: "Cleartext Transmission of Sensitive Information" },
  "Missing X-Frame-Options": { cwe: "CWE-1021", name: "Improper Restriction of Rendered UI Layers (Clickjacking)" },
  "Missing X-Content-Type-Options": { cwe: "CWE-430", name: "MIME-sniffing" },
  "Missing Referrer-Policy": { cwe: "CWE-200", name: "Information Exposure" },
  "Missing Permissions-Policy": { cwe: "CWE-693", name: "Protection Mechanism Failure" },
  "Weak Content-Security-Policy": { cwe: "CWE-693", name: "Protection Mechanism Failure" },
  "Information disclosure via Server header": { cwe: "CWE-200", name: "Information Exposure" },
  "Information disclosure via X-Powered-By": { cwe: "CWE-200", name: "Information Exposure" },
  "Cookie missing HttpOnly": { cwe: "CWE-1004", name: "Sensitive Cookie Without HttpOnly Flag" },
  "Cookie missing Secure": { cwe: "CWE-614", name: "Sensitive Cookie Without Secure Attribute" },
  "Cookie missing SameSite": { cwe: "CWE-1275", name: "Sensitive Cookie with Improper SameSite Attribute" },
  "Permissive CORS (Access-Control-Allow-Origin: *)": { cwe: "CWE-942", name: "Permissive Cross-domain Policy" },
  "Reflected input in parameter": { cwe: "CWE-79", name: "Cross-site Scripting (Reflected)" },
  "Open directory listing": { cwe: "CWE-548", name: "Directory Listing Exposure" },
  "Exposed .git": { cwe: "CWE-540", name: "Source Code Repository Exposure" },
  "Exposed .env": { cwe: "CWE-200", name: "Credential Exposure in Environment File" },
  "GraphQL introspection enabled": { cwe: "CWE-200", name: "GraphQL Schema Disclosure" },
  "Source map exposed": { cwe: "CWE-540", name: "Source Code Disclosure via Source Map" }
};

const SECRET_CWE = { cwe: "CWE-798", name: "Use of Hard-coded Credentials" };

// MITRE ATT&CK technique mapping (web/recon subset, presentation-relevant)
const ATTACK_MAP = {
  "fingerprint":     { id: "T1592.002", name: "Gather Victim Host Information: Software" },
  "cve":             { id: "T1190",     name: "Exploit Public-Facing Application" },
  "secret":          { id: "T1552.001", name: "Unsecured Credentials: Credentials In Files" },
  "exposure":        { id: "T1213.003", name: "Data from Information Repositories: Code Repositories" },
  "endpoint":        { id: "T1595.002", name: "Active Scanning: Vulnerability Scanning" },
  "graphql":         { id: "T1213",     name: "Data from Information Repositories" },
  "sec-header":      { id: "T1190",     name: "Exploit Public-Facing Application (Preconditions)" }
};

// Map a finding title to the closest CWE entry by substring; returns null if no match.
function cweFor(title) {
  if (!title) return null;
  for (const key in CWE_MAP) {
    if (title.toLowerCase().includes(key.toLowerCase())) return CWE_MAP[key];
  }
  return null;
}

// Matrix-rain intro splash — plays briefly on open, then fades out.
function runMatrixSplash() {
  const canvas = document.getElementById("matrix");
  if (!canvas) return;
  const ctx = canvas.getContext("2d");
  const W = (canvas.width = 380);
  const H = (canvas.height = Math.max(380, document.body.scrollHeight || 480));
  const chars = "01░▒▓<>/\\{}[]#$%&*ｱｲｳｴｵｶｷｸ".split("");
  const fontSize = 13;
  const cols = Math.floor(W / fontSize);
  const drops = Array(cols).fill(0).map(() => Math.random() * -20);

  let frames = 0;
  const maxFrames = 60; // ~1.6s at ~37fps
  function draw() {
    ctx.fillStyle = "rgba(5,8,7,0.18)";
    ctx.fillRect(0, 0, W, H);
    ctx.fillStyle = "#00ff8c";
    ctx.font = fontSize + "px monospace";
    for (let i = 0; i < cols; i++) {
      const ch = chars[(Math.random() * chars.length) | 0];
      const x = i * fontSize;
      const y = drops[i] * fontSize;
      ctx.shadowColor = "#00ff8c";
      ctx.shadowBlur = 6;
      ctx.fillText(ch, x, y);
      if (y > H && Math.random() > 0.975) drops[i] = 0;
      drops[i] += 0.7;
    }
    frames++;
    if (frames < maxFrames) {
      requestAnimationFrame(draw);
    } else {
      canvas.classList.add("fade");
      setTimeout(() => canvas.remove(), 800);
    }
  }
  draw();
}

async function init() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  currentTab = tab;
  const stackPanel = document.getElementById("stack");
  const securityPanel = document.getElementById("security");
  const urlEl = document.getElementById("url");
  const secCount = document.getElementById("secCount");

  // Show the target URL immediately, regardless of scan result.
  urlEl.textContent = tab.url || "unknown target";

  // Guard against a restricted page where we can't scan.
  if (/^(chrome|edge|about|chrome-extension|view-source|devtools):/i.test(tab.url || "")) {
    stackPanel.innerHTML = `<p class="empty">// cannot scan browser/system pages — open a normal http(s) site</p>`;
    wireUi(tab);
    return;
  }

  chrome.runtime.sendMessage({ type: "RH_ENSURE", tabId: tab.id, url: tab.url }, (report) => {
    if (chrome.runtime.lastError) {
      stackPanel.innerHTML = `<p class="empty">// engine error: ${chrome.runtime.lastError.message}<br/>try reloading the page</p>`;
      return;
    }
    lastReport = report || { tech: [], security: [] };
    urlEl.textContent = lastReport.url || tab.url;

    renderRisk(lastReport.risk);
    renderBrain(lastReport.brain);

    // Tech stack
    if (!lastReport.tech?.length) {
      stackPanel.innerHTML = `<p class="empty">// no technologies detected — reload target</p>`;
    } else {
      stackPanel.innerHTML = lastReport.tech.map(renderTech).join("");
    }

    // Security findings
    const findings = lastReport.security || [];
    secCount.textContent = String(findings.length);
    securityPanel.innerHTML = findings.length
      ? findings.map(renderFinding).join("")
      : `<p class="empty">// no security findings</p>`;

    // Secret findings
    const secrets = lastReport.secrets || [];
    document.getElementById("secretCount").textContent = String(secrets.length);
    document.getElementById("secrets").innerHTML = secrets.length
      ? secrets.map(renderSecret).join("")
      : `<p class="empty">// no secrets detected in page or scripts</p>`;

    // Extracted endpoints
    const endpoints = lastReport.endpoints || [];
    document.getElementById("endpointCount").textContent = String(endpoints.length);
    document.getElementById("endpoints").innerHTML = endpoints.length
      ? endpoints.map(renderEndpoint).join("")
      : `<p class="empty">// no routes extracted — reload to deep-scan scripts</p>`;

    // Recon: subdomains + params
    renderRecon(lastReport.subdomains || [], lastReport.params || []);

    // Detection is shown instantly above. Now load CVE + exploit-intel in the
    // background (NVD/KEV/EPSS) and refresh the affected panels when ready.
    if (lastReport.partial) {
      document.getElementById("brain").innerHTML = `<p class="empty">// 🧠 analyzing exploit intelligence (NVD · KEV · EPSS)…</p>`;
      loadCveIntel();
    }
  });

  wireUi(tab);
}

// Background load of full CVE + brain data; refreshes stack, brain and risk.
function loadCveIntel() {
  chrome.runtime.sendMessage({ type: "RH_GET_FULL", tabId: currentTab.id }, (full) => {
    if (chrome.runtime.lastError || !full) return;
    lastReport = full;
    renderRisk(full.risk);
    renderBrain(full.brain);
    const stackPanel = document.getElementById("stack");
    if (full.tech?.length) stackPanel.innerHTML = full.tech.map(renderTech).join("");
  });
}

function wireUi(tab) {
  // Tab switching
  document.querySelectorAll(".tab").forEach((btn) => {
    btn.addEventListener("click", () => {
      document.querySelectorAll(".tab").forEach((b) => b.classList.remove("active"));
      document.querySelectorAll(".panel").forEach((p) => p.classList.remove("active"));
      btn.classList.add("active");
      document.getElementById(btn.dataset.tab).classList.add("active");
      if (btn.dataset.tab === "history") loadHistory();
    });
  });

  document.getElementById("saveSnap").addEventListener("click", () => {
    chrome.runtime.sendMessage({ type: "RH_SAVE_SNAPSHOT", tabId: currentTab.id }, () => loadHistory());
  });

  // Active-scan consent + run (remembered per host so you confirm only once)
  const authConfirm = document.getElementById("authConfirm");
  const runActive = document.getElementById("runActive");
  const host = (() => { try { return new URL(tab.url).host; } catch { return ""; } })();
  chrome.storage.local.get({ authorizedHosts: [] }, ({ authorizedHosts }) => {
    if (host && authorizedHosts.includes(host)) {
      authConfirm.checked = true;
      runActive.disabled = false;
    }
  });
  authConfirm.addEventListener("change", () => {
    runActive.disabled = !authConfirm.checked;
    if (host) {
      chrome.storage.local.get({ authorizedHosts: [] }, ({ authorizedHosts }) => {
        const set = new Set(authorizedHosts);
        if (authConfirm.checked) set.add(host); else set.delete(host);
        chrome.storage.local.set({ authorizedHosts: [...set] });
      });
    }
  });
  runActive.addEventListener("click", runActiveScan);

  document.getElementById("export").addEventListener("click", exportJson);
  document.getElementById("exportHtml").addEventListener("click", exportHtml);
  const csvBtn = document.getElementById("exportCsv");
  if (csvBtn) csvBtn.addEventListener("click", exportCsv);
  document.getElementById("settings").addEventListener("click", () => chrome.runtime.openOptionsPage());
}

function runActiveScan() {
  const runActive = document.getElementById("runActive");
  const out = document.getElementById("activeResults");
  runActive.disabled = true;
  runActive.textContent = "⏳ EXECUTING…";
  out.innerHTML = `<p class="empty">// probing sensitive paths, source maps, graphql…</p>`;

  chrome.runtime.sendMessage(
    { type: "RH_ACTIVE_SCAN", tabId: currentTab.id, url: lastReport?.url || currentTab.url },
    (res) => {
      runActive.disabled = false;
      runActive.textContent = "⚡ EXECUTE ACTIVE SCAN";
      if (chrome.runtime.lastError || res?.error) {
        out.innerHTML = `<p class="empty">${(res && res.error) || chrome.runtime.lastError.message}</p>`;
        return;
      }
      if (lastReport) lastReport.activeScan = res.findings;
      if (lastReport) lastReport.exposures = res.exposures || [];
      const exposures = (res.exposures || []).map(renderExposure).join("");
      const paths = res.findings.length
        ? res.findings.map(renderPathHit).join("")
        : `<p class="empty">// no exposed sensitive paths found</p>`;
      out.innerHTML =
        (exposures ? `<div class="section-label">verified exposures</div>${exposures}` : "") +
        `<div class="section-label">reachable paths</div>${paths}`;
      refreshReport(); // recompute risk grade with new exposures
    }
  );
}

function renderExposure(e) {
  return `
    <div class="finding sev-${e.severity}">
      <div class="finding-title">
        <a href="${safeAttr(e.url)}" target="_blank" rel="noreferrer">${escapeHtml(e.title)}</a>
        <span class="badge sev-${e.severity}">${e.severity}</span>
        <span class="conf ${e.needsManual ? "unconfirmed" : "confirmed"}">${e.needsManual ? "verify manually" : "verified"}</span>
      </div>
      <div class="finding-detail">${escapeHtml(e.detail)}</div>
    </div>`;
}

function renderSecret(s) {
  return `
    <div class="finding sev-${s.severity}">
      <div class="finding-title">${escapeHtml(s.title)}<span class="badge sev-${s.severity}">${s.severity}</span></div>
      <div class="finding-detail">
        <code>${escapeHtml(s.match)}</code><br/>
        <span class="muted">source: ${escapeHtml(s.source)} · entropy ${s.entropy}</span>
      </div>
    </div>`;
}

function renderEndpoint(e) {
  return `
    <div class="endpoint">
      <span class="etype ${e.type}">${e.type}</span>
      <a href="${safeAttr(e.path)}" target="_blank" rel="noreferrer">${escapeHtml(e.path)}</a>
      <div class="muted">${escapeHtml(e.source)}</div>
    </div>`;
}

function renderPathHit(h) {
  return `
    <div class="finding sev-${h.severity}">
      <div class="finding-title">
        <a href="${safeAttr(h.url)}" target="_blank" rel="noreferrer">${escapeHtml(h.path)}</a>
        <span class="badge sev-${h.severity}">${h.severity}</span>
        <span class="conf">HTTP ${h.status}</span>
      </div>
      <div class="finding-detail">${escapeHtml(h.note)}</div>
    </div>`;
}

function renderTech(t) {
  const cves = (t.cves || []).slice(0, 6).map((c) => {
    const tags = [];
    if (c.ransomware) tags.push(`<span class="xtag rw">☣ RANSOMWARE</span>`);
    if (c.kev) tags.push(`<span class="xtag kev">⚡ ACTIVELY EXPLOITED</span>`);
    else if (c.exploitAvailable) tags.push(`<span class="xtag exp">⚑ EXPLOIT LIKELY</span>`);

    const links = [
      `<a href="${safeAttr(c.exploitDb)}" target="_blank" rel="noreferrer">ExploitDB</a>`,
      `<a href="${safeAttr(c.metasploit)}" target="_blank" rel="noreferrer">Metasploit</a>`,
      `<a href="${safeAttr(c.nuclei)}" target="_blank" rel="noreferrer">Nuclei</a>`,
      `<a href="${safeAttr(c.githubPoc)}" target="_blank" rel="noreferrer">PoC</a>`
    ].join(" · ");

    return `
      <div class="cve ${c.kev ? "kev-row" : ""}">
        <a href="${safeAttr(c.nvd)}" target="_blank" rel="noreferrer">${escapeHtml(c.id)}</a>
        <span class="sev-${c.severity}">${c.severity}${c.score != null ? " (" + c.score + ")" : ""}</span>
        ${c.confidence ? `<span class="conf ${c.confidence}">${c.confidence}</span>` : ""}
        ${tags.join(" ")}
        <div class="xlinks">${links}</div>
      </div>`;
  }).join("");

  const confBadge = t.detConfidenceLabel
    ? `<span class="detconf detconf-${t.detConfidenceLabel}" title="${escapeHtml((t.detSignals||[]).join(' + ') || 'detection signals')}">${t.detConfidence}% ${t.detConfidenceLabel}</span>`
    : "";

  return `
    <div class="tech">
      <div class="tech-name">${escapeHtml(t.tech)}${t.version ? ` <span class="ver">v${escapeHtml(t.version)}</span>` : ""} ${confBadge}</div>
      <div class="cat">${escapeHtml(t.category)}</div>
      ${cves}
    </div>`;
}

function renderFinding(f) {
  return `
    <div class="finding sev-${f.severity}">
      <div class="finding-title">${escapeHtml(f.title)}<span class="badge sev-${f.severity}">${f.severity}</span></div>
      <div class="finding-detail">${escapeHtml(f.detail)}</div>
    </div>`;
}

function renderRisk(risk) {
  if (!risk) return;
  const gradeEl = document.getElementById("grade");
  const cls = "g-" + (risk.grade === "A+" ? "Aplus" : risk.grade);
  gradeEl.className = "grade " + cls;
  gradeEl.textContent = risk.grade;

  document.getElementById("scoreVal").textContent = `${risk.score}/100`;
  document.getElementById("barFill").style.width = risk.score + "%";

  const c = risk.counts || {};
  document.getElementById("sevLegend").innerHTML =
    `<span class="lg-c">C:<b>${c.CRITICAL || 0}</b></span>
     <span class="lg-h">H:<b>${c.HIGH || 0}</b></span>
     <span class="lg-m">M:<b>${c.MEDIUM || 0}</b></span>
     <span class="lg-l">L:<b>${c.LOW || 0}</b></span>`;
}

function renderBrain(brain) {
  const panel = document.getElementById("brain");
  if (!panel) return;
  if (!brain || !brain.top) {
    panel.innerHTML = `<p class="empty">// no exploit-intelligence data — reload target</p>`;
    return;
  }
  const cls = brain.counts.weaponized ? "weaponized" : brain.counts.likely ? "likely" : "low";
  const head = `
    <div class="brain-head ${cls}">
      <div class="brain-meter">
        <div class="brain-score">${brain.overall}</div>
        <div class="brain-score-l">EXPLOITABILITY</div>
      </div>
      <div class="brain-headline">${escapeHtml(brain.headline)}</div>
    </div>
    <div class="brain-stats">
      <span class="vbadge weaponized">${brain.counts.weaponized} WEAPONIZED</span>
      <span class="vbadge likely">${brain.counts.likely} LIKELY</span>
      <span class="muted">${brain.counts.total} CVE(s) analyzed · NVD + KEV + EPSS</span>
    </div>`;

  const rows = brain.top.length
    ? brain.top.map(renderBrainRow).join("")
    : `<p class="empty">// no CVEs correlated to detected stack</p>`;

  // Attack chains (cross-finding correlation)
  let chainsHtml = "";
  if (brain.chains && brain.chains.length) {
    chainsHtml = `<div class="section-label">⛓ correlated attack paths</div>` +
      brain.chains.map((c) => `
        <div class="chain sev-${c.severity}">
          <div class="chain-title"><span class="badge sev-${c.severity}">${c.severity}</span> ${escapeHtml(c.title)}</div>
          <ol class="chain-steps">${c.steps.map((s) => `<li>${escapeHtml(s)}</li>`).join("")}</ol>
          <div class="chain-rec">▸ ${escapeHtml(c.recommendation)}</div>
        </div>`).join("");
  }

  // Remediation priority (impact / effort)
  let remHtml = "";
  if (brain.remediation && brain.remediation.length) {
    remHtml = `<div class="section-label">🎯 fix priority (impact ÷ effort)</div>` +
      brain.remediation.map((it, i) => `
        <div class="rem-row">
          <span class="rem-rank">${i + 1}</span>
          <span class="rem-score" title="impact ${it.impact}/100 · effort ${it.effort}/5">${it.priorityScore}</span>
          <span class="rem-action">${escapeHtml(it.action)}<br><span class="muted">${escapeHtml(it.why)}</span></span>
        </div>`).join("");
  }

  panel.innerHTML = head + chainsHtml + remHtml + `<div class="section-label">prioritized exploit targets</div>` + rows;
}

function renderBrainRow(r) {
  const epssPct = r.epss != null ? (r.epss * 100).toFixed(1) + "%" : "—";
  const tags = [];
  if (r.ransomware) tags.push(`<span class="xtag rw">☣ RANSOMWARE</span>`);
  if (r.kev) tags.push(`<span class="xtag kev">⚡ KEV</span>`);
  return `
    <div class="brain-row v-${r.verdictClass}">
      <div class="brain-row-top">
        <a href="${safeAttr(r.nvd)}" target="_blank" rel="noreferrer">${escapeHtml(r.id)}</a>
        <span class="vbadge ${r.verdictClass}">${r.verdict}</span>
        <span class="brain-exp">${r.exploitability}</span>
      </div>
      <div class="muted">${escapeHtml(r.tech)} · ${r.severity}${r.score != null ? " (" + r.score + ")" : ""} · EPSS ${epssPct} ${tags.join(" ")}</div>
      <div class="brain-reason">${escapeHtml(r.reasoning)}</div>
      <div class="brain-action">▸ ${escapeHtml(r.action)}</div>
      <div class="xlinks">
        <a href="${safeAttr(r.metasploit)}" target="_blank" rel="noreferrer">Metasploit</a> ·
        <a href="${safeAttr(r.nuclei)}" target="_blank" rel="noreferrer">Nuclei</a> ·
        <a href="${safeAttr(r.exploitDb)}" target="_blank" rel="noreferrer">ExploitDB</a> ·
        <a href="${safeAttr(r.githubPoc)}" target="_blank" rel="noreferrer">PoC</a>
      </div>
    </div>`;
}

function renderRecon(subdomains, params) {
  const fav = lastReport?.favicon;
  const total = subdomains.length + params.length + (fav ? 1 : 0);
  document.getElementById("reconCount").textContent = String(total);
  const panel = document.getElementById("recon");
  if (!total) {
    panel.innerHTML = `<p class="empty">// no subdomains or params extracted yet — run an active scan for favicon fingerprint</p>`;
    return;
  }
  const subChips = subdomains.map((s) => `<span class="chip">${escapeHtml(s)}</span>`).join("");
  const paramChips = params.map((p) => `<span class="chip">${escapeHtml(p)}</span>`).join("");

  let favHtml = "";
  if (fav) {
    favHtml =
      `<div class="section-label">favicon fingerprint (mmh3)</div>` +
      `<div class="fav-box">` +
      `<div>hash: <code>${escapeHtml(String(fav.faviconHash))}</code>${fav.product ? ` → <b>${escapeHtml(fav.product)}</b>` : ""}</div>` +
      `<div class="muted">Shodan pivot: <a href="${safeAttr(fav.shodanUrl)}" target="_blank" rel="noreferrer">${escapeHtml(fav.shodanQuery)}</a></div>` +
      `</div>`;
  }

  panel.innerHTML =
    favHtml +
    `<div class="section-label">subdomains (${subdomains.length})</div>` +
    (subChips ? `<div class="chips">${subChips}</div>` : `<p class="muted">none</p>`) +
    `<div class="section-label">query params (${params.length})</div>` +
    (paramChips ? `<div class="chips">${paramChips}</div>` : `<p class="muted">none</p>`);
}

function refreshReport() {
  chrome.runtime.sendMessage({ type: "RH_GET_FULL", tabId: currentTab.id }, (report) => {
    if (chrome.runtime.lastError || !report) return;
    lastReport = report;
    renderRisk(report.risk);
  });
}

function loadHistory() {
  const diffBox = document.getElementById("diffBox");
  const list = document.getElementById("historyList");
  chrome.runtime.sendMessage({ type: "RH_GET_HISTORY", tabId: currentTab.id }, (res) => {
    if (chrome.runtime.lastError || !res) {
      list.innerHTML = `<p class="empty">// history unavailable</p>`;
      return;
    }
    // Diff vs most recent saved snapshot
    if (res.diff) {
      const d = res.diff;
      const deltaCls = d.scoreDelta > 0 ? "delta-up" : d.scoreDelta < 0 ? "delta-down" : "delta-flat";
      const deltaTxt = (d.scoreDelta > 0 ? "+" : "") + d.scoreDelta;
      const added = d.added.slice(0, 30).map((x) => `<div class="diff-item add">${escapeHtml(x)}</div>`).join("");
      const removed = d.removed.slice(0, 30).map((x) => `<div class="diff-item rem">${escapeHtml(x)}</div>`).join("");
      diffBox.innerHTML = `
        <div class="diff">
          <div class="diff-head">DIFF vs last snapshot — grade ${escapeHtml(d.gradeFrom)} → ${escapeHtml(d.gradeTo)}
            · score <span class="${deltaCls}">${deltaTxt}</span></div>
          ${added || removed
            ? added + removed
            : `<div class="diff-item">// no changes since last snapshot</div>`}
        </div>`;
    } else {
      diffBox.innerHTML = `<p class="muted">// no prior snapshot for ${escapeHtml(res.host)} — save one to start tracking</p>`;
    }

    // History list for this host
    list.innerHTML = res.snapshots.length
      ? res.snapshots.map(renderSnap).join("")
      : `<p class="empty">// no saved snapshots</p>`;
  });
}

function renderSnap(s) {
  const cls = "g-" + (s.grade === "A+" ? "Aplus" : s.grade);
  const when = new Date(s.ts).toLocaleString();
  const c = s.counts || {};
  return `
    <div class="snap-row">
      <span class="snap-grade grade ${cls}">${escapeHtml(s.grade)}</span>
      <div style="flex:1;margin:0 10px">
        <div>${s.score}/100 · C:${c.CRITICAL || 0} H:${c.HIGH || 0} M:${c.MEDIUM || 0} L:${c.LOW || 0}</div>
        <div class="snap-meta">${escapeHtml(when)}</div>
      </div>
    </div>`;
}

function exportJson() {
  if (!lastReport) return;
  download(
    new Blob([JSON.stringify(lastReport, null, 2)], { type: "application/json" }),
    `reconhound-report-${Date.now()}.json`
  );
}

// CSV export — flat findings table for SIEM / spreadsheet ingestion.
function exportCsv() {
  if (!lastReport) return;
  const r = lastReport;
  const rows = [["category", "severity", "title", "detail", "source_or_url", "confidence"]];
  const q = (v) => `"${String(v == null ? "" : v).replace(/"/g, '""')}"`;

  (r.tech || []).forEach((t) => {
    (t.cves || []).forEach((c) => {
      rows.push(["cve", c.severity || "", c.id || "", `${t.tech} ${t.version || ""} — CVSS ${c.score ?? "n/a"}${c.kev ? " [KEV]" : ""}`, c.nvd || "", c.confidence || ""]);
    });
    rows.push(["technology", "INFO", `${t.tech} ${t.version || ""}`.trim(), t.category || "", t.source || "", (t.detConfidence != null ? t.detConfidence + "%" : "")]);
  });
  (r.security || []).forEach((f) => rows.push(["misconfiguration", f.severity || "", f.title || "", f.detail || "", "", ""]));
  (r.secrets || []).forEach((s) => rows.push(["secret", s.severity || "", s.title || "", s.match || "", s.source || "", ""]));
  (r.exposures || []).forEach((e) => rows.push(["exposure", e.severity || "", e.title || "", e.detail || "", e.url || "", e.needsManual ? "manual" : "verified"]));
  (r.endpoints || []).forEach((e) => rows.push(["endpoint", "INFO", e.path || "", e.type || "", e.source || "", ""]));
  (r.activeScan || []).forEach((h) => rows.push(["path", h.severity || "", h.path || "", h.note || "", h.url || "", `HTTP ${h.status}`]));

  const csv = rows.map((row) => row.map(q).join(",")).join("\r\n");
  download(new Blob([csv], { type: "text/csv" }), `reconhound-findings-${Date.now()}.csv`);
}

function exportHtml() {
  if (!lastReport) return;
  const r = lastReport;
  const risk = r.risk || { grade: "—", score: 0, counts: {} };
  const c = risk.counts || {};
  const now = new Date();
  const reportId = "RH-" + now.getTime().toString(36).toUpperCase();

  // Safe URL helper for the *exported* document (independent of popup CSP).
  const safeHref = (u) => {
    const s = String(u == null ? "" : u).trim();
    if (!s || !/^(https?:|mailto:|#)/i.test(s)) return "#";
    return s.replace(/[&<>"']/g, (ch) => ({
      "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
    }[ch]));
  };

  const sevTag = (s) => `<span class="sev sev-${s}">${s}</span>`;
  const confTag = (conf) => {
    if (!conf) return "";
    const cls = conf === "confirmed" ? "ok" : conf === "possible" ? "warn" : "muted";
    return `<span class="conftag ${cls}">${esc(conf.toUpperCase())}</span>`;
  };

  // -------- Technology rows (CONFIRMED first, then a clearly-separated "possible"
  //          section so the headline numbers reflect only true-positive matches).
  const renderCveLi = (c2) => {
    const flags = [];
    if (c2.ransomware) flags.push('<b class="flag-rw">RANSOMWARE</b>');
    if (c2.kev) flags.push('<b class="flag-kev">CISA KEV · ACTIVELY EXPLOITED</b>');
    else if (c2.exploitAvailable) flags.push('<span class="flag-exp">exploit likely</span>');
    const links = [
      `<a href="${safeHref(c2.exploitDb)}">ExploitDB</a>`,
      `<a href="${safeHref(c2.metasploit)}">Metasploit</a>`,
      `<a href="${safeHref(c2.nuclei)}">Nuclei</a>`,
      `<a href="${safeHref(c2.githubPoc)}">Public PoC</a>`,
      `<a href="${safeHref(c2.vulners)}">Vulners</a>`
    ].filter(Boolean).join(" · ");
    return `<li><a href="${safeHref(c2.nvd)}"><b>${esc(c2.id)}</b></a> ${sevTag(c2.severity)}${c2.score != null ? ` <span class="cvss">CVSS ${c2.score}</span>` : ""}
        ${confTag(c2.confidence)} ${flags.join(" ")}<br>
        <small class="poc">${links}</small></li>`;
  };

  const techRowsConfirmed = (r.tech || []).map((t) => {
    const confirmedCves = (t.cves || []).filter((c2) => c2.confidence !== "possible" && c2.confidence !== "unconfirmed");
    if (!confirmedCves.length && !(t.cves || []).length) {
      return `<tr><td>${esc(t.tech)}</td><td>${esc(t.version || "—")}</td><td>${esc(t.category)}</td><td><em>No known CVEs in NVD</em></td></tr>`;
    }
    const cvesHtml = confirmedCves.map(renderCveLi).join("");
    return `<tr><td><b>${esc(t.tech)}</b></td><td>${esc(t.version || "—")}</td><td>${esc(t.category)}</td>
            <td>${cvesHtml ? `<ul class="cve-list">${cvesHtml}</ul>` : "<em>No version-confirmed CVEs</em>"}</td></tr>`;
  }).join("");

  const possibleCvesAll = (r.tech || []).flatMap((t) =>
    (t.cves || []).filter((c2) => c2.confidence === "possible" || c2.confidence === "unconfirmed")
      .map((c2) => ({ ...c2, tech: t.tech, version: t.version }))
  );

  const possibleRows = possibleCvesAll.length
    ? possibleCvesAll.map((c2) => `<tr><td>${esc(c2.tech)} ${esc(c2.version || "")}</td><td><a href="${safeHref(c2.nvd)}">${esc(c2.id)}</a></td><td>${sevTag(c2.severity)}</td><td>${confTag(c2.confidence)}</td></tr>`).join("")
    : `<tr><td colspan="4"><em>None — every CVE in this report passed version-range matching against NVD's CPE configurations.</em></td></tr>`;

  // -------- Security misconfigurations (with CWE mapping for each)
  const secRows = (r.security || []).map((f) => {
    const w = cweFor(f.title);
    const cweCell = w ? `<a href="https://cwe.mitre.org/data/definitions/${w.cwe.replace("CWE-","")}.html">${w.cwe}</a><br><small>${esc(w.name)}</small>` : "—";
    return `<tr><td>${sevTag(f.severity)}</td><td><b>${esc(f.title)}</b></td><td>${esc(f.detail)}</td><td>${cweCell}</td></tr>`;
  }).join("");

  // -------- Secret findings (CWE-798 across the board)
  const secretRows = (r.secrets || []).map((s) =>
    `<tr><td>${sevTag(s.severity)}</td><td><b>${esc(s.title)}</b></td><td><code>${esc(s.match)}</code><br><small>entropy: ${esc(s.entropy)} bits/char</small></td><td>${esc(s.source)}</td><td><a href="https://cwe.mitre.org/data/definitions/798.html">${SECRET_CWE.cwe}</a></td></tr>`
  ).join("");

  // -------- Exposure / active findings (with reproducibility curl)
  const exposureRows = (r.exposures || []).map((e) => {
    const repro = `curl -sI -o /dev/null -w "%{http_code}\\n" "${esc(e.url)}"`;
    return `<tr><td>${sevTag(e.severity)}</td><td><a href="${safeHref(e.url)}"><b>${esc(e.title)}</b></a></td><td>${esc(e.detail)}<br><small class="repro">Reproduce: <code>${esc(repro)}</code></small></td></tr>`;
  }).join("");

  const endpointRows = (r.endpoints || []).map((e) =>
    `<tr><td><span class="etype">${esc(e.type)}</span></td><td><a href="${safeHref(e.path)}"><code>${esc(e.path)}</code></a></td><td>${esc(e.source)}</td></tr>`
  ).join("");

  const activeRows = (r.activeScan || []).map((h) => {
    const repro = `curl -sI -o /dev/null -w "%{http_code}\\n" "${esc(h.url)}"`;
    return `<tr><td>${sevTag(h.severity)}</td><td><a href="${safeHref(h.url)}"><code>${esc(h.path)}</code></a></td><td>HTTP ${esc(String(h.status))}</td><td>${esc(h.note)}<br><small class="repro">Reproduce: <code>${esc(repro)}</code></small></td></tr>`;
  }).join("");

  const subChips = (r.subdomains || []).map((s) => `<span class="chip">${esc(s)}</span>`).join("") || "—";
  const paramChips = (r.params || []).map((p) => `<span class="chip">${esc(p)}</span>`).join("") || "—";

  const total = risk.total || ((c.CRITICAL || 0) + (c.HIGH || 0) + (c.MEDIUM || 0) + (c.LOW || 0));
  const summary = buildExecSummary(risk, r);
  const brainBlock = buildBrainBlock(r.brain);

  // Risk-distribution mini SVG chart (no external deps).
  const total4 = (c.CRITICAL || 0) + (c.HIGH || 0) + (c.MEDIUM || 0) + (c.LOW || 0) || 1;
  const pct = (n) => Math.round((n / total4) * 100);
  const sevChart = `
    <svg viewBox="0 0 400 30" class="sev-chart" preserveAspectRatio="none" role="img" aria-label="Severity distribution">
      <rect x="0" y="0" width="${pct(c.CRITICAL||0)*4}" height="30" fill="#c0392b"/>
      <rect x="${pct(c.CRITICAL||0)*4}" y="0" width="${pct(c.HIGH||0)*4}" height="30" fill="#e67e22"/>
      <rect x="${(pct(c.CRITICAL||0)+pct(c.HIGH||0))*4}" y="0" width="${pct(c.MEDIUM||0)*4}" height="30" fill="#d4a017"/>
      <rect x="${(pct(c.CRITICAL||0)+pct(c.HIGH||0)+pct(c.MEDIUM||0))*4}" y="0" width="${pct(c.LOW||0)*4}" height="30" fill="#27ae60"/>
    </svg>`;

  // MITRE ATT&CK coverage band
  const techniquesHit = new Set();
  if ((r.tech || []).some((t) => (t.cves || []).length)) { techniquesHit.add("cve"); techniquesHit.add("fingerprint"); }
  if ((r.secrets || []).length) techniquesHit.add("secret");
  if ((r.exposures || []).length) techniquesHit.add("exposure");
  if ((r.endpoints || []).length) techniquesHit.add("endpoint");
  if ((r.security || []).length) techniquesHit.add("sec-header");
  const attackRows = [...techniquesHit].map((k) => {
    const m = ATTACK_MAP[k]; if (!m) return "";
    return `<tr><td><a href="https://attack.mitre.org/techniques/${m.id.replace(".","/").replace("T","T")}/"><code>${esc(m.id)}</code></a></td><td>${esc(m.name)}</td></tr>`;
  }).join("");

  const html = `<!DOCTYPE html><html lang="en"><head><meta charset="utf-8">
<title>ReconHound Security Assessment — ${esc(r.url || "")}</title>
<meta name="author" content="Rhishinathvarma Marimuthu">
<meta name="generator" content="ReconHound ${esc(RH_VERSION)}">
<style>
  :root{--crit:#c0392b;--high:#e67e22;--med:#d4a017;--low:#27ae60;--ink:#1a2027;--soft:#5b6770;--line:#e4e8ec;--bg:#f5f7f9;--accent:#0d6e4a;}
  *{box-sizing:border-box}
  body{font-family:-apple-system,Segoe UI,Roboto,Helvetica,Arial,sans-serif;margin:0;color:var(--ink);background:var(--bg);font-size:14px;line-height:1.6}
  .page{max-width:920px;margin:0 auto;background:#fff;box-shadow:0 1px 4px rgba(0,0,0,.08)}
  /* Cover */
  .cover{background:linear-gradient(135deg,#06170f,#0d6e4a 60%,#1a8f63);color:#eafff5;padding:54px 40px 40px}
  .cover .brand{font-size:11px;letter-spacing:3px;color:#7fdcb4;margin-bottom:8px;text-transform:uppercase}
  .cover h1{margin:0;font-size:32px;letter-spacing:.5px;font-weight:800}
  .cover .sub{color:#b9e8d4;margin-top:6px;font-size:13px}
  .cover .target{margin-top:24px;font-size:15px;word-break:break-all;background:rgba(255,255,255,.06);padding:10px 14px;border-radius:6px;font-family:ui-monospace,Consolas,monospace}
  .meta-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:14px;margin-top:24px;font-size:12px;color:#b9e8d4}
  .meta-grid div{background:rgba(255,255,255,.05);padding:10px 14px;border-radius:6px;border:1px solid rgba(255,255,255,.08)}
  .meta-grid b{display:block;color:#eafff5;font-size:14px;margin-bottom:2px}
  .gradewrap{display:flex;align-items:center;gap:30px;margin-top:28px;flex-wrap:wrap}
  .gradebig{font-size:78px;font-weight:800;line-height:1;padding:8px 28px;border-radius:14px;background:rgba(255,255,255,.10);min-width:120px;text-align:center}
  .g-A,.g-Aplus{color:#3ddc84}.g-B{color:#48d1ff}.g-C{color:#ffcf3a}.g-D{color:#ff9a3a}.g-F{color:#ff5a5a}
  .scoreline{font-size:13px;color:#b9e8d4;margin-bottom:4px}
  .scorebar{height:12px;width:320px;background:rgba(255,255,255,.14);border-radius:6px;overflow:hidden;margin-top:6px}
  .scorebar > i{display:block;height:100%;background:linear-gradient(90deg,#3ddc84,#ffcf3a 55%,#ff5a5a)}
  /* TOC */
  .toc{padding:24px 40px;background:#fafbfc;border-top:1px solid var(--line);border-bottom:1px solid var(--line)}
  .toc h3{margin:0 0 10px;font-size:12px;letter-spacing:.5px;color:var(--soft);text-transform:uppercase}
  .toc ol{margin:0;padding-left:20px;columns:2;font-size:13px}
  .toc a{color:var(--accent);text-decoration:none}
  .toc a:hover{text-decoration:underline}
  /* Body */
  section{padding:30px 40px;border-top:1px solid var(--line)}
  section:first-of-type{border-top:0}
  h2{font-size:20px;margin:0 0 16px;padding-bottom:10px;border-bottom:3px solid var(--accent);color:var(--ink)}
  h3{font-size:13px;margin:20px 0 8px;color:var(--soft);text-transform:uppercase;letter-spacing:.5px}
  p{margin:8px 0}
  table{border-collapse:collapse;width:100%;margin-top:10px;font-size:13px}
  th,td{border:1px solid var(--line);padding:9px 11px;text-align:left;vertical-align:top}
  th{background:var(--bg);font-size:11px;text-transform:uppercase;letter-spacing:.4px;color:var(--soft)}
  ul.cve-list{margin:0;padding-left:18px}
  ul.cve-list li{margin-bottom:8px}
  code{background:#f0f2f4;border:1px solid var(--line);border-radius:3px;padding:1px 5px;font-size:12px;font-family:ui-monospace,Consolas,monospace;word-break:break-all}
  .sev{font-weight:700;font-size:10px;padding:3px 9px;border-radius:10px;color:#fff;display:inline-block;text-transform:uppercase;letter-spacing:.4px}
  .sev-CRITICAL{background:var(--crit)}.sev-HIGH{background:var(--high)}.sev-MEDIUM{background:var(--med)}.sev-LOW{background:var(--low)}.sev-UNKNOWN{background:#90a0ab}
  .conftag{font-size:10px;font-weight:700;padding:2px 7px;border-radius:3px;text-transform:uppercase;letter-spacing:.3px;margin-left:4px}
  .conftag.ok{background:#d8f3e2;color:#176c43}
  .conftag.warn{background:#fff3d6;color:#7a5a00}
  .conftag.muted{background:#eee;color:#666}
  .cvss{display:inline-block;background:#e8ecf0;border:1px solid var(--line);padding:1px 6px;border-radius:3px;font-size:11px;color:var(--soft);font-family:ui-monospace,Consolas,monospace}
  .flag-rw{color:var(--crit);background:#fce7e4;padding:2px 7px;border-radius:3px;font-size:11px}
  .flag-kev{color:#7a005a;background:#fce4f0;padding:2px 7px;border-radius:3px;font-size:11px}
  .flag-exp{color:#7a5a00;background:#fff3d6;padding:2px 7px;border-radius:3px;font-size:11px}
  .cards{display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:14px;margin:14px 0}
  .card{border:1px solid var(--line);border-radius:8px;padding:14px;text-align:center;background:#fff}
  .card .n{font-size:32px;font-weight:800;line-height:1}
  .card.crit .n{color:var(--crit)}.card.high .n{color:var(--high)}.card.med .n{color:var(--med)}.card.low .n{color:var(--low)}
  .card .l{font-size:11px;color:var(--soft);text-transform:uppercase;letter-spacing:.5px;margin-top:4px}
  .chip{display:inline-block;background:#eef4f1;border:1px solid var(--line);border-radius:4px;padding:3px 8px;margin:2px;font-size:12px;font-family:ui-monospace,Consolas,monospace}
  .etype{display:inline-block;background:var(--accent);color:#fff;font-size:10px;padding:2px 7px;border-radius:3px;text-transform:uppercase;letter-spacing:.4px}
  .callout{background:#fff8e6;border-left:4px solid var(--med);padding:13px 16px;border-radius:0 6px 6px 0;font-size:13px;margin:14px 0}
  .disclaimer{background:#fbecec;border-left:4px solid var(--crit);padding:13px 16px;border-radius:0 6px 6px 0;font-size:12px;color:#7a2b2b;margin:12px 0}
  .sev-chart{width:100%;height:30px;border-radius:4px;overflow:hidden;border:1px solid var(--line)}
  .repro{color:var(--soft);font-size:11px;display:block;margin-top:6px}
  .repro code{background:#0a1810;color:#cfe9dd;border-color:#1e3a2c;font-size:11px}
  .poc{color:var(--soft);font-size:11px}
  .poc a{color:var(--accent)}
  footer.report{padding:24px 40px 40px;font-size:11px;color:var(--soft);text-align:center;border-top:1px solid var(--line)}
  .signature{margin-top:18px;padding:14px;background:var(--bg);border-radius:6px;text-align:left;font-size:12px}
  .rh-toolbar{position:fixed;top:14px;right:14px;display:flex;gap:8px;z-index:10}
  .rh-toolbar button{font-family:inherit;font-size:12px;padding:7px 12px;border-radius:6px;border:1px solid var(--line);background:#fff;color:var(--ink);cursor:pointer;box-shadow:0 1px 3px rgba(0,0,0,.12)}
  .rh-toolbar button:hover{background:var(--bg)}
  body.dark{--ink:#cfe9dd;--soft:#7fa493;--line:#1e3a2c;--bg:#0a0f0c;--accent:#3ddc84}
  body.dark .page{background:#0c130f}
  body.dark .toc{background:#0a1810}
  body.dark .card,body.dark .chip{background:#0a1810}
  body.dark .rh-toolbar button{background:#0c130f;color:#cfe9dd;border-color:#1e3a2c}
  body.dark th{background:#0a0f0c}
  body.dark code{background:#0a1810;border-color:#1e3a2c;color:#ffb000}
  body.dark .callout{background:#1c1604;border-color:#d4a017}
  body.dark .disclaimer{background:#1c0c0c;border-color:#c0392b;color:#ff9d9d}
  body.dark .conftag.ok{background:#0d4424;color:#7fdcb4}
  body.dark .conftag.warn{background:#3a2a00;color:#ffcf3a}
  @media print{body{background:#fff}.page{box-shadow:none}.rh-toolbar{display:none}body.dark{--ink:#1a2027;--soft:#5b6770;--line:#e4e8ec;--bg:#f5f7f9;--accent:#0d6e4a}body.dark .page{background:#fff}section{break-inside:avoid}}
</style></head><body><div class="page">

  <div class="rh-toolbar">
    <button onclick="document.body.classList.toggle('dark')">🌓 Dark / Light</button>
    <button onclick="window.print()">🖨 Print / PDF</button>
  </div>

  <div class="cover">
    <div class="brand">🛡 ReconHound · Security Assessment</div>
    <h1>WEB APPLICATION SECURITY ASSESSMENT</h1>
    <div class="sub">Automated reconnaissance · CVE correlation · Exploit-intelligence ranking</div>
    <div class="target"><b>Target:</b> ${esc(r.url || "n/a")}</div>
    <div class="meta-grid">
      <div><b>${esc(reportId)}</b>Report ID</div>
      <div><b>${esc(now.toLocaleDateString())}</b>Date</div>
      <div><b>${esc(now.toLocaleTimeString())}</b>Time</div>
      <div><b>${total}</b>Total Findings</div>
      <div><b>${(r.tech || []).length}</b>Technologies</div>
      <div><b>${esc(RH_VERSION)}</b>Engine Version</div>
    </div>
    <div class="gradewrap">
      <div class="gradebig ${risk.grade === "A+" ? "g-Aplus" : "g-" + risk.grade}">${esc(risk.grade)}</div>
      <div>
        <div class="scoreline">Overall Risk Score</div>
        <div style="font-size:24px;font-weight:800;color:#eafff5">${risk.score}/100</div>
        <div class="scorebar"><i style="width:${risk.score}%"></i></div>
        <div class="scoreline" style="margin-top:10px">
          ${sevTag("CRITICAL")} ${c.CRITICAL || 0} &nbsp; ${sevTag("HIGH")} ${c.HIGH || 0} &nbsp;
          ${sevTag("MEDIUM")} ${c.MEDIUM || 0} &nbsp; ${sevTag("LOW")} ${c.LOW || 0}
        </div>
      </div>
    </div>
  </div>

  <nav class="toc">
    <h3>Table of Contents</h3>
    <ol>
      <li><a href="#sec-summary">Executive Summary</a></li>
      <li><a href="#sec-brain">Exploit-Intelligence Analysis</a></li>
      <li><a href="#sec-method">Methodology &amp; Confidence Model</a></li>
      <li><a href="#sec-stack">Technology Stack &amp; Confirmed CVEs</a></li>
      <li><a href="#sec-misconfig">Security Misconfigurations</a></li>
      <li><a href="#sec-secrets">Credential &amp; Secret Exposure</a></li>
      <li><a href="#sec-active">Verified Active Findings</a></li>
      <li><a href="#sec-surface">Attack Surface &amp; Reconnaissance</a></li>
      <li><a href="#sec-attack">MITRE ATT&amp;CK Coverage</a></li>
      <li><a href="#sec-recs">Prioritized Recommendations</a></li>
      <li><a href="#sec-appendix">Appendix · Lower-Confidence Matches</a></li>
    </ol>
  </nav>

  <section id="sec-summary">
    <h2>1. Executive Summary</h2>
    ${summary}
    <h3>Severity distribution</h3>
    ${sevChart}
    <div class="cards">
      <div class="card crit"><div class="n">${c.CRITICAL || 0}</div><div class="l">Critical</div></div>
      <div class="card high"><div class="n">${c.HIGH || 0}</div><div class="l">High</div></div>
      <div class="card med"><div class="n">${c.MEDIUM || 0}</div><div class="l">Medium</div></div>
      <div class="card low"><div class="n">${c.LOW || 0}</div><div class="l">Low</div></div>
    </div>
  </section>

  <section id="sec-brain">
    <h2>2. Exploit-Intelligence Analysis (AI Brain)</h2>
    ${brainBlock}
  </section>

  <section id="sec-method">
    <h2>3. Methodology &amp; Confidence Model</h2>
    <p>This assessment was produced by the <b>ReconHound</b> browser extension using a combination of
    <b>passive fingerprinting</b> (HTTP response headers, loaded resources, runtime globals,
    cookie signatures) and, where the operator explicitly confirmed authorization, <b>active
    probing</b> (sensitive-path discovery, VCS/secret-file exposure verification, source-map
    enumeration, GraphQL introspection check, canary-based reflection probe, directory-listing
    probe). All active probes are <b>non-destructive</b> and use benign marker values rather
    than weaponized payloads — confirmation of exploitation is left to manual testing in the
    operator's authorized environment.</p>
    <h3>Confidence Tiers</h3>
    <table>
      <thead><tr><th>Tier</th><th>Definition</th><th>Action</th></tr></thead>
      <tbody>
        <tr><td>${confTag("confirmed")}</td><td>Version-range match against NVD's CPE configurations <em>or</em> content-verified active probe response.</td><td>Treat as true positive; remediate.</td></tr>
        <tr><td>${confTag("possible")}</td><td>Name-only match without version constraint; possibly affected.</td><td>Manual verification required (see appendix).</td></tr>
        <tr><td>${confTag("unconfirmed")}</td><td>Detected with low corroboration; review only.</td><td>Manual triage; not counted in main findings.</td></tr>
      </tbody>
    </table>
    <h3>Severity Scale (CVSS-aligned)</h3>
    <div class="callout">Critical ≥ 9.0 · High 7.0–8.9 · Medium 4.0–6.9 · Low &lt; 4.0. The overall
    grade weights CRITICAL/HIGH most heavily and applies a CISA KEV multiplier when CVEs are
    confirmed to be actively exploited in the wild.</div>
    <h3>Data Sources</h3>
    <p>NIST NVD 2.0 (CVE + CPE) · CISA Known Exploited Vulnerabilities catalog · FIRST.org EPSS
    (Exploitation Prediction) · Public exploit indices: ExploitDB, Rapid7 Metasploit DB,
    ProjectDiscovery Nuclei templates, Vulners, GitHub Security Advisories. All correlation is
    performed in-browser; no scan data is transmitted to ReconHound's author or any third party.</p>
  </section>

  <section id="sec-stack">
    <h2>4. Technology Stack &amp; Confirmed CVEs</h2>
    <p>Each technology below was identified via at least one of: HTTP response header signature,
    cookie pattern, runtime global, or DOM marker. CVEs shown have passed <b>CPE version-range
    matching</b> against NVD — they affect the detected version, not just bear a name match.</p>
    <table><thead><tr><th>Technology</th><th>Version</th><th>Category</th><th>Version-Confirmed CVEs</th></tr></thead>
    <tbody>${techRowsConfirmed || "<tr><td colspan=4>None detected</td></tr>"}</tbody></table>
  </section>

  <section id="sec-misconfig">
    <h2>5. Security Misconfigurations</h2>
    <table><thead><tr><th>Severity</th><th>Issue</th><th>Detail</th><th>CWE</th></tr></thead>
    <tbody>${secRows || "<tr><td colspan=4>None identified</td></tr>"}</tbody></table>
  </section>

  <section id="sec-secrets">
    <h2>6. Credential &amp; Secret Exposure</h2>
    <p>Secrets were detected using <b>provider-specific patterns</b> (AWS, GitHub, Stripe, Slack,
    Google, SendGrid, Twilio, npm, etc.) and a <b>Shannon-entropy-gated</b> generic detector to
    reduce noise. All values are redacted in this report; rotate any matched credentials
    immediately and remove them from client-side delivery.</p>
    <table><thead><tr><th>Severity</th><th>Type</th><th>Match (redacted)</th><th>Source</th><th>CWE</th></tr></thead>
    <tbody>${secretRows || "<tr><td colspan=5>None identified</td></tr>"}</tbody></table>
  </section>

  <section id="sec-active">
    <h2>7. Verified Active Findings</h2>
    <p>The following items were verified through active (non-destructive) probes during the
    authorized scan. Each row includes a one-liner you can run from a terminal to reproduce
    the observation for evidence collection.</p>
    <h3>Content-verified exposures</h3>
    <table><thead><tr><th>Severity</th><th>Exposure</th><th>Detail / Reproduction</th></tr></thead>
    <tbody>${exposureRows || "<tr><td colspan=3>Active scan not executed, or no verified exposures.</td></tr>"}</tbody></table>
    <h3>Reachable sensitive paths</h3>
    <table><thead><tr><th>Severity</th><th>Path</th><th>Status</th><th>Note / Reproduction</th></tr></thead>
    <tbody>${activeRows || "<tr><td colspan=4>Active scan not executed.</td></tr>"}</tbody></table>
  </section>

  <section id="sec-surface">
    <h2>8. Attack Surface &amp; Reconnaissance</h2>
    ${r.favicon ? `<h3>Favicon fingerprint (Shodan-compatible mmh3)</h3>
    <p>Hash <code>${esc(String(r.favicon.faviconHash))}</code>${r.favicon.product ? ` — identified as <b>${esc(r.favicon.product)}</b>` : " (no default match in local table)"}.
    Internet-wide pivot: <a href="${safeHref(r.favicon.shodanUrl)}"><code>${esc(r.favicon.shodanQuery)}</code></a> finds other hosts serving the same favicon — useful for discovering related infrastructure.</p>` : ""}
    <h3>API / Application endpoints</h3>
    <table><thead><tr><th>Type</th><th>Path / URL</th><th>Source</th></tr></thead>
    <tbody>${endpointRows || "<tr><td colspan=3>None extracted</td></tr>"}</tbody></table>
    <h3>Discovered subdomains (${(r.subdomains||[]).length})</h3><p>${subChips}</p>
    <h3>Observed query parameters (${(r.params||[]).length})</h3><p>${paramChips}</p>
  </section>

  <section id="sec-attack">
    <h2>9. MITRE ATT&amp;CK Coverage</h2>
    <p>The findings in this report relate to the following adversary techniques, mapped against
    the MITRE ATT&amp;CK Enterprise matrix. This is intended to help blue-team analysts correlate
    detections and tune defenses.</p>
    <table><thead><tr><th>Technique ID</th><th>Technique</th></tr></thead>
    <tbody>${attackRows || "<tr><td colspan=2>No mappings — no findings of mappable type.</td></tr>"}</tbody></table>
  </section>

  <section id="sec-recs">
    <h2>10. Prioritized Recommendations</h2>
    <ol>
      ${buildRecommendations(r)}
    </ol>
  </section>

  <section id="sec-appendix">
    <h2>Appendix A · Lower-Confidence CVE Matches</h2>
    <p>The CVEs below were keyword-matched to a detected technology but <b>could not be
    confirmed</b> against the observed version (typically because no version was disclosed).
    They are listed here for manual review and excluded from the headline counts to avoid
    inflating false positives.</p>
    <table><thead><tr><th>Technology</th><th>CVE</th><th>Severity</th><th>Confidence</th></tr></thead>
    <tbody>${possibleRows}</tbody></table>
  </section>

  <footer class="report">
    <div class="disclaimer"><b>Legal &amp; Ethical Notice:</b> This report is intended solely for
    authorized security assessment of systems the operator owns or has explicit written
    permission to test. Unauthorized scanning or exploitation may violate computer-misuse
    laws including the CFAA (US), the IT Act 2000 (India), and equivalent statutes elsewhere.
    The author and ReconHound accept no liability for misuse.</div>
    <div class="signature">
      <b>Report metadata</b><br>
      Report ID: <code>${esc(reportId)}</code><br>
      Generated: ${esc(now.toISOString())}<br>
      Engine: ReconHound v${esc(RH_VERSION)}<br>
      Author: ${esc(RH_AUTHOR)}
    </div>
    <p style="margin-top:14px">Generated by <b>ReconHound</b> · © ${now.getFullYear()} ${esc(RH_AUTHOR)}</p>
  </footer>

</div></body></html>`;

  download(new Blob([html], { type: "text/html" }), `ReconHound_Report_${reportId}.html`);
}

function buildBrainBlock(brain) {
  if (!brain || !brain.top || !brain.top.length) {
    return `<p>No CVEs were correlated to the detected stack, so no exploit-intelligence
      ranking is available. Manual testing is still recommended — automated detection
      cannot identify novel or application-specific vulnerabilities.</p>`;
  }
  // Local safeHref for the report context (same allow-list as the popup helper)
  const sH = (u) => {
    const s = String(u == null ? "" : u).trim();
    if (!s || !/^(https?:|mailto:|#)/i.test(s)) return "#";
    return s.replace(/[&<>"']/g, (ch) => ({
      "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
    }[ch]));
  };
  const rows = brain.top.map((r) => {
    const epss = r.epss != null ? (r.epss * 100).toFixed(1) + "%" : "—";
    const flags = [];
    if (r.ransomware) flags.push('<b class="flag-rw">RANSOMWARE</b>');
    if (r.kev) flags.push('<b class="flag-kev">KEV</b>');
    const links = `<a href="${sH(r.metasploit)}">Metasploit</a> · <a href="${sH(r.nuclei)}">Nuclei</a> · <a href="${sH(r.exploitDb)}">ExploitDB</a> · <a href="${sH(r.githubPoc)}">PoC</a>`;
    return `<tr>
      <td><b>${esc(String(r.exploitability))}</b></td>
      <td>${esc(r.verdict)}</td>
      <td><a href="${sH(r.nvd)}">${esc(r.id)}</a> ${flags.join(" ")}</td>
      <td>${esc(r.tech)}</td>
      <td>${esc(epss)}</td>
      <td>${esc(r.reasoning)}<br><small class="repro">▸ ${esc(r.action)}</small><br><small class="poc">${links}</small></td>
    </tr>`;
  }).join("");

  return `
    <p><b>${esc(brain.headline)}</b></p>
    <p>Overall exploitability index: <b>${brain.overall}/100</b> · Weaponized: <b>${brain.counts.weaponized}</b>
       · Likely exploitable: <b>${brain.counts.likely}</b> · CVEs analyzed: ${brain.counts.total}.
       Scoring fuses NVD severity, CISA KEV (active exploitation), EPSS (exploitation probability)
       and public exploit-tool availability.</p>
    ${buildChainsHtml(brain.chains)}
    ${buildRemediationHtml(brain.remediation)}
    <h3>Prioritized exploit targets</h3>
    <table><thead><tr><th>Exploit&nbsp;Idx</th><th>Verdict</th><th>CVE</th><th>Component</th><th>EPSS</th><th>Reasoning &amp; Recommended Action</th></tr></thead>
    <tbody>${rows}</tbody></table>`;
}

// Correlated attack-path chains for the report.
function buildChainsHtml(chains) {
  if (!chains || !chains.length) return "";
  const rows = chains.map((c) => `
    <div class="callout" style="border-left-color:${c.severity === "CRITICAL" ? "var(--crit)" : "var(--high)"}">
      <b>[${esc(c.severity)}] ${esc(c.title)}</b>
      <ol style="margin:6px 0 6px 18px">${c.steps.map((s) => `<li>${esc(s)}</li>`).join("")}</ol>
      <div><b>Recommendation:</b> ${esc(c.recommendation)}</div>
    </div>`).join("");
  return `<h3>Correlated attack paths</h3>${rows}`;
}

// Remediation-priority table (impact ÷ effort) for the report.
function buildRemediationHtml(rem) {
  if (!rem || !rem.length) return "";
  const rows = rem.map((it, i) => `<tr>
    <td>${i + 1}</td>
    <td><b>${esc(String(it.priorityScore))}</b></td>
    <td>${esc(it.action)}</td>
    <td>${esc(it.why)}</td>
    <td>${esc(String(it.impact))}/100</td>
    <td>${esc(String(it.effort))}/5</td>
  </tr>`).join("");
  return `<h3>Remediation priority (impact ÷ effort)</h3>
    <p>Ordered by exploitability-reduction-per-unit-effort, so the fastest wins surface first
    rather than strictly by severity.</p>
    <table><thead><tr><th>#</th><th>Priority</th><th>Action</th><th>Rationale</th><th>Impact</th><th>Effort</th></tr></thead>
    <tbody>${rows}</tbody></table>`;
}

function buildExecSummary(risk, r) {
  const c = risk.counts || {};
  const grade = risk.grade;
  let posture;
  if (grade === "F") posture = "a <b>critical</b> security posture requiring immediate remediation";
  else if (grade === "D") posture = "a <b>poor</b> security posture with serious weaknesses";
  else if (grade === "C") posture = "a <b>moderate</b> security posture with notable gaps";
  else if (grade === "B") posture = "a <b>fair</b> security posture with minor issues";
  else posture = "a <b>strong</b> security posture";

  const highlights = [];
  if ((r.secrets || []).length) highlights.push(`${r.secrets.length} potential credential/secret leak(s)`);
  if ((r.exposures || []).length) highlights.push(`${r.exposures.length} verified file/VCS exposure(s)`);
  const cveCount = (r.tech || []).reduce((n, t) => n + (t.cves || []).length, 0);
  if (cveCount) highlights.push(`${cveCount} known CVE(s) across the stack`);
  const kevCount = (r.tech || []).reduce((n, t) => n + (t.cves || []).filter((c) => c.kev).length, 0);
  if (kevCount) highlights.push(`<b style="color:#b1006b">${kevCount} actively-exploited (CISA KEV) CVE(s)</b>`);
  if (c.CRITICAL) highlights.push(`${c.CRITICAL} critical-severity issue(s)`);

  const list = highlights.length
    ? `Key concerns include ${highlights.join(", ")}.`
    : "No high-impact issues were automatically identified, though manual testing is still recommended.";

  return `<p>The target <code>${esc(r.url || "")}</code> was assessed and assigned an
    overall risk grade of <b>${esc(grade)}</b> (score ${risk.score}/100), indicating
    ${posture}. ${list}</p>`;
}

function buildRecommendations(r) {
  const recs = [];
  if ((r.security || []).some((f) => /content-security-policy/i.test(f.title)))
    recs.push("Implement a strict Content-Security-Policy to mitigate XSS.");
  if ((r.security || []).some((f) => /hsts|strict-transport/i.test(f.title)))
    recs.push("Enable HTTP Strict Transport Security (HSTS) with a long max-age.");
  if ((r.secrets || []).length)
    recs.push("Rotate any exposed credentials immediately and remove secrets from client-side code.");
  if ((r.exposures || []).length)
    recs.push("Block public access to VCS metadata (.git/.svn), .env and backup files at the web-server level.");
  if ((r.tech || []).some((t) => (t.cves || []).length))
    recs.push("Upgrade outdated components to patched versions to remediate known CVEs.");
  if ((r.security || []).some((f) => /cors/i.test(f.title)))
    recs.push("Tighten CORS policy — avoid wildcard origins combined with credentials.");
  if (!recs.length)
    recs.push("Maintain current controls and schedule periodic re-assessment.");
  recs.push("Conduct manual penetration testing to validate and expand on these automated findings.");
  return recs.map((x) => `<li>${esc(x)}</li>`).join("");
}

function download(blob, filename) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

function esc(s) {
  return String(s).replace(/[&<>"']/g, (c) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
  }[c]));
}

function escapeHtml(s) {
  return String(s).replace(/[&<>"']/g, (c) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
  }[c]));
}

try { runMatrixSplash(); } catch (_) {}
init().catch((e) => {
  const s = document.getElementById("stack");
  if (s) s.innerHTML = `<p class="empty">// init error: ${String(e && e.message || e)}</p>`;
});

