"""
DOM XSS dynamic confirmer.

The static analyser in `detection.dom` produces `DomCandidate` objects:
a source (e.g. `location.hash`) that reaches a sink (e.g. `innerHTML`)
through the JS control-flow graph. That's a *hypothesis*, not a bug.

This module confirms the hypothesis by:

  1. Loading the page in a real headless browser.
  2. Driving the source with an execution-marker payload — the exact
     mechanism depends on the source kind:
        url_fragment    →  navigate to page + '#' + payload
        url_search      →  navigate to page + '?_arx=' + payload
        url             →  navigate to page + '?_arx=' + payload
        url_path        →  navigate to page + '/' + encoded(payload)
        window_name     →  set window.name via a control page + navigate
        postmessage     →  postMessage(payload) from parent to iframe
        storage         →  pre-seed localStorage before navigation
        cookie          →  set document.cookie via same-origin script
        referrer        →  navigate from a control page whose URL contains payload
  3. Watching the same execution signals HeadlessOracle uses (window.__arx
     sentinel, console listener, dialog handler).
  4. Emitting a Finding with `xss_class=DOM` when execution is observed.

The confirmer intentionally uses a *variety* of markers so we can prove
the source→sink correlation and not just that the page executes JS in
general.
"""

from __future__ import annotations

import logging
import secrets
from dataclasses import dataclass
from typing import Optional
from urllib.parse import quote, urlsplit, urlunsplit

from arachnex.core.config import Config
from arachnex.core.target import (
    Finding,
    HttpMethod,
    InjectionPoint,
    ReflectionContext,
    ReflectionEvidence,
    Severity,
    Target,
    XSSClass,
)
from arachnex.detection.dom import DomCandidate
from arachnex.utils.http import HttpClient

log = logging.getLogger("arachnex.detect.dom_confirm")


# --------------------------------------------------------------------------- #
# Payload builders per source kind
# --------------------------------------------------------------------------- #


# Universal breakout wrappers keyed by likely sink type. Each contains a
# distinct execution marker the confirmer greps for.
def _wrappers(marker: str) -> list[tuple[str, str, str]]:
    """
    Return (label, payload_bytes, delivery_hint) tuples. The delivery
    hint tells the confirmer where in the URL to inject.
    """
    payloads: list[tuple[str, str, str]] = [
        ("html_body",     f"<img src=x onerror=window.__arx&&__arx.mark('{marker}')>",  "html"),
        ("script_break", f"';window.__arx&&__arx.mark('{marker}');//",                  "js"),
        ("js_template",   f"${{window.__arx&&__arx.mark('{marker}')}}",                 "js"),
        ("attr_break",    f"\"><svg onload=window.__arx&&__arx.mark('{marker}')>",      "html"),
        ("javascript_url", f"javascript:window.__arx&&__arx.mark('{marker}')",          "url"),
        ("data_url",      f"data:text/html,<script>window.__arx&&__arx.mark('{marker}')</script>", "url"),
    ]
    return payloads


# --------------------------------------------------------------------------- #
# Confirmer
# --------------------------------------------------------------------------- #


@dataclass
class _ConfirmedDom:
    candidate: DomCandidate
    payload: str
    marker: str
    delivery: str          # 'fragment', 'search', 'name', 'postmessage', 'storage'
    exec_observed: bool


class DomXSSConfirmer:
    """
    Given a set of `DomCandidate`s discovered by the static analyser
    and a page URL that loads them, drive each source and watch for exec.
    """

    def __init__(self, cfg: Config, http: HttpClient, oracle) -> None:
        self.cfg = cfg
        self.http = http
        self.oracle = oracle          # HeadlessOracle instance

    def _available(self) -> bool:
        return self.oracle is not None and getattr(self.oracle, "_browser", None) is not None

    async def confirm(
        self, page_url: str, candidates: list[DomCandidate],
    ) -> list[Finding]:
        if not self._available() or not candidates:
            return []

        findings: list[Finding] = []
        for cand in candidates[: self.cfg.dom_confirm_max_candidates]:
            try:
                res = await self._confirm_one(page_url, cand)
            except Exception:
                log.debug("dom-confirm crashed on %s -> %s",
                          cand.source_label, cand.sink_label, exc_info=True)
                res = None
            if res and res.exec_observed:
                findings.append(self._to_finding(page_url, res))
        return findings

    # ------------------------------------------------------------------ #
    # Per-candidate driver
    # ------------------------------------------------------------------ #

    async def _confirm_one(
        self, page_url: str, cand: DomCandidate,
    ) -> Optional[_ConfirmedDom]:
        marker = f"arx-dom-{secrets.token_hex(3)}"
        wrappers = _wrappers(marker)

        for label, payload, _hint in wrappers:
            delivery, driven_url, extra_setup = self._prepare_delivery(
                page_url, cand.source_kind, payload,
            )
            if driven_url is None and delivery != "postmessage" and delivery != "storage":
                continue
            executed = await self._drive_and_watch(
                driven_url, delivery, payload, marker, extra_setup,
            )
            if executed:
                return _ConfirmedDom(
                    candidate=cand, payload=payload, marker=marker,
                    delivery=delivery, exec_observed=True,
                )
        return None

    # ------------------------------------------------------------------ #
    # Delivery preparation
    # ------------------------------------------------------------------ #

    def _prepare_delivery(
        self, page_url: str, source_kind: str, payload: str,
    ) -> tuple[str, Optional[str], Optional[dict]]:
        """
        Return (delivery_label, url_to_load, extra_setup_dict). The extra
        setup dict tells `_drive_and_watch` what to do *before* the
        navigation (seed storage, set window.name, etc.).
        """
        u = urlsplit(page_url)

        if source_kind == "url_fragment":
            new_url = urlunsplit((u.scheme, u.netloc, u.path, u.query,
                                  quote(payload, safe="")))
            return "fragment", new_url, None

        if source_kind in ("url_search", "url", "url_path"):
            from urllib.parse import parse_qsl, urlencode
            qs = parse_qsl(u.query, keep_blank_values=True)
            qs.append(("_arx", payload))
            new_url = urlunsplit(
                (u.scheme, u.netloc, u.path or "/",
                 urlencode(qs, doseq=True), u.fragment)
            )
            return "search", new_url, None

        if source_kind == "window_name":
            # We can't set window.name for a target from a Python
            # process directly; we set it via page.evaluate before nav.
            return "name", page_url, {"window_name": payload}

        if source_kind == "postmessage":
            # We load the target then postMessage into it.
            return "postmessage", page_url, {"postmessage": payload}

        if source_kind == "storage":
            return "storage", page_url, {"storage_key": "arx", "storage_val": payload}

        if source_kind == "cookie":
            return "cookie", page_url, {"cookie": f"arx={quote(payload, safe='')}"}

        if source_kind == "referrer":
            # A control page whose URL contains payload, that then
            # navigates to page_url. Playwright does this via `about:blank`
            # → set-referrer via headers.
            return "referrer", page_url, {"referrer_payload": payload}

        return "unknown", None, None

    # ------------------------------------------------------------------ #
    # Playwright driver + oracle watching
    # ------------------------------------------------------------------ #

    async def _drive_and_watch(
        self,
        url: str,
        delivery: str,
        payload: str,
        marker: str,
        extra_setup: Optional[dict],
    ) -> bool:
        """
        Load `url` under Playwright, apply any pre-nav setup, then watch
        the oracle's three exec signals for `marker`.
        """
        browser = self.oracle._browser
        context = None
        page = None
        executed = {"val": False}
        try:
            context = await browser.new_context(
                ignore_https_errors=not self.cfg.verify_tls,
                user_agent=self.cfg.user_agent,
                extra_http_headers=self.cfg.extra_headers or None,
                proxy={"server": self.cfg.proxy} if self.cfg.proxy else None,
            )
            # Same __arx sentinel HeadlessOracle uses.
            await context.add_init_script(_ARX_SENTINEL)
            page = await context.new_page()

            def _console_handler(msg):
                try:
                    text = msg.text or ""
                    if marker in text:
                        executed["val"] = True
                except Exception:
                    pass

            page.on("console", _console_handler)

            def _dialog_handler(dlg):
                try:
                    if marker in (dlg.message or ""):
                        executed["val"] = True
                    import asyncio as _a
                    _a.ensure_future(dlg.dismiss())
                except Exception:
                    pass

            page.on("dialog", _dialog_handler)

            # Pre-nav setup
            if extra_setup:
                if "window_name" in extra_setup:
                    await page.goto("about:blank",
                                    wait_until="domcontentloaded", timeout=5000)
                    await page.evaluate(
                        "n => window.name = n", extra_setup["window_name"],
                    )
                elif "cookie" in extra_setup:
                    # Set via context.add_cookies for correct scoping
                    try:
                        parts = extra_setup["cookie"].split("=", 1)
                        u = urlsplit(url)
                        await context.add_cookies([{
                            "name": parts[0], "value": parts[1] if len(parts) == 2 else "",
                            "domain": u.hostname, "path": "/",
                            "httpOnly": False, "secure": u.scheme == "https",
                        }])
                    except Exception:
                        pass
                elif "storage_key" in extra_setup:
                    # Playwright: pre-seed via addInitScript
                    key = extra_setup["storage_key"]
                    val = extra_setup["storage_val"]
                    await context.add_init_script(
                        "(k,v)=>{try{localStorage.setItem(k,v);sessionStorage.setItem(k,v);}catch(e){}}",
                    )
                    # Fallback: also set via page.evaluate right after nav
                    await context.add_init_script(
                        f"try{{localStorage.setItem({key!r},{val!r});}}catch(e){{}}"
                    )

            # Navigate
            await page.goto(url, timeout=8000, wait_until="domcontentloaded")

            # Post-nav delivery
            if extra_setup and "postmessage" in extra_setup:
                await page.evaluate(
                    "p => window.postMessage(p, '*')",
                    extra_setup["postmessage"],
                )

            # Let the page settle
            try:
                await page.wait_for_timeout(1200)
            except Exception:
                pass

            # Poll the __arx sentinel for the marker
            try:
                sentinel_hit = await page.evaluate(
                    "m => !!(window.__arx && window.__arx.hits && window.__arx.hits.includes(m))",
                    marker,
                )
                if sentinel_hit:
                    executed["val"] = True
            except Exception:
                pass

            return executed["val"]
        except Exception:
            log.debug("dom-confirm drive failed", exc_info=True)
            return False
        finally:
            for closer in (page, context):
                if closer is not None:
                    try:
                        await closer.close()
                    except Exception:
                        pass

    # ------------------------------------------------------------------ #
    # Finding builder
    # ------------------------------------------------------------------ #

    @staticmethod
    def _to_finding(page_url: str, res: _ConfirmedDom) -> Finding:
        cand = res.candidate
        title = (
            f"DOM XSS: {cand.source_label} → {cand.sink_label} "
            f"(delivered via {res.delivery})"
        )
        return Finding(
            xss_class=XSSClass.DOM,
            severity=Severity.HIGH,
            confidence=0.95,
            target_url=page_url,
            method=HttpMethod.GET,
            injection_point=InjectionPoint(
                location=res.delivery, name=cand.source_label,
            ),
            payload=res.payload,
            reflection=ReflectionEvidence(
                canary=res.marker,
                snippet=f"source={cand.source_label} sink={cand.sink_label}",
                offset=-1, response_size=0, response_hash="",
                classified_context=ReflectionContext.HTML_BODY,
                classifier_confidence=1.0,
            ),
            title=title,
            extra={
                "source_kind": cand.source_kind,
                "sink_kind": cand.sink_kind,
                "delivery": res.delivery,
                "flow_path": cand.path,
                "marker": res.marker,
            },
            cwe=["CWE-79"],
        )


# The same execution sentinel HeadlessOracle uses; we inline it here so
# the confirmer works even when Playwright is loaded lazily.
_ARX_SENTINEL = r"""
(() => {
  if (window.__arx) return;
  const hits = [];
  window.__arx = {
    hits,
    mark(tag) { try { hits.push(String(tag)); console.log('__arx_exec__:' + tag); } catch(e){} return tag; }
  };
  const wrap = (fn, name) => function() {
    try {
      const s = String(arguments[0] || '');
      window.__arx.mark('call:' + name + ':' + s.slice(0, 64));
    } catch (e) {}
    try { return fn.apply(this, arguments); } catch (e) {}
  };
  try { window.alert   = wrap(window.alert,   'alert'); } catch (e) {}
  try { window.prompt  = wrap(window.prompt,  'prompt'); } catch (e) {}
  try { window.confirm = wrap(window.confirm, 'confirm'); } catch (e) {}
})();
"""
