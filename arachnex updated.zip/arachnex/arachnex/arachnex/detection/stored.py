"""
Stored XSS detector.

The classical stored-XSS flow is:

  1. Write user-controlled data to a "sink" endpoint (POST/PUT/PATCH,
     or GET with a persistent side-effect).
  2. That data is later rendered on a "view" endpoint that the tester
     did not visit at write time — sometimes a different URL, sometimes
     the same URL fetched again (Post/Redirect/Get pattern).

Signature scanners miss stored XSS entirely because they compare each
request's *own* response to its payload. If the payload only surfaces
on a *different* request, they never see it.

ArachneX's stored detector runs a small state-tracking loop per target:

  Phase A — write
    Send a canary as the injected value using the target's method.
    Follow redirects (Post-Redirect-Get is the common vulnerable pattern).
    Record whether the canary was reflected in the final response body.

  Phase B — view
    Re-GET a "view URL" derived from the target. Two heuristics:
      • strip the injection param and re-GET the same path (list pages)
      • follow `Location` header from the write response if it points
        to the same host
    Record whether the canary appears in either.

  Phase C — fuzz
    If the canary landed in either the immediate response or the view
    response, treat it like a reflected-in-view situation: classify the
    context on the view body, run static + LLM payloads for that context,
    and re-verify each via the same write→view sequence. The finding
    carries XSSClass.STORED so the reporter frames the impact correctly.

The detector intentionally does *not* generate write→view pairs by
brute force. It uses the target as-shipped and one derived view URL.
Explicit pairs (a config-declared "write X, verify at Y") are a follow-
up feature; this covers the common PRG case that traditional scanners
miss.
"""

from __future__ import annotations

import hashlib
import logging
import secrets
from dataclasses import dataclass
from typing import Optional
from urllib.parse import parse_qsl, urlencode, urljoin, urlsplit, urlunsplit

import httpx

from arachnex.ai.payload_generator import LLMPayloadGenerator
from arachnex.ai.triage import Triager, extract_features
from arachnex.core.config import Config, HeadlessMode
from arachnex.core.target import (
    Finding,
    HttpMethod,
    InjectionPoint,
    ReflectionContext,
    ReflectionEvidence,
    Severity,
    Target,
    XSSClass,
)
from arachnex.detection.context import ContextClassifier
from arachnex.exploitation.headless import HeadlessOracle
from arachnex.exploitation.payloads import PayloadLibrary
from arachnex.utils.http import HttpClient

log = logging.getLogger("arachnex.detect.stored")


@dataclass
class _StoredProbe:
    """
    State after a canary write-then-view pass. Deliberately compact:
    we don't retain the raw httpx.Response (which would hold the
    connection open) or the full response bodies past the point where
    we've decided if the canary landed. Only the small evidence body
    used for context classification is kept.
    """
    canary: str
    write_status: int
    write_location: Optional[str]     # value of the write response's Location header, if any
    view_status: Optional[int]
    where: str                        # "write", "view", or "" for not seen
    evidence_body: str                # the body we'll classify against later


class StoredXSSDetector:
    """
    Stored XSS via write-then-view state tracking.

    Only fires on targets whose method mutates state (POST/PUT/PATCH) or
    whose response chain suggests persistence. For pure-GET reflection
    the reflected detector already handles it; there's nothing new here.
    """

    _MUTATING_METHODS = {"POST", "PUT", "PATCH"}

    def __init__(
        self,
        cfg: Config,
        http: HttpClient,
        payloads: PayloadLibrary,
        classifier: ContextClassifier,
        llm: Optional[LLMPayloadGenerator],
        oracle: Optional[HeadlessOracle],
        triager: Triager,
    ) -> None:
        self.cfg = cfg
        self.http = http
        self.payloads = payloads
        self.classifier = classifier
        self.llm = llm
        self.oracle = oracle
        self.triager = triager

    async def scan_target(self, target: Target) -> list[Finding]:
        if target.method.value not in self._MUTATING_METHODS:
            return []
        if not target.injection_points:
            return []

        findings: list[Finding] = []
        for ip in target.injection_points:
            try:
                ip_findings = await self._scan_injection(target, ip)
                findings.extend(ip_findings)
            except Exception:
                log.exception("stored scan failed for %s :: %s",
                              target.url, ip.name)
        return findings

    # ------------------------------------------------------------------ #
    # Per-injection-point pipeline
    # ------------------------------------------------------------------ #

    async def _scan_injection(self, target: Target,
                              ip: InjectionPoint) -> list[Finding]:
        canary = f"arx{secrets.token_hex(4)}"
        probe = await self._write_then_view(target, ip, canary)
        if probe is None or not probe.where:
            return []

        contexts = self.classifier.classify(probe.evidence_body, canary)
        contexts = [c for c in contexts
                    if c.context != ReflectionContext.UNREFLECTED]
        if not contexts:
            return []

        # Use the first context — stored contexts rarely have multi-site
        # reflections in practice.
        ctx_result = contexts[0]

        # Assemble payload set: static + LLM (deduplicated by value).
        static = self.payloads.for_context(ctx_result.context)
        seen: set[str] = set()
        ordered: list[tuple[str, str, str]] = []
        for p in static:
            if p.value in seen:
                continue
            seen.add(p.value)
            ordered.append((p.value, p.marker, "static"))

        if self.llm and self.cfg.use_llm:
            try:
                llm_payloads = self.llm.generate(
                    context=ctx_result.context,
                    snippet=ctx_result.snippet,
                    canary="arx-marker",
                    n=self.cfg.llm_payloads_per_context,
                )
                for p in llm_payloads:
                    if p.value in seen:
                        continue
                    seen.add(p.value)
                    ordered.append((p.value, p.marker or "alert:31337", "llm"))
            except Exception:
                log.debug("LLM generation failed for stored context",
                          exc_info=True)

        log.info("stored fuzz %s [%s] with %d payloads",
                 target.url, ctx_result.context.value, len(ordered))

        findings: list[Finding] = []
        for value, marker, source in ordered:
            replay = await self._write_then_view(target, ip, value)
            if replay is None or not replay.where:
                continue
            saw_in_view = (replay.where == "view")
            finding = self._build_finding(
                target, ip, ctx_result.context, value, source,
                replay.evidence_body, marker,
                saw_in_view=saw_in_view,
            )

            # Headless verification if oracle is up. We verify against
            # the view URL if that's where the payload landed — that
            # matches what a real victim would see.
            if self.oracle and self.cfg.headless != HeadlessMode.OFF:
                verify_target = target
                if saw_in_view:
                    verify_target = self._as_view_target(target)
                try:
                    oc = await self.oracle.verify(
                        verify_target, ip, value, marker,
                    )
                    if oc and oc.executed:
                        finding.browser_proof = oc.to_browser_proof()
                except Exception:
                    log.debug("stored oracle failed", exc_info=True)

            feats = extract_features(
                finding, response_headers={},
                waf_active=False, auth_required=False,
            )
            finding.confidence = self.triager.score(finding, feats)
            finding.severity = self.triager.severity_for(finding.confidence,
                                                         feats)

            if finding.confidence >= self.cfg.triage_threshold:
                findings.append(finding)
                # One confirmed stored finding per (target, ip) is enough.
                if finding.browser_proof and finding.browser_proof.exec_observed:
                    return findings

        return findings

    # ------------------------------------------------------------------ #
    # Write-then-view state tracker
    # ------------------------------------------------------------------ #

    async def _write_then_view(
        self, target: Target, ip: InjectionPoint, value: str,
    ) -> Optional[_StoredProbe]:
        # Phase A — write. We hold onto the write body only long enough
        # to check for reflection; then drop it so we don't retain
        # (possibly megabytes of) response text per fuzz iteration.
        write_resp, write_body = await self._send(target, ip, value)
        if write_resp is None:
            return None
        seen_in_write = value in write_body
        write_status = write_resp.status_code
        write_location = (
            write_resp.headers.get("location")
            or write_resp.headers.get("Location")
        )

        # Phase B — view
        view_url = self._derive_view_url(target, write_location)
        view_body = ""
        view_status: Optional[int] = None
        if view_url:
            try:
                view_resp = await self.http.request(
                    "GET", view_url,
                    headers=dict(target.headers) or None,
                    cookies=dict(target.cookies) or None,
                )
                view_status = view_resp.status_code
                view_body = _safe_body(view_resp)
            except Exception:
                log.debug("view GET failed for %s", view_url, exc_info=True)

        seen_in_view = (value in view_body) if view_body else False
        where = "view" if seen_in_view else ("write" if seen_in_write else "")

        # Pick the body we'll classify against; drop the other to shrink
        # per-iteration memory. Cap the retained body to a modest snippet
        # window — the classifier only needs the neighbourhood.
        evidence_body = view_body if seen_in_view else (write_body if seen_in_write else "")

        return _StoredProbe(
            canary=value,
            write_status=write_status,
            write_location=write_location,
            view_status=view_status,
            where=where,
            evidence_body=evidence_body,
        )

    def _derive_view_url(
        self, target: Target, location_header: Optional[str],
    ) -> Optional[str]:
        """
        Pick a URL to fetch to check for stored reflection.

        Priority:
          1. Same-scheme, same-host `Location` header from the write
             response — resolved absolute against the target URL.
          2. The target URL itself, but with the mutating query stripped.

        We reject Location headers that would change scheme (e.g.
        redirects to `file://`, `data:`, or protocol-relative URLs that
        resolve to a different host). Cookies are attached to the view
        request, so a permissive redirect would exfiltrate them.
        """
        target_split = urlsplit(target.url)
        allowed_schemes = {"http", "https"}

        if location_header:
            try:
                absolute = urljoin(target.url, location_header)
                u = urlsplit(absolute)
                if (u.scheme in allowed_schemes
                        and u.netloc.lower() == target_split.netloc.lower()):
                    return absolute
            except Exception:
                pass

        # Fallback: re-GET the target URL with no query params. Skip when
        # the target itself lives on a non-http scheme (defensive).
        if target_split.scheme in allowed_schemes:
            return urlunsplit(
                (target_split.scheme, target_split.netloc,
                 target_split.path or "/", "", "")
            )
        return None

    @staticmethod
    def _as_view_target(target: Target) -> Target:
        """Return a GET-shaped copy of the target for oracle verification."""
        try:
            u = urlsplit(target.url)
            view_url = urlunsplit((u.scheme, u.netloc, u.path or "/", "", ""))
        except Exception:
            view_url = target.url
        return Target(
            url=view_url,
            method=HttpMethod.GET,
            headers=dict(target.headers),
            cookies=dict(target.cookies),
        )

    # ------------------------------------------------------------------ #
    # HTTP send — same as ReflectedXSSDetector._send_with_payload but
    # kept isolated so it doesn't couple stored to reflected internals.
    # ------------------------------------------------------------------ #

    async def _send(
        self, target: Target, ip: InjectionPoint, value: str,
    ) -> tuple[Optional[httpx.Response], str]:
        try:
            method = target.method.value
            url = target.url
            data = target.body
            headers = dict(target.headers)
            cookies = dict(target.cookies)

            if ip.location == "query":
                u = urlsplit(url)
                qs = parse_qsl(u.query, keep_blank_values=True)
                qs = [(k, value if k == ip.name else v) for k, v in qs]
                if ip.name not in dict(qs):
                    qs.append((ip.name, value))
                url = urlunsplit(u._replace(query=urlencode(qs, doseq=True)))
            elif ip.location == "body":
                if target.body_kind == "json":
                    import json as _json
                    try:
                        b = _json.loads(target.body or "{}")
                        b[ip.name] = value
                        data = _json.dumps(b)
                    except Exception:
                        return None, ""
                else:
                    items = parse_qsl(target.body or "", keep_blank_values=True)
                    items = [(k, value if k == ip.name else v) for k, v in items]
                    if ip.name not in dict(items):
                        items.append((ip.name, value))
                    data = urlencode(items, doseq=True)
            elif ip.location == "header":
                headers[ip.name] = _strip_ctl(value)
            elif ip.location == "cookie":
                cookies[ip.name] = _strip_ctl(value)
            else:
                return None, ""

            resp = await self.http.request(
                method, url,
                data=data if method in {"POST", "PUT", "PATCH"} else None,
                headers=headers, cookies=cookies,
            )
            body = _safe_body(resp)
            return resp, body
        except Exception:
            log.debug("stored send failed", exc_info=True)
            return None, ""

    # ------------------------------------------------------------------ #
    # Finding builder
    # ------------------------------------------------------------------ #

    @staticmethod
    def _build_finding(
        target: Target,
        ip: InjectionPoint,
        ctx: ReflectionContext,
        payload: str,
        source: str,
        body: str,
        marker: str,
        *,
        saw_in_view: bool,
    ) -> Finding:
        offset = body.find(payload)
        snippet = body[max(0, offset - 100): offset + len(payload) + 100] \
            if offset >= 0 else body[:300]
        # Reproducible hash — Python's builtin hash() is randomised per
        # interpreter run, which makes response_hash useless for
        # cross-run diffing of scan reports.
        body_hash = hashlib.sha256(body.encode("utf-8", errors="replace")).hexdigest()[:16]
        evidence = ReflectionEvidence(
            canary=payload,
            snippet=snippet,
            offset=offset,
            response_size=len(body),
            response_hash=body_hash,
            classified_context=ctx,
            classifier_confidence=0.90,
        )
        where = "view endpoint" if saw_in_view else "write response"
        return Finding(
            xss_class=XSSClass.STORED,
            severity=Severity.HIGH,
            confidence=0.0,
            target_url=target.url,
            method=target.method,
            injection_point=ip,
            payload=payload,
            reflection=evidence,
            title=(f"Stored XSS via `{ip.name}` "
                   f"(reflected on {where}, context: {ctx.value})"),
            raw_request=target.url,
            raw_response_snippet=snippet,
            extra={"payload_source": source, "stored_marker": marker,
                   "stored_where": where},
            cwe=["CWE-79"],
        )


# Cap for full body materialisation; an attacker who controls the target
# can otherwise OOM the scanner with a multi-GB response.
_MAX_BODY_BYTES = 4 * 1024 * 1024        # 4 MiB


def _strip_ctl(value: str) -> str:
    """
    Remove control characters that would enable CRLF injection when a
    payload flows into a header or cookie sink. Real XSS payloads never
    need CR/LF/NUL in header/cookie contexts, so stripping preserves
    the fuzzing intent while closing this scanner-host attack surface.
    """
    return value.replace("\r", "").replace("\n", "").replace("\x00", "")


def _safe_body(resp) -> str:
    """
    Read response body up to _MAX_BODY_BYTES. httpx's `resp.text` loads
    the entire body into memory. An attacker-controlled target could
    otherwise DoS the scanner with a giant response.
    """
    try:
        raw = resp.content
    except Exception:
        return ""
    if raw is None:
        return ""
    if len(raw) > _MAX_BODY_BYTES:
        raw = raw[:_MAX_BODY_BYTES]
    encoding = resp.encoding or "utf-8"
    try:
        return raw.decode(encoding, errors="replace")
    except LookupError:
        return raw.decode("utf-8", errors="replace")
