"""
postMessage XSS detector.

Modern SPAs and multi-frame apps use `window.postMessage` liberally.
Pages that read `event.data` without validating either the sender's
origin or the data structure execute arbitrary attacker-controlled JS
when a malicious page posts a message.

Static analysis (see `detection.dom`) can spot `event.data → sink`
flows in JS bundles but many message handlers are attached at runtime
(e.g. by a library that lazy-loads). This dynamic detector:

  1. Loads the target page in a headless browser.
  2. Monkey-patches `window.addEventListener` at init time so every
     'message' handler registration is captured on `window.__arx_msg`.
  3. Fires a suite of adversarial `postMessage` payloads at the top
     window (and all iframes we can reach) that exercise common unsafe
     patterns: HTML-like data, JS-like strings, `{href:'javascript:…'}`
     shaped objects, and pure-object destructuring targets.
  4. Watches for exec via the standard `__arx` sentinel + console.

Each executing payload becomes a DOM/postmessage Finding.
"""

from __future__ import annotations

import logging
import secrets
from dataclasses import dataclass
from typing import Optional

from arachnex.core.config import Config
from arachnex.core.target import (
    Finding,
    HttpMethod,
    InjectionPoint,
    ReflectionContext,
    ReflectionEvidence,
    Severity,
    Target,
    XSSClass,
)

log = logging.getLogger("arachnex.detect.postmessage")


# JS injected before any page script. It:
#   1. Installs the standard __arx sentinel that HeadlessOracle uses.
#   2. Wraps addEventListener so 'message' handlers get recorded.
_INIT_SCRIPT = r"""
(() => {
  if (window.__arx) return;
  const hits = [];
  window.__arx = {
    hits,
    mark(tag) { try { hits.push(String(tag)); console.log('__arx_exec__:'+tag); } catch(e){} return tag; }
  };
  const wrap = (fn, name) => function() {
    try {
      const s = String(arguments[0] || '');
      window.__arx.mark('call:'+name+':'+s.slice(0, 64));
    } catch (e) {}
    try { return fn.apply(this, arguments); } catch (e) {}
  };
  try { window.alert   = wrap(window.alert,   'alert'); } catch (e) {}
  try { window.prompt  = wrap(window.prompt,  'prompt'); } catch (e) {}
  try { window.confirm = wrap(window.confirm, 'confirm'); } catch (e) {}

  // Capture message handler registrations
  window.__arx_msg = { handlers: [] };
  const orig = window.addEventListener;
  window.addEventListener = function(type, listener, opts) {
    try {
      if (type === 'message' && typeof listener === 'function') {
        window.__arx_msg.handlers.push({
          fn_name: listener.name || '<anon>',
          fn_src_len: (listener.toString() || '').length
        });
      }
    } catch (e) {}
    return orig.call(this, type, listener, opts);
  };
})();
"""


@dataclass
class _PMResult:
    payload_label: str
    payload_data: object
    exec_observed: bool


def _payloads(marker: str) -> list[tuple[str, object]]:
    """
    Adversarial postMessage payloads that catch common unsafe patterns:

      * plain HTML string (used with innerHTML)
      * object with .html / .content / .body keys (destructured -> innerHTML)
      * object with .href / .url (assigned to location or as href attr)
      * object with .type + .payload (Redux-style)
      * pure JS string (used with eval/Function)
    """
    js_body = f"window.__arx&&__arx.mark('{marker}')"
    html_body = f"<img src=x onerror=\"window.__arx&&__arx.mark('{marker}')\">"
    href_body = f"javascript:{js_body}"

    return [
        ("plain_html_string",   html_body),
        ("object_html_key",     {"html":    html_body}),
        ("object_content_key",  {"content": html_body}),
        ("object_body_key",     {"body":    html_body}),
        ("object_message_key",  {"message": html_body}),
        ("object_href_key",     {"href":    href_body}),
        ("object_url_key",      {"url":     href_body}),
        ("object_src_key",      {"src":     href_body}),
        ("redux_style",         {"type": "SET_HTML", "payload": html_body}),
        ("plain_js_string",     js_body),
        ("object_code_key",     {"code":    js_body}),
        ("object_action_key",   {"action":  "eval", "data": js_body}),
        # Some handlers JSON.parse(data) — provide a stringified variant
        ("json_stringified",    '{"html":"' + html_body.replace('"', '\\"') + '"}'),
    ]


class PostMessageXSSDetector:
    """
    Dynamic postMessage-XSS detection. Runs against a page URL.
    """

    def __init__(self, cfg: Config, oracle) -> None:
        self.cfg = cfg
        self.oracle = oracle          # HeadlessOracle instance

    def _available(self) -> bool:
        return self.oracle is not None and getattr(self.oracle, "_browser", None) is not None

    async def scan(self, page_url: str) -> list[Finding]:
        if not self._available():
            return []

        findings: list[Finding] = []
        marker = f"arx-pm-{secrets.token_hex(3)}"
        payloads = _payloads(marker)

        browser = self.oracle._browser
        context = None
        page = None
        handlers_seen = 0
        try:
            context = await browser.new_context(
                ignore_https_errors=not self.cfg.verify_tls,
                user_agent=self.cfg.user_agent,
                extra_http_headers=self.cfg.extra_headers or None,
                proxy={"server": self.cfg.proxy} if self.cfg.proxy else None,
            )
            await context.add_init_script(_INIT_SCRIPT)
            page = await context.new_page()

            executed_marker = {"val": False}

            def _console(msg):
                try:
                    if marker in (msg.text or ""):
                        executed_marker["val"] = True
                except Exception:
                    pass

            page.on("console", _console)

            def _dialog(dlg):
                try:
                    if marker in (dlg.message or ""):
                        executed_marker["val"] = True
                    import asyncio as _a
                    _a.ensure_future(dlg.dismiss())
                except Exception:
                    pass

            page.on("dialog", _dialog)

            try:
                await page.goto(page_url, timeout=8000,
                                wait_until="domcontentloaded")
            except Exception as e:
                log.debug("postmessage nav failed: %s", e)
                return []

            # If the page never installs a 'message' handler, we bail
            # early. Not doing so would produce a lot of low-value noise
            # against pages that just don't use postMessage.
            try:
                handlers_seen = int(await page.evaluate(
                    "() => (window.__arx_msg && window.__arx_msg.handlers.length) || 0"
                ) or 0)
            except Exception:
                handlers_seen = 0

            if handlers_seen == 0:
                log.debug("postmessage: no message handlers on %s", page_url)
                return []

            # Fire each payload separately with a short settle window.
            confirmed: list[_PMResult] = []
            for label, data in payloads:
                executed_marker["val"] = False
                try:
                    await page.evaluate(
                        "p => window.postMessage(p, '*')", data,
                    )
                    await page.wait_for_timeout(600)
                    hit = bool(await page.evaluate(
                        "m => !!(window.__arx && window.__arx.hits && window.__arx.hits.includes(m))",
                        marker,
                    ))
                    if hit or executed_marker["val"]:
                        confirmed.append(_PMResult(label, data, True))
                except Exception:
                    log.debug("postmessage payload %s failed", label, exc_info=True)

            for r in confirmed:
                findings.append(self._to_finding(page_url, r, marker, handlers_seen))
        except Exception:
            log.debug("postmessage scan crashed", exc_info=True)
        finally:
            for closer in (page, context):
                if closer is not None:
                    try:
                        await closer.close()
                    except Exception:
                        pass

        return findings

    @staticmethod
    def _to_finding(page_url: str, r: _PMResult, marker: str,
                    handlers_seen: int) -> Finding:
        return Finding(
            xss_class=XSSClass.DOM,
            severity=Severity.HIGH,
            confidence=0.95,
            target_url=page_url,
            method=HttpMethod.GET,
            injection_point=InjectionPoint(
                location="postmessage", name="event.data",
            ),
            payload=str(r.payload_data)[:512],
            reflection=ReflectionEvidence(
                canary=marker,
                snippet=f"postMessage → handler exec (label={r.payload_label})",
                offset=-1, response_size=0, response_hash="",
                classified_context=ReflectionContext.HTML_BODY,
                classifier_confidence=1.0,
            ),
            title=f"postMessage XSS ({r.payload_label}) at {page_url}",
            extra={
                "postmessage_label": r.payload_label,
                "message_handlers_installed": handlers_seen,
                "marker": marker,
            },
            cwe=["CWE-79", "CWE-346"],
        )
