"""
Self-XSS annotator.

"Self-XSS" is a class where a payload only ever executes for the user
who supplied it. Real bug-bounty programs *sometimes* accept self-XSS
(if the target lets an attacker plant the payload via another channel:
clipboard hijack, social-engineering paste, extension injection) but
most modern programs reject it as out-of-scope. The reporter should
therefore *label* self-XSS distinctly rather than silently promoting it
to a full Reflected finding.

This module doesn't run its own network fuzz. It inspects the set of
findings produced by other detectors and re-classifies the ones that
are structurally self-XSS:

  * Reflection sources whose only trigger is a user's own input
    (client-side reflection of `document.cookie`, `localStorage`,
    `window.name` when *the same origin* set them).
  * Reflected findings where the injection point is a header the
    target reads back but the browser never sends unless the user pasted
    it (custom headers not sent by default; `Referer` when a same-origin
    control page set it).
  * Findings whose confirmed path requires a user gesture the attacker
    cannot induce (e.g. paste-into-search, drag-drop only).

Everything remains a Finding — we downgrade severity + attach a
`self_xss_reason` explanation so the report layer can render it in the
right bucket.
"""

from __future__ import annotations

import logging
from typing import Iterable

from arachnex.core.target import Finding, Severity, XSSClass

log = logging.getLogger("arachnex.detect.self_xss")


# Injection-point (location, name) tuples the browser never sends to a
# server unless the user (or a same-origin script) sets them.
_SELF_ONLY_SOURCES = {
    ("dom", "document.cookie"),
    ("dom", "localStorage.getItem"),
    ("dom", "sessionStorage.getItem"),
    ("dom", "window.name"),
    ("header", "X-Custom"),
}


# Header names browsers actively refuse to override via fetch/XHR — if a
# scanner "finds" reflection here, the exploit path is not attacker-
# reachable.
_FORBIDDEN_HEADERS = {
    "cookie", "host", "content-length", "connection", "origin",
    "sec-fetch-mode", "sec-fetch-site", "user-agent",
}


def annotate(findings: Iterable[Finding]) -> list[Finding]:
    """
    Pass 1: mark findings that are structurally self-XSS.

    We mutate the finding in place: downgrade severity to LOW/INFO,
    change xss_class to SELF if it was REFLECTED, and add
    `finding.extra["self_xss_reason"]`.

    Returns the same list; caller keeps the ordering.
    """
    out: list[Finding] = []
    for f in findings:
        reason = _reason_for(f)
        if reason is None:
            out.append(f)
            continue
        f.extra = dict(f.extra or {})
        f.extra["self_xss_reason"] = reason
        # If this was previously classified as reflected but is
        # structurally self-only, re-label it. Preserve the original
        # class in extra so the operator can inspect.
        f.extra["original_xss_class"] = f.xss_class.value
        f.xss_class = XSSClass.SELF
        f.severity = Severity.LOW
        # Confidence is unchanged: the exploit still works, just for
        # the user's own session.
        log.info("self-xss annotated: %s (%s)", f.title, reason)
        out.append(f)
    return out


def _reason_for(f: Finding) -> str | None:
    ip_key = (f.injection_point.location, f.injection_point.name)
    if ip_key in _SELF_ONLY_SOURCES:
        return f"source {ip_key[1]} is user-set, not attacker-reachable"

    if f.injection_point.location == "header":
        low = f.injection_point.name.lower()
        if low in _FORBIDDEN_HEADERS:
            return (
                f"header `{f.injection_point.name}` is forbidden for "
                f"cross-origin fetch — attacker cannot induce this "
                f"header on a victim request"
            )

    # DOM sources that need same-origin setup already fall under the
    # SELF class if the confirmer marked them so.
    if f.xss_class == XSSClass.DOM:
        src_kind = (f.extra or {}).get("source_kind", "")
        if src_kind in {"cookie", "window_name", "storage"}:
            # These *can* be attacker-reachable via secondary bugs
            # (SSO leak, session-fixation, extension abuse) but not
            # via a simple URL delivered to a victim. Downgrade to
            # LOW and label it.
            return (
                f"DOM XSS driven by {src_kind} — requires a secondary "
                f"vector (paste, extension, prior compromise) to reach "
                f"an attacker-controlled state"
            )

    return None
