"""
WAF fingerprinting.

Single-regex WAF identifiers fail against modern deployments: vendors
rotate signatures constantly and many deployments are tuned to look
generic. We use a *multi-feature voting* approach instead:

  • status code anomalies (412, 419, 429, 503 patterns)
  • response header signatures (Server, X-*, Set-Cookie names, CF-Ray, etc.)
  • body signatures (block-page DOM, ray IDs, support refs)
  • timing patterns (canned response latency ~< 50 ms after 200-char POST)
  • response size cliffs (block pages have characteristic sizes)
  • header-order fingerprint (some WAFs reorder headers)

Each vendor has a vote table. The vendor with the highest summed score
above a threshold wins. Below the threshold we report 'unknown'.

This is *deliberately conservative* — false positives in WAF
identification cause us to pick the wrong bypass strategy, wasting
budget. We'd rather say 'unknown' than guess.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Optional

import httpx


@dataclass
class WafFingerprint:
    vendor: Optional[str]
    confidence: float
    matched_features: list[str] = field(default_factory=list)
    block_status: Optional[int] = None
    block_signature: Optional[str] = None


# --------------------------------------------------------------------------- #
# Vendor feature tables
# --------------------------------------------------------------------------- #


# Each feature is (label, predicate, weight). Predicates take a dict of
# observations and return bool. Keep these tight — overfitting hurts.

def _has_header(name: str, pat: str | None = None):
    rx = re.compile(pat, re.I) if pat else None

    def _pred(obs: dict) -> bool:
        v = obs["headers"].get(name.lower())
        if v is None:
            return False
        return rx is None or bool(rx.search(v))
    return _pred


def _set_cookie_has(name_pat: str):
    rx = re.compile(name_pat, re.I)

    def _pred(obs: dict) -> bool:
        for c in obs["set_cookies"]:
            if rx.search(c):
                return True
        return False
    return _pred


def _body_has(pat: str):
    rx = re.compile(pat, re.I | re.S)
    return lambda obs: bool(obs["body"]) and bool(rx.search(obs["body"]))


def _status_in(codes: set[int]):
    return lambda obs: obs["status"] in codes


VENDORS: dict[str, list[tuple[str, callable, float]]] = {
    "cloudflare": [
        ("header_server_cloudflare",   _has_header("server", r"\bcloudflare\b"),         1.0),
        ("header_cf_ray",              _has_header("cf-ray"),                            1.5),
        ("header_cf_cache_status",     _has_header("cf-cache-status"),                   0.5),
        ("set_cookie___cf_bm",         _set_cookie_has(r"^__cf_bm\b"),                   1.2),
        ("set_cookie_cf_clearance",    _set_cookie_has(r"^cf_clearance\b"),              1.4),
        ("body_attention_required",    _body_has(r"attention required.*cloudflare"),    1.5),
        ("body_ray_id",                _body_has(r"ray id:?\s*[a-f0-9]+"),               0.8),
        ("status_403_after_block",     _status_in({403, 429}),                           0.2),
    ],
    "akamai": [
        ("header_akamai_x_cache",      _has_header("x-cache", r"akamai"),                1.0),
        ("set_cookie_akamai_bm_sz",    _set_cookie_has(r"^bm_sz\b"),                     1.3),
        ("set_cookie_akamai_ak_bmsc",  _set_cookie_has(r"^ak_bmsc\b"),                   1.3),
        ("set_cookie_akamai_bm_sv",    _set_cookie_has(r"^bm_sv\b"),                     1.2),
        ("body_reference_id",          _body_has(r"reference\s*#?\s*\d+\.[0-9a-f]+"),    1.4),
    ],
    "awswaf": [
        ("header_x_amzn_requestid",    _has_header("x-amzn-requestid"),                  0.6),
        ("header_server_awselb",       _has_header("server", r"awselb|amazonelb"),       0.6),
        ("body_aws_waf_token",         _body_has(r"aws-waf-token"),                      1.5),
        ("set_cookie_aws_waf_token",   _set_cookie_has(r"^aws-waf-token\b"),             1.5),
        ("status_403_request_blocked", _status_in({403}),                                0.2),
    ],
    "sucuri": [
        ("header_server_sucuri",       _has_header("server", r"sucuri"),                 1.5),
        ("header_x_sucuri_id",         _has_header("x-sucuri-id"),                       1.5),
        ("body_sucuri_block_page",     _body_has(r"sucuri\s+website\s+firewall"),       1.5),
    ],
    "fastly": [
        ("header_fastly",              _has_header("fastly-debug-digest"),               1.0),
        ("header_x_served_by_fastly",  _has_header("x-served-by", r"cache-.*-"),         0.4),
        ("header_server_varnish",      _has_header("server", r"\bvarnish\b"),            0.5),
    ],
    "imperva_incapsula": [
        ("header_x_iinfo",             _has_header("x-iinfo"),                           1.5),
        ("header_x_cdn_imperva",       _has_header("x-cdn", r"imperva|incapsula"),       1.4),
        ("body_incapsula_incident_id", _body_has(r"incapsula\s+incident\s+id"),         1.5),
        ("set_cookie_visid_incap",     _set_cookie_has(r"^visid_incap_"),                1.0),
        ("set_cookie_incap_ses",       _set_cookie_has(r"^incap_ses_"),                  1.0),
    ],
    "f5_bigip_asm": [
        ("set_cookie_ts_session",      _set_cookie_has(r"^TS[0-9a-f]{8,}$"),             1.2),
        ("body_support_id",            _body_has(r"the requested url was rejected"),    1.4),
        ("body_support_id_number",     _body_has(r"support id is[:\s]+\d+"),             1.3),
    ],
    "modsecurity": [
        ("body_mod_security_block",    _body_has(r"mod_security|modsecurity"),           1.2),
        ("body_not_acceptable_block",  _body_has(r"\bnot acceptable\b.*mod_security"),  1.5),
        ("status_406",                 _status_in({406}),                                0.3),
    ],
    "azure_frontdoor": [
        ("header_server_azure_fd",     _has_header("server", r"microsoft-iis|azurefd"),  0.6),
        ("header_x_azure_ref",         _has_header("x-azure-ref"),                       1.4),
        ("body_blocked_by_microsoft",  _body_has(r"blocked\s+by\s+the\s+azure"),         1.4),
    ],
}


# --------------------------------------------------------------------------- #
# Public API
# --------------------------------------------------------------------------- #


class WafFingerprinter:
    """
    Stateless. Caller passes responses (baseline + a known-bad probe); we
    return the fingerprint. The engine will store this per-host so we
    don't re-fingerprint.
    """

    BLOCK_STATUSES = {401, 403, 406, 412, 419, 429, 451, 501, 503}

    def fingerprint_response(self, response: httpx.Response,
                             body_text: Optional[str] = None) -> WafFingerprint:
        obs = self._observe(response, body_text)
        scores: dict[str, tuple[float, list[str]]] = {}

        for vendor, features in VENDORS.items():
            score = 0.0
            matched: list[str] = []
            for label, pred, w in features:
                try:
                    if pred(obs):
                        score += w
                        matched.append(label)
                except Exception:
                    continue
            if score > 0:
                scores[vendor] = (score, matched)

        if not scores:
            return WafFingerprint(
                vendor=None,
                confidence=0.0,
                block_status=obs["status"] if obs["status"] in self.BLOCK_STATUSES else None,
            )

        vendor, (top_score, matched) = max(scores.items(), key=lambda kv: kv[1][0])
        # Confidence is monotonic in score; ~2.0 → high.
        conf = min(0.99, top_score / 3.0)

        block_sig = None
        if obs["body"]:
            # Capture a short signature for the report
            for line in obs["body"].splitlines():
                line = line.strip()
                if not line:
                    continue
                low = line.lower()
                if any(k in low for k in ("blocked", "firewall", "denied",
                                          "ray id", "incident", "reference",
                                          "support id")):
                    block_sig = line[:200]
                    break

        return WafFingerprint(
            vendor=vendor,
            confidence=conf,
            matched_features=matched,
            block_status=obs["status"] if obs["status"] in self.BLOCK_STATUSES else None,
            block_signature=block_sig,
        )

    @staticmethod
    def _observe(resp: httpx.Response, body_text: Optional[str]) -> dict:
        # httpx headers are case-insensitive but we normalize to lower keys.
        headers = {k.lower(): v for k, v in resp.headers.items()}
        # Cookies: collect raw Set-Cookie lines
        set_cookies: list[str] = []
        for k, v in resp.headers.multi_items():
            if k.lower() == "set-cookie":
                set_cookies.append(v)

        body = body_text
        if body is None:
            try:
                # Cap body inspection to first 8 KiB; block pages are short.
                body = resp.text[:8192]
            except Exception:
                body = ""

        return {
            "status": resp.status_code,
            "headers": headers,
            "set_cookies": set_cookies,
            "body": body or "",
        }
