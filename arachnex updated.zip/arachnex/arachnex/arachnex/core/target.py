"""
Core data models. Single source of truth for what flows through the pipeline.

Everything is Pydantic for cheap validation + JSON serialization. Findings
carry enough provenance that the report generator can rebuild the entire
attack story (request, response, mutation, browser execution proof).
"""

from __future__ import annotations

from datetime import datetime, timezone
from enum import Enum
from typing import Any, Optional
from uuid import uuid4

from pydantic import BaseModel, Field, HttpUrl


class ReflectionContext(str, Enum):
    """
    The 17 reflection contexts ArachneX's classifier targets.

    Why 17? Because the right escape sequence is fundamentally different
    in each. A `"><svg onload=alert(1)>` works in HTML body, fails in a
    double-quoted attribute (which needs `" onload="alert(1)`), fails again
    inside `<script>` (which wants `';alert(1)//`), and so on.
    """
    HTML_BODY            = "html_body"
    ATTR_DOUBLE_QUOTED   = "attr_dq"
    ATTR_SINGLE_QUOTED   = "attr_sq"
    ATTR_UNQUOTED        = "attr_uq"
    ATTR_EVENT_HANDLER   = "attr_on"          # onclick="...", etc.
    URL_HREF_SRC         = "url"              # href=, src=, formaction=
    SCRIPT_STRING_DQ     = "js_string_dq"     # var x="HERE"
    SCRIPT_STRING_SQ     = "js_string_sq"
    SCRIPT_TEMPLATE      = "js_template"      # `HERE`
    SCRIPT_IDENTIFIER    = "js_ident"         # var HERE = 1
    SCRIPT_JSON          = "js_json"          # <script>{"k":"HERE"}</script>
    STYLE_BLOCK          = "style"            # <style> or style="..."
    HTML_COMMENT         = "comment"
    CDATA                = "cdata"
    SVG_FOREIGN          = "svg_foreign"      # <svg> namespace tricks
    MATHML_FOREIGN       = "mathml_foreign"
    UNREFLECTED          = "unreflected"      # no observed reflection


class XSSClass(str, Enum):
    REFLECTED   = "reflected"
    STORED      = "stored"
    DOM         = "dom"
    BLIND       = "blind"
    MUTATION    = "mxss"
    SELF        = "self"


class Severity(str, Enum):
    INFO        = "info"
    LOW         = "low"
    MEDIUM      = "medium"
    HIGH        = "high"
    CRITICAL    = "critical"


class HttpMethod(str, Enum):
    GET     = "GET"
    POST    = "POST"
    PUT     = "PUT"
    PATCH   = "PATCH"
    DELETE  = "DELETE"


# --------------------------------------------------------------------------- #
# Target / input shape
# --------------------------------------------------------------------------- #


class InjectionPoint(BaseModel):
    """One specific input location to fuzz."""
    location: str                          # 'query', 'body', 'header', 'cookie', 'path', 'fragment', 'json'
    name: str                              # parameter / header name
    sample_value: str = ""                 # observed value, used as canary baseline
    raw_request: Optional[str] = None      # for fragment locations within json bodies, etc.


class Target(BaseModel):
    """A request shape to fuzz. Many injection points may attach to one Target."""
    id: str = Field(default_factory=lambda: uuid4().hex[:12])
    url: str                                # str not HttpUrl — many real targets have weird URLs
    method: HttpMethod = HttpMethod.GET
    headers: dict[str, str] = Field(default_factory=dict)
    cookies: dict[str, str] = Field(default_factory=dict)
    body: Optional[str] = None
    body_kind: Optional[str] = None         # 'form', 'json', 'multipart', 'raw'
    injection_points: list[InjectionPoint] = Field(default_factory=list)


# --------------------------------------------------------------------------- #
# Detection trace / evidence
# --------------------------------------------------------------------------- #


class ReflectionEvidence(BaseModel):
    """A captured reflection of an injected canary in a response."""
    canary: str
    snippet: str                            # ±100 chars around the reflection
    offset: int
    response_size: int
    response_hash: str
    classified_context: ReflectionContext
    classifier_confidence: float = 0.0


class BrowserExecutionProof(BaseModel):
    """Evidence captured from the headless browser oracle."""
    exec_observed: bool
    exec_token: str
    console_messages: list[str] = Field(default_factory=list)
    exception_text: Optional[str] = None
    cookies_present: list[str] = Field(default_factory=list)
    page_title: Optional[str] = None
    screenshot_path: Optional[str] = None
    har_path: Optional[str] = None


class WafSignal(BaseModel):
    """What we observed about the WAF defending this endpoint."""
    detected: bool = False
    vendor: Optional[str] = None            # internal detection label (see ai.waf_fingerprint.VENDORS)
    confidence: float = 0.0
    block_status: Optional[int] = None
    block_body_signature: Optional[str] = None
    bypass_strategies_tried: list[str] = Field(default_factory=list)


# --------------------------------------------------------------------------- #
# Finding — the main output unit
# --------------------------------------------------------------------------- #


class Finding(BaseModel):
    """
    One reportable issue. The shape is deliberately rich because the report
    generator narrates the attack from this object alone — no re-fetching.
    """
    id: str = Field(default_factory=lambda: uuid4().hex[:12])
    discovered_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

    xss_class: XSSClass
    severity: Severity
    confidence: float = 0.0                 # AI triage output [0, 1]

    target_url: str
    method: HttpMethod
    injection_point: InjectionPoint
    payload: str
    payload_lineage: list[str] = Field(default_factory=list)   # GA history

    reflection: Optional[ReflectionEvidence] = None
    browser_proof: Optional[BrowserExecutionProof] = None
    waf_signal: Optional[WafSignal] = None

    cvss40_vector: Optional[str] = None
    cvss40_score: float = 0.0
    cwe: list[str] = Field(default_factory=lambda: ["CWE-79"])

    title: str = ""
    narrative: Optional[str] = None         # LLM-written, optional
    remediation: Optional[str] = None

    raw_request: Optional[str] = None
    raw_response_snippet: Optional[str] = None

    extra: dict[str, Any] = Field(default_factory=dict)


class ScanSummary(BaseModel):
    """Top-level scan output."""
    scan_id: str = Field(default_factory=lambda: uuid4().hex)
    started_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    ended_at: Optional[datetime] = None

    scope: list[str] = Field(default_factory=list)
    urls_discovered: int = 0
    params_discovered: int = 0
    requests_sent: int = 0
    findings: list[Finding] = Field(default_factory=list)

    @property
    def critical_count(self) -> int:
        return sum(1 for f in self.findings if f.severity == Severity.CRITICAL)

    @property
    def high_count(self) -> int:
        return sum(1 for f in self.findings if f.severity == Severity.HIGH)
