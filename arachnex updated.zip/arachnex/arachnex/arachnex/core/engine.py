"""
ArachneX engine — top-level orchestration.

Pipeline:

  Stage 1 — Discovery
    a. Seed normalisation
    b. Async crawler
    c. Parameter miner against discovered URLs (deep mode only)
    d. JS asset DOM analysis (deep mode only)

  Stage 2 — Detection
    a. Reflected XSS sweep over all (Target, InjectionPoint) tuples
    b. Stored XSS detection (a second pass: re-fetch view endpoints
       after injecting on write endpoints; v1 = explicit pairs only)
    c. Blind XSS payload delivery (if --blind enabled)
    d. mXSS pass over reflective endpoints
    e. DOM XSS hypotheses from static analysis, dynamically confirmed

  Stage 3 — Triage & Scoring
    a. AI triage classifier
    b. CVSS 4.0 vector + numeric score
    c. Severity escalation

  Stage 4 — Reporting
    a. Build ScanSummary
    b. Render HTML / JSON / Markdown / PDF as configured

The engine respects the global request budget. Critically, it never
holds the http client unconditionally — every stage uses its own context
manager so we always close connections cleanly on Ctrl-C.
"""

from __future__ import annotations

import asyncio
import logging
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

from arachnex.ai.payload_generator import LLMPayloadGenerator
from arachnex.ai.triage import Triager
from arachnex.ai.waf_fingerprint import WafFingerprinter
from arachnex.core.config import Config, HeadlessMode, ScanMode
from arachnex.core.target import (
    Finding,
    HttpMethod,
    InjectionPoint,
    ScanSummary,
    Target,
)
from arachnex.detection.blind import BlindScanner
from arachnex.detection.context import ContextClassifier
from arachnex.detection.dom_confirm import DomXSSConfirmer
from arachnex.detection.mxss import MXSSScanner
from arachnex.detection.postmessage import PostMessageXSSDetector
from arachnex.detection.reflected import ReflectedXSSDetector
from arachnex.detection.self_xss import annotate as self_xss_annotate
from arachnex.detection.stored import StoredXSSDetector
from arachnex.discovery.crawler import Crawler
from arachnex.discovery.param_miner import ParamMiner
from arachnex.exploitation.headless import HeadlessOracle
from arachnex.exploitation.payloads import PayloadLibrary
from arachnex.reporting.cvss import populate as cvss_populate
from arachnex.reporting.html_report import HtmlReporter
from arachnex.reporting.json_report import JsonReporter
from arachnex.reporting.markdown_report import MarkdownReporter
from arachnex.utils.http import HttpClient
from arachnex.utils.logger import console, emit_finding, setup_logging

log = logging.getLogger("arachnex.engine")


class Engine:
    def __init__(self, cfg: Config) -> None:
        self.cfg = cfg
        self.summary = ScanSummary(scope=cfg.targets)

        # Component wiring — all single-instance, shared across detectors.
        self.classifier = ContextClassifier(
            model_path=Path("models/context_clf.joblib")
        )
        self.payload_lib = PayloadLibrary(cfg.payload_root)
        self.llm = LLMPayloadGenerator(
            api_key=cfg.anthropic_api_key,
            model=cfg.llm_model,
        ) if cfg.use_llm else None
        self.triager = Triager()
        self.waf_fp = WafFingerprinter()
        self.oracle: Optional[HeadlessOracle] = None
        self.dashboard = None         # set in run() when cfg.live_dashboard
        self._dashboard_task: Optional[asyncio.Task] = None

    # ------------------------------------------------------------------ #
    # Top-level run
    # ------------------------------------------------------------------ #

    async def run(self) -> ScanSummary:
        setup_logging(self.cfg.log_level, self.cfg.quiet)
        log.info("ArachneX starting · mode=%s · headless=%s · llm=%s",
                 self.cfg.mode.value, self.cfg.headless.value,
                 "yes" if self.llm and self.llm.available() else "no")
        self._warn_capability_gaps()

        # ---- Live dashboard ----
        if self.cfg.live_dashboard:
            try:
                from arachnex.exploitation.live_dashboard import LiveDashboard
                target_label = (self.cfg.targets[0] if self.cfg.targets
                                else "scope-file")
                self.dashboard = LiveDashboard(target_label=target_label)
                self._dashboard_task = asyncio.create_task(self.dashboard.run())
            except Exception:
                log.warning("could not start live dashboard", exc_info=True)
                self.dashboard = None

        if self.cfg.headless != HeadlessMode.OFF:
            try:
                self.oracle = HeadlessOracle(self.cfg)
                await self.oracle.start()
            except Exception:
                log.warning("could not start headless oracle; continuing without",
                            exc_info=True)
                self.oracle = None

        http = HttpClient(self.cfg)
        try:
            # Stage 1: discovery
            if self.dashboard:
                from arachnex.exploitation.live_dashboard import StageEvent
                self.dashboard.emit_nowait(StageEvent("discovery", "running"))
            targets = await self._discover(http)
            self.summary.urls_discovered = len({t.url for t in targets})
            self.summary.params_discovered = sum(len(t.injection_points) for t in targets)
            if self.dashboard:
                from arachnex.exploitation.live_dashboard import StageEvent
                self.dashboard.emit_nowait(
                    StageEvent("discovery", "done",
                               detail=f"{len(targets)} targets")
                )

            # Stage 2: detection
            findings = await self._detect(http, targets)

            # Structural self-XSS annotation before scoring so triage
            # sees the downgraded class + severity.
            findings = self_xss_annotate(findings)

            # Stage 3: triage & scoring
            self._score(findings)

            # Stage 4: collect
            self.summary.findings = findings
            self.summary.requests_sent = http.requests_sent
            self.summary.ended_at = datetime.now(timezone.utc)

            # Stage 5: reports
            if self.dashboard:
                from arachnex.exploitation.live_dashboard import StageEvent
                self.dashboard.emit_nowait(StageEvent("report", "running"))
            await self._report()
            if self.dashboard:
                from arachnex.exploitation.live_dashboard import StageEvent
                self.dashboard.emit_nowait(StageEvent("report", "done"))
            return self.summary
        finally:
            await http.aclose()
            if self.oracle:
                await self.oracle.stop()
            if self.dashboard:
                self.dashboard.stop()
                if self._dashboard_task:
                    try:
                        await asyncio.wait_for(self._dashboard_task, timeout=2.0)
                    except (asyncio.TimeoutError, asyncio.CancelledError):
                        self._dashboard_task.cancel()

    # ------------------------------------------------------------------ #
    # Capability warnings
    # ------------------------------------------------------------------ #

    def _warn_capability_gaps(self) -> None:
        """
        Surface silent-fallback situations. The engine keeps running with
        reduced capability, but the operator must know — otherwise demos
        misrepresent what the tool did.
        """
        if self.cfg.quiet:
            return
        # LLM requested but no key present -> silently falls back to library.
        if self.cfg.use_llm and (self.llm is None or not self.llm.available()):
            console.print(
                "[yellow]![/yellow] LLM payload generation requested but "
                "unavailable — set ANTHROPIC_API_KEY to enable. "
                "Continuing with static + polyglot payloads only."
            )
        # Trained context classifier missing -> heuristic-only path.
        model_path = Path("models/context_clf.joblib")
        if not model_path.exists():
            console.print(
                f"[yellow]![/yellow] context classifier model not found at "
                f"{model_path} — using html5lib heuristic path only "
                f"(fine for most cases; ML path adds fidelity on ambiguous "
                f"reflections)."
            )
        # Blind XSS payloads are built but never delivered unless the operator
        # points us at a collaborator — call that out too.
        if not self.cfg.blind_collab_url:
            log.info("blind XSS delivery disabled — set blind_collab_url to enable")

    # ------------------------------------------------------------------ #
    # Discovery
    # ------------------------------------------------------------------ #

    async def _discover(self, http: HttpClient) -> list[Target]:
        seeds = self.cfg.targets
        if self.cfg.scope_file and self.cfg.scope_file.exists():
            seeds = seeds + [
                ln.strip() for ln in self.cfg.scope_file.read_text().splitlines()
                if ln.strip() and not ln.startswith("#")
            ]

        if not seeds:
            log.error("no targets provided")
            return []

        all_targets: list[Target] = []

        # Add seeds themselves as Targets even if they have no obvious params,
        # so we can at least probe for hidden ones in deep mode.
        for s in seeds:
            all_targets.append(Target(url=s, method=HttpMethod.GET))

        # Crawl unless QUICK mode
        if self.cfg.mode != ScanMode.QUICK:
            crawler = Crawler(self.cfg, http)
            crawled = await crawler.crawl(seeds)
            all_targets.extend(crawled.targets)

        # Param mining on root URLs in deep / bb mode
        if self.cfg.mode in {ScanMode.DEEP, ScanMode.BUG_BOUNTY}:
            miner = ParamMiner(self.cfg, http)
            mined_total = 0
            for seed in seeds[:5]:        # bound the mining scope
                try:
                    mined = await miner.mine_query(seed)
                except Exception:
                    log.debug("mining failed", exc_info=True)
                    mined = []
                if mined:
                    mined_total += len(mined)
                    all_targets.append(
                        Target(
                            url=seed, method=HttpMethod.GET,
                            injection_points=[
                                InjectionPoint(location=m.location, name=m.name)
                                for m in mined
                            ],
                        )
                    )
            if mined_total:
                log.info("param mining: %d hidden parameters discovered", mined_total)

        # De-dupe targets by (method, url, sorted_param_names)
        seen: set[tuple] = set()
        deduped: list[Target] = []
        for t in all_targets:
            key = (
                t.method.value, t.url,
                tuple(sorted((ip.location, ip.name) for ip in t.injection_points)),
            )
            if key in seen:
                continue
            seen.add(key)
            if t.injection_points or self.cfg.mode in {ScanMode.DEEP, ScanMode.BUG_BOUNTY}:
                deduped.append(t)
        return deduped

    # ------------------------------------------------------------------ #
    # Detection
    # ------------------------------------------------------------------ #

    async def _detect(self, http: HttpClient, targets: list[Target]) -> list[Finding]:
        detector = ReflectedXSSDetector(
            cfg=self.cfg, http=http, payloads=self.payload_lib,
            classifier=self.classifier, llm=self.llm,
            oracle=self.oracle, triager=self.triager, waf_fp=self.waf_fp,
        )

        # Stored XSS runs on mutating-method targets (POST/PUT/PATCH).
        # The detector re-fetches a "view" URL after each write and looks
        # for the canary there — catches the classical PRG-pattern stored
        # bug that reflection-only scanners miss entirely.
        stored_detector: Optional[StoredXSSDetector] = None
        if self.cfg.mode != ScanMode.QUICK:
            stored_detector = StoredXSSDetector(
                cfg=self.cfg, http=http, payloads=self.payload_lib,
                classifier=self.classifier, llm=self.llm,
                oracle=self.oracle, triager=self.triager,
            )

        # mXSS scanner runs unless mode is QUICK — the differential-parse
        # pass is cheap per (target, ip) but the corpus is bounded.
        mxss_scanner: Optional[MXSSScanner] = None
        if self.cfg.mode != ScanMode.QUICK:
            candidate = MXSSScanner(cfg=self.cfg, http=http)
            if candidate.available():
                mxss_scanner = candidate
            else:
                log.info("mxss scanner unavailable (html5lib missing); skipping")

        # Blind XSS delivery — only active when the operator configured a
        # collaborator URL. Callbacks are read back at the end of the pass.
        blind_scanner: Optional[BlindScanner] = None
        if self.cfg.blind_collab_url:
            blind_scanner = BlindScanner(
                cfg=self.cfg, http=http, scan_id=self.summary.scan_id,
            )
            log.info("blind XSS delivery enabled · collab=%s",
                     self.cfg.blind_collab_url)

        # ---- Post-exploitation engine (active when oracle is up) ----
        post_exploit = None
        if self.oracle and self.cfg.run_post_exploit:
            from arachnex.exploitation.post_exploit import PostExploitEngine
            post_exploit = PostExploitEngine(self.cfg, self.oracle)

        # ---- Advanced exploitation runner (opt-in) ----
        advanced_exploit = None
        if self.oracle and self.cfg.advanced_exploit:
            from arachnex.exploitation.advanced import AdvancedExploitEngine
            advanced_exploit = AdvancedExploitEngine(self.cfg, self.oracle)
            active_note = " (ACTIVE payloads enabled)" if self.cfg.advanced_exploit_active else ""
            log.info("advanced exploitation enabled%s", active_note)

        # ---- Dynamic DOM-XSS confirmer + postMessage detector ----
        dom_confirmer: Optional[DomXSSConfirmer] = None
        pm_detector: Optional[PostMessageXSSDetector] = None
        if self.oracle:
            if self.cfg.dom_confirm:
                dom_confirmer = DomXSSConfirmer(self.cfg, http, self.oracle)
            if self.cfg.postmessage_scan:
                pm_detector = PostMessageXSSDetector(self.cfg, self.oracle)

        log.info("scanning %d targets …", len(targets))
        if self.dashboard:
            from arachnex.exploitation.live_dashboard import StageEvent
            self.dashboard.emit_nowait(
                StageEvent(name="detection", state="running",
                           detail=f"0/{len(targets)}")
            )

        sem = asyncio.Semaphore(self.cfg.threads)
        results: list[Finding] = []
        results_lock = asyncio.Lock()
        completed = {"n": 0}

        async def _one(t: Target):
            async with sem:
                try:
                    fs = await detector.scan_target(t)
                except Exception:
                    log.exception("detector crashed on %s", t.url)
                    fs = []

                # mXSS second pass — independent of reflected. We keep both
                # findings sets: reflected + mutation reveal different bugs.
                if mxss_scanner is not None:
                    try:
                        mxss_findings = await mxss_scanner.scan_target(t)
                    except Exception:
                        log.exception("mxss scanner crashed on %s", t.url)
                        mxss_findings = []
                    if mxss_findings:
                        fs = fs + mxss_findings

                # Stored XSS pass — only fires on mutating-method targets.
                if stored_detector is not None:
                    try:
                        stored_findings = await stored_detector.scan_target(t)
                    except Exception:
                        log.exception("stored scanner crashed on %s", t.url)
                        stored_findings = []
                    if stored_findings:
                        fs = fs + stored_findings

                # postMessage XSS — only for GET-style pages the crawler
                # actually loads. Runs one browser context per target,
                # so we keep it opt-in via cfg.postmessage_scan.
                if pm_detector is not None and t.method.value == "GET":
                    try:
                        pm_findings = await pm_detector.scan(t.url)
                    except Exception:
                        log.exception("postmessage scanner crashed on %s", t.url)
                        pm_findings = []
                    if pm_findings:
                        fs = fs + pm_findings

                # Blind XSS payload delivery — fire-and-remember. Findings
                # only surface later once the collab server records a
                # callback matching one of our probe ids.
                if blind_scanner is not None:
                    try:
                        await blind_scanner.deliver(t)
                    except Exception:
                        log.debug("blind delivery crashed on %s", t.url,
                                  exc_info=True)

                if fs:
                    async with results_lock:
                        for f in fs:
                            results.append(f)
                            emit_finding(
                                short_title=f.title, sev=f.severity, url=t.url,
                                extra={"payload": f.payload[:80]},
                            )
                            # Push to live dashboard
                            if self.dashboard:
                                from arachnex.exploitation.live_dashboard import FindingEvent
                                self.dashboard.emit_nowait(FindingEvent(
                                    severity=f.severity.value,
                                    title=f.title, url=t.url,
                                    payload=f.payload,
                                    executed=bool(f.browser_proof
                                                  and f.browser_proof.exec_observed),
                                    cvss=f.cvss40_score or 0.0,
                                ))

                            # ---- Post-exploitation pass ----
                            if post_exploit and f.browser_proof \
                                    and f.browser_proof.exec_observed:
                                try:
                                    proof = await post_exploit.capture(
                                        f, t, f.injection_point
                                    )
                                    f.extra["post_exploit"] = proof.__dict__
                                    if self.dashboard:
                                        from arachnex.exploitation.live_dashboard import PostExploitEvent
                                        self.dashboard.emit_nowait(PostExploitEvent(
                                            finding_title=f.title,
                                            cookies_total=len(proof.cookies),
                                            cookies_httponly=proof.cookies_http_only_count,
                                            has_session=proof.has_session_cookie,
                                            has_jwt=proof.has_jwt,
                                            has_api_key=proof.has_api_key,
                                            csrf_count=len(proof.csrf_tokens),
                                            forms_count=len(proof.forms_on_page),
                                            forms_without_csrf=sum(
                                                1 for fm in proof.forms_on_page
                                                if not fm.has_csrf
                                            ),
                                            inline_secrets=len(proof.inline_script_secrets),
                                            uplift_summary=proof.severity_uplift(),
                                            sample_tokens=[
                                                (t.location, t.name, t.value_preview)
                                                for t in proof.auth_tokens[:3]
                                            ],
                                        ))
                                except Exception:
                                    log.debug("post-exploit failed", exc_info=True)

                            # ---- Advanced exploitation pass ----
                            # Runs after the post-exploit capture so
                            # findings gain a `advanced_exploits` list
                            # with per-payload proof.
                            if advanced_exploit and f.browser_proof \
                                    and f.browser_proof.exec_observed:
                                try:
                                    adv_results = await advanced_exploit.run(
                                        f, t, f.injection_point,
                                    )
                                    if adv_results:
                                        from arachnex.exploitation.advanced import summarise
                                        f.extra["advanced_exploits"] = [
                                            {"name": r.name, "ran": r.ran,
                                             "active": r.active,
                                             "error": r.error,
                                             "data": r.data}
                                            for r in adv_results
                                        ]
                                        f.extra["advanced_exploits_summary"] = \
                                            summarise(adv_results)
                                        log.info("advanced-exploit · %s · %s",
                                                 f.title[:60],
                                                 f.extra["advanced_exploits_summary"])
                                except Exception:
                                    log.debug("advanced-exploit failed",
                                              exc_info=True)

                completed["n"] += 1
                if self.dashboard:
                    from arachnex.exploitation.live_dashboard import StageEvent
                    self.dashboard.emit_nowait(StageEvent(
                        name="detection", state="running",
                        progress=completed["n"] / max(1, len(targets)),
                        detail=f"{completed['n']}/{len(targets)}",
                    ))

        await asyncio.gather(*(_one(t) for t in targets))

        # DOM XSS static-plus-dynamic pass — one traversal per unique
        # page URL. Loads the page, extracts inline + linked JS,
        # runs the AST analyser for source→sink hypotheses, then hands
        # each candidate to the DOM confirmer which drives the
        # corresponding source in a real browser.
        if dom_confirmer is not None:
            try:
                dom_findings = await self._dom_pass(http, dom_confirmer, targets)
            except Exception:
                log.exception("dom pass crashed")
                dom_findings = []
            for f in dom_findings:
                results.append(f)
                emit_finding(
                    short_title=f.title, sev=f.severity, url=f.target_url,
                    extra={"payload": f.payload[:80]},
                )

        # Correlate any blind callbacks the collaborator recorded during
        # the pass (and optionally poll a little longer via
        # blind_collect_wait_seconds). Findings show up in the same report.
        if blind_scanner is not None:
            try:
                blind_findings = await blind_scanner.collect_findings()
            except Exception:
                log.exception("blind callback collection failed")
                blind_findings = []
            for f in blind_findings:
                results.append(f)
                emit_finding(
                    short_title=f.title, sev=f.severity, url=f.target_url,
                    extra={"probe": f.extra.get("callback_ip", "")},
                )

        if self.dashboard:
            from arachnex.exploitation.live_dashboard import StageEvent
            self.dashboard.emit_nowait(StageEvent(name="detection", state="done"))
        return results

    # ------------------------------------------------------------------ #
    # DOM XSS pass — static analyzer + dynamic confirmer
    # ------------------------------------------------------------------ #

    async def _dom_pass(
        self, http: HttpClient, dom_confirmer, targets: list[Target],
    ) -> list[Finding]:
        """
        For each unique page URL, fetch the page, harvest inline JS +
        linked script sources, feed everything to `DomXSSAnalyzer`, and
        hand the candidates to `DomXSSConfirmer` for browser confirmation.
        """
        try:
            from arachnex.detection.dom import DomXSSAnalyzer
            analyzer = DomXSSAnalyzer()
        except Exception:
            log.info("dom static analyzer unavailable (esprima missing); "
                     "skipping DOM pass")
            return []

        import re as _re
        from urllib.parse import urljoin, urlsplit
        from bs4 import BeautifulSoup

        seen_pages: set[str] = set()
        page_urls = [t.url for t in targets if t.method.value == "GET"]
        findings: list[Finding] = []

        for page_url in page_urls:
            u = urlsplit(page_url)
            key = f"{u.scheme}://{u.netloc}{u.path}"
            if key in seen_pages:
                continue
            seen_pages.add(key)

            try:
                resp = await http.request("GET", page_url)
                content_type = resp.headers.get("content-type", "").lower()
                if "text/html" not in content_type and "application/xhtml" not in content_type:
                    continue
                body = resp.text
            except Exception:
                log.debug("dom pass GET failed for %s", page_url, exc_info=True)
                continue

            try:
                soup = BeautifulSoup(body, "lxml")
            except Exception:
                soup = BeautifulSoup(body, "html.parser")

            candidates = []
            # Inline scripts
            for s in soup.find_all("script", src=False):
                src = s.string or s.get_text() or ""
                if not src.strip():
                    continue
                try:
                    candidates.extend(analyzer.analyse(src, page_url))
                except Exception:
                    pass

            # Linked script sources (same-origin only)
            page_host = u.netloc.lower()
            for s in soup.find_all("script", src=True):
                script_url = urljoin(page_url, s["src"].strip())
                if urlsplit(script_url).netloc.lower() != page_host:
                    continue
                try:
                    script_resp = await http.request("GET", script_url)
                    script_src = script_resp.text
                except Exception:
                    continue
                try:
                    candidates.extend(analyzer.analyse(script_src, script_url))
                except Exception:
                    pass

            if not candidates:
                continue

            # De-dupe by (source, sink) pair — many candidates
            # collapse after the walker enumerates all edges.
            uniq = {}
            for c in candidates:
                uniq[(c.source_label, c.sink_label)] = c
            unique_candidates = list(uniq.values())

            try:
                confirmed = await dom_confirmer.confirm(page_url, unique_candidates)
            except Exception:
                log.debug("dom-confirmer crashed on %s", page_url, exc_info=True)
                confirmed = []
            findings.extend(confirmed)

        return findings

    # ------------------------------------------------------------------ #
    # Scoring
    # ------------------------------------------------------------------ #

    def _score(self, findings: list[Finding]) -> None:
        for f in findings:
            waf_active = bool(f.waf_signal and f.waf_signal.detected)
            auth_required = False    # v1 — engine can be taught via cfg
            cvss_populate(f, waf_active=waf_active, auth_required=auth_required)

    # ------------------------------------------------------------------ #
    # Reports
    # ------------------------------------------------------------------ #

    async def _report(self) -> list[Path]:
        out_dir = self.cfg.output_dir
        out_dir.mkdir(parents=True, exist_ok=True)
        scan_dir = out_dir / self.summary.scan_id[:12]
        scan_dir.mkdir(parents=True, exist_ok=True)
        written: list[Path] = []

        fmts = {f.lower() for f in self.cfg.report_formats}

        if "html" in fmts:
            from arachnex import __version__
            html_rep = HtmlReporter(version=__version__)
            written.append(html_rep.render(self.summary, scan_dir / "report.html"))
        if "json" in fmts:
            written.append(JsonReporter().render(self.summary, scan_dir / "report.json"))
        if "md" in fmts or "markdown" in fmts:
            written.append(MarkdownReporter().render(self.summary, scan_dir / "report.md"))

        console.print()
        console.print(f"[bold green]✓[/bold green] scan complete · "
                      f"{self.summary.critical_count} critical, "
                      f"{self.summary.high_count} high")
        for p in written:
            console.print(f"  [dim]→[/dim] {p}")
        return written
