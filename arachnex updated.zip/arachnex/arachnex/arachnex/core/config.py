"""
Scan configuration. Loaded from CLI args, env vars, or YAML file.

Precedence: CLI > env > YAML > defaults.
"""

from __future__ import annotations

from enum import Enum
from pathlib import Path
from typing import Optional

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class ScanMode(str, Enum):
    QUICK         = "quick"      # one-shot, fast, library payloads only
    STANDARD      = "standard"   # default: library + context classifier + browser verify
    DEEP          = "deep"       # + LLM gen + GA evolution + full crawl
    BUG_BOUNTY    = "bb"         # alias of deep with rate limits tuned for prod targets


class HeadlessMode(str, Enum):
    OFF           = "off"        # no browser at all
    VERIFY        = "verify"     # browser only confirms reflection-flagged findings
    ALWAYS        = "always"     # browser is the primary oracle


class Config(BaseSettings):
    """
    All scan knobs live here. Add a field — it's automatically available
    via env var (prefix ARACHNEX_) and via the CLI flag of the same name.
    """

    model_config = SettingsConfigDict(
        env_prefix="ARACHNEX_",
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )

    # ----- Targets & scope -------------------------------------------------- #
    targets: list[str] = Field(default_factory=list)
    scope_file: Optional[Path] = None
    out_of_scope: list[str] = Field(default_factory=list)

    # ----- Pipeline mode ---------------------------------------------------- #
    mode: ScanMode = ScanMode.STANDARD
    headless: HeadlessMode = HeadlessMode.VERIFY

    # ----- Concurrency & rate limits --------------------------------------- #
    threads: int = 25                       # logical concurrent workers
    rps_per_host: float = 8.0               # per-host token bucket
    request_timeout: float = 15.0
    crawl_depth: int = 3
    crawl_max_urls: int = 1500

    # ----- HTTP behaviour --------------------------------------------------- #
    user_agent: str = "ArachneX/0.1 (authorized testing only)"
    proxy: Optional[str] = None             # HTTP(S) proxy URL, e.g. http://127.0.0.1:8080
    follow_redirects: bool = True
    verify_tls: bool = True
    cookies: dict[str, str] = Field(default_factory=dict)
    extra_headers: dict[str, str] = Field(default_factory=dict)

    # ----- AI knobs --------------------------------------------------------- #
    use_llm: bool = True                    # falls back gracefully if no key
    anthropic_api_key: Optional[str] = None
    llm_model: str = "claude-sonnet-4-6"
    llm_payloads_per_context: int = 10
    use_evolution: bool = True
    evolution_generations: int = 30
    evolution_pop_size: int = 24
    triage_threshold: float = 0.4           # findings below this are suppressed

    # ----- Payload library -------------------------------------------------- #
    payload_root: Path = Path("payloads")
    custom_payload_file: Optional[Path] = None
    max_payloads_per_param: int = 0         # 0 = unlimited; AI sets the budget

    # ----- Blind XSS -------------------------------------------------------- #
    blind_domain: Optional[str] = None      # e.g. xss.your-collab.com
    blind_listen: str = "0.0.0.0:8443"

    # Public URL of the collaborator (set when the operator wants blind
    # payloads to be delivered as part of the scan). The engine reads
    # callbacks from the collaborator's SQLite DB after the fuzz pass.
    blind_collab_url: Optional[str] = None    # e.g. https://xss.your-collab.com
    blind_collab_ws:  Optional[str] = None    # e.g. wss://xss.your-collab.com
    blind_collab_dns: Optional[str] = None    # e.g. xss.your-collab.com
    blind_collab_db:  Path = Path("./arachnex-out/collab.sqlite3")
    # How long the engine polls the DB after the fuzz pass, waiting for
    # slow-firing callbacks. Zero disables the wait; callbacks that land
    # later are still visible in the collab DB for follow-up scans.
    blind_collect_wait_seconds: float = 0.0

    # ----- Output ----------------------------------------------------------- #
    output_dir: Path = Path("./arachnex-out")
    report_formats: list[str] = Field(default_factory=lambda: ["html", "json"])
    screenshot_findings: bool = True
    save_har: bool = False

    # ----- Exploitation features ------------------------------------------- #
    run_post_exploit: bool = True           # capture impact data on confirmed XSS
    live_dashboard: bool = False            # render real-time TUI during scan

    # Advanced exploitation — runs after a confirmed XSS to demonstrate
    # concrete impact via a suite of JS payloads (session hijack, JWT
    # decoding, GraphQL introspection, form snapshot, credential
    # overlay). Read-only payloads only unless the operator explicitly
    # enables the active suite.
    advanced_exploit: bool = False
    advanced_exploit_active: bool = False     # enable payloads that modify target state
    advanced_exploit_suite: list[str] = Field(default_factory=list)
                                             # explicit payload names; empty = default suite

    # ----- DOM XSS dynamic confirmation ------------------------------------ #
    dom_confirm: bool = True                # dynamically confirm static DOM candidates
    dom_confirm_max_candidates: int = 12    # cap candidates per page (Playwright is slow)

    # ----- postMessage XSS -------------------------------------------------- #
    postmessage_scan: bool = True           # run postMessage fuzzer on crawled pages

    # ----- Diagnostics ------------------------------------------------------ #
    log_level: str = "INFO"
    quiet: bool = False

    def in_scope(self, host: str) -> bool:
        """Coarse scope check; the engine layers a finer one on top."""
        if any(host == oos or host.endswith("." + oos) for oos in self.out_of_scope):
            return False
        if not self.scope_file:
            return True
        # scope_file is parsed lazily by the engine; this is a placeholder.
        return True
