"""
HTML report generator.

A real bug-bounty / pentest report needs:
  • A summary panel that explains the scan and key counts
  • Per-finding cards: title, severity, CVSS vector, payload, request,
    response snippet with the reflection highlighted, browser proof
    (screenshot if available), and a recommended fix.
  • A self-contained HTML — no external CDN, no JS framework. The
    person reading this might be offline (airgapped triage box).

We render everything via Jinja2 with a single template. Screenshots are
base64-embedded so the report is one file you can email or attach.
"""

from __future__ import annotations

import base64
import html
import logging
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

from jinja2 import Environment, DictLoader, select_autoescape

from arachnex.core.target import Finding, ScanSummary, Severity

log = logging.getLogger("arachnex.report.html")


HTML_TEMPLATE = r"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>ArachneX Report — {{ summary.scan_id[:12] }}</title>
<meta name="viewport" content="width=device-width,initial-scale=1">
<style>
  :root {
    --bg: #0e1015;
    --panel: #161922;
    --panel-2: #1d2230;
    --border: #2a3142;
    --text: #e6e8ee;
    --text-dim: #9aa3b2;
    --accent: #7c9cff;
    --critical: #ff5577;
    --high: #ff8855;
    --medium: #f1c40f;
    --low: #2ecc71;
    --info: #5dade2;
    --code-bg: #0a0c12;
  }
  * { box-sizing: border-box; }
  body {
    margin: 0; background: var(--bg); color: var(--text);
    font-family: ui-sans-serif, system-ui, -apple-system, "Segoe UI",
                 Roboto, "Helvetica Neue", Arial, sans-serif;
    line-height: 1.55; font-size: 14px;
  }
  .wrap { max-width: 1100px; margin: 0 auto; padding: 32px 24px 60px; }
  header.head {
    display: flex; align-items: flex-end; justify-content: space-between;
    gap: 24px; padding-bottom: 18px; border-bottom: 1px solid var(--border);
  }
  .brand { font-size: 22px; font-weight: 700; letter-spacing: .3px; }
  .brand .x { color: var(--accent); }
  .meta { color: var(--text-dim); font-size: 12px; text-align: right; }

  .summary {
    margin: 26px 0; display: grid; gap: 14px;
    grid-template-columns: repeat(auto-fit, minmax(140px, 1fr));
  }
  .card {
    background: var(--panel); border: 1px solid var(--border);
    border-radius: 10px; padding: 14px 16px;
  }
  .card .k { font-size: 11px; text-transform: uppercase;
             letter-spacing: .8px; color: var(--text-dim); }
  .card .v { font-size: 26px; font-weight: 700; margin-top: 4px; }
  .card.crit .v { color: var(--critical); }
  .card.high .v { color: var(--high); }

  h2.section-title {
    margin: 36px 0 14px; font-size: 13px; color: var(--text-dim);
    text-transform: uppercase; letter-spacing: 1px; font-weight: 600;
  }

  .finding {
    background: var(--panel); border: 1px solid var(--border);
    border-left: 4px solid var(--info); border-radius: 12px;
    padding: 20px 22px; margin-bottom: 16px;
  }
  .finding.sev-critical { border-left-color: var(--critical); }
  .finding.sev-high     { border-left-color: var(--high); }
  .finding.sev-medium   { border-left-color: var(--medium); }
  .finding.sev-low      { border-left-color: var(--low); }
  .finding.sev-info     { border-left-color: var(--info); }

  .finding-head {
    display: flex; align-items: center; gap: 12px; flex-wrap: wrap;
    margin-bottom: 8px;
  }
  .sev-badge {
    font-size: 11px; font-weight: 700; text-transform: uppercase;
    padding: 2px 8px; border-radius: 999px; letter-spacing: .6px;
  }
  .sev-badge.sev-critical { background: rgba(255, 85, 119, .14); color: var(--critical); }
  .sev-badge.sev-high     { background: rgba(255, 136, 85, .14); color: var(--high); }
  .sev-badge.sev-medium   { background: rgba(241, 196, 15, .14); color: var(--medium); }
  .sev-badge.sev-low      { background: rgba(46, 204, 113, .14); color: var(--low); }
  .sev-badge.sev-info     { background: rgba(93, 173, 226, .14); color: var(--info); }

  .finding h3 { margin: 0; font-size: 16px; font-weight: 600; flex: 1; }
  .conf { font-size: 12px; color: var(--text-dim); }

  .grid2 {
    display: grid; grid-template-columns: 1fr 1fr; gap: 12px; margin-top: 14px;
  }
  @media (max-width: 720px) { .grid2 { grid-template-columns: 1fr; } }

  .kv { font-size: 13px; }
  .kv .k { color: var(--text-dim); margin-right: 6px; }

  pre, code, .mono {
    font-family: ui-monospace, SFMono-Regular, "JetBrains Mono",
                 Menlo, Consolas, monospace; font-size: 12px;
  }
  pre {
    background: var(--code-bg); padding: 10px 12px; border-radius: 8px;
    overflow-x: auto; border: 1px solid var(--border); margin: 8px 0;
    white-space: pre-wrap; word-break: break-word;
  }
  .hl { background: rgba(124, 156, 255, .25); padding: 0 2px;
        border-radius: 3px; outline: 1px solid rgba(124, 156, 255, .5); }

  .screenshot { max-width: 100%; border: 1px solid var(--border);
                border-radius: 8px; margin-top: 10px; }

  .footer { color: var(--text-dim); font-size: 11px;
            margin-top: 40px; text-align: center; border-top: 1px solid var(--border);
            padding-top: 18px; }
  .footer a { color: var(--accent); text-decoration: none; }
</style>
</head>
<body>
<div class="wrap">

<header class="head">
  <div>
    <div class="brand">Arachne<span class="x">X</span> · scan report</div>
    <div class="meta" style="text-align:left;margin-top:4px;color:var(--text-dim)">
      scan id <span class="mono">{{ summary.scan_id }}</span>
    </div>
  </div>
  <div class="meta">
    started {{ summary.started_at.strftime("%Y-%m-%d %H:%M UTC") }}<br>
    {% if summary.ended_at %}ended {{ summary.ended_at.strftime("%Y-%m-%d %H:%M UTC") }}{% endif %}
  </div>
</header>

<div class="summary">
  <div class="card crit"><div class="k">critical</div><div class="v">{{ summary.critical_count }}</div></div>
  <div class="card high"><div class="k">high</div><div class="v">{{ summary.high_count }}</div></div>
  <div class="card"><div class="k">total findings</div><div class="v">{{ summary.findings | length }}</div></div>
  <div class="card"><div class="k">urls visited</div><div class="v">{{ summary.urls_discovered }}</div></div>
  <div class="card"><div class="k">params tested</div><div class="v">{{ summary.params_discovered }}</div></div>
  <div class="card"><div class="k">requests sent</div><div class="v">{{ summary.requests_sent }}</div></div>
</div>

<h2 class="section-title">Findings</h2>

{% if not summary.findings %}
<div class="finding sev-info">
  <div class="finding-head">
    <span class="sev-badge sev-info">no findings</span>
    <h3>No reportable XSS issues above triage threshold.</h3>
  </div>
  <p style="color:var(--text-dim)">
    This is not a guarantee of absence. Consider running with
    <code>--mode deep</code> and a higher payload budget, and review
    the scope coverage in the JSON report.
  </p>
</div>
{% endif %}

{% for f in summary.findings %}
<div class="finding sev-{{ f.severity.value }}">
  <div class="finding-head">
    <span class="sev-badge sev-{{ f.severity.value }}">{{ f.severity.value }}</span>
    <h3>{{ f.title }}</h3>
    <span class="conf">confidence {{ "%.2f"|format(f.confidence) }}
      {% if f.cvss40_score %} · CVSS {{ "%.1f"|format(f.cvss40_score) }}{% endif %}
    </span>
  </div>

  <div class="kv">
    <span class="k">class:</span><code>{{ f.xss_class.value }}</code> ·
    <span class="k">method:</span><code>{{ f.method.value }}</code> ·
    <span class="k">param:</span><code>{{ f.injection_point.name }}</code>
    ({{ f.injection_point.location }})
    {% if f.waf_signal and f.waf_signal.detected %}
      · <span class="k">waf:</span><code>{{ f.waf_signal.vendor }}</code>
      ({{ "%.2f"|format(f.waf_signal.confidence) }})
    {% endif %}
  </div>

  <div class="kv" style="margin-top:6px"><span class="k">url:</span>
    <code>{{ f.target_url }}</code></div>

  {% if f.cvss40_vector %}
  <div class="kv" style="margin-top:4px"><span class="k">cvss vector:</span>
    <code>{{ f.cvss40_vector }}</code></div>
  {% endif %}

  <div class="grid2">
    <div>
      <div class="kv" style="margin-top:10px"><span class="k">payload:</span></div>
      <pre>{{ f.payload }}</pre>
      {% if f.payload_lineage %}
      <div class="kv"><span class="k">evolved via:</span>
        <code>{{ " → "|safe + (" → ".join(f.payload_lineage)) }}</code></div>
      {% endif %}
    </div>
    <div>
      <div class="kv" style="margin-top:10px"><span class="k">response snippet:</span></div>
      <pre>{{ highlight(f.raw_response_snippet or "", f.payload) | safe }}</pre>
    </div>
  </div>

  {% if f.browser_proof %}
    <div class="kv" style="margin-top:10px"><span class="k">browser proof:</span>
      <code>exec={{ "yes" if f.browser_proof.exec_observed else "no" }}</code>
      {% if f.browser_proof.page_title %}
        · <span class="k">title:</span><code>{{ f.browser_proof.page_title }}</code>
      {% endif %}
    </div>
    {% if f.browser_proof.console_messages %}
    <pre>{{ "\n".join(f.browser_proof.console_messages[:10]) }}</pre>
    {% endif %}
    {% if screenshot_b64(f) %}
      <img class="screenshot" alt="execution proof"
           src="data:image/png;base64,{{ screenshot_b64(f) }}">
    {% endif %}
  {% endif %}

  {% if f.remediation %}
  <div class="kv" style="margin-top:10px"><span class="k">remediation:</span></div>
  <pre>{{ f.remediation }}</pre>
  {% endif %}
</div>
{% endfor %}

<div class="footer">
  Generated by <strong>ArachneX</strong> v{{ version }} ·
  © Rhishinathvarma Marimuthu · authorized testing only
</div>

</div>
</body>
</html>
"""


def _highlight(snippet: str, needle: str) -> str:
    if not snippet:
        return ""
    if not needle or needle not in snippet:
        return html.escape(snippet)
    parts = snippet.split(needle)
    escaped_needle = html.escape(needle)
    return (f'<span class="hl">{escaped_needle}</span>'
            ).join(html.escape(p) for p in parts)


def _screenshot_b64(finding: Finding) -> Optional[str]:
    if not finding.browser_proof or not finding.browser_proof.screenshot_path:
        return None
    p = Path(finding.browser_proof.screenshot_path)
    if not p.exists():
        return None
    try:
        return base64.b64encode(p.read_bytes()).decode("ascii")
    except Exception:
        return None


class HtmlReporter:
    def __init__(self, version: str = "0.1.0") -> None:
        self.version = version
        env = Environment(
            loader=DictLoader({"report.html": HTML_TEMPLATE}),
            autoescape=select_autoescape(["html"]),
            trim_blocks=True,
            lstrip_blocks=True,
        )
        env.globals["highlight"] = _highlight
        env.globals["screenshot_b64"] = _screenshot_b64
        self._env = env

    def render(self, summary: ScanSummary, out_path: Path) -> Path:
        # Sort findings: severity desc, then confidence desc
        order = {Severity.CRITICAL: 0, Severity.HIGH: 1, Severity.MEDIUM: 2,
                 Severity.LOW: 3, Severity.INFO: 4}
        summary.findings.sort(key=lambda f: (order.get(f.severity, 5), -f.confidence))

        tpl = self._env.get_template("report.html")
        html_out = tpl.render(summary=summary, version=self.version,
                              now=datetime.now(timezone.utc))
        out_path.parent.mkdir(parents=True, exist_ok=True)
        out_path.write_text(html_out, encoding="utf-8")
        log.info("wrote HTML report: %s", out_path)
        return out_path
