<div align="center">

# ArachneX

### AI-Native XSS Discovery, Detection, Exploitation & Reporting Framework

*Built for offensive security researchers and application-security engineers who need context-aware XSS coverage against modern targets.*

[![Python 3.11+](https://img.shields.io/badge/python-3.11+-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![PRs Welcome](https://img.shields.io/badge/PRs-welcome-brightgreen.svg)](#)

Author: **Rhishinathvarma Marimuthu**

</div>

---

## Why ArachneX exists

Signature-based XSS scanners are limited by design. They ship a fixed payload list, throw it at every parameter, and grep the response. That approach breaks on modern targets that use:

- **Context-aware encoding** (a payload that works in HTML body fails in `<script>` blocks and vice versa)
- **Machine-learning WAFs** that score anomalies rather than match regex
- **Single-page applications with client-side routing** — most reflections never appear in HTTP responses
- **Mutation XSS** — browsers re-parse markup after `innerHTML`, and sanitized input becomes executable
- **Trusted Types & strict CSP** that block classical payloads outright

ArachneX flips the model. Instead of one fixed list against every target, it **classifies the reflection context**, **generates payloads specific to that context** (statically + via LLM), **verifies execution in a real browser**, and **evolves payloads** that get close to working. The scanner gets *smarter as the scan progresses*.

---

## What it does

| Capability | ArachneX |
|---|---|
| Payload strategy | Context-classified + LLM-generated + evolutionary |
| Context detection | HTML5 tokenizer state machine + optional transformer classifier |
| Verification | Headless Chromium with Chrome DevTools Protocol execution hooks |
| DOM XSS | AST + taint-flow graph + graph-walk ranking |
| WAF bypass | ML fingerprinting → strategy selection → genetic evolution |
| False positives | Trained classifier scores every finding |
| Mutation XSS (mXSS) | First-class — re-parses sanitizer output |
| Blind XSS | Callback server + DOM exfil + WebSocket beaconing |
| Modern web | SPA-aware, GraphQL, WebSocket, `postMessage` |
| Reporting | HTML / JSON / Markdown / CVSS 4.0 / LLM narrative |

---

## Architecture

```
                    ┌────────────────────────────────────────┐
                    │              ArachneX Engine             │
                    └───────────────────┬────────────────────┘
                                        │
        ┌───────────────────────────────┼────────────────────────────┐
        ▼                               ▼                            ▼
  ┌──────────┐                  ┌──────────────┐             ┌─────────────┐
  │ Recon &  │                  │  Detection   │             │ Exploitation│
  │Discovery │                  │  Pipeline    │             │ & Reporting │
  └────┬─────┘                  └──────┬───────┘             └──────┬──────┘
       │                               │                            │
   ┌───┴────┐                ┌─────────┼──────────┐         ┌───────┴───────┐
   ▼        ▼                ▼         ▼          ▼         ▼               ▼
 Crawler   JS-AST       Reflected    DOM    Blind/mXSS   Headless        HTML /
 Param-    Sink         + Context    + AST   + Collab    Verifier        JSON /
 Miner     Graph        Classifier   Flow                (Playwright)    CVSS 4
 Subdomain
 Wayback                           ┌─────────────┐
                                   │   AI Core   │  ←  drives every stage
                                   ├─────────────┤
                                   │ • Context   │
                                   │   Classifier│ (Transformer)
                                   │ • Payload   │
                                   │   Generator │ (LLM + library)
                                   │ • WAF       │
                                   │   Fingerprint│(GBDT)
                                   │ • Evolution │ (Genetic + RL)
                                   │ • Triage    │ (Classifier)
                                   └─────────────┘
```

See [docs/architecture.md](docs/architecture.md) and [docs/ai_methodology.md](docs/ai_methodology.md).

---

## Quick start

```bash
# Install
pip install -e .
playwright install chromium

# Configure the LLM API key for payload generation (optional)
export ANTHROPIC_API_KEY=sk-ant-...

# Scan a single URL
arachnex scan -u "https://target.example/search?q=test"

# Bug-bounty mode: crawl + scan a scope file
arachnex scan --scope scope.txt --mode bb --threads 25 --headless verify

# Blind XSS with self-hosted collaborator
arachnex blind --listen 0.0.0.0:8443 --domain xss.your-collab.example

# DOM-only audit (static, no requests)
arachnex dom --input ./js-bundle.js
```

---

## Highlights

### 1. Context-classified payload generation

When a parameter reflects, ArachneX extracts a 200-char neighborhood around the reflection, runs it through a fine-tuned classifier that outputs one of **17 contexts** (HTML body, double-quoted attribute, single-quoted attribute, unquoted attribute, `<script>` string literal, `<script>` identifier, `<style>`, `href`/`src` URL, JSON-in-script, on-event handler, comment, CDATA, SVG, MathML, Trusted-Types-protected, mXSS-prone, untainted). Each context maps to a hand-curated **escape set** plus an **LLM generator** that produces 5–20 fresh payloads aware of preceding/following bytes.

### 2. Real browser verification

Every "hit" is replayed in headless Chromium via Playwright with **Chrome DevTools Protocol** hooks on `Runtime.consoleAPICalled`, `Runtime.exceptionThrown`, and an injected `window.__arx_exec_token`. Findings are only reported when JavaScript actually executes — eliminating the entire class of reflection-but-not-exploitable false positives that plague signature scanners.

### 3. Evolutionary WAF bypass

When a payload is blocked but the target seems vulnerable, ArachneX runs a **genetic algorithm** over a transformation grammar (case toggling, comment splitting, unicode substitution, encoding stacks, event renaming, splitting across params) with a **fitness function** combining: (a) similarity to a baseline allowed response, (b) reflection of mutated bytes, (c) absence of WAF block signatures. Converges in 20–60 generations against most current WAF configurations.

### 4. AST-driven DOM XSS

Parses each `.js` asset, builds a data-flow graph from **sources** (`location.*`, `document.URL`, `postMessage`, `window.name`, storage APIs, `fetch` responses) to **sinks** (`innerHTML`, `eval`, `Function`, `document.write`, `setTimeout(str)`, `setAttribute('on*', …)`, `srcdoc`, etc.). A graph-walk ranks paths by exploitability; an LLM produces the URL fragment / `postMessage` payload to trigger each.

### 5. Mutation XSS (mXSS) — first-class

Ships with a hardened mXSS corpus (mathml, svg, foreign-content, template, noscript namespace confusions, named-character-reference variants) and a **differential parser** that compares the bytes sent vs the DOM after `innerHTML` round-trip. Finds sanitizer bypasses that signature-based scanners miss.

### 6. AI triage

A gradient-boosted classifier scores each finding (`reflection_strength`, `csp_present`, `trusted_types`, `sandbox`, `exec_observed`, `dom_mutation`, `context`, `waf_state`) and produces a confidence score in [0, 1] and an exploitability tier. Findings below the configured threshold are auto-suppressed; the rest land in the report ranked.

---

## What it is *not*

- Not a magic button. Modern XSS hunting still requires you to understand the app. ArachneX is a force multiplier, not a replacement for skill.
- Not a license-locked black box. Open source, MIT, run it on your own infrastructure.
- Not a network scanner. It tests one class of bug well, instead of testing fifty classes poorly.

---

## Authorization & legal

ArachneX is offensive tooling. **Only use it against targets you own or have explicit written authorization to test.** Unauthorized scanning is illegal in most jurisdictions. The author accepts no liability for misuse.

---

## Citation

```bibtex
@misc{arachnex2026,
  title  = {ArachneX: AI-Native XSS Discovery, Detection, Exploitation and Reporting},
  author = {Rhishinathvarma Marimuthu},
  year   = {2026}
}
```

---

## License

MIT — © Rhishinathvarma Marimuthu. See [LICENSE](LICENSE).
