# ArachneX Architecture

This document explains *how* ArachneX is put together and *why* each
piece exists. It's written for two audiences:

1. **Engineers extending the framework** — "where do I plug in a new
   detector / payload generator / sink?"
2. **Reviewers evaluating the design** — "is this real engineering, or
   marketing wrapped around a payload list?"

If you only read one section, read **Pipeline** below.

---

## 1. Pipeline

Every scan moves through four stages. Each stage has hard boundaries
and produces typed Pydantic objects — never untyped dicts — so a stage
crash never corrupts later stages.

```
┌─────────────┐   ┌─────────────┐   ┌─────────────┐   ┌─────────────┐
│  Discovery  │──▶│  Detection  │──▶│   Triage    │──▶│   Reports   │
└─────────────┘   └─────────────┘   └─────────────┘   └─────────────┘
        │                │                │                │
   crawler            reflected        AI triage        HTML / JSON /
   param miner        DOM (AST)        CVSS 4.0        Markdown / PDF
   js asset list      blind/mxss       severity         (each format
   wayback (opt)      headless oracle  escalation        independent)
```

### Stage 1 — Discovery (`arachnex.discovery`)

Inputs: seed URLs (or scope file). Outputs: `list[Target]`, each with
`InjectionPoint`s annotated by location (`query`, `body`, `header`,
`cookie`, `path`, `fragment`, `json`).

Components:

- **`crawler.Crawler`** — async BFS spider. Bounded by depth and total
  URL cap. Per-host token-bucket rate limit comes from `HttpClient`.
- **`param_miner.ParamMiner`** — discovers *undeclared* parameters via
  batched differential response analysis with binary-split bisection
  on suspicious batches. About 8–32x faster than naive per-word probing.
- **`subdomain.py`** (planned v0.2) — passive subdomain enumeration via
  certificate transparency logs.

### Stage 2 — Detection (`arachnex.detection`)

Each detector owns one XSS class.

- **`reflected.ReflectedXSSDetector`** — canary → reflection → context
  classification → context-specific payloads → headless verify →
  optional GA evolution.
- **`dom.DomXSSAnalyzer`** — AST + taint-flow graph + BFS source→sink.
  Static, fast, hypothesis-only; the engine dynamically confirms.
- **`blind.py`** — payload templates beaconing to the collaborator
  server. Confirmation happens out-of-band.
- **`mxss.MXSSDetector`** — differential HTML5 parser: re-parses
  server-returned bytes the way a browser does on `innerHTML` round-
  trip; detects sanitizer bypasses no signature scanner catches.

The shared brain is **`detection.context.ContextClassifier`** which
maps each reflection neighborhood into one of 17 contexts (see
`arachnex.core.target.ReflectionContext`).

### Stage 3 — Triage & Scoring

- **`ai.triage.Triager`** — feature extraction + logistic scoring with
  hand-tuned, *auditable* weights. The weights live in the module, not
  in an opaque file. Anyone can see exactly why a finding got 0.92
  versus 0.31.
- **`reporting.cvss`** — emits a CVSS 4.0 vector and a calibrated
  numeric score. Severity is escalated (never downgraded) by CVSS.

### Stage 4 — Reports

Three first-class formats: HTML (self-contained, screenshots inlined as
base64), JSON (schema-versioned, for CI integration), Markdown (PR /
ticket / Slack drops). PDF is a `weasyprint` render of the HTML.

---

## 2. The AI core (`arachnex.ai`)

There are four AI components. None of them is required for the scanner
to function — every fallback path is implemented and tested.

| Module | Type | What it does |
|---|---|---|
| `context_classifier` (in `detection.context`) | Hybrid heuristic + sklearn GBDT | Classifies reflection contexts. |
| `payload_generator.LLMPayloadGenerator` | Anthropic API (Claude) | Generates context-specific payloads grounded in the actual reflection neighborhood. JSON-schema-constrained output. |
| `waf_fingerprint.WafFingerprinter` | Weighted feature voting | Identifies WAF vendor from multi-signal observations. |
| `evolution.PayloadEvolver` | Genetic algorithm over a transformation grammar | Evolves blocked payloads against an unknown WAF. |
| `triage.Triager` | Logistic regression with hand-tuned weights | Scores each finding 0–1, severity. |

### Why use an LLM at all?

The LLM is *not* the centerpiece. It is one source of payloads, called
*after* the context is classified, with the actual byte neighborhood as
input. The same context can be exploited very differently depending on
adjacent bytes (e.g., a JS string inside a JSON property whose key
shares the reflected value's prefix needs a different break-out). A
hand-tuned static list cannot enumerate all of those; an LLM can reason
about them.

The LLM is wrapped behind a strict JSON schema and a 512-char hard cap
per payload. We don't ship its reasoning text as a payload. We cache by
`(context, neighborhood-hash, waf)`; many parameters share contexts, so
the LLM cost per scan is modest.

### Why a genetic algorithm and not pure RL?

Two reasons. (1) GAs handle the "discrete, no-gradient" search space of
payload transformations naturally — RL needs the same wrappers anyway.
(2) GAs converge well with the small populations we can afford under
real WAF rate limits. We *do* sneak RL flavor in: the fitness function
includes a learned "intactness" signal that's effectively a critic.

The transformation grammar (`evolution.TRANSFORMS`) is the interesting
part. Each transform is a syntactically-aware mutation, not a random
byte flip. This is what makes the GA actually converge in the 20–60
generations we have budget for.

---

## 3. Verification (`arachnex.exploitation.headless`)

The single most important non-AI component.

Reflection scanners' false positive rate is dominated by reflection-but-
not-execution: the canary appears in the response, but the browser does
not execute it (CSP, sandbox, encoded reflection, dead `<noscript>`,
etc.). We solve this the only way you can: run the page in a real
browser and ask whether JS executed.

`HeadlessOracle` uses Playwright + Chromium with three independent
signals:

1. **`window.__arx` sentinel** injected via `add_init_script` before
   page scripts. The sentinel rebinds `alert`/`prompt`/`confirm` to
   record events. Most payloads call one of these → we capture them
   even if the dialog never renders.
2. **`page.on("console")`** — payloads can use `console.log("__arx_exec__:tag")`.
3. **`page.on("dialog")`** — last-line catch for native dialogs.

When any of these fires, the finding gets a `BrowserExecutionProof`
attached, the screenshot is captured, and the triager's
`executed` feature flips. Most other scanners stop at signal 1; we use
all three because some payloads bypass the rebind but not the dialog
handler, and vice versa.

---

## 4. Concurrency model

Scanners that use threads-per-target collapse under any meaningful
target count. ArachneX is async end-to-end:

- One `httpx.AsyncClient` per scan, with HTTP/2 enabled.
- A single per-host token bucket (`utils.http.HostRateLimiter`)
  enforces RPS limits *across all workers*. This is essential — a
  poorly-rate-limited scanner gets banned from bug-bounty targets
  within minutes.
- The engine's worker pool is a single `asyncio.Semaphore`, sized by
  `cfg.threads`. We never spawn a process pool unless the user opts in.
- The headless oracle has its *own* concurrency limit (`min(8, threads)`)
  because each Chromium context costs ~80 MB; over-provisioning kills
  the host.

---

## 5. Data flow guarantees

- **No global state.** Every module takes the dependencies it needs in
  its constructor. Two engines can run side-by-side in the same process.
- **Pydantic everywhere on the wire.** Targets, InjectionPoints,
  Findings, ScanSummary — everything that crosses a module boundary is
  validated.
- **No untyped dicts in detector outputs.** Detectors return `Finding`,
  not "any dict that the reporter will figure out."
- **Reports are pure functions of `ScanSummary`.** No re-fetching, no
  hidden state. Reproducible.

---

## 6. Extension points

If you want to add to ArachneX:

| Want to add | Where to hook |
|---|---|
| A new payload context | Add enum value to `core.target.ReflectionContext`, add file under `payloads/contexts/`, add specificity weight in `ai.triage._CONTEXT_SPECIFICITY`, refine in `detection.context._refine_js_context` if needed. |
| A new WAF vendor | Add entry to `ai.waf_fingerprint.VENDORS` with predicate features. |
| A new payload transformation | Append a `(label, fn)` to `ai.evolution.TRANSFORMS`. |
| A new detector | Implement a class with `async def scan_target(target) -> list[Finding]`; wire it into `Engine._detect`. |
| A new report format | Implement a `render(summary, out_path)` class in `arachnex.reporting`; register in `Engine._report`. |
| A new discovery source | Add a module under `arachnex.discovery`; call it from `Engine._discover` before deduplication. |

---

## 7. What we deliberately *don't* do

- **Authentication automation.** ArachneX does not log into your target
  for you. We accept cookies/headers but won't drive a login flow. This
  is a feature, not a gap — auto-login is where most scanners cause
  account lockouts.
- **CSRF token harvesting.** Real bug-bounty scans need this; we plan
  it for v0.3 with strict opt-in.
- **Generic vulnerability scanning.** We do one class, well.
- **A built-in dashboard.** The reports are the dashboard. A long-
  running web UI is a separate project.

---

## 8. Open problems

A few things we *want* to be honest about.

1. **The context classifier overfits to neighborhood bytes.** When a
   sanitizer mangles input in surprising ways, the classifier may put
   the reflection in the wrong bucket. Mitigation: confidence threshold
   + fall through to polyglots.
2. **Evolution is rate-limited by the target.** A WAF that aggressively
   bans on repeat failures will starve the GA. We could add an outer
   exponential backoff layer with cross-IP rotation, but that's an
   ethics decision — leave it to the operator.
3. **DOM XSS confirmation is incomplete.** Static AST analysis produces
   hypotheses; we only dynamically confirm a subset (those with
   plausible `location.*` triggers). Confirming postMessage flows
   requires the engine to drive postMessage — planned for v0.2.
4. **mXSS coverage is sanitizer-specific.** Our 60-vector corpus catches
   most public DOMPurify CVEs and many generic mXSS classes; bespoke
   sanitizers may have unique gaps not in the corpus.

If any of those land squarely on something you care about, send a PR.
