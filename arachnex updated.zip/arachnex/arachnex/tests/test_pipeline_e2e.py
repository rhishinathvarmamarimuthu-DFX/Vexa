"""
End-to-end pipeline smoke test.

Exercises Engine.run() against a mocked HTTPX transport so async/await
regressions in the discovery -> detection -> reporting chain are caught
before the demo box gets involved. Deliberately runs with:

  * headless off        (no Playwright browser required)
  * LLM off             (no ANTHROPIC_API_KEY needed)
  * evolution off       (deterministic, fast)

Requires the `respx` dev dependency; the test is skipped otherwise.
"""

from __future__ import annotations

from pathlib import Path

import pytest


@pytest.mark.asyncio
async def test_pipeline_reflects_and_finds(tmp_path):
    respx = pytest.importorskip("respx")
    import httpx

    from arachnex.core.config import Config, HeadlessMode, ScanMode
    from arachnex.core.engine import Engine

    def _reflect_handler(request: httpx.Request) -> httpx.Response:
        # Echo the `q` parameter directly into the HTML body — the
        # reflected detector should classify it as HTML_BODY, fuzz with
        # the html_body.txt library, and record findings whose payload
        # bytes come back intact.
        q = request.url.params.get("q", "")
        body = (
            "<!doctype html><html><head><title>vuln</title></head><body>"
            f"<h1>Search results for {q}</h1>"
            "</body></html>"
        )
        return httpx.Response(
            200, headers={"content-type": "text/html; charset=utf-8"}, text=body,
        )

    payloads_dir = Path(__file__).resolve().parent.parent / "payloads"
    cfg = Config(
        targets=["https://vuln.test/search?q=hello"],
        mode=ScanMode.STANDARD,
        headless=HeadlessMode.OFF,
        use_llm=False,
        use_evolution=False,
        threads=2,
        rps_per_host=1000.0,          # don't throttle the test
        output_dir=tmp_path,
        payload_root=payloads_dir,
        report_formats=[],            # skip report rendering
        quiet=True,
        triage_threshold=0.0,         # keep low-confidence findings for the test
    )

    async with respx.mock(assert_all_called=False) as mock:
        mock.route(host="vuln.test").mock(side_effect=_reflect_handler)
        engine = Engine(cfg)
        summary = await engine.run()

    assert summary is not None
    assert summary.requests_sent > 0, "engine should have issued HTTP requests"

    reflected = [
        f for f in summary.findings
        if f.injection_point.name == "q" and f.xss_class.value == "reflected"
    ]
    assert reflected, (
        f"expected a reflected finding on `q`, got: "
        f"{[(f.xss_class.value, f.title) for f in summary.findings]}"
    )
