"""
ArachneX — AI-Native XSS Discovery, Detection, Exploitation & Reporting.
"""

__version__ = "0.1.0"
__author__ = "Rhishinathvarma Marimuthu"
__license__ = "MIT"

BANNER = r"""
    ___                  __                  _  __
   /   |_________ ______/ /_  ____  ___    | |/ /
  / /| / ___/ __ `/ ___/ __ \/ __ \/ _ \   |   /
 / ___ / /  / /_/ / /__/ / / / / / /  __/  /   |
/_/  |_\_/   \__,_/\___/_/ /_/_/ /_/\___/  /_/|_|

  AI-Native XSS Framework  ·  v{version}  ·  MIT
"""


def banner() -> str:
    return BANNER.format(version=__version__)
