"""
Finding triage.

Even with a browser oracle, raw findings need a final pass to estimate
exploitability. A reflection inside a `<noscript>` or in a CSP-protected
page with `script-src 'self'` may execute in our oracle but be unreachable
in the victim's actual browser config. We score every finding to surface
those nuances.

Design: rule-augmented logistic regression on engineered features.
We deliberately keep this simple so the model is auditable; a Black-Hat
audience will want to know *why* a finding got 0.92 and another got 0.31.

Feature vector (8 features):

  f0  : reflection_intactness          float in [0,1]
  f1  : oracle_executed                {0,1}
  f2  : csp_blocks_inline              {0,1}   (Content-Security-Policy script-src omits 'unsafe-inline')
  f3  : trusted_types_enabled          {0,1}   (require-trusted-types-for present)
  f4  : sandbox_attribute_present      {0,1}   (host iframe sandbox)
  f5  : context_specificity            float in [0,1]  (HTML_BODY=0.5, ATTR_*=0.7, JS_STRING=0.9, etc.)
  f6  : waf_active                     {0,1}
  f7  : auth_required_endpoint         {0,1}

We compute the score via a hand-tuned logistic function (no model file
needed for v1). When training data accumulates from real engagements,
we'll swap in a fitted sklearn LogisticRegression.
"""

from __future__ import annotations

import math
import re
from dataclasses import dataclass
from typing import Optional

from arachnex.core.target import Finding, ReflectionContext, Severity


# --------------------------------------------------------------------------- #
# Feature extraction
# --------------------------------------------------------------------------- #


@dataclass
class TriageFeatures:
    intactness: float
    executed: bool
    csp_blocks_inline: bool
    trusted_types: bool
    sandboxed: bool
    context_specificity: float
    waf_active: bool
    auth_required: bool


_CONTEXT_SPECIFICITY = {
    ReflectionContext.HTML_BODY:          0.55,
    ReflectionContext.ATTR_DOUBLE_QUOTED: 0.75,
    ReflectionContext.ATTR_SINGLE_QUOTED: 0.75,
    ReflectionContext.ATTR_UNQUOTED:      0.85,
    ReflectionContext.ATTR_EVENT_HANDLER: 0.95,
    ReflectionContext.URL_HREF_SRC:       0.80,
    ReflectionContext.SCRIPT_STRING_DQ:   0.92,
    ReflectionContext.SCRIPT_STRING_SQ:   0.92,
    ReflectionContext.SCRIPT_TEMPLATE:    0.94,
    ReflectionContext.SCRIPT_IDENTIFIER:  0.97,
    ReflectionContext.SCRIPT_JSON:        0.70,
    ReflectionContext.STYLE_BLOCK:        0.60,
    ReflectionContext.HTML_COMMENT:       0.30,
    ReflectionContext.CDATA:              0.40,
    ReflectionContext.SVG_FOREIGN:        0.88,
    ReflectionContext.MATHML_FOREIGN:     0.80,
    ReflectionContext.UNREFLECTED:        0.05,
}


def _csp_blocks_inline(csp: Optional[str]) -> bool:
    if not csp:
        return False
    # Coarse but correct enough: if script-src is set and lacks
    # 'unsafe-inline' / 'strict-dynamic', inline scripts blocked.
    m = re.search(r"script-src([^;]+)", csp, re.I)
    if not m:
        m = re.search(r"default-src([^;]+)", csp, re.I)
    if not m:
        return False
    directive = m.group(1).lower()
    if "'unsafe-inline'" in directive:
        return False
    # nonce-based or hash-based CSP also blocks our injected inline
    return True


def _trusted_types(csp: Optional[str]) -> bool:
    if not csp:
        return False
    return "require-trusted-types-for" in csp.lower()


def extract_features(finding: Finding, response_headers: dict[str, str],
                     waf_active: bool, auth_required: bool) -> TriageFeatures:
    csp = response_headers.get("content-security-policy") or response_headers.get(
        "content-security-policy-report-only"
    )
    intact = 0.0
    if finding.reflection:
        # rough intactness: did we see the whole canary?
        snippet = finding.reflection.snippet
        intact = 1.0 if finding.reflection.canary in snippet else 0.5

    executed = bool(finding.browser_proof and finding.browser_proof.exec_observed)

    sandboxed = bool(re.search(r"sandbox\s*=\s*['\"]", finding.raw_response_snippet or "", re.I))

    ctx = (
        finding.reflection.classified_context
        if finding.reflection else ReflectionContext.UNREFLECTED
    )
    spec = _CONTEXT_SPECIFICITY.get(ctx, 0.5)

    return TriageFeatures(
        intactness=intact,
        executed=executed,
        csp_blocks_inline=_csp_blocks_inline(csp),
        trusted_types=_trusted_types(csp),
        sandboxed=sandboxed,
        context_specificity=spec,
        waf_active=waf_active,
        auth_required=auth_required,
    )


# --------------------------------------------------------------------------- #
# Scoring
# --------------------------------------------------------------------------- #


# Hand-tuned weights — sign chosen on theory, magnitude on past engagements.
_WEIGHTS = {
    "intercept":           -0.4,
    "intactness":           1.6,
    "executed":             3.2,        # browser execution dominates
    "context_specificity":  1.0,
    "csp_blocks_inline":   -1.4,        # CSP knocks it down (unless we bypassed)
    "trusted_types":       -1.6,
    "sandboxed":           -0.8,
    "waf_active":          -0.3,        # WAF makes real-world exploit harder
    "auth_required":       -0.6,        # behind auth = lower impact
}


def _logistic(z: float) -> float:
    return 1.0 / (1.0 + math.exp(-z))


class Triager:
    def score(self, finding: Finding, feats: TriageFeatures) -> float:
        z = _WEIGHTS["intercept"]
        z += _WEIGHTS["intactness"]          * feats.intactness
        z += _WEIGHTS["executed"]            * (1.0 if feats.executed else 0.0)
        z += _WEIGHTS["context_specificity"] * feats.context_specificity
        z += _WEIGHTS["csp_blocks_inline"]   * (1.0 if feats.csp_blocks_inline else 0.0)
        z += _WEIGHTS["trusted_types"]       * (1.0 if feats.trusted_types else 0.0)
        z += _WEIGHTS["sandboxed"]           * (1.0 if feats.sandboxed else 0.0)
        z += _WEIGHTS["waf_active"]          * (1.0 if feats.waf_active else 0.0)
        z += _WEIGHTS["auth_required"]       * (1.0 if feats.auth_required else 0.0)
        return _logistic(z)

    def severity_for(self, confidence: float, feats: TriageFeatures) -> Severity:
        if feats.executed and confidence > 0.85:
            return Severity.CRITICAL
        if confidence > 0.75:
            return Severity.HIGH
        if confidence > 0.55:
            return Severity.MEDIUM
        if confidence > 0.35:
            return Severity.LOW
        return Severity.INFO

    def explain(self, feats: TriageFeatures, confidence: float) -> str:
        bits: list[str] = [f"confidence={confidence:.2f}"]
        if feats.executed:
            bits.append("browser_exec=yes")
        else:
            bits.append("browser_exec=no")
        bits.append(f"ctx_specificity={feats.context_specificity:.2f}")
        if feats.csp_blocks_inline:
            bits.append("CSP=blocks_inline")
        if feats.trusted_types:
            bits.append("trusted_types=on")
        if feats.sandboxed:
            bits.append("sandbox=on")
        if feats.waf_active:
            bits.append("waf=active")
        if feats.auth_required:
            bits.append("auth=required")
        return " · ".join(bits)
