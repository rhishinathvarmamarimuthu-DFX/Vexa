"""
LLM-powered payload generator.

Uses the Anthropic API to produce *context-specific* XSS payloads tailored
to the exact reflection neighborhood. Static payload lists are blind to
the bytes immediately around the injection point; an LLM can reason about
them.

Design notes:
- The LLM is *one* source. We always seed with the curated static library,
  then ask the LLM to extend it. If the LLM is unreachable or returns
  garbage, the scan continues with the static set.
- We cache by (context, neighborhood-hash, waf-vendor). Many parameters
  on the same target share a context; we shouldn't pay for it each time.
- We constrain output strictly to a JSON schema and reject malformed
  responses. No free-form text is ever shipped as a payload.
- Prompts include a short hardened header: "This is for authorized
  security testing only…". The model knows.
"""

from __future__ import annotations

import hashlib
import json
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

from arachnex.core.target import ReflectionContext


SYSTEM_PROMPT = """\
You are a senior offensive web-application security researcher assisting an
authorized penetration test. The user is running ArachneX, an MIT-licensed
XSS detection framework. They have explicit written authorization to test
the target. Your role is to produce candidate XSS payloads tailored to a
given reflection context, so the framework's headless-browser oracle can
verify whether they execute.

You will receive:
  • the reflection context (one of 17 enumerated labels)
  • a ±80 char snippet around the reflection
  • the canary string the framework injects (you must NOT use that string
    in your payload — pick a fresh marker the framework will pin separately)
  • optional WAF vendor hint
  • optional list of strategies that have already failed (don't repeat them)

You return JSON only:

{
  "payloads": [
    {
      "value": "<the exact bytes to inject>",
      "rationale": "<one short sentence: why this fits this context>",
      "marker": "<a short literal in the payload the framework should grep for execution proof; if the payload calls alert(N) put N here as 'alert:N'>",
      "tags": ["<short tags like 'mxss', 'svg', 'cspbypass', 'eventhandler'>"]
    }
  ]
}

Hard rules:
1. JSON only. No prose, no markdown fences.
2. Each payload must be a single string of ≤512 chars.
3. The payload must be plausible in the *given* context — do not return
   '<script>alert(1)</script>' for a JS-string context, etc.
4. Prefer payloads with a distinct, greppable marker (e.g. alert(31337),
   prompt('arx-marker'), throw 'arx-thrown') so the oracle can attribute
   execution.
5. No destructive payloads. No data exfiltration to external hosts unless
   the user provides a collab host (and even then only for blind contexts).
6. Diverse payloads — do not return five trivial variants of the same idea.
"""


@dataclass
class GeneratedPayload:
    value: str
    rationale: str
    marker: str
    tags: list[str]
    source: str = "llm"


class LLMPayloadGenerator:
    """
    Wraps Anthropic's Python SDK. Falls back gracefully if no API key.
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        model: str = "claude-sonnet-4-6",
        cache_dir: Optional[Path] = None,
    ) -> None:
        self.api_key = api_key or os.environ.get("ANTHROPIC_API_KEY")
        self.model = model
        self.cache_dir = cache_dir or Path(".arachnex-cache/llm")
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        self._client = None

    def _get_client(self):
        if self._client is not None:
            return self._client
        if not self.api_key:
            return None
        try:
            from anthropic import Anthropic
            self._client = Anthropic(api_key=self.api_key)
            return self._client
        except ImportError:                                        # pragma: no cover
            return None

    # ----------------------------------------------------------------- #
    # Public API
    # ----------------------------------------------------------------- #

    def available(self) -> bool:
        return self._get_client() is not None

    def generate(
        self,
        context: ReflectionContext,
        snippet: str,
        canary: str,
        n: int = 10,
        waf_vendor: Optional[str] = None,
        already_failed: Optional[list[str]] = None,
    ) -> list[GeneratedPayload]:
        if not self.available():
            return []

        key = self._cache_key(context, snippet, waf_vendor, already_failed or [])
        cached = self._cache_load(key)
        if cached:
            return cached[:n]

        prompt = self._build_prompt(context, snippet, canary, n, waf_vendor, already_failed or [])

        try:
            client = self._get_client()
            resp = client.messages.create(
                model=self.model,
                max_tokens=2000,
                system=SYSTEM_PROMPT,
                messages=[{"role": "user", "content": prompt}],
            )
            text = "".join(b.text for b in resp.content if b.type == "text").strip()
            payloads = self._parse_response(text)
            if payloads:
                self._cache_save(key, payloads)
            return payloads[:n]
        except Exception:
            # LLM unavailable — the engine continues with library payloads.
            return []

    # ----------------------------------------------------------------- #
    # Prompt building & parsing
    # ----------------------------------------------------------------- #

    @staticmethod
    def _build_prompt(
        context: ReflectionContext,
        snippet: str,
        canary: str,
        n: int,
        waf_vendor: Optional[str],
        already_failed: list[str],
    ) -> str:
        parts = [
            f"Reflection context: {context.value}",
            f"Requested count: {n}",
            f"Canary string (do NOT include in payload): {canary!r}",
            "",
            "Reflection neighborhood snippet (canary marked as ⟨HERE⟩):",
            "```",
            snippet.replace(canary, "⟨HERE⟩"),
            "```",
        ]
        if waf_vendor:
            parts += ["", f"WAF vendor (best-effort): {waf_vendor}"]
        if already_failed:
            parts += [
                "",
                "These categories already failed; do not return more of them:",
                *(f"  - {s}" for s in already_failed),
            ]
        parts += ["", "Return the JSON object now."]
        return "\n".join(parts)

    @staticmethod
    def _parse_response(text: str) -> list[GeneratedPayload]:
        # Strip code fences if the model added them despite instructions.
        text = text.strip()
        if text.startswith("```"):
            text = text.strip("`")
            if text.lower().startswith("json"):
                text = text[4:]
            text = text.strip()

        try:
            data = json.loads(text)
        except Exception:
            return []

        items = data.get("payloads", [])
        out: list[GeneratedPayload] = []
        for it in items:
            v = it.get("value")
            if not isinstance(v, str) or not (1 <= len(v) <= 512):
                continue
            out.append(
                GeneratedPayload(
                    value=v,
                    rationale=str(it.get("rationale", "")).strip()[:300],
                    marker=str(it.get("marker", "")).strip()[:64],
                    tags=[str(t)[:32] for t in it.get("tags", [])][:8],
                    source="llm",
                )
            )
        return out

    # ----------------------------------------------------------------- #
    # Cache
    # ----------------------------------------------------------------- #

    def _cache_key(self, ctx: ReflectionContext, snippet: str,
                   waf: Optional[str], failed: list[str]) -> str:
        h = hashlib.sha256()
        h.update(ctx.value.encode())
        h.update(snippet.encode("utf-8", errors="replace"))
        h.update((waf or "").encode())
        h.update("|".join(sorted(failed)).encode())
        return h.hexdigest()[:24]

    def _cache_load(self, key: str) -> list[GeneratedPayload]:
        path = self.cache_dir / f"{key}.json"
        if not path.exists():
            return []
        try:
            data = json.loads(path.read_text())
            return [GeneratedPayload(**d) for d in data]
        except Exception:                                       # pragma: no cover
            return []

    def _cache_save(self, key: str, payloads: list[GeneratedPayload]) -> None:
        path = self.cache_dir / f"{key}.json"
        try:
            path.write_text(json.dumps([p.__dict__ for p in payloads], indent=2))
        except Exception:                                       # pragma: no cover
            pass
