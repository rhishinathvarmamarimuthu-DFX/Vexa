"""
CVSS 4.0 scoring for XSS findings.

We map ArachneX's internal feature set to the CVSS 4.0 metrics:

  AV:N           XSS is always network-attackable
  AC:L           (no special conditions) unless WAF active → AC:H
  AT:N           no attack-requirement preconditions for most cases
  PR:N           reflected/DOM payloads: no auth; stored may be PR:L
  UI:A           the victim must click / load the link → 'active'
  VC:L/H         confidentiality impact: low (read DOM) → high (steal session)
  VI:L/H         integrity: low (deface) → high (full session takeover)
  VA:N           availability rarely affected by XSS
  SC:L/H         downstream subsequent confidentiality (admin scope blast)
  SI:L           subsequent integrity in another security domain

This module is *deliberately conservative* — we ship a vector, not a
brand-new score. Consumers of the report use the vector to plug into
their own CVSS calculator if they want a tweaked baseline.

For the v1 cut we ship a hand-tuned numeric mapping; later we link
against the FIRST CVSS 4.0 calculator JS if/when there's a vetted
Python port.
"""

from __future__ import annotations

from arachnex.core.target import Finding, ReflectionContext, Severity, XSSClass


def _impact(finding: Finding) -> tuple[str, str, str, str]:
    """Return (VC, VI, SC, SI). VA is N for XSS by default."""
    ctx = (finding.reflection.classified_context
           if finding.reflection else ReflectionContext.UNREFLECTED)

    # Authenticated/session-bearing contexts → high blast radius
    if finding.xss_class == XSSClass.STORED:
        return "H", "H", "L", "L"
    if finding.xss_class == XSSClass.BLIND:
        return "H", "H", "H", "L"
    if finding.browser_proof and finding.browser_proof.exec_observed:
        if ctx in {ReflectionContext.SCRIPT_STRING_DQ,
                   ReflectionContext.SCRIPT_STRING_SQ,
                   ReflectionContext.SCRIPT_IDENTIFIER}:
            return "H", "H", "L", "N"
        return "L", "L", "L", "N"
    return "L", "L", "N", "N"


def build_vector(finding: Finding, waf_active: bool, auth_required: bool) -> str:
    av = "N"
    ac = "H" if waf_active else "L"
    at = "N"
    pr = "L" if auth_required else "N"
    ui = "A"          # active — link click / form submission
    vc, vi, sc, si = _impact(finding)
    va = "N"
    sa = "N"

    parts = [
        "CVSS:4.0",
        f"AV:{av}", f"AC:{ac}", f"AT:{at}", f"PR:{pr}", f"UI:{ui}",
        f"VC:{vc}", f"VI:{vi}", f"VA:{va}",
        f"SC:{sc}", f"SI:{si}", f"SA:{sa}",
    ]
    return "/".join(parts)


# Hand-tuned table from (severity_signal, exec, stored/blind) → numeric score.
# CVSS 4.0 doesn't have a trivial closed-form formula; we approximate.
_NUMERIC_MAP: dict[tuple[bool, bool, bool], float] = {
    # (executed, stored_or_blind, waf_active)
    (True,  True,  True):  9.1,
    (True,  True,  False): 9.4,
    (True,  False, True):  7.4,
    (True,  False, False): 8.1,
    (False, True,  True):  6.4,
    (False, True,  False): 7.0,
    (False, False, True):  4.3,
    (False, False, False): 5.4,
}


def numeric_score(finding: Finding, waf_active: bool) -> float:
    executed = bool(finding.browser_proof and finding.browser_proof.exec_observed)
    stored_or_blind = finding.xss_class in {XSSClass.STORED, XSSClass.BLIND}
    return _NUMERIC_MAP[(executed, stored_or_blind, waf_active)]


def severity_for_score(score: float) -> Severity:
    if score >= 9.0:
        return Severity.CRITICAL
    if score >= 7.0:
        return Severity.HIGH
    if score >= 4.0:
        return Severity.MEDIUM
    if score >= 1.0:
        return Severity.LOW
    return Severity.INFO


def populate(finding: Finding, *, waf_active: bool, auth_required: bool) -> None:
    finding.cvss40_vector = build_vector(finding, waf_active, auth_required)
    finding.cvss40_score = numeric_score(finding, waf_active)
    # Don't downgrade severity below what triage set, only escalate.
    cvss_sev = severity_for_score(finding.cvss40_score)
    order = [Severity.INFO, Severity.LOW, Severity.MEDIUM, Severity.HIGH, Severity.CRITICAL]
    if order.index(cvss_sev) > order.index(finding.severity):
        finding.severity = cvss_sev
