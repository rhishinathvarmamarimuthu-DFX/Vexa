"""
JSON report.

Stable, schema-versioned. This is the format CI/CD pipelines should
consume — never scrape the HTML.
"""

from __future__ import annotations

import logging
from pathlib import Path

import orjson

from arachnex.core.target import ScanSummary

log = logging.getLogger("arachnex.report.json")


SCHEMA_VERSION = "1.0.0"


class JsonReporter:
    def render(self, summary: ScanSummary, out_path: Path) -> Path:
        out_path.parent.mkdir(parents=True, exist_ok=True)
        payload = {
            "schema": "arachnex/scan-summary",
            "schema_version": SCHEMA_VERSION,
            "summary": summary.model_dump(mode="json"),
        }
        out_path.write_bytes(
            orjson.dumps(payload, option=orjson.OPT_INDENT_2 | orjson.OPT_NAIVE_UTC)
        )
        log.info("wrote JSON report: %s", out_path)
        return out_path
