"""
Markdown report.

Use case: post the scan result as a GitHub PR comment, a Slack-bot
message, or a bug-bounty submission draft.
"""

from __future__ import annotations

import logging
from pathlib import Path

from arachnex.core.target import ScanSummary, Severity

log = logging.getLogger("arachnex.report.md")


_SEV_EMOJI = {
    Severity.CRITICAL: "🔴",
    Severity.HIGH:     "🟠",
    Severity.MEDIUM:   "🟡",
    Severity.LOW:      "🟢",
    Severity.INFO:     "🔵",
}


class MarkdownReporter:
    def render(self, summary: ScanSummary, out_path: Path) -> Path:
        lines: list[str] = []
        lines.append(f"# ArachneX Scan Report — `{summary.scan_id[:12]}`")
        lines.append("")
        lines.append(f"- **Started**: {summary.started_at.isoformat()}")
        if summary.ended_at:
            lines.append(f"- **Ended**: {summary.ended_at.isoformat()}")
        lines.append(f"- **URLs visited**: {summary.urls_discovered}")
        lines.append(f"- **Parameters tested**: {summary.params_discovered}")
        lines.append(f"- **Requests sent**: {summary.requests_sent}")
        lines.append("")
        lines.append("## Summary")
        lines.append("")
        lines.append("| Severity | Count |")
        lines.append("|----------|------:|")
        for sev in (Severity.CRITICAL, Severity.HIGH, Severity.MEDIUM,
                    Severity.LOW, Severity.INFO):
            n = sum(1 for f in summary.findings if f.severity == sev)
            lines.append(f"| {_SEV_EMOJI[sev]} {sev.value.upper()} | {n} |")
        lines.append("")

        if not summary.findings:
            lines.append("_No reportable findings above triage threshold._")
            out_path.parent.mkdir(parents=True, exist_ok=True)
            out_path.write_text("\n".join(lines), encoding="utf-8")
            return out_path

        # Sort
        order = {Severity.CRITICAL: 0, Severity.HIGH: 1, Severity.MEDIUM: 2,
                 Severity.LOW: 3, Severity.INFO: 4}
        ordered = sorted(summary.findings,
                         key=lambda f: (order.get(f.severity, 5), -f.confidence))

        lines.append("## Findings")
        lines.append("")
        for i, f in enumerate(ordered, 1):
            emoji = _SEV_EMOJI[f.severity]
            lines.append(f"### {i}. {emoji} {f.title}")
            lines.append("")
            lines.append(f"- **Class**: `{f.xss_class.value}`")
            lines.append(f"- **Severity**: `{f.severity.value}` · **Confidence**: `{f.confidence:.2f}`")
            if f.cvss40_score:
                lines.append(f"- **CVSS 4.0**: `{f.cvss40_score:.1f}` · `{f.cvss40_vector}`")
            lines.append(f"- **URL**: `{f.target_url}`")
            lines.append(f"- **Method / Param**: `{f.method.value}` `{f.injection_point.name}` "
                         f"({f.injection_point.location})")
            if f.waf_signal and f.waf_signal.detected:
                lines.append(f"- **WAF**: `{f.waf_signal.vendor}` "
                             f"(confidence {f.waf_signal.confidence:.2f})")
            lines.append("")
            lines.append("**Payload**")
            lines.append("```")
            lines.append(f.payload)
            lines.append("```")
            if f.payload_lineage:
                lines.append(f"_Evolved via: {' → '.join(f.payload_lineage)}_")
                lines.append("")
            if f.browser_proof and f.browser_proof.exec_observed:
                lines.append("**Browser execution observed** ✅")
                if f.browser_proof.console_messages:
                    lines.append("```")
                    lines.append("\n".join(f.browser_proof.console_messages[:6]))
                    lines.append("```")
            if f.remediation:
                lines.append("**Remediation**")
                lines.append("")
                lines.append(f.remediation)
            lines.append("")

        out_path.parent.mkdir(parents=True, exist_ok=True)
        out_path.write_text("\n".join(lines), encoding="utf-8")
        log.info("wrote Markdown report: %s", out_path)
        return out_path
