"""
ArachneX engine — top-level orchestration.

Pipeline:

  Stage 1 — Discovery
    a. Seed normalisation
    b. Async crawler
    c. Parameter miner against discovered URLs (deep mode only)
    d. JS asset DOM analysis (deep mode only)

  Stage 2 — Detection
    a. Reflected XSS sweep over all (Target, InjectionPoint) tuples
    b. Stored XSS detection (a second pass: re-fetch view endpoints
       after injecting on write endpoints; v1 = explicit pairs only)
    c. Blind XSS payload delivery (if --blind enabled)
    d. mXSS pass over reflective endpoints
    e. DOM XSS hypotheses from static analysis, dynamically confirmed

  Stage 3 — Triage & Scoring
    a. AI triage classifier
    b. CVSS 4.0 vector + numeric score
    c. Severity escalation

  Stage 4 — Reporting
    a. Build ScanSummary
    b. Render HTML / JSON / Markdown / PDF as configured

The engine respects the global request budget. Critically, it never
holds the http client unconditionally — every stage uses its own context
manager so we always close connections cleanly on Ctrl-C.
"""

from __future__ import annotations

import asyncio
import logging
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

from arachnex.ai.payload_generator import LLMPayloadGenerator
from arachnex.ai.triage import Triager
from arachnex.ai.waf_fingerprint import WafFingerprinter
from arachnex.core.config import Config, HeadlessMode, ScanMode
from arachnex.core.target import (
    Finding,
    HttpMethod,
    InjectionPoint,
    ScanSummary,
    Target,
)
from arachnex.detection.context import ContextClassifier
from arachnex.detection.reflected import ReflectedXSSDetector
from arachnex.discovery.crawler import Crawler
from arachnex.discovery.param_miner import ParamMiner
from arachnex.exploitation.headless import HeadlessOracle
from arachnex.exploitation.payloads import PayloadLibrary
from arachnex.reporting.cvss import populate as cvss_populate
from arachnex.reporting.html_report import HtmlReporter
from arachnex.reporting.json_report import JsonReporter
from arachnex.reporting.markdown_report import MarkdownReporter
from arachnex.utils.http import HttpClient
from arachnex.utils.logger import console, emit_finding, setup_logging

log = logging.getLogger("arachnex.engine")


class Engine:
    def __init__(self, cfg: Config) -> None:
        self.cfg = cfg
        self.summary = ScanSummary(scope=cfg.targets)

        # Component wiring — all single-instance, shared across detectors.
        self.classifier = ContextClassifier(
            model_path=Path("models/context_clf.joblib")
        )
        self.payload_lib = PayloadLibrary(cfg.payload_root)
        self.llm = LLMPayloadGenerator(
            api_key=cfg.anthropic_api_key,
            model=cfg.llm_model,
        ) if cfg.use_llm else None
        self.triager = Triager()
        self.waf_fp = WafFingerprinter()
        self.oracle: Optional[HeadlessOracle] = None
        self.dashboard = None         # set in run() when cfg.live_dashboard
        self._dashboard_task: Optional[asyncio.Task] = None

    # ------------------------------------------------------------------ #
    # Top-level run
    # ------------------------------------------------------------------ #

    async def run(self) -> ScanSummary:
        setup_logging(self.cfg.log_level, self.cfg.quiet)
        log.info("ArachneX starting · mode=%s · headless=%s · llm=%s",
                 self.cfg.mode.value, self.cfg.headless.value,
                 "yes" if self.llm and self.llm.available() else "no")

        # ---- Live dashboard ----
        if self.cfg.live_dashboard:
            try:
                from arachnex.exploitation.live_dashboard import LiveDashboard
                target_label = (self.cfg.targets[0] if self.cfg.targets
                                else "scope-file")
                self.dashboard = LiveDashboard(target_label=target_label)
                self._dashboard_task = asyncio.create_task(self.dashboard.run())
            except Exception:
                log.warning("could not start live dashboard", exc_info=True)
                self.dashboard = None

        if self.cfg.headless != HeadlessMode.OFF:
            try:
                self.oracle = HeadlessOracle(self.cfg)
                await self.oracle.start()
            except Exception:
                log.warning("could not start headless oracle; continuing without",
                            exc_info=True)
                self.oracle = None

        http = HttpClient(self.cfg)
        try:
            # Stage 1: discovery
            if self.dashboard:
                from arachnex.exploitation.live_dashboard import StageEvent
                self.dashboard.emit_nowait(StageEvent("discovery", "running"))
            targets = await self._discover(http)
            self.summary.urls_discovered = len({t.url for t in targets})
            self.summary.params_discovered = sum(len(t.injection_points) for t in targets)
            if self.dashboard:
                from arachnex.exploitation.live_dashboard import StageEvent
                self.dashboard.emit_nowait(
                    StageEvent("discovery", "done",
                               detail=f"{len(targets)} targets")
                )

            # Stage 2: detection
            findings = await self._detect(http, targets)

            # Stage 3: triage & scoring
            self._score(findings)

            # Stage 4: collect
            self.summary.findings = findings
            self.summary.requests_sent = http.requests_sent
            self.summary.ended_at = datetime.now(timezone.utc)

            # Stage 5: reports
            if self.dashboard:
                from arachnex.exploitation.live_dashboard import StageEvent
                self.dashboard.emit_nowait(StageEvent("report", "running"))
            await self._report()
            if self.dashboard:
                from arachnex.exploitation.live_dashboard import StageEvent
                self.dashboard.emit_nowait(StageEvent("report", "done"))
            return self.summary
        finally:
            await http.aclose()
            if self.oracle:
                await self.oracle.stop()
            if self.dashboard:
                self.dashboard.stop()
                if self._dashboard_task:
                    try:
                        await asyncio.wait_for(self._dashboard_task, timeout=2.0)
                    except (asyncio.TimeoutError, asyncio.CancelledError):
                        self._dashboard_task.cancel()

    # ------------------------------------------------------------------ #
    # Discovery
    # ------------------------------------------------------------------ #

    async def _discover(self, http: HttpClient) -> list[Target]:
        seeds = self.cfg.targets
        if self.cfg.scope_file and self.cfg.scope_file.exists():
            seeds = seeds + [
                ln.strip() for ln in self.cfg.scope_file.read_text().splitlines()
                if ln.strip() and not ln.startswith("#")
            ]

        if not seeds:
            log.error("no targets provided")
            return []

        all_targets: list[Target] = []

        # Add seeds themselves as Targets even if they have no obvious params,
        # so we can at least probe for hidden ones in deep mode.
        for s in seeds:
            all_targets.append(Target(url=s, method=HttpMethod.GET))

        # Crawl unless QUICK mode
        if self.cfg.mode != ScanMode.QUICK:
            crawler = Crawler(self.cfg, http)
            crawled = await crawler.crawl(seeds)
            all_targets.extend(crawled.targets)

        # Param mining on root URLs in deep / bb mode
        if self.cfg.mode in {ScanMode.DEEP, ScanMode.BUG_BOUNTY}:
            miner = ParamMiner(self.cfg, http)
            mined_total = 0
            for seed in seeds[:5]:        # bound the mining scope
                try:
                    mined = await miner.mine_query(seed)
                except Exception:
                    log.debug("mining failed", exc_info=True)
                    mined = []
                if mined:
                    mined_total += len(mined)
                    all_targets.append(
                        Target(
                            url=seed, method=HttpMethod.GET,
                            injection_points=[
                                InjectionPoint(location=m.location, name=m.name)
                                for m in mined
                            ],
                        )
                    )
            if mined_total:
                log.info("param mining: %d hidden parameters discovered", mined_total)

        # De-dupe targets by (method, url, sorted_param_names)
        seen: set[tuple] = set()
        deduped: list[Target] = []
        for t in all_targets:
            key = (
                t.method.value, t.url,
                tuple(sorted((ip.location, ip.name) for ip in t.injection_points)),
            )
            if key in seen:
                continue
            seen.add(key)
            if t.injection_points or self.cfg.mode in {ScanMode.DEEP, ScanMode.BUG_BOUNTY}:
                deduped.append(t)
        return deduped

    # ------------------------------------------------------------------ #
    # Detection
    # ------------------------------------------------------------------ #

    async def _detect(self, http: HttpClient, targets: list[Target]) -> list[Finding]:
        detector = ReflectedXSSDetector(
            cfg=self.cfg, http=http, payloads=self.payload_lib,
            classifier=self.classifier, llm=self.llm,
            oracle=self.oracle, triager=self.triager, waf_fp=self.waf_fp,
        )

        # ---- Post-exploitation engine (active when oracle is up) ----
        post_exploit = None
        if self.oracle and self.cfg.run_post_exploit:
            from arachnex.exploitation.post_exploit import PostExploitEngine
            post_exploit = PostExploitEngine(self.cfg, self.oracle)

        log.info("scanning %d targets …", len(targets))
        if self.dashboard:
            from arachnex.exploitation.live_dashboard import StageEvent
            self.dashboard.emit_nowait(
                StageEvent(name="detection", state="running",
                           detail=f"0/{len(targets)}")
            )

        sem = asyncio.Semaphore(self.cfg.threads)
        results: list[Finding] = []
        results_lock = asyncio.Lock()
        completed = {"n": 0}

        async def _one(t: Target):
            async with sem:
                try:
                    fs = await detector.scan_target(t)
                except Exception:
                    log.exception("detector crashed on %s", t.url)
                    fs = []

                if fs:
                    async with results_lock:
                        for f in fs:
                            results.append(f)
                            emit_finding(
                                short_title=f.title, sev=f.severity, url=t.url,
                                extra={"payload": f.payload[:80]},
                            )
                            # Push to live dashboard
                            if self.dashboard:
                                from arachnex.exploitation.live_dashboard import FindingEvent
                                self.dashboard.emit_nowait(FindingEvent(
                                    severity=f.severity.value,
                                    title=f.title, url=t.url,
                                    payload=f.payload,
                                    executed=bool(f.browser_proof
                                                  and f.browser_proof.exec_observed),
                                    cvss=f.cvss40_score or 0.0,
                                ))

                            # ---- Post-exploitation pass ----
                            if post_exploit and f.browser_proof \
                                    and f.browser_proof.exec_observed:
                                try:
                                    proof = await post_exploit.capture(
                                        f, t, f.injection_point
                                    )
                                    f.extra["post_exploit"] = proof.__dict__
                                    if self.dashboard:
                                        from arachnex.exploitation.live_dashboard import PostExploitEvent
                                        self.dashboard.emit_nowait(PostExploitEvent(
                                            finding_title=f.title,
                                            cookies_total=len(proof.cookies),
                                            cookies_httponly=proof.cookies_http_only_count,
                                            has_session=proof.has_session_cookie,
                                            has_jwt=proof.has_jwt,
                                            has_api_key=proof.has_api_key,
                                            csrf_count=len(proof.csrf_tokens),
                                            forms_count=len(proof.forms_on_page),
                                            forms_without_csrf=sum(
                                                1 for fm in proof.forms_on_page
                                                if not fm.has_csrf
                                            ),
                                            inline_secrets=len(proof.inline_script_secrets),
                                            uplift_summary=proof.severity_uplift(),
                                            sample_tokens=[
                                                (t.location, t.name, t.value_preview)
                                                for t in proof.auth_tokens[:3]
                                            ],
                                        ))
                                except Exception:
                                    log.debug("post-exploit failed", exc_info=True)

                completed["n"] += 1
                if self.dashboard:
                    from arachnex.exploitation.live_dashboard import StageEvent
                    self.dashboard.emit_nowait(StageEvent(
                        name="detection", state="running",
                        progress=completed["n"] / max(1, len(targets)),
                        detail=f"{completed['n']}/{len(targets)}",
                    ))

        await asyncio.gather(*(_one(t) for t in targets))
        if self.dashboard:
            from arachnex.exploitation.live_dashboard import StageEvent
            self.dashboard.emit_nowait(StageEvent(name="detection", state="done"))
        return results

    # ------------------------------------------------------------------ #
    # Scoring
    # ------------------------------------------------------------------ #

    def _score(self, findings: list[Finding]) -> None:
        for f in findings:
            waf_active = bool(f.waf_signal and f.waf_signal.detected)
            auth_required = False    # v1 — engine can be taught via cfg
            cvss_populate(f, waf_active=waf_active, auth_required=auth_required)

    # ------------------------------------------------------------------ #
    # Reports
    # ------------------------------------------------------------------ #

    async def _report(self) -> list[Path]:
        out_dir = self.cfg.output_dir
        out_dir.mkdir(parents=True, exist_ok=True)
        scan_dir = out_dir / self.summary.scan_id[:12]
        scan_dir.mkdir(parents=True, exist_ok=True)
        written: list[Path] = []

        fmts = {f.lower() for f in self.cfg.report_formats}

        if "html" in fmts:
            from arachnex import __version__
            html_rep = HtmlReporter(version=__version__)
            written.append(html_rep.render(self.summary, scan_dir / "report.html"))
        if "json" in fmts:
            written.append(JsonReporter().render(self.summary, scan_dir / "report.json"))
        if "md" in fmts or "markdown" in fmts:
            written.append(MarkdownReporter().render(self.summary, scan_dir / "report.md"))

        console.print()
        console.print(f"[bold green]✓[/bold green] scan complete · "
                      f"{self.summary.critical_count} critical, "
                      f"{self.summary.high_count} high")
        for p in written:
            console.print(f"  [dim]→[/dim] {p}")
        return written
