"""
ArachneX CLI.

Subcommands:
  scan        Full scan against URLs or a scope file.
  dom         Static DOM-XSS audit of one or more local JS files.
  blind       Run the blind-XSS collaborator server.
  demo        Self-contained end-to-end demo against a local target.
  version     Print version and exit.

The CLI is the only place we touch argv/env directly. Every other module
takes a typed Config.
"""

from __future__ import annotations

import asyncio
import logging
from pathlib import Path
from typing import Optional

import typer
from rich.table import Table

from arachnex import __version__, banner
from arachnex.core.config import Config, HeadlessMode, ScanMode
from arachnex.core.engine import Engine
from arachnex.utils.logger import console, setup_logging

app = typer.Typer(
    name="arachnex",
    help="AI-Native XSS Discovery, Detection, Exploitation & Reporting",
    no_args_is_help=True,
    add_completion=False,
)


# --------------------------------------------------------------------------- #
# scan
# --------------------------------------------------------------------------- #


@app.command()
def scan(
    urls: list[str] = typer.Option(
        [], "--url", "-u", help="Target URL (may be repeated)."
    ),
    scope_file: Optional[Path] = typer.Option(
        None, "--scope", "-s", help="Newline-delimited URL/host scope file."
    ),
    out_of_scope: list[str] = typer.Option(
        [], "--exclude", help="Out-of-scope host (may be repeated)."
    ),
    mode: ScanMode = typer.Option(ScanMode.STANDARD, "--mode", "-m"),
    headless: HeadlessMode = typer.Option(HeadlessMode.VERIFY, "--headless"),
    threads: int = typer.Option(25, "--threads", "-t"),
    rps_per_host: float = typer.Option(8.0, "--rps"),
    proxy: Optional[str] = typer.Option(
        None, "--proxy", help="HTTP proxy URL (e.g. http://127.0.0.1:8080)."
    ),
    cookie: list[str] = typer.Option(
        [], "--cookie", help="K=V cookie (may be repeated)."
    ),
    header: list[str] = typer.Option(
        [], "--header", "-H", help="K:V header (may be repeated)."
    ),
    payload_root: Path = typer.Option(Path("payloads"), "--payloads"),
    use_llm: bool = typer.Option(True, "--llm/--no-llm"),
    use_evolution: bool = typer.Option(True, "--evolve/--no-evolve"),
    triage_threshold: float = typer.Option(0.4, "--triage"),
    output_dir: Path = typer.Option(Path("./arachnex-out"), "--out", "-o"),
    formats: list[str] = typer.Option(["html", "json"], "--format", "-f"),
    save_har: bool = typer.Option(False, "--save-har"),
    quiet: bool = typer.Option(False, "--quiet", "-q"),
    log_level: str = typer.Option("INFO", "--log-level"),
):
    """Run a full ArachneX scan."""
    if not urls and not scope_file:
        console.print("[red]error:[/red] provide at least one --url or --scope")
        raise typer.Exit(2)

    cookies = dict(_kv(c, "=") for c in cookie)
    headers = dict(_kv(h, ":") for h in header)

    cfg = Config(
        targets=list(urls),
        scope_file=scope_file,
        out_of_scope=list(out_of_scope),
        mode=mode,
        headless=headless,
        threads=threads,
        rps_per_host=rps_per_host,
        proxy=proxy,
        cookies=cookies,
        extra_headers=headers,
        payload_root=payload_root,
        use_llm=use_llm,
        use_evolution=use_evolution,
        triage_threshold=triage_threshold,
        output_dir=output_dir,
        report_formats=list(formats),
        save_har=save_har,
        quiet=quiet,
        log_level=log_level,
    )

    if not cfg.quiet:
        console.print(f"[cyan]{banner()}[/cyan]")
        _print_config(cfg)

    engine = Engine(cfg)
    asyncio.run(engine.run())


# --------------------------------------------------------------------------- #
# dom
# --------------------------------------------------------------------------- #


@app.command()
def dom(
    inputs: list[Path] = typer.Argument(..., help="JS files or directories."),
    out_path: Optional[Path] = typer.Option(None, "--out", "-o"),
):
    """Static DOM-XSS audit (no requests)."""
    from arachnex.detection.dom import DomXSSAnalyzer

    setup_logging("INFO")
    analyzer = DomXSSAnalyzer()

    js_files: list[Path] = []
    for inp in inputs:
        if inp.is_dir():
            js_files.extend(inp.rglob("*.js"))
        elif inp.suffix in {".js", ".mjs", ".ts"}:
            js_files.append(inp)
    if not js_files:
        console.print("[yellow]no .js files found[/yellow]")
        raise typer.Exit(1)

    results = []
    for f in js_files:
        try:
            src = f.read_text(encoding="utf-8", errors="replace")
            cands = analyzer.analyse(src, str(f))
        except Exception:
            continue
        if cands:
            results.append((f, cands))

    table = Table(title="DOM-XSS candidate flows", show_lines=False)
    table.add_column("file", overflow="fold")
    table.add_column("source", style="cyan")
    table.add_column("sink", style="red")
    table.add_column("path")
    for f, cands in results:
        for c in cands:
            table.add_row(str(f), c.source_label, c.sink_label, " → ".join(c.path[:6]))
    console.print(table)


# --------------------------------------------------------------------------- #
# blind
# --------------------------------------------------------------------------- #


@app.command()
def blind(
    listen: str = typer.Option("0.0.0.0:8443", "--listen"),
    domain: str = typer.Option(..., "--domain", help="Public domain pointing to this listener."),
):
    """Run the blind-XSS collaborator server."""
    try:
        from arachnex.server.blind_collab import run_server
    except ImportError:
        console.print("[red]fastapi/uvicorn not installed[/red]")
        raise typer.Exit(1)
    host, _, port = listen.partition(":")
    run_server(host=host or "0.0.0.0", port=int(port or "8443"), domain=domain)


# --------------------------------------------------------------------------- #
# version
# --------------------------------------------------------------------------- #


@app.command()
def version():
    """Print version."""
    console.print(banner())
    console.print(f"version: {__version__}")


# --------------------------------------------------------------------------- #
# helpers
# --------------------------------------------------------------------------- #


def _kv(s: str, sep: str) -> tuple[str, str]:
    if sep not in s:
        return s, ""
    k, _, v = s.partition(sep)
    return k.strip(), v.strip()


def _print_config(cfg: Config) -> None:
    t = Table(show_header=False, box=None, padding=(0, 2))
    t.add_column("k", style="dim", no_wrap=True)
    t.add_column("v")
    t.add_row("mode", cfg.mode.value)
    t.add_row("headless", cfg.headless.value)
    t.add_row("threads", str(cfg.threads))
    t.add_row("rps/host", str(cfg.rps_per_host))
    t.add_row("targets", ", ".join(cfg.targets[:3]) + ("…" if len(cfg.targets) > 3 else ""))
    t.add_row("llm", "yes" if cfg.use_llm else "no")
    t.add_row("evolution", "yes" if cfg.use_evolution else "no")
    t.add_row("triage threshold", str(cfg.triage_threshold))
    t.add_row("output", str(cfg.output_dir))
    console.print(t)
    console.print()


if __name__ == "__main__":
    app()
