"""
Async HTTP client with the things every scanner gets wrong:

- Per-host token-bucket rate limiting (don't ddos prod targets)
- Sane retries on transient failures only (5xx, network errors)
- Optional HTTP/2 (some WAFs treat h2 differently — useful intel)
- Connection pool sized for the worker count, not infinite
- Proxy support that doesn't silently disable TLS verification
- Header normalization that preserves WAF-relevant casing where it matters
"""

from __future__ import annotations

import asyncio
import time
from collections import defaultdict
from contextlib import asynccontextmanager
from dataclasses import dataclass
from typing import AsyncIterator, Optional
from urllib.parse import urlparse

import httpx
from tenacity import (
    retry,
    retry_if_exception_type,
    stop_after_attempt,
    wait_exponential_jitter,
)

from arachnex.core.config import Config


# --------------------------------------------------------------------------- #
# Per-host token bucket
# --------------------------------------------------------------------------- #


@dataclass
class _Bucket:
    tokens: float
    last: float
    rate: float           # tokens per second
    capacity: float


class HostRateLimiter:
    """
    Token bucket per host. Cheap, fair, and works for both crawl and fuzz
    phases. The engine should treat 'host' as scheme+netloc so HTTPS and
    HTTP variants don't share a budget.
    """

    def __init__(self, default_rate: float = 8.0, capacity: float = 16.0) -> None:
        self._default_rate = default_rate
        self._capacity = capacity
        self._buckets: dict[str, _Bucket] = {}
        self._lock = asyncio.Lock()

    def _bucket_for(self, host: str) -> _Bucket:
        b = self._buckets.get(host)
        if b is None:
            b = _Bucket(
                tokens=self._capacity,
                last=time.monotonic(),
                rate=self._default_rate,
                capacity=self._capacity,
            )
            self._buckets[host] = b
        return b

    async def acquire(self, host: str) -> None:
        while True:
            async with self._lock:
                b = self._bucket_for(host)
                now = time.monotonic()
                b.tokens = min(b.capacity, b.tokens + (now - b.last) * b.rate)
                b.last = now
                if b.tokens >= 1.0:
                    b.tokens -= 1.0
                    return
                wait_s = (1.0 - b.tokens) / b.rate
            await asyncio.sleep(wait_s)


# --------------------------------------------------------------------------- #
# Client wrapper
# --------------------------------------------------------------------------- #


class HttpClient:
    """
    Thin wrapper around httpx.AsyncClient. The engine should keep one of
    these per scan, not per request.
    """

    def __init__(self, cfg: Config) -> None:
        self._cfg = cfg
        self._limiter = HostRateLimiter(default_rate=cfg.rps_per_host)
        self._client = httpx.AsyncClient(
            http2=True,
            verify=cfg.verify_tls,
            timeout=httpx.Timeout(cfg.request_timeout),
            follow_redirects=cfg.follow_redirects,
            limits=httpx.Limits(
                max_connections=max(50, cfg.threads * 2),
                max_keepalive_connections=cfg.threads,
            ),
            proxy=cfg.proxy,
            headers=self._base_headers(),
        )
        self._sent = 0
        self._sent_lock = asyncio.Lock()

    def _base_headers(self) -> dict[str, str]:
        h = {
            "User-Agent": self._cfg.user_agent,
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            "Accept-Language": "en-US,en;q=0.9",
            "Accept-Encoding": "gzip, deflate, br",
            # X-ArachneX-Scan helps targets identify our traffic — drop it for
            # bug bounty where blending in matters, keep it for authorized eng.
            "X-ArachneX-Scan": "authorized-testing",
        }
        h.update(self._cfg.extra_headers)
        return h

    @property
    def requests_sent(self) -> int:
        return self._sent

    async def aclose(self) -> None:
        await self._client.aclose()

    @asynccontextmanager
    async def session(self) -> AsyncIterator["HttpClient"]:
        try:
            yield self
        finally:
            await self.aclose()

    @retry(
        retry=retry_if_exception_type(
            (httpx.NetworkError, httpx.RemoteProtocolError, httpx.PoolTimeout)
        ),
        wait=wait_exponential_jitter(initial=0.4, max=8.0),
        stop=stop_after_attempt(3),
        reraise=True,
    )
    async def request(
        self,
        method: str,
        url: str,
        *,
        params: Optional[dict[str, str] | list[tuple[str, str]]] = None,
        data: Optional[str | bytes | dict[str, str]] = None,
        json_body: Optional[dict] = None,
        headers: Optional[dict[str, str]] = None,
        cookies: Optional[dict[str, str]] = None,
    ) -> httpx.Response:
        host = self._host(url)
        await self._limiter.acquire(host)

        merged_headers = {**self._base_headers(), **(headers or {})}
        merged_cookies = {**self._cfg.cookies, **(cookies or {})}

        resp = await self._client.request(
            method,
            url,
            params=params,
            data=data,
            json=json_body,
            headers=merged_headers,
            cookies=merged_cookies,
        )
        async with self._sent_lock:
            self._sent += 1
        return resp

    # convenience
    async def get(self, url: str, **kw) -> httpx.Response:
        return await self.request("GET", url, **kw)

    async def post(self, url: str, **kw) -> httpx.Response:
        return await self.request("POST", url, **kw)

    @staticmethod
    def _host(url: str) -> str:
        u = urlparse(url)
        return f"{u.scheme}://{u.netloc}"
