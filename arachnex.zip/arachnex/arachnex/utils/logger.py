"""
Logging built on Rich. Findings render with severity colors; progress
shows live counters; debug stays out of the way unless asked.
"""

from __future__ import annotations

import logging
import sys
from typing import Any

from rich.console import Console
from rich.logging import RichHandler
from rich.text import Text
from rich.theme import Theme

from arachnex.core.target import Severity

_THEME = Theme(
    {
        "info": "cyan",
        "warn": "yellow",
        "error": "bold red",
        "critical": "bold magenta",
        "ok": "green",
        "dim": "grey50",
        "sev.info": "blue",
        "sev.low": "green",
        "sev.medium": "yellow",
        "sev.high": "red",
        "sev.critical": "bold magenta",
    }
)

console = Console(theme=_THEME, stderr=False, highlight=False)
err_console = Console(theme=_THEME, stderr=True, highlight=False)


_SEV_GLYPH = {
    Severity.INFO: ("●", "sev.info"),
    Severity.LOW: ("◆", "sev.low"),
    Severity.MEDIUM: ("▲", "sev.medium"),
    Severity.HIGH: ("■", "sev.high"),
    Severity.CRITICAL: ("★", "sev.critical"),
}


def setup_logging(level: str = "INFO", quiet: bool = False) -> logging.Logger:
    handler = RichHandler(
        console=err_console,
        rich_tracebacks=True,
        markup=True,
        show_time=True,
        show_path=False,
    )
    logging.basicConfig(
        level="CRITICAL" if quiet else level.upper(),
        format="%(message)s",
        datefmt="%H:%M:%S",
        handlers=[handler],
        force=True,
    )
    return logging.getLogger("arachnex")


def severity_badge(sev: Severity) -> Text:
    glyph, style = _SEV_GLYPH[sev]
    return Text(f"{glyph} {sev.value.upper():<8}", style=style)


def emit_finding(short_title: str, sev: Severity, url: str, extra: dict[str, Any] | None = None) -> None:
    """Pretty-print a finding to the user during scan."""
    badge = severity_badge(sev)
    line = Text.assemble(badge, ("│ ", "dim"), (short_title, "bold"), ("  ", ""), (url, "dim"))
    console.print(line)
    if extra:
        for k, v in extra.items():
            console.print(f"   [dim]{k}:[/dim] {v}")
