"""
Reflected XSS detector.

Flow per injection point:

  1. Inject a unique short canary (e.g. 'arx<6 hex>'). Observe reflection.
  2. If reflected, classify all reflection contexts.
  3. For each (context, neighborhood) tuple:
       - Pull static payloads for the context from the library.
       - Ask the LLM for additional payloads (if enabled).
       - Stream payloads to the target with the http client.
       - For each that survives intact, dispatch to the headless oracle.
       - On WAF block, kick off evolution against this (target, context).
  4. Surface findings to the engine.

The detector is async-first; it cooperates with the engine's worker pool
rather than spawning its own. The engine controls budget.
"""

from __future__ import annotations

import asyncio
import logging
import secrets
from dataclasses import dataclass, field
from typing import Optional

import httpx

from arachnex.ai.evolution import PayloadEvolver
from arachnex.ai.payload_generator import LLMPayloadGenerator
from arachnex.ai.triage import Triager, extract_features
from arachnex.ai.waf_fingerprint import WafFingerprinter, WafFingerprint
from arachnex.core.config import Config, HeadlessMode
from arachnex.core.target import (
    Finding,
    HttpMethod,
    InjectionPoint,
    ReflectionContext,
    ReflectionEvidence,
    Severity,
    Target,
    WafSignal,
    XSSClass,
)
from arachnex.detection.context import ContextClassifier
from arachnex.exploitation.headless import HeadlessOracle, OracleResult
from arachnex.exploitation.payloads import PayloadLibrary
from arachnex.utils.http import HttpClient

log = logging.getLogger("arachnex.detect.reflected")


@dataclass
class _CanaryProbe:
    canary: str
    response: httpx.Response
    body: str
    reflected: bool
    context_results: list = field(default_factory=list)


class ReflectedXSSDetector:
    def __init__(
        self,
        cfg: Config,
        http: HttpClient,
        payloads: PayloadLibrary,
        classifier: ContextClassifier,
        llm: Optional[LLMPayloadGenerator],
        oracle: Optional[HeadlessOracle],
        triager: Triager,
        waf_fp: WafFingerprinter,
    ) -> None:
        self.cfg = cfg
        self.http = http
        self.payloads = payloads
        self.classifier = classifier
        self.llm = llm
        self.oracle = oracle
        self.triager = triager
        self.waf_fp = waf_fp

    # ------------------------------------------------------------------ #
    # Entry point
    # ------------------------------------------------------------------ #

    async def scan_target(self, target: Target) -> list[Finding]:
        findings: list[Finding] = []
        for ip in target.injection_points:
            try:
                ip_findings = await self._scan_injection(target, ip)
                findings.extend(ip_findings)
            except Exception:
                log.exception("reflected scan failed for %s :: %s", target.url, ip.name)
        return findings

    # ------------------------------------------------------------------ #
    # Per-injection-point pipeline
    # ------------------------------------------------------------------ #

    async def _scan_injection(self, target: Target, ip: InjectionPoint) -> list[Finding]:
        # 1) Baseline + canary probe
        canary = f"arx{secrets.token_hex(4)}"
        probe = await self._probe_canary(target, ip, canary)
        if probe is None or not probe.reflected:
            return []

        # 2) Classify reflection contexts
        contexts = self.classifier.classify(probe.body, canary)
        contexts = [c for c in contexts if c.context != ReflectionContext.UNREFLECTED]
        if not contexts:
            return []

        # 3) WAF fingerprint (cheap; we use the canary response itself)
        waf = self.waf_fp.fingerprint_response(probe.response, probe.body)
        waf_signal = WafSignal(
            detected=waf.vendor is not None,
            vendor=waf.vendor,
            confidence=waf.confidence,
            block_status=waf.block_status,
            block_body_signature=waf.block_signature,
        )

        findings: list[Finding] = []
        for ctx_result in contexts:
            ctx_findings = await self._fuzz_context(
                target, ip, ctx_result, waf, waf_signal
            )
            findings.extend(ctx_findings)

        return findings

    async def _fuzz_context(
        self,
        target: Target,
        ip: InjectionPoint,
        ctx_result,
        waf: WafFingerprint,
        waf_signal: WafSignal,
    ) -> list[Finding]:

        ctx = ctx_result.context

        # Assemble payload set: static + LLM (deduplicated)
        static = self.payloads.for_context(ctx)
        llm_payloads = []
        if self.llm and self.cfg.use_llm:
            llm_canary = "arx-marker"  # never collide with our probe canary
            try:
                llm_payloads = self.llm.generate(
                    context=ctx,
                    snippet=ctx_result.snippet,
                    canary=llm_canary,
                    n=self.cfg.llm_payloads_per_context,
                    waf_vendor=waf.vendor,
                )
            except Exception:
                log.warning("LLM payload gen failed (continuing)", exc_info=True)

        seen: set[str] = set()
        ordered_payloads: list[tuple[str, str, str]] = []   # (value, marker, source)
        for p in static:
            if p.value in seen:
                continue
            seen.add(p.value)
            ordered_payloads.append((p.value, p.marker, "static"))
        for p in llm_payloads:
            if p.value in seen:
                continue
            seen.add(p.value)
            ordered_payloads.append((p.value, p.marker or "alert:31337", "llm"))

        log.info("fuzzing %s [%s] with %d payloads (waf=%s)",
                 target.url, ctx.value, len(ordered_payloads), waf.vendor or "none")

        findings: list[Finding] = []
        any_blocked = False

        # 4) Stream payloads — short-circuit on first executing payload
        for value, marker, source in ordered_payloads:
            sent, resp, body = await self._send_with_payload(target, ip, value)
            if sent is None:
                continue

            # WAF block detection per request
            this_waf = self.waf_fp.fingerprint_response(resp, body)
            blocked = self._looks_blocked(this_waf, waf)
            if blocked:
                any_blocked = True
                continue

            intact = (value in body)
            if not intact:
                continue

            finding = self._build_provisional_finding(
                target, ip, ctx, value, source, resp, body, waf_signal
            )

            # 5) Headless verification (the truth oracle)
            if self.oracle and self.cfg.headless != HeadlessMode.OFF:
                exec_result = await self._verify_with_oracle(target, ip, value, marker)
                if exec_result and exec_result.executed:
                    finding.browser_proof = exec_result.to_browser_proof()
            else:
                # No oracle — finding stays reflection-based, lower confidence
                pass

            # 6) Triage
            conf = self.triager.score(
                finding,
                extract_features(
                    finding,
                    response_headers={k.lower(): v for k, v in resp.headers.items()},
                    waf_active=waf_signal.detected,
                    auth_required=False,
                ),
            )
            finding.confidence = conf
            feats = extract_features(
                finding,
                response_headers={k.lower(): v for k, v in resp.headers.items()},
                waf_active=waf_signal.detected,
                auth_required=False,
            )
            finding.severity = self.triager.severity_for(conf, feats)

            if conf >= self.cfg.triage_threshold:
                findings.append(finding)
                # First executing finding for this context is enough
                if finding.browser_proof and finding.browser_proof.exec_observed:
                    return findings

        # 7) Nothing landed — try evolution against this context
        if any_blocked and self.cfg.use_evolution and ordered_payloads:
            evolved = await self._evolve(target, ip, ctx, ordered_payloads, waf, waf_signal)
            if evolved:
                findings.append(evolved)

        return findings

    # ------------------------------------------------------------------ #
    # Evolution path
    # ------------------------------------------------------------------ #

    async def _evolve(
        self,
        target: Target,
        ip: InjectionPoint,
        ctx: ReflectionContext,
        seeds: list[tuple[str, str, str]],
        waf: WafFingerprint,
        waf_signal: WafSignal,
    ) -> Optional[Finding]:

        seed_values = [v for v, _m, _s in seeds[:12]]

        evolver = PayloadEvolver(
            seed_payloads=seed_values,
            pop_size=self.cfg.evolution_pop_size,
            generations=self.cfg.evolution_generations,
        )

        async def probe(payload: str) -> tuple[bool, float, bool]:
            sent, resp, body = await self._send_with_payload(target, ip, payload)
            if resp is None:
                return True, 0.0, False
            fp = self.waf_fp.fingerprint_response(resp, body)
            blocked = self._looks_blocked(fp, waf)
            intact = self._intactness(payload, body)
            executed = False
            # Oracle check only when not blocked and intactness > 0.5
            if not blocked and intact > 0.5 and self.oracle:
                oc = await self._verify_with_oracle(target, ip, payload, "alert:31337")
                executed = bool(oc and oc.executed)
            return blocked, intact, executed

        best = await evolver.run(probe, oracle_top_k=2)
        if best.executed:
            sent, resp, body = await self._send_with_payload(target, ip, best.materialized)
            if resp is None:
                return None
            finding = self._build_provisional_finding(
                target, ip, ctx, best.materialized, "evolved", resp, body, waf_signal
            )
            oc = await self._verify_with_oracle(target, ip, best.materialized, "alert:31337")
            if oc:
                finding.browser_proof = oc.to_browser_proof()
            finding.payload_lineage = best.pipeline
            feats = extract_features(
                finding,
                response_headers={k.lower(): v for k, v in resp.headers.items()},
                waf_active=waf_signal.detected,
                auth_required=False,
            )
            finding.confidence = self.triager.score(finding, feats)
            finding.severity = self.triager.severity_for(finding.confidence, feats)
            return finding
        return None

    # ------------------------------------------------------------------ #
    # Helpers
    # ------------------------------------------------------------------ #

    async def _probe_canary(
        self, target: Target, ip: InjectionPoint, canary: str
    ) -> Optional[_CanaryProbe]:
        sent, resp, body = await self._send_with_payload(target, ip, canary)
        if resp is None:
            return None
        return _CanaryProbe(
            canary=canary, response=resp, body=body, reflected=(canary in body)
        )

    async def _send_with_payload(
        self, target: Target, ip: InjectionPoint, value: str
    ) -> tuple[Optional[httpx.Request], Optional[httpx.Response], str]:
        """Build and send a request injecting `value` at the given point."""
        try:
            method = target.method.value
            url = target.url
            params: Optional[list[tuple[str, str]]] = None
            data = target.body
            headers = dict(target.headers)
            cookies = dict(target.cookies)

            if ip.location == "query":
                # Replace the named parameter, preserving other params
                from urllib.parse import urlsplit, urlunsplit, parse_qsl, urlencode
                u = urlsplit(url)
                qs = parse_qsl(u.query, keep_blank_values=True)
                qs = [(k, value if k == ip.name else v) for k, v in qs]
                if ip.name not in dict(qs):
                    qs.append((ip.name, value))
                url = urlunsplit(u._replace(query=urlencode(qs, doseq=True)))
            elif ip.location == "body":
                if target.body_kind == "json":
                    import json as _json
                    try:
                        b = _json.loads(target.body or "{}")
                        b[ip.name] = value
                        data = _json.dumps(b)
                    except Exception:
                        return None, None, ""
                else:
                    # form-encoded
                    from urllib.parse import parse_qsl, urlencode
                    items = parse_qsl(target.body or "", keep_blank_values=True)
                    items = [(k, value if k == ip.name else v) for k, v in items]
                    if ip.name not in dict(items):
                        items.append((ip.name, value))
                    data = urlencode(items, doseq=True)
            elif ip.location == "header":
                headers[ip.name] = value
            elif ip.location == "cookie":
                cookies[ip.name] = value
            else:
                return None, None, ""

            resp = await self.http.request(
                method, url,
                data=data if method in {"POST", "PUT", "PATCH"} else None,
                headers=headers, cookies=cookies,
            )
            try:
                body = resp.text
            except Exception:
                body = ""
            return resp.request, resp, body
        except Exception:
            log.debug("send failed", exc_info=True)
            return None, None, ""

    async def _verify_with_oracle(
        self, target: Target, ip: InjectionPoint, payload: str, marker: str
    ) -> Optional[OracleResult]:
        if not self.oracle:
            return None
        try:
            return await self.oracle.verify(target, ip, payload, marker)
        except Exception:
            log.debug("oracle failed", exc_info=True)
            return None

    @staticmethod
    def _intactness(payload: str, body: str) -> float:
        if not payload:
            return 0.0
        if payload in body:
            return 1.0
        # longest substring match approximation
        max_l = 0
        n = len(payload)
        for size in range(n, max(4, n // 4) - 1, -1):
            for i in range(0, n - size + 1):
                if payload[i:i + size] in body:
                    max_l = size
                    break
            if max_l:
                break
        return max_l / n

    @staticmethod
    def _looks_blocked(this: WafFingerprint, baseline: WafFingerprint) -> bool:
        if this.block_status and this.block_status != baseline.block_status:
            return True
        if this.block_signature and this.block_signature != baseline.block_signature:
            return True
        return False

    def _build_provisional_finding(
        self,
        target: Target,
        ip: InjectionPoint,
        ctx: ReflectionContext,
        payload: str,
        source: str,
        resp: httpx.Response,
        body: str,
        waf_signal: WafSignal,
    ) -> Finding:
        evidence = ReflectionEvidence(
            canary=payload,
            snippet=self._snip(body, payload),
            offset=body.find(payload) if payload in body else -1,
            response_size=len(body),
            response_hash=str(abs(hash(body)) % (10**16)),
            classified_context=ctx,
            classifier_confidence=0.95,
        )
        return Finding(
            xss_class=XSSClass.REFLECTED,
            severity=Severity.MEDIUM,           # set later by triage
            confidence=0.0,
            target_url=target.url,
            method=HttpMethod(resp.request.method),
            injection_point=ip,
            payload=payload,
            reflection=evidence,
            waf_signal=waf_signal,
            title=f"Reflected XSS via `{ip.name}` (context: {ctx.value})",
            raw_request=str(resp.request.url),
            raw_response_snippet=evidence.snippet,
            extra={"payload_source": source},
            cwe=["CWE-79"],
        )

    @staticmethod
    def _snip(body: str, needle: str) -> str:
        idx = body.find(needle)
        if idx < 0:
            return body[:300]
        return body[max(0, idx - 100): idx + len(needle) + 100]
