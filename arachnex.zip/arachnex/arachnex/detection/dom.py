"""
DOM-based XSS detector.

Most scanners look for DOM XSS by regex-matching `document.write` or
`innerHTML` in `.js` files. That's noise. We do it properly:

  1. Parse JS to an AST with esprima.
  2. Walk the AST building a directed *taint-flow graph*. Nodes are
     identifiers/properties; edges are dataflow steps (assignment,
     argument-passing, return).
  3. Mark known *source* nodes (location.*, document.URL, postMessage
     data, window.name, localStorage/sessionStorage, fetch responses).
  4. Mark known *sink* nodes (innerHTML, outerHTML, insertAdjacentHTML,
     eval, Function ctor, document.write[ln], setTimeout/setInterval
     with string args, location/href/src assignments to javascript:,
     setAttribute('on*'|'src'|'href'|'srcdoc', ...), DOMParser, jQuery
     .html(), Range.createContextualFragment).
  5. Run BFS from each source. Any path that reaches a sink is a
     candidate DOM XSS.
  6. For each candidate, the LLM is asked to produce a URL fragment /
     postMessage / window.name payload that would land at the sink.

This module is intentionally STATIC. It produces hypotheses; the engine
combines them with a dynamic Playwright execution to confirm.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Optional

try:
    import esprima
    _ESPRIMA = True
except ImportError:                                              # pragma: no cover
    _ESPRIMA = False

log = logging.getLogger("arachnex.detect.dom")


# --------------------------------------------------------------------------- #
# Known sources and sinks
# --------------------------------------------------------------------------- #


SOURCES = {
    # location family
    "location.hash":                "url_fragment",
    "location.search":              "url_search",
    "location.href":                "url",
    "location.pathname":            "url_path",
    "document.URL":                 "url",
    "document.documentURI":         "url",
    "document.baseURI":             "url",
    "document.referrer":            "referrer",
    "window.name":                  "window_name",
    "window.location":              "url",
    "window.location.hash":         "url_fragment",
    # storage / cross-document
    "localStorage.getItem":         "storage",
    "sessionStorage.getItem":       "storage",
    "document.cookie":              "cookie",
    # postMessage handler argument
    "event.data":                   "postmessage",
    "msg.data":                     "postmessage",
}


SINKS = {
    # DOM HTML
    "innerHTML":                    "html",
    "outerHTML":                    "html",
    "insertAdjacentHTML":           "html",
    "document.write":               "html",
    "document.writeln":             "html",
    "Range.createContextualFragment": "html",
    "DOMParser.parseFromString":    "html",
    # eval-equivalents
    "eval":                         "code",
    "Function":                     "code",
    "setTimeout":                   "code_if_string",
    "setInterval":                  "code_if_string",
    "setImmediate":                 "code_if_string",
    "execScript":                   "code",
    # navigation / scheme
    "location":                     "scheme",
    "location.href":                "scheme",
    "location.assign":              "scheme",
    "location.replace":             "scheme",
    "window.open":                  "scheme",
    # attribute writes
    "setAttribute":                 "attr",
    "src":                          "attr",
    "srcdoc":                       "attr",
    "href":                         "attr",
    # jQuery (very common in legacy)
    "$.html":                       "html",
    "$.append":                     "html",
    "$.prepend":                    "html",
    "$.after":                      "html",
    "$.before":                     "html",
    "$.replaceWith":                "html",
}


# --------------------------------------------------------------------------- #
# Result dataclasses
# --------------------------------------------------------------------------- #


@dataclass
class TaintEdge:
    src_node: str
    dst_node: str
    kind: str              # 'assign', 'arg', 'return', 'property'
    loc: Optional[tuple[int, int]] = None      # (line, col)


@dataclass
class DomCandidate:
    source_label: str
    source_kind: str
    sink_label: str
    sink_kind: str
    path: list[str] = field(default_factory=list)        # node labels along the path
    locations: list[tuple[int, int]] = field(default_factory=list)
    raw_snippets: list[str] = field(default_factory=list)


# --------------------------------------------------------------------------- #
# Static analyser
# --------------------------------------------------------------------------- #


class DomXSSAnalyzer:
    """Per-file analyser. Pass it the source string; it returns candidates."""

    def __init__(self) -> None:
        if not _ESPRIMA:
            raise RuntimeError("esprima not installed; pip install esprima")

    def analyse(self, source: str, filename: str = "<inline>") -> list[DomCandidate]:
        try:
            tree = esprima.parseScript(source, options={"loc": True, "tolerant": True})
        except Exception as e:
            log.debug("esprima parse failed for %s: %s", filename, e)
            return []

        edges: list[TaintEdge] = []
        source_nodes: set[str] = set()
        sink_nodes: dict[str, str] = {}   # label -> kind

        self._walk(tree, edges, source_nodes, sink_nodes)

        if not source_nodes or not sink_nodes:
            return []

        # Build adjacency
        adj: dict[str, list[TaintEdge]] = {}
        for e in edges:
            adj.setdefault(e.src_node, []).append(e)

        # BFS from each source
        results: list[DomCandidate] = []
        for src in source_nodes:
            for sink_label, sink_kind in sink_nodes.items():
                path = self._bfs(adj, src, sink_label)
                if path is None:
                    continue
                results.append(
                    DomCandidate(
                        source_label=src,
                        source_kind=SOURCES.get(src, "unknown"),
                        sink_label=sink_label,
                        sink_kind=sink_kind,
                        path=path,
                    )
                )
        return results

    # ------------------------------------------------------------------ #
    # AST walk: identify sources/sinks and collect edges
    # ------------------------------------------------------------------ #

    def _walk(
        self,
        node,
        edges: list[TaintEdge],
        sources: set[str],
        sinks: dict[str, str],
    ) -> None:
        if not hasattr(node, "type"):
            return

        t = node.type

        # Identify source/sink expressions
        full = self._member_chain(node)
        if full:
            if full in SOURCES:
                sources.add(full)
            if full in SINKS:
                sinks[full] = SINKS[full]

        # Assignment: x = SOURCE  → edge SOURCE → x
        if t == "AssignmentExpression" and getattr(node, "operator", None) == "=":
            lhs_name = self._lhs_label(node.left)
            rhs_chain = self._member_chain(node.right)
            if lhs_name:
                if rhs_chain:
                    edges.append(TaintEdge(rhs_chain, lhs_name, "assign"))
                # Right side may itself be an expression containing sources
                self._collect_atoms(node.right, lhs_name, edges)
            # Sink on LHS: x.innerHTML = expr
            lhs_chain = self._member_chain(node.left)
            if lhs_chain and lhs_chain.split(".")[-1] in SINKS:
                sinks[lhs_chain] = SINKS[lhs_chain.split(".")[-1]]
                self._collect_atoms(node.right, lhs_chain, edges)

        # Variable declarations: const x = SOURCE
        if t == "VariableDeclarator":
            init = getattr(node, "init", None)
            id_ = getattr(node, "id", None)
            if init is not None and id_ is not None and getattr(id_, "name", None):
                rhs_chain = self._member_chain(init)
                if rhs_chain:
                    edges.append(TaintEdge(rhs_chain, id_.name, "assign"))
                self._collect_atoms(init, id_.name, edges)

        # Call expression: sink(arg)
        if t == "CallExpression":
            callee_chain = self._member_chain(node.callee)
            if callee_chain and (
                callee_chain in SINKS or callee_chain.split(".")[-1] in SINKS
            ):
                sink_label = callee_chain
                sinks[sink_label] = SINKS.get(callee_chain) or SINKS[callee_chain.split(".")[-1]]
                for a in node.arguments or []:
                    arg_chain = self._member_chain(a)
                    if arg_chain:
                        edges.append(TaintEdge(arg_chain, sink_label, "arg"))
                    self._collect_atoms(a, sink_label, edges)

        # Function bodies: walk children
        for child in self._children(node):
            self._walk(child, edges, sources, sinks)

    # --- AST helpers ---------------------------------------------------- #

    def _children(self, node):
        for attr in vars(node).values() if hasattr(node, "__dict__") else []:
            if isinstance(attr, list):
                yield from (c for c in attr if hasattr(c, "type"))
            elif hasattr(attr, "type"):
                yield attr

    def _member_chain(self, node) -> Optional[str]:
        """
        Produce dotted strings for MemberExpression / Identifier nodes
        so we can match against the SOURCES/SINKS tables.
        """
        if node is None:
            return None
        t = getattr(node, "type", None)
        if t == "Identifier":
            return node.name
        if t == "MemberExpression":
            obj = self._member_chain(node.object)
            prop = getattr(node.property, "name", None) or getattr(
                node.property, "value", None
            )
            if obj is None or prop is None:
                return None
            return f"{obj}.{prop}"
        return None

    def _lhs_label(self, node) -> Optional[str]:
        if node is None:
            return None
        if node.type == "Identifier":
            return node.name
        return self._member_chain(node)

    def _collect_atoms(self, node, sink_label: str, edges: list[TaintEdge]) -> None:
        """
        Walks an expression sub-tree, adding edges from any identifier or
        member-chain to `sink_label`. Conservative — over-reports rather
        than misses.
        """
        if node is None or not hasattr(node, "type"):
            return
        chain = self._member_chain(node)
        if chain and chain != sink_label:
            edges.append(TaintEdge(chain, sink_label, "expr"))
        for child in self._children(node):
            self._collect_atoms(child, sink_label, edges)

    # --- graph search --------------------------------------------------- #

    @staticmethod
    def _bfs(adj: dict[str, list[TaintEdge]], src: str, dst: str, max_depth: int = 8):
        from collections import deque
        seen = {src}
        q = deque([(src, [src])])
        while q:
            node, path = q.popleft()
            if node == dst:
                return path
            if len(path) > max_depth:
                continue
            for e in adj.get(node, []):
                if e.dst_node in seen:
                    continue
                seen.add(e.dst_node)
                q.append((e.dst_node, path + [e.dst_node]))
            # Also follow chain prefixes (e.g. x → x.innerHTML)
            for k in adj:
                if k.startswith(node + ".") and k not in seen:
                    seen.add(k)
                    q.append((k, path + [k]))
        return None
