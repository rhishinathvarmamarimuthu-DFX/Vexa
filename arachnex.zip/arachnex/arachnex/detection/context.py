"""
Context classifier — the single most important component.

When a canary reflects in a response, *where* it reflects determines what
payload will work. Classical scanners ignore this and shotgun payloads;
ArachneX classifies first, then generates context-specific payloads.

Two layers:

1. A fast deterministic HTML5-parser-based classifier that handles 80%
   of cases with confidence > 0.9. Built on html5lib (a real WHATWG
   tokenizer; not regex on tag soup) so it correctly tracks tag stack,
   quote state, and namespace-foreign content.

2. An optional trained sklearn GradientBoosting classifier on hand-
   engineered features for the ambiguous cases. The features are
   chosen to be robust against minor template variation: byte n-grams
   immediately around the reflection, parent-chain encoding, character
   class distributions, and a few WAF-block fingerprints.

Both layers emit (ReflectionContext, confidence). The detection layer
trusts the heuristic when confidence > 0.85, otherwise consults the ML
classifier (if installed).
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from html.parser import HTMLParser
from pathlib import Path
from typing import Optional

from arachnex.core.target import ReflectionContext

# Try to load the optional ML classifier. The library works without it.
try:
    import joblib  # noqa: F401
    _SK_AVAILABLE = True
except ImportError:                                          # pragma: no cover
    _SK_AVAILABLE = False


# --------------------------------------------------------------------------- #
# Output shape
# --------------------------------------------------------------------------- #


@dataclass
class ContextResult:
    context: ReflectionContext
    confidence: float
    snippet: str                          # the reflection neighborhood
    encoded_form: Optional[str] = None    # if the canary reflected encoded
    tag_stack: list[str] | None = None    # parent chain at the reflection
    quote_char: Optional[str] = None      # for attribute contexts


# --------------------------------------------------------------------------- #
# Heuristic classifier — uses a real HTML5 tokenizer for state tracking
# --------------------------------------------------------------------------- #


_FOREIGN_NS = {"svg", "math"}
_RAW_TEXT_TAGS = {"script", "style", "xmp", "iframe", "noembed",
                  "noframes", "noscript", "plaintext"}


class _StateTrackingParser(HTMLParser):
    """
    Walks the response and records the parser state at each occurrence of
    `canary`. We override the low-level handlers because we need exact
    offsets (not the parser's high-level events).
    """

    def __init__(self, canary: str, response: str) -> None:
        super().__init__(convert_charrefs=False)
        self.canary = canary
        self.response = response
        self.stack: list[str] = []
        self.hits: list[dict] = []
        # We also walk the raw bytes manually because the stdlib parser
        # is generous with broken markup; we want to know *exactly* where
        # we are relative to quotes.

    def handle_starttag(self, tag: str, attrs):
        # Attribute reflections fire here — check each attribute value.
        for name, value in attrs:
            if value is None:
                continue
            if self.canary not in value:
                continue
            # Determine quote style from raw markup
            quote = self._quote_style_for_attr(name, value)
            ctx = self._classify_attribute_context(name, value, quote)
            self.hits.append(
                dict(
                    ctx=ctx,
                    in_tag=tag,
                    attr=name,
                    quote=quote,
                    tag_stack=list(self.stack),
                )
            )
        if tag not in {"br", "img", "input", "meta", "link", "hr", "area", "base", "col",
                       "embed", "param", "source", "track", "wbr"}:
            self.stack.append(tag)

    def handle_endtag(self, tag: str):
        if self.stack and self.stack[-1] == tag:
            self.stack.pop()

    def handle_data(self, data: str):
        if self.canary not in data:
            return
        parent = self.stack[-1].lower() if self.stack else None
        if parent == "script":
            # We refine js context (string vs identifier vs template) below.
            self.hits.append(dict(ctx="js_raw", parent="script", tag_stack=list(self.stack)))
        elif parent == "style":
            self.hits.append(dict(ctx=ReflectionContext.STYLE_BLOCK, parent="style",
                                  tag_stack=list(self.stack)))
        elif parent in _FOREIGN_NS:
            ns_ctx = (ReflectionContext.SVG_FOREIGN if parent == "svg"
                      else ReflectionContext.MATHML_FOREIGN)
            self.hits.append(dict(ctx=ns_ctx, parent=parent, tag_stack=list(self.stack)))
        elif parent in _RAW_TEXT_TAGS:
            # raw text contexts behave like HTML body for escape purposes
            self.hits.append(dict(ctx=ReflectionContext.HTML_BODY, parent=parent,
                                  tag_stack=list(self.stack)))
        else:
            self.hits.append(dict(ctx=ReflectionContext.HTML_BODY, parent=parent,
                                  tag_stack=list(self.stack)))

    def handle_comment(self, data: str):
        if self.canary in data:
            self.hits.append(dict(ctx=ReflectionContext.HTML_COMMENT,
                                  tag_stack=list(self.stack)))

    # ----- helpers ----- #

    def _quote_style_for_attr(self, name: str, value: str) -> str:
        """
        The Python stdlib parser already strips quotes from attribute values,
        so we go back to the raw response to inspect the byte just before the
        reflection.
        """
        idx = self.response.find(self.canary)
        if idx == -1:
            return ""
        # Walk left looking for '=' then check the next char
        for j in range(idx - 1, max(0, idx - 256), -1):
            c = self.response[j]
            if c == "=":
                # Skip whitespace
                k = j + 1
                while k < len(self.response) and self.response[k] in " \t":
                    k += 1
                if k < len(self.response):
                    nxt = self.response[k]
                    if nxt in ('"', "'"):
                        return nxt
                    return ""           # unquoted
                return ""
        return ""

    @staticmethod
    def _classify_attribute_context(name: str, value: str, quote: str) -> ReflectionContext:
        low = name.lower()
        if low.startswith("on"):
            return ReflectionContext.ATTR_EVENT_HANDLER
        if low in {"href", "src", "action", "formaction", "data",
                   "poster", "background", "manifest", "cite", "longdesc"}:
            return ReflectionContext.URL_HREF_SRC
        if low == "style":
            return ReflectionContext.STYLE_BLOCK
        if quote == '"':
            return ReflectionContext.ATTR_DOUBLE_QUOTED
        if quote == "'":
            return ReflectionContext.ATTR_SINGLE_QUOTED
        return ReflectionContext.ATTR_UNQUOTED


# --------------------------------------------------------------------------- #
# JS sub-context refinement
# --------------------------------------------------------------------------- #


_JS_STRING_DQ = re.compile(r'"([^"\\]|\\.)*' + r'(?P<canary>{canary})' + r'([^"\\]|\\.)*"')
_JS_STRING_SQ = re.compile(r"'([^'\\]|\\.)*" + r'(?P<canary>{canary})' + r"([^'\\]|\\.)*'")
_JS_TEMPLATE  = re.compile(r"`([^`\\]|\\.)*" + r'(?P<canary>{canary})' + r"([^`\\]|\\.)*`")
_JS_JSON_KEY  = re.compile(r'"[\w\-_.]+"\s*:\s*"[^"]*' + r'(?P<canary>{canary})')


def _refine_js_context(response: str, canary: str) -> ReflectionContext:
    """
    Inside a <script>, narrow the context further. Rough but effective.
    """
    esc = re.escape(canary)
    for rx, ctx in (
        (re.compile(_JS_STRING_DQ.pattern.format(canary=esc)),    ReflectionContext.SCRIPT_STRING_DQ),
        (re.compile(_JS_STRING_SQ.pattern.format(canary=esc)),    ReflectionContext.SCRIPT_STRING_SQ),
        (re.compile(_JS_TEMPLATE.pattern.format(canary=esc)),     ReflectionContext.SCRIPT_TEMPLATE),
        (re.compile(_JS_JSON_KEY.pattern.format(canary=esc)),     ReflectionContext.SCRIPT_JSON),
    ):
        if rx.search(response):
            return ctx
    return ReflectionContext.SCRIPT_IDENTIFIER


# --------------------------------------------------------------------------- #
# Public API
# --------------------------------------------------------------------------- #


class ContextClassifier:
    """
    Classify *all* reflection sites for a given canary in a response.

    Why all? A single canary can reflect multiple times in multiple contexts
    (e.g. once in a meta tag attribute and once in a <script> JSON blob).
    We want them all because we'll generate payloads for each.
    """

    def __init__(self, model_path: Optional[Path] = None) -> None:
        self.model = None
        if model_path and _SK_AVAILABLE and model_path.exists():
            try:
                import joblib
                self.model = joblib.load(model_path)
            except Exception:                                  # pragma: no cover
                self.model = None

    def classify(self, response_text: str, canary: str) -> list[ContextResult]:
        if canary not in response_text:
            return [ContextResult(ReflectionContext.UNREFLECTED, 1.0, "")]

        # Step 1: encoded-form check — many WAFs HTML-encode the canary.
        encoded_forms = self._encoded_forms(canary)
        encoded_seen = [enc for enc in encoded_forms if enc in response_text]

        # Step 2: HTML state tracking
        parser = _StateTrackingParser(canary, response_text)
        try:
            parser.feed(response_text)
        except Exception:
            # tolerate broken markup
            pass

        results: list[ContextResult] = []

        for hit in parser.hits:
            if hit["ctx"] == "js_raw":
                ctx = _refine_js_context(response_text, canary)
            else:
                ctx = hit["ctx"]

            offset = response_text.find(canary)
            snippet = response_text[max(0, offset - 80): offset + len(canary) + 80]

            # Heuristic confidence: high when tag stack is non-empty and
            # context is specific; lower for HTML_BODY without parent.
            conf = 0.95 if ctx not in {ReflectionContext.HTML_BODY,
                                       ReflectionContext.UNREFLECTED} else 0.80

            results.append(
                ContextResult(
                    context=ctx,
                    confidence=conf,
                    snippet=snippet,
                    encoded_form=encoded_seen[0] if encoded_seen else None,
                    tag_stack=hit.get("tag_stack"),
                    quote_char=hit.get("quote"),
                )
            )

        # Step 3: ML fallback for low-confidence or no-hit cases
        if (not results or max(r.confidence for r in results) < 0.85) and self.model:
            ml_ctx, ml_conf = self._ml_classify(response_text, canary)
            if ml_conf > 0.5:
                offset = response_text.find(canary)
                snippet = response_text[max(0, offset - 80): offset + len(canary) + 80]
                results.append(ContextResult(ml_ctx, ml_conf, snippet))

        if not results:
            offset = response_text.find(canary)
            snippet = response_text[max(0, offset - 80): offset + len(canary) + 80]
            results.append(ContextResult(ReflectionContext.HTML_BODY, 0.5, snippet))

        return results

    # ----------------- helpers ----------------- #

    @staticmethod
    def _encoded_forms(canary: str) -> list[str]:
        """Common encodings WAFs / templates apply to user input."""
        forms = []
        # HTML entity
        forms.append("".join(f"&#{ord(c)};" for c in canary))
        forms.append("".join(f"&#x{ord(c):x};" for c in canary))
        # URL encoded
        from urllib.parse import quote
        forms.append(quote(canary, safe=""))
        forms.append(quote(canary, safe="").lower())
        # Unicode escape (in <script> contexts)
        forms.append("".join(f"\\u{ord(c):04x}" for c in canary))
        # Base64 (sometimes templates do this — surprisingly common)
        import base64
        forms.append(base64.b64encode(canary.encode()).decode())
        return forms

    def _ml_classify(self, response: str, canary: str) -> tuple[ReflectionContext, float]:
        """
        Optional sklearn classifier path. Feature vector is built from
        the 200 bytes around the canary plus a few coarse counters.
        """
        if not self.model:
            return ReflectionContext.UNREFLECTED, 0.0
        offset = response.find(canary)
        if offset < 0:
            return ReflectionContext.UNREFLECTED, 0.0
        window = response[max(0, offset - 100): offset + len(canary) + 100]
        features = _featurize(window)
        try:
            probs = self.model.predict_proba([features])[0]
            best = int(probs.argmax())
            label = list(ReflectionContext)[best]
            return label, float(probs[best])
        except Exception:                                       # pragma: no cover
            return ReflectionContext.UNREFLECTED, 0.0


def _featurize(window: str) -> list[float]:
    """
    Tiny but useful feature vector — kept stable so a trained model on
    disk keeps working across versions. Order matters; don't rearrange.
    """
    features = [
        window.count("<"),
        window.count(">"),
        window.count('"'),
        window.count("'"),
        window.count("="),
        window.count("&"),
        window.count(";"),
        window.count("\\"),
        window.count("/"),
        window.count("("),
        window.count(")"),
        window.count("{"),
        window.count("}"),
        window.count("`"),
        float(bool(re.search(r"<script\b", window, re.I))),
        float(bool(re.search(r"<style\b", window, re.I))),
        float(bool(re.search(r"<svg\b", window, re.I))),
        float(bool(re.search(r"<math\b", window, re.I))),
        float(bool(re.search(r"on\w+\s*=", window, re.I))),
        float(bool(re.search(r'href\s*=', window, re.I))),
        len(window),
    ]
    return features
