"""
Parameter miner.

Many real-world targets accept parameters that aren't declared in any
HTML form — debug flags, callbacks, internal IDs that bypass auth in
specific combinations. ParamMiner discovers these by sending requests
with candidate parameter names from a wordlist and comparing responses
against a baseline.

Algorithm:
  1. Baseline: fetch the URL with no extra params; record canonicalized
     response fingerprint (status, length, simhash of body shape).
  2. Batch test: send N candidates at once as query/body params with
     random values. If any batch differs from baseline, binary-split
     the batch to find the responsible parameter(s).
  3. Verify: send each suspect individually, confirm differential.

This is faster than the naive "one request per word" approach used by
older tools — by 8–32x depending on response stability.
"""

from __future__ import annotations

import asyncio
import hashlib
import logging
import secrets
from dataclasses import dataclass
from typing import Optional
from urllib.parse import urlencode, urlsplit, urlunsplit, parse_qsl

import httpx

from arachnex.core.config import Config
from arachnex.core.target import HttpMethod, InjectionPoint
from arachnex.utils.http import HttpClient

log = logging.getLogger("arachnex.mine")


# Compact built-in wordlist — the longer ones are external file inputs.
BUILTIN_PARAMS = [
    "callback", "jsonp", "debug", "test", "preview", "admin", "redirect",
    "url", "next", "return", "returnUrl", "continue", "destination",
    "uid", "user_id", "id", "userid", "u",
    "q", "query", "search", "keyword", "term",
    "lang", "locale", "language", "country",
    "token", "auth", "key", "apikey", "api_key", "access_token",
    "page", "p", "view", "v", "format", "f", "type", "t",
    "file", "filename", "path", "dir", "folder",
    "name", "title", "description", "body", "content", "text", "html",
    "category", "cat", "tag", "tags",
    "email", "username", "uname",
    "include", "template", "theme",
    "filter", "sort", "order", "by",
    "from", "to", "since", "until",
    "callback_url", "return_to", "goto",
]


@dataclass
class MinedParam:
    name: str
    location: str               # 'query' or 'body'
    response_size_delta: int    # vs baseline
    confidence: float


class ParamMiner:
    def __init__(self, cfg: Config, http: HttpClient,
                 extra_wordlist: Optional[list[str]] = None,
                 batch_size: int = 25) -> None:
        self.cfg = cfg
        self.http = http
        self.batch_size = batch_size
        seen: set[str] = set()
        merged: list[str] = []
        for w in BUILTIN_PARAMS + (extra_wordlist or []):
            if w not in seen:
                seen.add(w)
                merged.append(w)
        self.wordlist = merged

    async def mine_query(self, url: str) -> list[MinedParam]:
        baseline = await self._baseline(url)
        if not baseline:
            return []

        suspects: list[str] = []

        # Batch tests
        for i in range(0, len(self.wordlist), self.batch_size):
            batch = self.wordlist[i:i + self.batch_size]
            differs = await self._batch_differs(url, batch, baseline)
            if differs:
                # binary-split
                suspects.extend(await self._bisect(url, batch, baseline))

        # Verify each individually
        verified: list[MinedParam] = []
        for name in suspects:
            res = await self._single_test(url, name, baseline)
            if res:
                verified.append(res)
        return verified

    # ------------------------------------------------------------------ #
    # Baseline
    # ------------------------------------------------------------------ #

    @dataclass
    class _Baseline:
        status: int
        size: int
        body_hash: str
        body: str

    async def _baseline(self, url: str) -> Optional["_Baseline"]:
        try:
            resp = await self.http.get(url)
        except Exception:
            return None
        try:
            body = resp.text
        except Exception:
            body = ""
        return self._Baseline(
            status=resp.status_code,
            size=len(body),
            body_hash=hashlib.sha1(body.encode("utf-8", errors="replace")).hexdigest(),
            body=body,
        )

    async def _send_with_params(self, url: str, extra: dict[str, str]) -> Optional[httpx.Response]:
        u = urlsplit(url)
        qs = parse_qsl(u.query, keep_blank_values=True)
        qs.extend(extra.items())
        new_url = urlunsplit(u._replace(query=urlencode(qs, doseq=True)))
        try:
            return await self.http.get(new_url)
        except Exception:
            return None

    def _diff_score(self, baseline: "_Baseline", resp: httpx.Response, body: str) -> float:
        if resp.status_code != baseline.status:
            return 1.0
        if len(body) == 0 and baseline.size > 0:
            return 0.8
        delta = abs(len(body) - baseline.size)
        rel = delta / max(1, baseline.size)
        if rel > 0.05:
            return min(1.0, rel * 2.0)
        return 0.0

    async def _batch_differs(self, url: str, names: list[str], baseline: "_Baseline") -> bool:
        extra = {n: secrets.token_hex(4) for n in names}
        resp = await self._send_with_params(url, extra)
        if not resp:
            return False
        try:
            body = resp.text
        except Exception:
            return False
        return self._diff_score(baseline, resp, body) > 0.2

    async def _bisect(self, url: str, batch: list[str], baseline: "_Baseline") -> list[str]:
        if len(batch) == 1:
            return batch
        mid = len(batch) // 2
        left, right = batch[:mid], batch[mid:]
        suspects: list[str] = []
        if await self._batch_differs(url, left, baseline):
            suspects.extend(await self._bisect(url, left, baseline))
        if await self._batch_differs(url, right, baseline):
            suspects.extend(await self._bisect(url, right, baseline))
        return suspects

    async def _single_test(self, url: str, name: str, baseline: "_Baseline") -> Optional[MinedParam]:
        marker = secrets.token_hex(4)
        resp = await self._send_with_params(url, {name: marker})
        if not resp:
            return None
        try:
            body = resp.text
        except Exception:
            return None
        score = self._diff_score(baseline, resp, body)
        if score < 0.2:
            return None
        return MinedParam(
            name=name,
            location="query",
            response_size_delta=len(body) - baseline.size,
            confidence=min(0.99, score),
        )
