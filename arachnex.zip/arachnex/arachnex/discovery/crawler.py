"""
Crawler.

A crawler for an XSS scanner has a specific job: enumerate as many
(URL, parameter) tuples as possible within the scope and rate budget.
It is *not* a generic spider. We optimize for:

  • Form discovery (incl. POST endpoints)
  • Query parameter harvesting from <a href> and <form action>
  • JS asset URLs (we feed them to the DOM analyzer)
  • SPA hash-route harvesting (look for routes in JS bundles)
  • Wayback / archive.org enrichment (separate, optional module)

Concurrency: aiohttp-style worker pool with per-host rate limiting
inherited from HttpClient. Depth-bounded. Loop-resistant via visited set
and URL canonicalization.
"""

from __future__ import annotations

import asyncio
import logging
import re
from collections import deque
from dataclasses import dataclass, field
from typing import Optional
from urllib.parse import urljoin, urlsplit, urlunsplit, parse_qsl

from bs4 import BeautifulSoup

from arachnex.core.config import Config
from arachnex.core.target import HttpMethod, InjectionPoint, Target
from arachnex.utils.http import HttpClient

log = logging.getLogger("arachnex.crawl")


# --------------------------------------------------------------------------- #
# URL canonicalization
# --------------------------------------------------------------------------- #


_DROP_QUERY_PARAMS = {"utm_source", "utm_medium", "utm_campaign", "utm_term",
                      "utm_content", "fbclid", "gclid", "ref"}


def canonicalize(url: str) -> str:
    u = urlsplit(url)
    # lowercase host
    netloc = u.netloc.lower()
    # strip trailing default port
    if netloc.endswith(":80") and u.scheme == "http":
        netloc = netloc[:-3]
    if netloc.endswith(":443") and u.scheme == "https":
        netloc = netloc[:-4]
    # drop tracking params
    qs = [(k, v) for k, v in parse_qsl(u.query, keep_blank_values=True)
          if k.lower() not in _DROP_QUERY_PARAMS]
    qs.sort()
    from urllib.parse import urlencode
    query = urlencode(qs, doseq=True)
    # drop fragment for visited-set purposes
    return urlunsplit((u.scheme, netloc, u.path or "/", query, ""))


def same_scope(seed_host: str, candidate: str) -> bool:
    try:
        u = urlsplit(candidate)
    except Exception:
        return False
    host = u.netloc.split("@")[-1].split(":")[0].lower()
    s = seed_host.lower()
    return host == s or host.endswith("." + s)


# --------------------------------------------------------------------------- #
# Crawler
# --------------------------------------------------------------------------- #


@dataclass
class CrawlOutput:
    targets: list[Target] = field(default_factory=list)
    js_assets: set[str] = field(default_factory=set)
    visited: set[str] = field(default_factory=set)


class Crawler:
    SKIP_EXT = {
        ".png", ".jpg", ".jpeg", ".gif", ".svg", ".webp", ".ico",
        ".css", ".woff", ".woff2", ".ttf", ".otf", ".eot",
        ".pdf", ".zip", ".rar", ".7z", ".gz", ".tar",
        ".mp4", ".mp3", ".mov", ".webm", ".avi",
    }

    def __init__(self, cfg: Config, http: HttpClient) -> None:
        self.cfg = cfg
        self.http = http

    async def crawl(self, seeds: list[str]) -> CrawlOutput:
        out = CrawlOutput()
        if not seeds:
            return out

        seed_host = urlsplit(seeds[0]).netloc.split(":")[0].lower()

        q: deque[tuple[str, int]] = deque((canonicalize(s), 0) for s in seeds)
        visited: set[str] = set()

        sem = asyncio.Semaphore(self.cfg.threads)

        async def worker(url: str, depth: int) -> tuple[list[tuple[str, int]],
                                                        list[Target], set[str]]:
            new_urls: list[tuple[str, int]] = []
            new_targets: list[Target] = []
            new_js: set[str] = set()

            async with sem:
                try:
                    resp = await self.http.get(url)
                except Exception as e:
                    log.debug("crawl GET %s failed: %s", url, e)
                    return [], [], set()

            content_type = resp.headers.get("content-type", "").lower()
            if "text/html" not in content_type and "application/xhtml" not in content_type:
                return [], [], set()

            try:
                body = resp.text
            except Exception:
                return [], [], set()

            # Always add the URL itself as a target if it has query params
            params = parse_qsl(urlsplit(url).query, keep_blank_values=True)
            if params:
                new_targets.append(
                    Target(
                        url=url,
                        method=HttpMethod.GET,
                        injection_points=[
                            InjectionPoint(location="query", name=k, sample_value=v)
                            for k, v in params
                        ],
                    )
                )

            try:
                soup = BeautifulSoup(body, "lxml")
            except Exception:
                soup = BeautifulSoup(body, "html.parser")

            # Anchors
            for a in soup.find_all("a", href=True):
                href = a["href"].strip()
                if not href or href.startswith(("javascript:", "mailto:", "tel:", "#")):
                    continue
                absolute = urljoin(url, href)
                if not same_scope(seed_host, absolute):
                    continue
                if any(absolute.lower().endswith(ext) for ext in self.SKIP_EXT):
                    continue
                canon = canonicalize(absolute)
                if canon not in visited and depth + 1 <= self.cfg.crawl_depth:
                    new_urls.append((canon, depth + 1))

            # Forms
            for form in soup.find_all("form"):
                action = (form.get("action") or "").strip() or url
                method = (form.get("method") or "GET").upper()
                absolute = urljoin(url, action)
                if not same_scope(seed_host, absolute):
                    continue
                inputs: list[InjectionPoint] = []
                for inp in form.find_all(["input", "textarea", "select"]):
                    name = inp.get("name")
                    if not name:
                        continue
                    sample = inp.get("value") or ""
                    inputs.append(InjectionPoint(
                        location="body" if method == "POST" else "query",
                        name=name,
                        sample_value=sample,
                    ))
                if inputs:
                    new_targets.append(
                        Target(
                            url=absolute,
                            method=HttpMethod(method),
                            injection_points=inputs,
                            body_kind="form" if method == "POST" else None,
                        )
                    )

            # JS assets
            for s in soup.find_all("script", src=True):
                absolute = urljoin(url, s["src"])
                if same_scope(seed_host, absolute):
                    new_js.add(absolute)

            # Extract URLs from inline JS (very common in SPAs)
            for s in soup.find_all("script", src=False):
                if s.string:
                    for m in re.finditer(r'["\'](/[^"\'\s<>]{1,200})["\']', s.string):
                        absolute = urljoin(url, m.group(1))
                        if (same_scope(seed_host, absolute)
                                and not any(absolute.lower().endswith(ext)
                                            for ext in self.SKIP_EXT)):
                            canon = canonicalize(absolute)
                            if canon not in visited and depth + 1 <= self.cfg.crawl_depth:
                                new_urls.append((canon, depth + 1))

            return new_urls, new_targets, new_js

        # BFS loop
        in_flight: set[asyncio.Task] = set()
        while q or in_flight:
            while q and len(in_flight) < self.cfg.threads and len(visited) < self.cfg.crawl_max_urls:
                url, depth = q.popleft()
                if url in visited:
                    continue
                visited.add(url)
                in_flight.add(asyncio.create_task(worker(url, depth)))

            if not in_flight:
                break

            done, in_flight = await asyncio.wait(in_flight, return_when=asyncio.FIRST_COMPLETED)
            for d in done:
                try:
                    new_urls, new_targets, new_js = d.result()
                except Exception:
                    continue
                out.targets.extend(new_targets)
                out.js_assets.update(new_js)
                for u, depth in new_urls:
                    if u not in visited and len(visited) + len(q) < self.cfg.crawl_max_urls:
                        q.append((u, depth))

        out.visited = visited
        log.info("crawl complete: %d urls visited, %d targets, %d js assets",
                 len(visited), len(out.targets), len(out.js_assets))
        return out
