"""
ArachneX demo target — a deliberately vulnerable Flask app.

Run it locally on a port that is NOT exposed to the internet:

    pip install flask
    python examples/demo_target.py

Then point ArachneX at it:

    arachnex scan -u http://127.0.0.1:5050/ --mode deep

The app contains six deliberately vulnerable endpoints, one in each
"shape" ArachneX needs to handle:

  /reflect/html-body      — reflection in HTML text
  /reflect/attr-dq        — reflection in a double-quoted attribute
  /reflect/event-handler  — reflection inside an on* attribute
  /reflect/js-string      — reflection inside a <script> string
  /reflect/svg            — reflection inside an SVG namespace
  /reflect/url-href       — reflection as an href value
  /reflect/mxss           — sanitizer that decodes <listing> wrong
  /reflect/post           — POST body parameter reflection
  /dom/                   — DOM-XSS via location.hash → innerHTML
  /blind/comment          — write-then-read stored reflection
                            (renders only on /blind/feed for admin role)

DO NOT run this on a public-facing host. The whole point is that every
endpoint is exploitable.
"""

from __future__ import annotations

import html
from urllib.parse import quote_plus

try:
    from flask import Flask, request, redirect, make_response
except ImportError:
    raise SystemExit("flask not installed — `pip install flask` first")


app = Flask(__name__)

INDEX_HTML = """\
<!doctype html><meta charset=utf-8><title>ArachneX demo target</title>
<style>body{font-family:system-ui,sans-serif;max-width:760px;margin:32px auto;
padding:0 16px;color:#222}code{background:#f3f3f3;padding:2px 6px;border-radius:4px}
h2{margin-top:28px}</style>
<h1>ArachneX demo target</h1>
<p>Every endpoint below is intentionally vulnerable. Do not deploy.</p>
<ul>
  <li><a href="/reflect/html-body?q=hello">/reflect/html-body?q=…</a></li>
  <li><a href='/reflect/attr-dq?q=hello'>/reflect/attr-dq?q=…</a></li>
  <li><a href='/reflect/event-handler?q=hello'>/reflect/event-handler?q=…</a></li>
  <li><a href='/reflect/js-string?q=hello'>/reflect/js-string?q=…</a></li>
  <li><a href='/reflect/svg?q=hello'>/reflect/svg?q=…</a></li>
  <li><a href='/reflect/url-href?q=https://example.com'>/reflect/url-href?q=…</a></li>
  <li><a href='/reflect/mxss?q=hello'>/reflect/mxss?q=…</a></li>
  <li><a href='/reflect/post'>/reflect/post (form POST)</a></li>
  <li><a href='/dom/'>/dom/ (try #hello)</a></li>
  <li><a href='/blind/comment'>/blind/comment (write a comment, view at /blind/feed)</a></li>
</ul>
"""


@app.get("/")
def index():
    return INDEX_HTML


# ---------- reflection variants ---------- #

@app.get("/reflect/html-body")
def html_body():
    q = request.args.get("q", "")
    return f"<!doctype html><h1>Hello, {q}!</h1>"


@app.get("/reflect/attr-dq")
def attr_dq():
    q = request.args.get("q", "")
    return f'<!doctype html><input type="text" value="{q}">'


@app.get("/reflect/event-handler")
def event_handler():
    q = request.args.get("q", "")
    # Naive "escape only <>" — fails to escape inside on* handlers
    safe = q.replace("<", "&lt;").replace(">", "&gt;")
    return f'<!doctype html><button onclick="track(\'{safe}\')">click</button>'


@app.get("/reflect/js-string")
def js_string():
    q = request.args.get("q", "")
    return f'<!doctype html><script>var name="{q}";console.log(name);</script>'


@app.get("/reflect/svg")
def svg():
    q = request.args.get("q", "")
    return f'<!doctype html><svg width=200 height=80><text x=10 y=20>{q}</text></svg>'


@app.get("/reflect/url-href")
def url_href():
    q = request.args.get("q", "")
    return f'<!doctype html><a href="{q}">click</a>'


@app.get("/reflect/mxss")
def mxss():
    """Sanitizer-escapes < and > but uses <listing> which decodes them."""
    q = request.args.get("q", "")
    encoded = q.replace("<", "&lt;").replace(">", "&gt;")
    return f"<!doctype html><listing>{encoded}</listing>"


@app.post("/reflect/post")
def post_reflect():
    q = request.form.get("q", "")
    return f"<!doctype html><h2>You said: {q}</h2>"


@app.get("/reflect/post")
def post_form():
    return ('<!doctype html><form method=post action=/reflect/post>'
            '<input name=q><button>submit</button></form>')


# ---------- DOM XSS ---------- #

@app.get("/dom/")
def dom():
    return """\
<!doctype html><meta charset=utf-8><title>DOM demo</title>
<h2>DOM XSS sink</h2>
<div id=greeting></div>
<script>
  // Vulnerable: location.hash flows into innerHTML with no sanitization.
  document.getElementById('greeting').innerHTML =
    'Hello, ' + decodeURIComponent(location.hash.slice(1));
</script>
"""


# ---------- Stored / blind-style ---------- #

_COMMENTS: list[str] = []


@app.route("/blind/comment", methods=["GET", "POST"])
def blind_comment():
    if request.method == "POST":
        body = request.form.get("body", "")
        _COMMENTS.append(body)
        return redirect("/blind/comment")
    items = "".join(f"<li>{html.escape(c)}</li>" for c in _COMMENTS[-10:])
    return f"""\
<!doctype html><meta charset=utf-8>
<h2>Leave a comment</h2>
<form method=post><input name=body style="width:400px"><button>post</button></form>
<p>Public preview (escaped):</p>
<ol>{items}</ol>
<p style=color:#888>An admin reviews comments at <code>/blind/feed</code>.</p>
"""


@app.get("/blind/feed")
def blind_feed():
    """Admin view — comments are NOT escaped. Classic stored XSS."""
    items = "".join(f"<li>{c}</li>" for c in _COMMENTS[-50:])
    return f"<!doctype html><h2>Admin feed (DO NOT SHARE)</h2><ol>{items}</ol>"


if __name__ == "__main__":
    print("ArachneX demo target — http://127.0.0.1:5050/")
    print("WARNING: every endpoint is deliberately vulnerable.")
    app.run(host="127.0.0.1", port=5050, debug=False)
