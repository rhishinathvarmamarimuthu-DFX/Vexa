# `models/` — trained model artifacts

This directory holds pre-trained model files used by ArachneX
components. It is intentionally checked in **empty** in the public
distribution: training data for the context classifier comes from
real engagements and isn't redistributable.

## What ArachneX looks for here

| File | Used by | Purpose |
|---|---|---|
| `context_clf.joblib` | `detection.context.ContextClassifier` | Sklearn pipeline that classifies the 17 reflection contexts when the heuristic returns low confidence. |
| `triage_calibration.json` | `ai.triage.Triager` (planned v0.2) | Per-target prior calibration for triage scoring. |

## What happens when files are missing

Every model file is **optional**. If `context_clf.joblib` is absent,
`ContextClassifier` falls back to its heuristic path (a real WHATWG
HTML5 tokenizer + regex refinement for JS sub-contexts). This is the
default for the open-source distribution and is more than sufficient
for the demo on the project README.

If `triage_calibration.json` is absent, the triager uses the hand-tuned
weights in `ai.triage._WEIGHTS`. This is the deliberate v1 design
choice: auditable linear baseline shipped in source, learned
refinements layered on top later.

## Training your own

A training harness will land in `tools/train_context.py` in v0.2. The
short version: collect (reflection_neighborhood, true_label) tuples
from past scans (or synthesize them from a fuzzer hitting your own
test apps), train a gradient-boosted tree, dump with `joblib.dump`
into this directory.

If you train a model that materially outperforms the heuristic, please
consider contributing it back — model weights, not training data,
are redistributable under the project's MIT license.
