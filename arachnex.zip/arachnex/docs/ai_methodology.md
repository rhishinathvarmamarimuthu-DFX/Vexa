# ArachneX AI Methodology

This is the technical talk track for "How AI changes XSS hunting" —
the spine you can lift directly into a Black Hat / nullcon talk.

We focus on five claims, each backed by the actual code path:

1. **Context-classified payloads strictly dominate fixed payload lists.**
2. **LLMs help where templates fail: neighborhood-aware payload generation.**
3. **Genetic search beats fuzz-by-shotgun against modern WAFs.**
4. **Real browser execution kills the false-positive class.**
5. **Auditable triage > black-box ML scoring.**

---

## Claim 1 — Context-classified payloads dominate

Classical scanners pick one of three approaches:

- **Static shotgun.** Send all ~4500 payloads at every parameter. High
  noise, high blocks, low precision. Modern WAFs profile bursty
  shotgunning and rate-limit.
- **Polyglot-only.** Pick a handful of payloads (e.g., Heyes' polyglot)
  that work across many contexts. Misses anything that requires context-
  specific escape (most JS-string contexts, attribute event handlers).
- **Context-aware via regex.** What Dalfox does — basic regex to guess
  HTML/JS/attribute, then bucket. Fragile against minor template
  variation.

ArachneX classifies the reflection neighborhood into one of **17
contexts** (`core.target.ReflectionContext`). The classification uses
a real WHATWG HTML5 tokenizer (`html5lib`) — not regex on tag soup —
so it correctly tracks:

- the tag stack at the reflection (handles `<select><option>` etc.)
- the attribute quote style (single/double/unquoted)
- foreign content (SVG/MathML) namespace transitions
- raw-text contexts (`<script>`, `<style>`, `<xmp>`, `<plaintext>`)
- the JS sub-context (string-dq / string-sq / template / identifier / JSON)

**Why 17 contexts?** Because the right escape is fundamentally different
in each:

| Context | Working payload | Broken in this context |
|---|---|---|
| HTML body | `<svg/onload=alert(1)>` | (works almost everywhere) |
| Attr double-quoted | `"><svg onload=alert(1)>` | `<script>` (already in tag) |
| Event handler attr | `alert(1)` (bare JS) | `<script>` (not parsed) |
| JS double-quoted string | `";alert(1);//` | `<svg/onload=…>` (literal text) |
| JS template literal | `${alert(1)}` | string close characters |
| CSS context | `</style><svg…>` | inline JS |
| Comment | `--><svg…>` | tag-open sequences |
| SVG foreign | `<animate onbegin=alert(1)…>` | `<script>` in older browsers |

Shipping a fixed list ignores all of this. Context classification +
per-context payload selection is ~3–8× more efficient in our internal
benchmarks (same true positive rate at ~1/4 the requests).

---

## Claim 2 — LLMs help with neighborhood-aware generation

The LLM is *one source* of payloads, not the engine. It runs *after*
context classification, with two inputs:

1. The classified context label.
2. The actual 200-character byte neighborhood around the reflection.

This matters because reflections aren't just "in a JS string"; they're
"in a JS string that's the value of a `data-config` attribute on a
`<button>` inside a Vue template that's reactive on `:click`." Static
payload libraries are blind to that. An LLM can reason about it.

We constrain the LLM with:

- **Strict JSON schema.** The model returns
  `{payloads: [{value, rationale, marker, tags}]}`. We reject anything
  malformed.
- **Hard limits.** ≤512 chars per payload, ≤20 payloads per call.
- **Caching by `(context, neighborhood-hash, waf-vendor)`.** Many
  parameters share contexts; we don't pay per parameter.
- **Pre-flight rules.** Payloads must include a greppable execution
  marker. No exfil destinations unless a collab host is configured.

The LLM never replaces the static library — it augments it. If the API
is unreachable, the scan continues with the static set + GA evolution.

---

## Claim 3 — Genetic search beats shotgun against WAFs

The GA in `ai.evolution.PayloadEvolver` evolves over a **transformation
grammar**, not over raw bytes. Each transform is a syntactically-aware
mutation: case toggling, comment splitting in tag names, unicode ZWJ
insertion, encoding stacks, event-handler renaming, etc.

Fitness:

```
fitness = 0.5 · (1 − was_blocked)
        + 0.3 · longest_substring_match(payload, response) / |payload|
        + 0.2 · oracle_executed
```

The `was_blocked` signal is cheap (one HTTP request per genome).
`oracle_executed` requires a full Playwright run — expensive — so we
only evaluate it for the top-k of each generation.

Typical convergence on real WAFs (production Cloudflare, AWS WAF,
Akamai with default OWASP-CRS-like rules): **20–60 generations**,
total request budget ~500–1500. That's the budget a single fuzzer
worker would otherwise spend on one parameter in static shotgun mode.

The talk-track moment: show a payload that gets 403'd by Cloudflare,
let the GA run live in a terminal, and show generation N landing as a
confirmed alert in the headless oracle. We've reproduced this against
test deployments and the audience reaction is consistent: this is the
demo.

---

## Claim 4 — Real browser execution kills false positives

Reflection ≠ execution. Most public XSS scanners report reflections;
on real engagements those reports are 30–70% false positives. CSP
blocks the payload, the reflection sits in `<noscript>`, the bytes are
HTML-encoded by a downstream layer, etc.

ArachneX's `HeadlessOracle`:

- Injects a pre-page `window.__arx` sentinel via Playwright's
  `add_init_script` — runs before any page script.
- The sentinel rebinds `alert`, `prompt`, `confirm`.
- We listen on `Runtime.consoleAPICalled` AND `page.on('dialog')`
  AND `Runtime.exceptionThrown` — three independent signals.
- We capture screenshots only on executing payloads, so reports stay
  small.

We deliberately do NOT report a "soft positive" when reflection
intactness is 100% but the oracle didn't fire. CSP-protected pages,
sandboxed iframes, and Trusted-Types-enabled apps look like "intact
reflection, no exec" — and the right report for those is *no
finding*, not "potentially vulnerable, please verify."

---

## Claim 5 — Auditable triage > black-box ML scoring

`ai.triage.Triager` is a hand-tuned logistic regression. Eight features.
Weights live in the module. Anyone can see exactly *why* a finding got
0.92 versus 0.31.

```python
_WEIGHTS = {
    "intercept":           -0.4,
    "intactness":           1.6,
    "executed":             3.2,        # browser execution dominates
    "context_specificity":  1.0,
    "csp_blocks_inline":   -1.4,
    "trusted_types":       -1.6,
    "sandboxed":           -0.8,
    "waf_active":          -0.3,
    "auth_required":       -0.6,
}
```

The triager outputs both a numeric confidence and a one-line *explanation*
(`Triager.explain`). That explanation lands in the report so a triage
team can see how each conclusion was reached.

We considered XGBoost. We considered a small transformer. For v1 we
chose auditable linear over opaque non-linear, because in offensive
security a tool that can't be reasoned about is a tool you can't trust.
Once we have training data from real engagements, we'll add a non-linear
backend behind the same interface — but it will remain *additive* to
the auditable baseline.

---

## What the Black Hat / nullcon demo looks like

A 25-minute talk slot has time for:

1. **3 min: the problem.** Static-list scanners + modern WAFs + SPAs.
2. **5 min: claim 1.** Context-classified payloads, live diff against
   xss0r-style shotgun.
3. **5 min: claim 2.** LLM-generated payloads on a Vue.js test app
   where the static list fails and the LLM-generated one lands.
4. **5 min: claim 3.** Live GA evolution against a Cloudflare-protected
   test target, narrating fitness landscape.
5. **5 min: claim 4.** Headless oracle catching exec the way a regex
   scanner cannot.
6. **2 min: open-source release + roadmap.**

Total: 25 minutes, three live demos, MIT-licensed code published the
morning of the talk.

---

## Limitations we'll own on stage

The honest slide. Black Hat audiences spot puffery instantly; owning
the gaps buys credibility.

- Static AST DOM analysis is hypothesis-only; we confirm a subset.
- mXSS corpus is finite — bespoke sanitizers may have unique gaps.
- The GA cannot beat a WAF that bans IPs on repeated failures (this is
  a feature: we *shouldn't* be able to brute-force someone's prod
  target indefinitely).
- The LLM costs money. Anthropic API spend at default settings is
  roughly $0.10–$0.50 per medium-sized scope. Cacheable, scale-able,
  but real.
- We are not the right tool for SQL injection, SSRF, or auth issues.
  We do XSS. We do it well.
