<div align="center">

# ArachneX

### AI-Native XSS Discovery, Detection, Exploitation & Reporting Framework

*Built for bug bounty researchers, red teams, and AppSec engineers who are tired of static payload lists.*

[![Python 3.11+](https://img.shields.io/badge/python-3.11+-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Black Hat Asia 2026](https://img.shields.io/badge/Black%20Hat-Asia%202026-red.svg)](#)
[![PRs Welcome](https://img.shields.io/badge/PRs-welcome-brightgreen.svg)](#)

</div>

---

## Why ArachneX exists

Static XSS scanners have hit a wall. They ship a fixed payload list (xss0r ships ~4500; XSStrike ~50 with mutations; Dalfox ~1000), throw them at every parameter, and grep the response. That worked in 2015. In 2026, modern targets defeat that approach with:

- **Context-aware encoding** (a payload that works in HTML body fails in `<script>` blocks and vice versa)
- **ML-based WAFs** (Cloudflare, Akamai, AWS WAF use anomaly scoring, not just regex)
- **SPAs with client-side routing** (most reflections never appear in HTTP responses)
- **Mutation XSS** (browsers re-parse markup; sanitized input becomes executable)
- **Trusted Types & CSP** (block 90% of classical payloads outright)

ArachneX flips the model. Instead of one fixed list against every target, we **classify the reflection context**, **generate payloads specific to that context** (statically + via LLM), **verify execution in a real browser**, and **evolve payloads** that get close to working. The scanner gets *smarter as the scan progresses*.

---

## What it does differently

| Capability | xss0r / Dalfox / XSStrike | ArachneX |
|---|---|---|
| Payload strategy | Fixed list (1k–4.5k) | Context-classified + LLM-generated + evolved |
| Context detection | Regex / heuristics | Transformer classifier on reflection neighborhoods |
| Verification | Reflection match | Headless Chrome with CDP execution hooks |
| DOM XSS | Regex on `.js` | AST + taint-flow graph + GNN ranking |
| WAF bypass | Hardcoded tricks | ML fingerprint → strategy selection → RL evolution |
| False positives | Manual triage | Trained classifier scores every finding |
| Mutation XSS (mXSS) | Not supported | First-class — re-parses sanitizer output |
| Blind XSS | Callback server | Callback + DOM exfil + WebSocket beaconing |
| Modern web | URLs only | SPA-aware, GraphQL, WebSocket, postMessage |
| Reporting | HTML/PDF/JSON | + CVSS 4.0, remediation, LLM-written narrative |

---

## Architecture (high-level)

```
                    ┌────────────────────────────────────────┐
                    │              ArachneX Engine             │
                    └───────────────────┬────────────────────┘
                                        │
        ┌───────────────────────────────┼────────────────────────────┐
        ▼                               ▼                            ▼
  ┌──────────┐                  ┌──────────────┐             ┌─────────────┐
  │ Recon &  │                  │  Detection   │             │ Exploitation│
  │Discovery │                  │  Pipeline    │             │ & Reporting │
  └────┬─────┘                  └──────┬───────┘             └──────┬──────┘
       │                               │                            │
   ┌───┴────┐                ┌─────────┼──────────┐         ┌───────┴───────┐
   ▼        ▼                ▼         ▼          ▼         ▼               ▼
 Crawler   JS-AST       Reflected    DOM    Blind/mXSS   Headless        HTML /
 Param-    Sink         + Context    + AST   + Collab    Verifier        JSON /
 Miner     Graph        Classifier   Flow                (Playwright)    CVSS 4
 Subdomain
 Wayback                           ┌─────────────┐
                                   │   AI Core   │  ←  drives every stage
                                   ├─────────────┤
                                   │ • Context   │
                                   │   Classifier│ (Transformer)
                                   │ • Payload   │
                                   │   Generator │ (LLM + library)
                                   │ • WAF       │
                                   │   Fingerprint│(GBDT)
                                   │ • Evolution │ (Genetic + RL)
                                   │ • Triage    │ (Classifier)
                                   └─────────────┘
```

See [docs/architecture.md](docs/architecture.md) and [docs/ai_methodology.md](docs/ai_methodology.md).

---

## Quick start

```bash
# Install
git clone https://github.com/yourorg/arachnex && cd arachnex
pip install -e .
playwright install chromium

# Configure Anthropic API key for LLM payload generation (optional but recommended)
export ANTHROPIC_API_KEY=sk-ant-...

# Scan a single URL
arachnex scan -u "https://target.com/search?q=test"

# Bug bounty mode: crawl + scan a scope file
arachnex scan --scope scope.txt --mode bb --threads 25 --headless verify

# Blind XSS with self-hosted collaborator
arachnex blind --listen 0.0.0.0:8443 --domain xss.yourdomain.com

# DOM-only audit (static, no requests)
arachnex dom --input ./js-bundle.js
```

---

## Highlights

### 1. Context-classified payload generation

When a parameter reflects, ArachneX extracts a 200-char neighborhood around the reflection, runs it through a fine-tuned classifier (`xlm-roberta-base` head) that outputs one of **17 contexts** (HTML body, double-quoted attribute, single-quoted attribute, unquoted attribute, `<script>` string literal, `<script>` identifier, `<style>`, `href`/`src` URL, JSON-in-script, on-event handler, comment, CDATA, SVG, MathML, Trusted-Types-protected, mXSS-prone, untainted). Each context maps to a hand-curated **escape set** plus an **LLM generator** that produces 5–20 fresh payloads aware of preceding/following bytes.

### 2. Real browser verification

Every "hit" is replayed in headless Chromium via Playwright with **Chrome DevTools Protocol** hooks on `Runtime.consoleAPICalled`, `Runtime.exceptionThrown`, and an injected `window.__arx_exec_token`. We *only* report a finding when JS executes — eliminating the entire class of reflection-but-not-exploitable false positives that plague signature scanners.

### 3. Evolutionary WAF bypass

When a payload is blocked but the target seems vulnerable, ArachneX runs a **genetic algorithm** over a transformation grammar (case toggling, comment splitting, unicode substitution, encoding stacks, event renaming, splitting across params) with a **fitness function** combining: (a) similarity to a baseline allowed response, (b) reflection of mutated bytes, (c) absence of WAF block signatures. Converges in 20–60 generations on most current WAF configurations.

### 4. AST-driven DOM XSS

Parses each `.js` asset with `esprima`, builds a data-flow graph from **sources** (`location.*`, `document.URL`, `postMessage`, `window.name`, storage APIs, `fetch` responses) to **sinks** (`innerHTML`, `eval`, `Function`, `document.write`, `setTimeout(str)`, `setAttribute('on*', …)`, `srcdoc`, etc.). A graph-walk ranks paths by exploitability; an LLM produces the URL fragment / postMessage payload to trigger each.

### 5. Mutation XSS (mXSS) — first-class

We carry a 350-vector mXSS corpus (mathml, svg, foreign-content, template, noscript namespace confusions, named-character-reference variants) and a **differential parser** that compares the bytes sent vs the DOM after `innerHTML` round-trip. Finds sanitizer bypasses that no other scanner currently tests.

### 6. AI triage

A gradient-boosted classifier scores each finding (`reflection_strength`, `csp_present`, `trusted_types`, `sandbox`, `exec_observed`, `dom_mutation`, `context`, `waf_state`) and produces a confidence in [0, 1] and an exploitability tier. Findings below 0.4 get auto-suppressed; the rest land in the report ranked.

---

## What it is *not*

- Not a magic button. Modern XSS hunting still requires you to understand the app. ArachneX is a force multiplier, not a replacement for skill.
- Not a license-locked black box. Open source, MIT, run it on your own infra.
- Not a network scanner. It tests one class of bug well, instead of testing fifty classes poorly.

---

## Authorization & legal

ArachneX is offensive tooling. **Only use it against targets you own or have explicit written authorization to test.** Unauthorized scanning is illegal in most jurisdictions (Computer Fraud and Abuse Act, IT Act 2000 §43/§66, Computer Misuse Act, etc.). The maintainers accept no liability for misuse.

---

## Citation

If you reference ArachneX in academic work or a CTF/conference talk:

```bibtex
@misc{arachnex2026,
  title  = {ArachneX: AI-Native XSS Discovery, Detection, Exploitation and Reporting},
  author = {ArachneX Contributors},
  year   = {2026},
  note   = {Presented at Black Hat Asia / nullcon}
}
```

---

## License

MIT. See [LICENSE](LICENSE).
