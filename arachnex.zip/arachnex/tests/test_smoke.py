"""
Smoke tests.

These tests don't exercise any network or browser — they just import
every module and confirm core dataclasses round-trip through JSON.
Run with:

    pytest tests/ -q

The point is to catch dumb wiring bugs (a typo in a module path, a
stale type import) without needing the heavy dev dependencies.
"""

from __future__ import annotations

import json
from datetime import datetime, timezone


def test_imports():
    """Every public module must import cleanly."""
    import arachnex
    import arachnex.cli                          # noqa: F401
    import arachnex.core.config                  # noqa: F401
    import arachnex.core.engine                  # noqa: F401
    import arachnex.core.target                  # noqa: F401
    import arachnex.ai.evolution                 # noqa: F401
    import arachnex.ai.payload_generator         # noqa: F401
    import arachnex.ai.triage                    # noqa: F401
    import arachnex.ai.waf_fingerprint           # noqa: F401
    import arachnex.detection.blind              # noqa: F401
    import arachnex.detection.context            # noqa: F401
    import arachnex.detection.dom                # noqa: F401
    import arachnex.detection.mxss               # noqa: F401
    import arachnex.detection.reflected          # noqa: F401
    import arachnex.discovery.crawler            # noqa: F401
    import arachnex.discovery.param_miner        # noqa: F401
    import arachnex.exploitation.payloads        # noqa: F401
    import arachnex.reporting.cvss               # noqa: F401
    import arachnex.reporting.html_report        # noqa: F401
    import arachnex.reporting.json_report        # noqa: F401
    import arachnex.reporting.markdown_report    # noqa: F401
    import arachnex.utils.http                   # noqa: F401
    import arachnex.utils.logger                 # noqa: F401
    assert arachnex.__version__


def test_target_roundtrip():
    """Targets / Findings round-trip through JSON cleanly."""
    from arachnex.core.target import (
        Finding, HttpMethod, InjectionPoint, ScanSummary, Severity,
        Target, XSSClass,
    )

    t = Target(
        url="https://example.test/search",
        method=HttpMethod.GET,
        injection_points=[InjectionPoint(location="query", name="q",
                                         sample_value="hello")],
    )
    payload = json.loads(t.model_dump_json())
    assert payload["url"] == "https://example.test/search"

    f = Finding(
        xss_class=XSSClass.REFLECTED,
        severity=Severity.HIGH,
        confidence=0.91,
        target_url=t.url,
        method=t.method,
        injection_point=t.injection_points[0],
        payload="<svg/onload=alert(1)>",
        title="reflected XSS in q",
    )
    summary = ScanSummary(scope=[t.url])
    summary.findings.append(f)
    summary.ended_at = datetime.now(timezone.utc)
    summary.urls_discovered = 1
    summary.params_discovered = 1
    summary.requests_sent = 12
    data = summary.model_dump_json()
    again = ScanSummary.model_validate_json(data)
    assert again.findings[0].title == f.title


def test_context_classifier_basic():
    """Classifier returns ContextResult list with reasonable top guesses."""
    from arachnex.detection.context import ContextClassifier
    from arachnex.core.target import ReflectionContext

    clf = ContextClassifier(model_path=None)

    body = '<!doctype html><input type="text" value="CANARY">'
    results = clf.classify(body, "CANARY")
    assert results, "should find at least one reflection"
    assert results[0].context == ReflectionContext.ATTR_DOUBLE_QUOTED

    body = "<!doctype html><h1>Welcome CANARY</h1>"
    results = clf.classify(body, "CANARY")
    assert results
    assert results[0].context == ReflectionContext.HTML_BODY

    body = '<!doctype html><script>var x="CANARY";</script>'
    results = clf.classify(body, "CANARY")
    assert results
    assert results[0].context == ReflectionContext.SCRIPT_STRING_DQ


def test_triage_explains_itself():
    """Triager produces a numeric score and a human-readable rationale."""
    import hashlib
    from arachnex.ai.triage import Triager, extract_features
    from arachnex.core.target import (
        BrowserExecutionProof, Finding, HttpMethod, InjectionPoint,
        ReflectionContext, ReflectionEvidence, Severity, XSSClass,
    )

    triager = Triager()
    canary = "CANARY"
    snippet = "<h1>Hello, CANARY</h1>"
    f = Finding(
        xss_class=XSSClass.REFLECTED,
        severity=Severity.MEDIUM,
        confidence=0.5,
        target_url="https://example.test/q?x=1",
        method=HttpMethod.GET,
        injection_point=InjectionPoint(location="query", name="x"),
        payload="<svg/onload=alert(1)>",
        title="placeholder",
        reflection=ReflectionEvidence(
            canary=canary,
            snippet=snippet,
            offset=11,
            response_size=len(snippet),
            response_hash=hashlib.sha1(snippet.encode()).hexdigest(),
            classified_context=ReflectionContext.HTML_BODY,
        ),
        browser_proof=BrowserExecutionProof(exec_observed=True, exec_token="t"),
    )
    feats = extract_features(f, response_headers={}, waf_active=False,
                             auth_required=False)
    score = triager.score(f, feats)
    explanation = triager.explain(feats, score)
    assert 0.0 <= score <= 1.0
    assert isinstance(explanation, str) and explanation


def test_payload_library_loads():
    """Payload library finds and tags context files."""
    from pathlib import Path
    from arachnex.core.target import ReflectionContext
    from arachnex.exploitation.payloads import PayloadLibrary

    root = Path(__file__).resolve().parent.parent / "payloads"
    lib = PayloadLibrary(root)
    html_payloads = lib.for_context(ReflectionContext.HTML_BODY)
    assert html_payloads, "html_body payloads should load"
    assert any("svg" in p.value.lower() for p in html_payloads)
    assert all(p.marker for p in html_payloads)


def test_cvss_scoring():
    """CVSS populate sets a vector and elevates severity for executed findings."""
    from arachnex.core.target import (
        BrowserExecutionProof, Finding, HttpMethod, InjectionPoint,
        Severity, XSSClass,
    )
    from arachnex.reporting.cvss import populate

    f = Finding(
        xss_class=XSSClass.REFLECTED,
        severity=Severity.MEDIUM,
        confidence=0.7,
        target_url="https://example.test/",
        method=HttpMethod.GET,
        injection_point=InjectionPoint(location="query", name="q"),
        payload="<svg/onload=alert(1)>",
        title="t",
        browser_proof=BrowserExecutionProof(exec_observed=True, exec_token="t"),
    )
    populate(f, waf_active=False, auth_required=False)
    assert f.cvss40_vector and f.cvss40_vector.startswith("CVSS:4.0")
    assert f.cvss40_score > 0
